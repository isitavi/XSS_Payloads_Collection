    &lt;script&gt;let{location={href:&#39;http://evil.com/ &#39;}}=0;alert(location.href);&lt;/script&gt;
    
