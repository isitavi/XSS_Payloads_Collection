var link = document.createElement(&#39;a&#39;);
link.href = &#39;http://the.earth.li/~sgtatham/putty/latest/x86/putty.exe&#39;;
link.download = &#39;&#39;;
document.body.appendChild(link);
link.click();

